# azure-idp-tool

Azure Document Intelligence を活用した取引書類PDF転記SaaS(マルチテナント)のモノレポ。

## 構成

| ディレクトリ | 内容 |
|---|---|
| [docs/](docs/) | ブレインストーミング・設計・開発・デプロイ・運用のドキュメント |
| [frontend/](frontend/) | Vue 3 + Vuetify 3 + Pinia + Vite + TypeScript |
| [backend/](backend/) | Python 3.14 + FastAPI(APIサーバとワーカーを同一パッケージ・同一イメージで実装) |
| [infra/](infra/) | Bicep(IaC)。環境差分は `.bicepparam` で表現。社内検証環境は [infra/verify/](infra/verify/) |
| `.github/workflows/` | CI(パッケージ別に lint + ユニットテスト) |

要件・設計の詳細は [docs/01_design/README.md](docs/01_design/README.md) から辿れる。

## 開発環境

Windows 11 + WSL2(Ubuntu)+ VS Code Remote - WSL を前提とする。
セットアップ手順は [docs/02_development/dev-environment.md](docs/02_development/dev-environment.md) と
[docs/02_development/onboarding.md](docs/02_development/onboarding.md) を参照。

### クイックスタート(WSL内)

```bash
# 1. ローカル依存サービス起動(PostgreSQL / Azurite / Service Busエミュレータ)
docker compose up -d

# 2. バックエンド
cd backend
cp .env.example .env        # DI_ENDPOINT / DI_KEY は各自受領した値を設定
uv sync
uv run alembic upgrade head
uv run python scripts/seed.py
uv run uvicorn app.main:app --reload --port 8000

# 3. ワーカー(別ターミナル)
cd backend
uv run python -m app.worker.main

# 4. フロントエンド(別ターミナル)
cd frontend
cp .env.example .env
npm install
npm run dev                 # http://localhost:5173
```

> **初回セットアップ時の注意**: `uv.lock` / `package-lock.json` は初回の `uv sync` / `npm install` で
> 生成されたものをコミットすること(CIはlockfile前提で動く)。
> 依存パッケージのバージョン指定は暫定値のため、初回インストール時に最新安定版へ調整する。

## Azureへのデプロイ(社内検証)

上記クイックスタートと同等の動作確認をAzure上で行う手順は
[docs/03_deployment/verify-deployment-guide.md](docs/03_deployment/verify-deployment-guide.md)、
IaCは [infra/verify/](infra/verify/) を参照。CI/CDは使わず、Azure CLI + ポータル操作の手動デプロイで完結する。

## 運用

テナントの受け入れ・解約、資格情報のローテーションと失効の手順は
[docs/04_operations/](docs/04_operations/) を参照。

## 開発規約

[docs/02_development/coding-standards.md](docs/02_development/coding-standards.md) を参照。
ブランチモデルは GitHub Flow(`main` + `feature/xxx`)。
