# frontend

Vue 3 + Vuetify 3 + Pinia + Vite + TypeScript によるフロントエンド(SPA)。本番は Azure Static Web Apps へデプロイする想定。

## ディレクトリ構成

| パス | 内容 |
|---|---|
| `src/pages/` | 画面(メイン操作画面: MainPage / 書類詳細 / 共有ビュー / 管理者向け画面: AdminPage + タブ3枚) |
| `src/components/` | 共通コンポーネント(DocumentsModal / UploadPanel / PageViewer / StatusChip / UsageBarChart) |
| `src/stores/` | Pinia ストア(auth / documents / documentDetail / masters) |
| `src/api/` | APIクライアント(`http.ts` が共通fetchラッパー。`types/` に型定義) |
| `src/router/` | vue-router 設定 |
| `src/plugins/vuetify.ts` | Vuetify 設定 |
| `src/utils/overlay.ts` | 書類ページ画像への座標オーバーレイ計算 |
| `tests/` | ユニットテスト(Vitest) |

画面仕様は [docs/01_design/screen-design.md](../docs/01_design/screen-design.md) を参照。

## セットアップと起動(WSL内)

前提: バックエンドAPIが `localhost:8000` で起動していること(APIへは Vite の proxy 経由で相対パス `/api` でアクセスする)。

```bash
cp .env.example .env
npm install
npm run dev        # http://localhost:5173
```

## 開発コマンド

```bash
npm run dev         # 開発サーバ
npm run build       # 型チェック + 本番ビルド
npm run typecheck   # 型チェックのみ(vue-tsc)
npm run lint        # ESLint
npm run format      # Prettier(src/ を整形)
npm run test        # Vitest
```
