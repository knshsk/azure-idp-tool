import { describe, expect, it } from 'vitest'

import { fitPageScale, fitWidthScale, MAX_SCALE, MIN_SCALE, stepScale } from '@/utils/viewerZoom'

describe('fitPageScale', () => {
  it('縦横の制約が厳しい方の倍率を返す(幅制約)', () => {
    expect(fitPageScale(800, 600, 1600, 600)).toBe(0.5)
  })

  it('縦横の制約が厳しい方の倍率を返す(高さ制約)', () => {
    expect(fitPageScale(800, 400, 800, 1600)).toBe(0.25)
  })

  it('ページ寸法が不正な場合は等倍を返す', () => {
    expect(fitPageScale(800, 600, 0, 0)).toBe(1)
  })
})

describe('fitWidthScale', () => {
  it('ページ幅がコンテナ幅に一致する倍率を返す', () => {
    expect(fitWidthScale(620, 1240)).toBe(0.5)
  })

  it('ページ寸法が不正な場合は等倍を返す', () => {
    expect(fitWidthScale(620, 0)).toBe(1)
  })
})

describe('stepScale', () => {
  it('10%刻みで増減する', () => {
    expect(stepScale(0.5, 1)).toBe(0.6)
    expect(stepScale(0.5, -1)).toBe(0.4)
  })

  it('浮動小数の誤差を丸める', () => {
    expect(stepScale(0.2, 1)).toBe(0.3)
    expect(stepScale(0.35, 1)).toBe(0.45)
  })

  it('上限・下限でクランプする', () => {
    expect(stepScale(MAX_SCALE, 1)).toBe(MAX_SCALE)
    expect(stepScale(3.95, 1)).toBe(MAX_SCALE)
    expect(stepScale(MIN_SCALE, -1)).toBe(MIN_SCALE)
    expect(stepScale(0.12, -1)).toBe(MIN_SCALE)
  })
})
