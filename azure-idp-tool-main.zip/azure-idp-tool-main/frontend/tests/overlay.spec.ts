import { describe, expect, it } from 'vitest'

import { bboxToRect } from '@/utils/overlay'

describe('bboxToRect', () => {
  it('正規化bboxをページピクセル座標へ変換する', () => {
    const rect = bboxToRect({ x0: 0.1, y0: 0.2, x1: 0.5, y1: 0.4 }, 1000, 2000)
    expect(rect).toEqual({ x: 100, y: 400, width: 400, height: 400 })
  })

  it('幅・高さゼロのbboxも扱える', () => {
    const rect = bboxToRect({ x0: 0.5, y0: 0.5, x1: 0.5, y1: 0.5 }, 1240, 1755)
    expect(rect.width).toBe(0)
    expect(rect.height).toBe(0)
  })
})
