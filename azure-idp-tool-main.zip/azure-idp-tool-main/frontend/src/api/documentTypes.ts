import { requestJson, requestRaw } from './http'
import type { DocumentType, FieldUpsert, TranscriptionField } from './types'

export async function listDocumentTypes(): Promise<DocumentType[]> {
  return requestJson('/v1/document-types')
}

export async function listTranscriptionFields(
  documentTypeId: string,
): Promise<TranscriptionField[]> {
  return requestJson(`/v1/document-types/${documentTypeId}/fields`)
}

export async function createDocumentType(code: string, name: string): Promise<DocumentType> {
  return requestJson('/v1/document-types', {
    method: 'POST',
    body: JSON.stringify({ code, name }),
  })
}

export async function updateDocumentType(
  id: string,
  code: string,
  name: string,
): Promise<DocumentType> {
  return requestJson(`/v1/document-types/${id}`, {
    method: 'PUT',
    body: JSON.stringify({ code, name }),
  })
}

export async function deleteDocumentType(id: string): Promise<void> {
  await requestRaw(`/v1/document-types/${id}`, { method: 'DELETE' })
}

export async function updateTranscriptionFields(
  id: string,
  fields: FieldUpsert[],
): Promise<TranscriptionField[]> {
  return requestJson(`/v1/document-types/${id}/fields`, {
    method: 'PUT',
    body: JSON.stringify({ fields }),
  })
}
