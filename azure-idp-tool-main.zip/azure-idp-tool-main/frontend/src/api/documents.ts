import { requestJson, requestRaw } from './http'
import type {
  AnalysisOverlay,
  Document,
  ExtractedValue,
  LineItemTableResult,
  ValueUpdateItem,
} from './types'

export interface DocumentListParams {
  status?: string
  document_type_id?: string
  source?: string
  created_from?: string
  created_to?: string
  page?: number
  per_page?: number
}

export async function listDocuments(
  params: DocumentListParams = {},
): Promise<{ items: Document[]; total: number }> {
  const query = new URLSearchParams()
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') {
      query.set(key, String(value))
    }
  }
  const response = await requestRaw(`/v1/documents?${query.toString()}`)
  return {
    items: (await response.json()) as Document[],
    total: Number(response.headers.get('X-Total-Count') ?? 0),
  }
}

export async function getDocument(id: string): Promise<Document> {
  return requestJson(`/v1/documents/${id}`)
}

/** 戻り値のcreated=falseはハッシュ重複(既存ドキュメントを返却)【仮】 */
export async function uploadDocument(
  file: File,
  documentTypeId: string,
): Promise<{ document: Document; created: boolean }> {
  const form = new FormData()
  form.set('file', file)
  form.set('document_type_id', documentTypeId)
  const response = await requestRaw('/v1/documents', { method: 'POST', body: form })
  return { document: (await response.json()) as Document, created: response.status === 202 }
}

export async function deleteDocument(id: string): Promise<void> {
  await requestRaw(`/v1/documents/${id}`, { method: 'DELETE' })
}

export async function analyzeDocument(id: string): Promise<Document> {
  return requestJson(`/v1/documents/${id}/analyze`, { method: 'POST' })
}

export async function getAnalysis(id: string): Promise<AnalysisOverlay> {
  return requestJson(`/v1/documents/${id}/analysis`)
}

export async function getValues(id: string): Promise<ExtractedValue[]> {
  return requestJson(`/v1/documents/${id}/values`)
}

export async function updateValues(
  id: string,
  items: ValueUpdateItem[],
): Promise<ExtractedValue[]> {
  return requestJson(`/v1/documents/${id}/values`, {
    method: 'PUT',
    body: JSON.stringify({ values: items }),
  })
}

export async function selectLineItemTable(
  id: string,
  pageNo: number,
  tableIndex: number,
): Promise<LineItemTableResult> {
  return requestJson(`/v1/documents/${id}/line-item-table`, {
    method: 'PUT',
    body: JSON.stringify({ page_no: pageNo, table_index: tableIndex }),
  })
}

export async function confirmDocument(id: string): Promise<Document> {
  return requestJson(`/v1/documents/${id}/confirm`, { method: 'POST' })
}

/**
 * ページPNGを取得する。
 *
 * このエンドポイントは他のAPIと同じくJWTを要求するが、`<img src>` や
 * `<image href>` にURLを渡すとブラウザが直接GETするためAuthorizationヘッダが
 * 付かない(AUTH_MODE=keycloak では401になる)。Blobで受けてobject URLに
 * 変換して使う(composables/pageImage.ts)。
 *
 * 認証なしで開ける共有ビュー(api/share.ts)は素のURLのままでよい。
 */
export async function fetchPageImage(id: string, pageNo: number): Promise<Blob> {
  const response = await requestRaw(`/v1/documents/${id}/pages/${pageNo}/image`)
  return response.blob()
}
