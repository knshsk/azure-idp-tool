import { requestJson } from './http'
import type { Me, TenantSettings, UsageSummary } from './types'

export async function getMe(): Promise<Me> {
  return requestJson('/v1/me')
}

export async function getUsageSummary(month: string): Promise<UsageSummary> {
  return requestJson(`/v1/usage/summary?month=${encodeURIComponent(month)}`)
}

export async function getTenantSettings(): Promise<TenantSettings> {
  return requestJson('/v1/tenant/settings')
}

export async function updateTenantSettings(retentionDays: number): Promise<TenantSettings> {
  return requestJson('/v1/tenant/settings', {
    method: 'PUT',
    body: JSON.stringify({ retention_days: retentionDays }),
  })
}
