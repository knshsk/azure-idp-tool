import { apiUrl, requestJson } from './http'

export interface ShareMeta {
  file_name: string
  page_count: number | null
  expires_at: string
}

export async function getShareMeta(token: string): Promise<ShareMeta> {
  return requestJson(`/v1/share/${token}`)
}

export function sharePageImageUrl(token: string, pageNo: number): string {
  return apiUrl(`/v1/share/${token}/pages/${pageNo}/image`)
}

export function shareDownloadUrl(token: string): string {
  return apiUrl(`/v1/share/${token}/download`)
}
