/**
 * APIクライアントの共通fetchラッパ。
 * 規約: コンポーネントから直接fetchせず、src/api の型付きクライアント関数を経由する。
 */

import { getAccessToken } from '@/auth/keycloak'

const baseUrl: string = import.meta.env.VITE_API_BASE_URL ?? '/api'

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

async function toApiError(response: Response): Promise<ApiError> {
  try {
    const body = (await response.json()) as { error: { code: string; message: string } }
    return new ApiError(response.status, body.error.code, body.error.message)
  } catch {
    return new ApiError(response.status, 'unknown_error', `HTTP ${response.status}`)
  }
}

/** 生のResponseが必要な場合(レスポンスヘッダ参照・multipart送信など)に使う */
export async function requestRaw(path: string, init?: RequestInit): Promise<Response> {
  // AUTH_MODE=local のときは null が返り、Authorizationヘッダを付けない
  const token = await getAccessToken()
  const headers = token
    ? { ...init?.headers, Authorization: `Bearer ${token}` }
    : init?.headers

  const response = await fetch(`${baseUrl}${path}`, { ...init, headers })
  if (!response.ok) {
    throw await toApiError(response)
  }
  return response
}

export async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await requestRaw(path, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
  })
  return (await response.json()) as T
}

/** 画像など、URLを直接<img>等に渡す場合のURL組み立て */
export function apiUrl(path: string): string {
  return `${baseUrl}${path}`
}
