/**
 * APIレスポンス型(バックエンドのPydanticスキーマと対応)。
 * 規約: APIレスポンス型はここに集約する【仮: OpenAPIからの自動生成を検討】
 */

export type DocumentStatus = 'uploaded' | 'analyzing' | 'analyzed' | 'confirmed' | 'failed'
export type DocumentSource = 'frontend' | 'batch'

export interface Document {
  id: string
  document_type_id: string
  status: DocumentStatus
  file_name: string
  file_hash: string
  page_count: number | null
  line_item_table: LineItemTable | null
  source: DocumentSource
  uploaded_by: string | null
  error_message: string | null
  created_at: string
  analyzed_at: string | null
  confirmed_at: string | null
}

export interface DocumentType {
  id: string
  code: string
  name: string
  created_at: string
}

export interface TranscriptionField {
  id: string
  document_type_id: string
  json_key: string
  label_ja: string
  value_type: 'string' | 'number' | 'date'
  query_field_key: string | null
  sort_order: number
}

/** 正規化座標(0〜1)の矩形 */
export interface Bbox {
  x0: number
  y0: number
  x1: number
  y1: number
}

export interface ExtractedValue {
  id: string
  transcription_field_id: string | null
  row_no: number | null
  column_no: number | null
  page_no: number | null
  bbox: Bbox | null
  value_raw: string
  value_normalized: string | null
  normalization_failed: boolean
  manually_edited: boolean
  updated_at: string
}

export interface PageMeta {
  page_no: number
  width_px: number
  height_px: number
}

export interface OverlayWord {
  content: string
  bbox: Bbox
}

export interface OverlayPage {
  page_no: number
  words: OverlayWord[]
  lines: OverlayWord[]
}

export interface OverlayTableCell {
  row: number
  column: number
  kind: string
  content: string
  page_no: number | null
  bbox: Bbox | null
}

export interface OverlayTable {
  table_index: number
  page_no: number | null
  row_count: number
  column_count: number
  bbox: Bbox | null
  cells: OverlayTableCell[]
}

export interface QueryFieldEntry {
  value_raw: string
  page_no: number | null
  bbox: Bbox | null
}

export interface AnalysisOverlay {
  pages: PageMeta[] | null
  layout: {
    pages: OverlayPage[]
    tables: OverlayTable[]
  }
  query_fields: Record<string, QueryFieldEntry> | null
}

export interface LineItemColumn {
  column_no: number
  header_text: string
}

export interface LineItemTable {
  page_no: number
  table_index: number
  columns: LineItemColumn[]
}

export interface LineItemTableResult {
  line_item_table: LineItemTable
  values: ExtractedValue[]
}

/** PUT /documents/{id}/values のリクエスト要素(ヘッダ or 明細セルの排他指定) */
export interface ValueUpdateItem {
  transcription_field_id?: string
  row_no?: number
  column_no?: number
  value_raw: string
}

export interface TenantSettings {
  name: string
  retention_days: number
}

export interface UsageDay {
  date: string
  di_calls: number
  di_pages: number
}

export interface UsageSummary {
  month: string
  di_calls: number
  di_pages: number
  /** APIMメトリクス未連携の間はnull */
  api_requests: number | null
  days: UsageDay[]
}

/** PUT /document-types/{id}/fields の要素(idなし=新規、リスト外の既存=削除) */
export interface FieldUpsert {
  id?: string
  json_key: string
  label_ja: string
  value_type: 'string' | 'number' | 'date'
  query_field_key: string | null
  sort_order: number
}
