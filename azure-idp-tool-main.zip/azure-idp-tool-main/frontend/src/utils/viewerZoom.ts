/** ページビューアのズーム倍率計算(1.0 = ページ画像の原寸) */

export const ZOOM_STEP = 0.1
export const MIN_SCALE = 0.1
export const MAX_SCALE = 4

/** 全体/幅フィットはページ切替・リサイズ後も再適用し、手動ズームは倍率を維持する */
export type FitMode = 'page' | 'width' | 'manual'

export function clampScale(scale: number): number {
  return Math.min(MAX_SCALE, Math.max(MIN_SCALE, scale))
}

/** ページ全体がコンテナに収まる倍率(縦横の制約が厳しい方) */
export function fitPageScale(
  containerWidth: number,
  containerHeight: number,
  pageWidth: number,
  pageHeight: number,
): number {
  if (pageWidth <= 0 || pageHeight <= 0) {
    return 1
  }
  return Math.min(containerWidth / pageWidth, containerHeight / pageHeight)
}

/** ページ幅がコンテナ幅に一致する倍率 */
export function fitWidthScale(containerWidth: number, pageWidth: number): number {
  if (pageWidth <= 0) {
    return 1
  }
  return containerWidth / pageWidth
}

/** 10%刻みでズームイン/アウトした倍率を返す(浮動小数の誤差は丸める) */
export function stepScale(scale: number, direction: 1 | -1): number {
  return clampScale(Math.round((scale + direction * ZOOM_STEP) * 100) / 100)
}
