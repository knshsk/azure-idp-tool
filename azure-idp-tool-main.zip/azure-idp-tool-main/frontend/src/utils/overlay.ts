import type { Bbox } from '@/api/types'

export interface OverlayRect {
  x: number
  y: number
  width: number
  height: number
}

/** 正規化bbox(0〜1)をページピクセル座標の矩形へ変換する(SVGオーバレイ描画用) */
export function bboxToRect(bbox: Bbox, widthPx: number, heightPx: number): OverlayRect {
  return {
    x: bbox.x0 * widthPx,
    y: bbox.y0 * heightPx,
    width: (bbox.x1 - bbox.x0) * widthPx,
    height: (bbox.y1 - bbox.y0) * heightPx,
  }
}
