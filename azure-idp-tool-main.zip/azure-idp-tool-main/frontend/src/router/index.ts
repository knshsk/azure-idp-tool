import { createRouter, createWebHistory } from 'vue-router'

// TODO: /login(Entra External ID対応時にMSALリダイレクトを実装)
const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      // メイン操作画面(ドキュメント未選択): 一覧・アップロードのモーダルを自動表示
      path: '/',
      name: 'home',
      component: () => import('@/pages/MainPage.vue'),
    },
    {
      // メイン操作画面(詳細表示): モーダルは表示しない
      path: '/documents/:id',
      name: 'document-detail',
      component: () => import('@/pages/DocumentDetailPage.vue'),
    },
    // 管理者向け画面(tenant_adminのみ。ロール制御はメニュー表示とAPI側403で担保)
    {
      path: '/admin',
      component: () => import('@/pages/AdminPage.vue'),
      children: [
        { path: '', redirect: '/admin/document-types' },
        {
          path: 'document-types',
          name: 'admin-document-types',
          component: () => import('@/pages/AdminDocumentTypesPage.vue'),
        },
        {
          path: 'usage',
          name: 'admin-usage',
          component: () => import('@/pages/AdminUsagePage.vue'),
        },
        {
          path: 'tenant',
          name: 'admin-tenant',
          component: () => import('@/pages/AdminTenantPage.vue'),
        },
      ],
    },
    {
      // 共有ビュー(認証なし・共通レイアウト外)
      path: '/share/:token',
      name: 'share-view',
      component: () => import('@/pages/ShareViewPage.vue'),
      meta: { plain: true },
    },
  ],
})

export default router
