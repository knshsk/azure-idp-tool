import { createRouter, createWebHistory } from 'vue-router'

import { isAuthenticated, isKeycloakMode } from '@/auth/keycloak'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      // ログイン(認証不要・共通レイアウト外)
      path: '/login',
      name: 'login',
      component: () => import('@/pages/LoginPage.vue'),
      meta: { plain: true, public: true },
    },
    {
      // メイン操作画面(ドキュメント未選択): 一覧・アップロードのモーダルを自動表示
      path: '/',
      name: 'home',
      component: () => import('@/pages/MainPage.vue'),
    },
    {
      // メイン操作画面(詳細表示): モーダルは表示しない
      path: '/documents/:id',
      name: 'document-detail',
      component: () => import('@/pages/DocumentDetailPage.vue'),
    },
    // 管理者向け画面(tenant_adminのみ。ロール制御はメニュー表示とAPI側403で担保)
    {
      path: '/admin',
      component: () => import('@/pages/AdminPage.vue'),
      children: [
        { path: '', redirect: '/admin/document-types' },
        {
          path: 'document-types',
          name: 'admin-document-types',
          component: () => import('@/pages/AdminDocumentTypesPage.vue'),
        },
        {
          path: 'usage',
          name: 'admin-usage',
          component: () => import('@/pages/AdminUsagePage.vue'),
        },
        {
          path: 'tenant',
          name: 'admin-tenant',
          component: () => import('@/pages/AdminTenantPage.vue'),
        },
      ],
    },
    {
      // 共有ビュー(認証なし・共通レイアウト外)
      path: '/share/:token',
      name: 'share-view',
      component: () => import('@/pages/ShareViewPage.vue'),
      meta: { plain: true, public: true },
    },
  ],
})

// 認証ガード。meta.public のルート(ログイン・共有ビュー)だけが未認証で開ける。
// AUTH_MODE=local では isAuthenticated() が常に true を返すため素通りする。
router.beforeEach((to) => {
  if (to.meta.public === true) {
    // 認証済みでログイン画面に来た場合はメイン画面へ戻す(screen-design.md 1)
    if (to.name === 'login' && isKeycloakMode() && isAuthenticated()) {
      return { path: '/' }
    }
    return true
  }
  if (!isAuthenticated()) {
    return { path: '/login' }
  }
  return true
})

export default router
