<script setup lang="ts">
import { computed, ref } from 'vue'

import { uploadDocument } from '@/api/documents'
import { ApiError } from '@/api/http'
import type { Document, DocumentType } from '@/api/types'

export interface UploadResult {
  fileName: string
  document?: Document
  created?: boolean
  error?: string
}

const props = defineProps<{ documentTypes: DocumentType[] }>()
const emit = defineEmits<{ done: [results: UploadResult[]] }>()

const documentTypeId = ref<string | null>(null)
const files = ref<File[]>([])
const uploading = ref(false)
const currentFileName = ref('')

const canUpload = computed(
  () => documentTypeId.value !== null && files.value.length > 0 && !uploading.value,
)

async function upload(): Promise<void> {
  if (documentTypeId.value === null) {
    return
  }
  uploading.value = true
  const results: UploadResult[] = []
  try {
    for (const file of files.value) {
      currentFileName.value = file.name
      try {
        const result = await uploadDocument(file, documentTypeId.value)
        results.push({ fileName: file.name, ...result })
      } catch (error) {
        results.push({
          fileName: file.name,
          error: error instanceof ApiError ? error.message : 'アップロードに失敗しました',
        })
      }
    }
  } finally {
    uploading.value = false
    currentFileName.value = ''
  }
  files.value = []
  emit('done', results)
}
</script>

<template>
  <div>
    <v-select
      v-model="documentTypeId"
      :items="props.documentTypes"
      item-title="name"
      item-value="id"
      label="書類種別(必須)"
      density="comfortable"
    />
    <v-file-input
      v-model="files"
      label="PDFファイル(複数選択可)"
      accept="application/pdf"
      multiple
      chips
      show-size
      density="comfortable"
    />
    <v-progress-linear v-if="uploading" indeterminate class="mt-2" />
    <div v-if="uploading" class="text-caption mt-1">アップロード中: {{ currentFileName }}</div>
    <div class="d-flex justify-end mt-2">
      <v-btn color="primary" variant="flat" :disabled="!canUpload" @click="upload">
        アップロード
      </v-btn>
    </div>
  </div>
</template>
