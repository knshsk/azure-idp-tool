<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'

import type { Bbox } from '@/api/types'
import { bboxToRect } from '@/utils/overlay'
import { fitPageScale, fitWidthScale, stepScale, type FitMode } from '@/utils/viewerZoom'

export interface ViewerRect {
  id: string
  bbox: Bbox
  kind: 'field' | 'word' | 'table' | 'cell'
  selected?: boolean
  clickable?: boolean
}

const props = withDefaults(
  defineProps<{
    imageUrl: string
    pageCount: number
    /** ページ画像のピクセル寸法。未指定時は画像の自然サイズを使う(共有ビュー用) */
    widthPx?: number
    heightPx?: number
    rects?: ViewerRect[]
    /** オーバレイ表示切替ボタンを表示するか(共有ビューでは非表示) */
    overlayToggle?: boolean
    height?: string
  }>(),
  {
    widthPx: undefined,
    heightPx: undefined,
    rects: () => [],
    overlayToggle: false,
    height: '70vh',
  },
)

const page = defineModel<number>('page', { required: true })
const overlay = defineModel<boolean>('overlay', { default: false })

const emit = defineEmits<{ rectClick: [id: string] }>()

// ---- ページ寸法(props優先、なければ画像の自然サイズ) ----

const naturalSize = ref<{ width: number; height: number } | null>(null)

watch(
  () => props.imageUrl,
  (url) => {
    if (props.widthPx !== undefined && props.heightPx !== undefined) {
      return
    }
    naturalSize.value = null
    const img = new Image()
    img.onload = () => {
      if (props.imageUrl === url) {
        naturalSize.value = { width: img.naturalWidth, height: img.naturalHeight }
      }
    }
    img.src = url
  },
  { immediate: true },
)

const pageW = computed(() => props.widthPx ?? naturalSize.value?.width ?? 0)
const pageH = computed(() => props.heightPx ?? naturalSize.value?.height ?? 0)

const shapes = computed(() =>
  props.rects.map((r) => ({ ...r, rect: bboxToRect(r.bbox, pageW.value, pageH.value) })),
)

// ---- ズーム(初期表示はページ全体) ----

const containerEl = ref<HTMLDivElement>()
const fitMode = ref<FitMode>('page')
const scale = ref(1)

const displayW = computed(() => pageW.value * scale.value)
const displayH = computed(() => pageH.value * scale.value)

function computeFitScale(): number | null {
  const el = containerEl.value
  if (!el || pageW.value <= 0) {
    return null
  }
  if (fitMode.value === 'page') {
    return fitPageScale(el.clientWidth, el.clientHeight, pageW.value, pageH.value)
  }
  if (fitMode.value === 'width') {
    return fitWidthScale(el.clientWidth, pageW.value)
  }
  return null
}

/** スクロールバーの出現・消滅でクライアント寸法が変わるため、2パスで自己補正する */
async function applyFit(): Promise<void> {
  const first = computeFitScale()
  if (first === null) {
    return
  }
  scale.value = first
  await nextTick()
  const second = computeFitScale()
  if (second !== null) {
    scale.value = second
  }
}

function setFit(mode: 'page' | 'width'): void {
  fitMode.value = mode
  void applyFit()
}

/** アンカー位置(クライアント座標。省略時はコンテナ中央)を保ったままズームする */
async function zoomBy(direction: 1 | -1, anchor?: { x: number; y: number }): Promise<void> {
  const el = containerEl.value
  if (!el || pageW.value <= 0) {
    return
  }
  const oldScale = scale.value
  const newScale = stepScale(oldScale, direction)
  if (newScale === oldScale) {
    return
  }
  const bounds = el.getBoundingClientRect()
  const ax = anchor ? anchor.x - bounds.left : el.clientWidth / 2
  const ay = anchor ? anchor.y - bounds.top : el.clientHeight / 2
  // コンテナより小さい間は中央寄せされるため、その余白を差し引いて画像座標へ変換する
  const offsetX = Math.max(0, (el.clientWidth - pageW.value * oldScale) / 2)
  const offsetY = Math.max(0, (el.clientHeight - pageH.value * oldScale) / 2)
  const imageX = (el.scrollLeft + ax - offsetX) / oldScale
  const imageY = (el.scrollTop + ay - offsetY) / oldScale
  fitMode.value = 'manual'
  scale.value = newScale
  await nextTick()
  const newOffsetX = Math.max(0, (el.clientWidth - pageW.value * newScale) / 2)
  const newOffsetY = Math.max(0, (el.clientHeight - pageH.value * newScale) / 2)
  el.scrollLeft = imageX * newScale + newOffsetX - ax
  el.scrollTop = imageY * newScale + newOffsetY - ay
}

function onWheel(event: WheelEvent): void {
  if (!event.ctrlKey) {
    return
  }
  event.preventDefault()
  void zoomBy(event.deltaY < 0 ? 1 : -1, { x: event.clientX, y: event.clientY })
}

let resizeObserver: ResizeObserver | undefined

onMounted(() => {
  void applyFit()
  if (containerEl.value) {
    resizeObserver = new ResizeObserver(() => {
      if (fitMode.value !== 'manual') {
        void applyFit()
      }
    })
    resizeObserver.observe(containerEl.value)
  }
})

onBeforeUnmount(() => {
  resizeObserver?.disconnect()
})

watch([pageW, pageH], () => {
  if (fitMode.value !== 'manual') {
    void applyFit()
  }
})

// ---- ドラッグでパン(矩形クリックと共存させるため、動いたときだけclickを抑止) ----

interface PanState {
  pointerId: number
  startX: number
  startY: number
  scrollLeft: number
  scrollTop: number
  moved: boolean
}

let panState: PanState | null = null
let suppressClick = false
const panning = ref(false)

function onPointerDown(event: PointerEvent): void {
  const el = containerEl.value
  if (!el || event.button !== 0) {
    return
  }
  const bounds = el.getBoundingClientRect()
  // スクロールバー上での押下はネイティブ操作に任せる
  if (event.clientX - bounds.left >= el.clientWidth || event.clientY - bounds.top >= el.clientHeight) {
    return
  }
  panState = {
    pointerId: event.pointerId,
    startX: event.clientX,
    startY: event.clientY,
    scrollLeft: el.scrollLeft,
    scrollTop: el.scrollTop,
    moved: false,
  }
  el.setPointerCapture(event.pointerId)
}

function onPointerMove(event: PointerEvent): void {
  const el = containerEl.value
  if (!el || panState === null || event.pointerId !== panState.pointerId) {
    return
  }
  const dx = event.clientX - panState.startX
  const dy = event.clientY - panState.startY
  if (!panState.moved && Math.abs(dx) + Math.abs(dy) > 4) {
    panState.moved = true
    panning.value = true
  }
  if (panState.moved) {
    el.scrollLeft = panState.scrollLeft - dx
    el.scrollTop = panState.scrollTop - dy
  }
}

function onPointerUp(event: PointerEvent): void {
  if (panState === null || event.pointerId !== panState.pointerId) {
    return
  }
  suppressClick = panState.moved
  panState = null
  panning.value = false
}

function onClickCapture(event: MouseEvent): void {
  if (suppressClick) {
    event.stopPropagation()
    event.preventDefault()
    suppressClick = false
  }
}
</script>

<template>
  <div class="viewer-root">
    <div
      ref="containerEl"
      class="viewer-container"
      :class="{ panning }"
      :style="{ height: props.height }"
      @wheel="onWheel"
      @pointerdown="onPointerDown"
      @pointermove="onPointerMove"
      @pointerup="onPointerUp"
      @pointercancel="onPointerUp"
      @click.capture="onClickCapture"
    >
      <svg
        v-if="pageW > 0"
        class="page-svg"
        :viewBox="`0 0 ${pageW} ${pageH}`"
        :width="displayW"
        :height="displayH"
      >
        <image :href="props.imageUrl" x="0" y="0" :width="pageW" :height="pageH" />
        <rect
          v-for="shape in shapes"
          :key="shape.id"
          :x="shape.rect.x"
          :y="shape.rect.y"
          :width="shape.rect.width"
          :height="shape.rect.height"
          :class="[
            'overlay-rect',
            `kind-${shape.kind}`,
            { selected: shape.selected, clickable: shape.clickable },
          ]"
          @click="shape.clickable && emit('rectClick', shape.id)"
        />
      </svg>
    </div>

    <!-- ビューア操作バー: アイコンのみ+ツールチップ(screen-design.md 2-2) -->
    <div class="d-flex align-center justify-center flex-wrap ga-1 mt-2">
      <v-btn
        v-tooltip:top="'前のページ'"
        icon="mdi-chevron-left"
        size="small"
        variant="text"
        :disabled="page <= 1"
        @click="page -= 1"
      />
      <span class="text-body-2">{{ page }} / {{ props.pageCount }}</span>
      <v-btn
        v-tooltip:top="'次のページ'"
        icon="mdi-chevron-right"
        size="small"
        variant="text"
        :disabled="page >= props.pageCount"
        @click="page += 1"
      />
      <v-divider vertical class="mx-1 align-self-center" length="24" />
      <v-btn
        v-tooltip:top="'縮小'"
        icon="mdi-magnify-minus-outline"
        size="small"
        variant="text"
        @click="zoomBy(-1)"
      />
      <v-btn
        v-tooltip:top="'拡大'"
        icon="mdi-magnify-plus-outline"
        size="small"
        variant="text"
        @click="zoomBy(1)"
      />
      <v-btn
        v-tooltip:top="'ページ全体を表示'"
        icon="mdi-fit-to-page-outline"
        size="small"
        variant="text"
        :active="fitMode === 'page'"
        @click="setFit('page')"
      />
      <v-btn
        v-tooltip:top="'幅に合わせる'"
        icon="mdi-arrow-expand-horizontal"
        size="small"
        variant="text"
        :active="fitMode === 'width'"
        @click="setFit('width')"
      />
      <template v-if="props.overlayToggle">
        <v-divider vertical class="mx-1 align-self-center" length="24" />
        <v-btn
          v-tooltip:top="'オーバレイ表示切替'"
          :icon="overlay ? 'mdi-eye' : 'mdi-eye-off'"
          size="small"
          variant="text"
          :active="overlay"
          @click="overlay = !overlay"
        />
      </template>
    </div>
  </div>
</template>

<style scoped>
.viewer-root {
  width: 100%;
}

.viewer-container {
  display: flex;
  overflow: auto;
  border: 1px solid rgba(0, 0, 0, 0.12);
  background: rgba(0, 0, 0, 0.04);
  cursor: grab;
  user-select: none;
}

.viewer-container.panning {
  cursor: grabbing;
}

.page-svg {
  margin: auto;
  flex: none;
  display: block;
  background: #fff;
}

.overlay-rect {
  fill: transparent;
}

.kind-field {
  stroke: #1976d2;
  stroke-width: 3;
}

.kind-word {
  stroke: rgba(0, 0, 0, 0.3);
  stroke-width: 1;
}

.kind-table {
  stroke: #7b1fa2;
  stroke-width: 3;
  stroke-dasharray: 8 4;
}

.kind-cell {
  stroke: rgba(123, 31, 162, 0.4);
  stroke-width: 1;
}

.selected {
  fill: rgba(25, 118, 210, 0.15);
  stroke-width: 4;
}

.kind-table.selected {
  fill: rgba(123, 31, 162, 0.08);
  stroke-dasharray: none;
}

.clickable {
  cursor: pointer;
}
</style>
