<script setup lang="ts">
import { computed, ref } from 'vue'

import type { UsageDay } from '@/api/types'

const props = defineProps<{
  month: string // YYYY-MM
  days: UsageDay[]
}>()

const WIDTH = 720
const HEIGHT = 180
const PADDING = { top: 12, right: 8, bottom: 24, left: 40 }
const BAR_RADIUS = 4
const BAR_GAP = 2

interface Bar {
  day: number
  date: string
  diPages: number
  diCalls: number
  x: number
  y: number
  width: number
  height: number
}

const daysInMonth = computed(() => {
  const [year, month] = props.month.split('-').map(Number)
  return new Date(year, month, 0).getDate()
})

const maxValue = computed(() => {
  const max = Math.max(0, ...props.days.map((d) => d.di_pages))
  if (max === 0) {
    return 10
  }
  // 上端を切りの良い値へ丸める
  const unit = 10 ** Math.floor(Math.log10(max))
  return Math.ceil(max / unit) * unit
})

const plotWidth = WIDTH - PADDING.left - PADDING.right
const plotHeight = HEIGHT - PADDING.top - PADDING.bottom

const bars = computed<Bar[]>(() => {
  const byDay = new Map(props.days.map((d) => [Number(d.date.slice(8, 10)), d]))
  const slot = plotWidth / daysInMonth.value
  const barWidth = Math.max(2, slot - BAR_GAP)
  return Array.from({ length: daysInMonth.value }, (_, i) => {
    const day = i + 1
    const entry = byDay.get(day)
    const diPages = entry?.di_pages ?? 0
    const height = (diPages / maxValue.value) * plotHeight
    return {
      day,
      date: `${props.month}-${String(day).padStart(2, '0')}`,
      diPages,
      diCalls: entry?.di_calls ?? 0,
      x: PADDING.left + i * slot + BAR_GAP / 2,
      y: PADDING.top + plotHeight - height,
      width: barWidth,
      height,
    }
  })
})

/** 上端のみ角丸のバーのSVGパス(データ端の角丸4px。ベースライン側は直角) */
function barPath(bar: Bar): string {
  if (bar.height <= 0) {
    return ''
  }
  const r = Math.min(BAR_RADIUS, bar.width / 2, bar.height)
  const { x, y, width, height } = bar
  return [
    `M ${x} ${y + height}`,
    `V ${y + r}`,
    `Q ${x} ${y} ${x + r} ${y}`,
    `H ${x + width - r}`,
    `Q ${x + width} ${y} ${x + width} ${y + r}`,
    `V ${y + height}`,
    'Z',
  ].join(' ')
}

const gridValues = computed(() => [maxValue.value / 2, maxValue.value])

function gridY(value: number): number {
  return PADDING.top + plotHeight - (value / maxValue.value) * plotHeight
}

const xLabels = computed(() =>
  [1, 5, 10, 15, 20, 25, daysInMonth.value].filter(
    (d, i, arr) => arr.indexOf(d) === i && d <= daysInMonth.value,
  ),
)

const hovered = ref<Bar | null>(null)
</script>

<template>
  <div class="chart-wrapper">
    <div class="chart-title text-caption text-medium-emphasis">DIページ数 / 日</div>
    <svg :viewBox="`0 0 ${WIDTH} ${HEIGHT}`" class="chart" role="img" aria-label="日次のDIページ数">
      <!-- グリッド(控えめ)と目盛ラベル -->
      <g v-for="value in gridValues" :key="value">
        <line
          :x1="PADDING.left"
          :x2="WIDTH - PADDING.right"
          :y1="gridY(value)"
          :y2="gridY(value)"
          class="grid-line"
        />
        <text :x="PADDING.left - 6" :y="gridY(value) + 4" class="axis-label" text-anchor="end">
          {{ value }}
        </text>
      </g>
      <!-- ベースライン -->
      <line
        :x1="PADDING.left"
        :x2="WIDTH - PADDING.right"
        :y1="PADDING.top + plotHeight"
        :y2="PADDING.top + plotHeight"
        class="baseline"
      />
      <!-- バー(ホバー対象は当たり判定を広げた透明rect) -->
      <g v-for="bar in bars" :key="bar.day">
        <path v-if="bar.height > 0" :d="barPath(bar)" class="bar" :class="{ hover: hovered?.day === bar.day }" />
        <rect
          :x="bar.x - BAR_GAP / 2"
          :y="PADDING.top"
          :width="bar.width + BAR_GAP"
          :height="plotHeight"
          fill="transparent"
          @mouseenter="hovered = bar"
          @mouseleave="hovered = null"
        />
      </g>
      <!-- x軸ラベル(日) -->
      <text
        v-for="day in xLabels"
        :key="day"
        :x="PADDING.left + (day - 0.5) * (plotWidth / daysInMonth)"
        :y="HEIGHT - 8"
        class="axis-label"
        text-anchor="middle"
      >
        {{ day }}
      </text>
    </svg>
    <div class="tooltip text-caption" :class="{ visible: hovered }">
      <template v-if="hovered">
        {{ hovered.date }}: DIコール {{ hovered.diCalls }} 件 / {{ hovered.diPages }} ページ
      </template>
      <template v-else>&nbsp;</template>
    </div>
  </div>
</template>

<style scoped>
.chart-wrapper {
  width: 100%;
  max-width: 760px;
}

.chart {
  width: 100%;
  height: auto;
  display: block;
}

.bar {
  fill: #1976d2;
}

.bar.hover {
  fill: #0d47a1;
}

.grid-line {
  stroke: rgba(0, 0, 0, 0.08);
  stroke-width: 1;
}

.baseline {
  stroke: rgba(0, 0, 0, 0.24);
  stroke-width: 1;
}

.axis-label {
  font-size: 10px;
  fill: rgba(0, 0, 0, 0.55);
}

.tooltip {
  min-height: 20px;
  color: rgba(0, 0, 0, 0.75);
}

.tooltip.visible {
  font-weight: 500;
}
</style>
