<script setup lang="ts">
import { onMounted, onUnmounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'

import type { Document } from '@/api/types'
import StatusChip from '@/components/StatusChip.vue'
import UploadPanel, { type UploadResult } from '@/components/UploadPanel.vue'
import { useDocumentsStore } from '@/stores/documents'
import { useMastersStore } from '@/stores/masters'

const router = useRouter()
const documents = useDocumentsStore()
const masters = useMastersStore()

// ドキュメント未選択の間は閉じられない(persistent・閉じるボタンなし)
const tab = ref<'list' | 'upload'>('list')
const snackbar = ref({ open: false, text: '', color: 'success' })

const statusOptions = [
  { title: '解析待ち', value: 'uploaded' },
  { title: '解析中', value: 'analyzing' },
  { title: '解析済', value: 'analyzed' },
  { title: '確定済', value: 'confirmed' },
  { title: '失敗', value: 'failed' },
]
const sourceOptions = [
  { title: '画面', value: 'frontend' },
  { title: 'バッチ', value: 'batch' },
]

onMounted(async () => {
  await masters.loadDocumentTypes()
  await documents.load()
  documents.startPolling()
})
onUnmounted(() => documents.stopPolling())

watch(
  () => documents.page,
  () => void documents.load(),
)

function openDetail(doc: Document): void {
  void router.push(`/documents/${doc.id}`)
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('ja-JP', { dateStyle: 'short', timeStyle: 'short' })
}

function onUploadDone(results: UploadResult[]): void {
  const failed = results.filter((r) => r.error)
  const duplicated = results.filter((r) => r.created === false)
  if (failed.length > 0) {
    snackbar.value = {
      open: true,
      color: 'error',
      text: failed.map((r) => `${r.fileName}: ${r.error}`).join(' / '),
    }
  } else if (duplicated.length > 0) {
    snackbar.value = {
      open: true,
      color: 'warning',
      text: `既存ドキュメントがあります: ${duplicated.map((r) => r.fileName).join(', ')}`,
    }
  } else {
    snackbar.value = { open: true, color: 'success', text: `${results.length}件を受け付けました` }
  }
  tab.value = 'list'
  void documents.load()
}
</script>

<template>
  <v-dialog :model-value="true" persistent no-click-animation max-width="1100" scrollable>
    <v-card min-height="70vh">
      <v-tabs v-model="tab" color="primary">
        <v-tab value="list" prepend-icon="mdi-file-document-multiple-outline">
          ドキュメント一覧
        </v-tab>
        <v-tab value="upload" prepend-icon="mdi-upload">アップロード</v-tab>
      </v-tabs>
      <v-divider />
      <v-card-text>
        <v-tabs-window v-model="tab">
          <v-tabs-window-item value="list">
            <v-row dense align="center" class="mb-2">
              <v-col cols="6" sm="2">
                <v-select
                  v-model="documents.filters.status"
                  :items="statusOptions"
                  label="状態"
                  density="compact"
                  clearable
                  hide-details
                />
              </v-col>
              <v-col cols="6" sm="2">
                <v-select
                  v-model="documents.filters.document_type_id"
                  :items="masters.documentTypes"
                  item-title="name"
                  item-value="id"
                  label="書類種別"
                  density="compact"
                  clearable
                  hide-details
                />
              </v-col>
              <v-col cols="6" sm="2">
                <v-select
                  v-model="documents.filters.source"
                  :items="sourceOptions"
                  label="取込元"
                  density="compact"
                  clearable
                  hide-details
                />
              </v-col>
              <v-col cols="6" sm="2">
                <v-text-field
                  v-model="documents.filters.created_from"
                  type="date"
                  label="From"
                  density="compact"
                  hide-details
                />
              </v-col>
              <v-col cols="6" sm="2">
                <v-text-field
                  v-model="documents.filters.created_to"
                  type="date"
                  label="To"
                  density="compact"
                  hide-details
                />
              </v-col>
              <v-col cols="6" sm="2">
                <v-btn prepend-icon="mdi-magnify" variant="tonal" @click="documents.search()">
                  検索
                </v-btn>
              </v-col>
            </v-row>

            <v-table hover>
              <thead>
                <tr>
                  <th>ファイル名</th>
                  <th>種別</th>
                  <th>状態</th>
                  <th>取込元</th>
                  <th>日時</th>
                </tr>
              </thead>
              <tbody>
                <tr
                  v-for="doc in documents.items"
                  :key="doc.id"
                  class="document-row"
                  @click="openDetail(doc)"
                >
                  <td>{{ doc.file_name }}</td>
                  <td>{{ masters.typeName(doc.document_type_id) }}</td>
                  <td><StatusChip :status="doc.status" :error-message="doc.error_message" /></td>
                  <td>{{ doc.source === 'frontend' ? '画面' : 'batch' }}</td>
                  <td>{{ formatDate(doc.created_at) }}</td>
                </tr>
                <tr v-if="!documents.loading && documents.items.length === 0">
                  <td colspan="5" class="text-center text-medium-emphasis py-8">
                    ドキュメントがありません
                  </td>
                </tr>
              </tbody>
            </v-table>
            <v-progress-linear v-if="documents.loading" indeterminate />
            <div class="d-flex justify-center py-2">
              <v-pagination
                v-model="documents.page"
                :length="documents.pageCount"
                density="comfortable"
              />
            </div>
          </v-tabs-window-item>

          <v-tabs-window-item value="upload">
            <UploadPanel :document-types="masters.documentTypes" @done="onUploadDone" />
          </v-tabs-window-item>
        </v-tabs-window>
      </v-card-text>
    </v-card>
    <v-snackbar v-model="snackbar.open" :color="snackbar.color" timeout="6000">
      {{ snackbar.text }}
    </v-snackbar>
  </v-dialog>
</template>

<style scoped>
.document-row {
  cursor: pointer;
}
</style>
