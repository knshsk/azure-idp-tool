<script setup lang="ts">
import { computed } from 'vue'

import type { DocumentStatus } from '@/api/types'

const props = defineProps<{
  status: DocumentStatus
  errorMessage?: string | null
}>()

const appearance = computed(() => {
  switch (props.status) {
    case 'uploaded':
      return { label: '解析待ち', color: 'grey', icon: 'mdi-clock-outline' }
    case 'analyzing':
      return { label: '解析中', color: 'blue', icon: 'mdi-loading mdi-spin' }
    case 'analyzed':
      return { label: '解析済', color: 'green', icon: 'mdi-check' }
    case 'confirmed':
      return { label: '確定済', color: 'teal', icon: 'mdi-check-decagram' }
    case 'failed':
      return { label: '失敗', color: 'error', icon: 'mdi-alert' }
    default:
      return { label: props.status, color: 'grey', icon: 'mdi-help' }
  }
})
</script>

<template>
  <v-chip :color="appearance.color" size="small" variant="tonal" :prepend-icon="appearance.icon">
    {{ appearance.label }}
    <v-tooltip v-if="status === 'failed' && errorMessage" activator="parent" location="bottom">
      {{ errorMessage }}
    </v-tooltip>
  </v-chip>
</template>
