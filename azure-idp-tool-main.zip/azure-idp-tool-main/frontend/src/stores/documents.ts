import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

import { listDocuments } from '@/api/documents'
import type { Document } from '@/api/types'

const PER_PAGE = 20
const POLLING_INTERVAL_MS = 5000

/** ドキュメント一覧(フィルタ・ページネーション・解析中のポーリング) */
export const useDocumentsStore = defineStore('documents', () => {
  const items = ref<Document[]>([])
  const total = ref(0)
  const page = ref(1)
  const loading = ref(false)

  const filters = ref({
    status: '' as string,
    document_type_id: '' as string,
    source: '' as string,
    created_from: '' as string,
    created_to: '' as string,
  })

  const pageCount = computed(() => Math.max(1, Math.ceil(total.value / PER_PAGE)))
  const hasActiveDocuments = computed(() =>
    items.value.some((d) => d.status === 'uploaded' || d.status === 'analyzing'),
  )

  async function load(options: { silent?: boolean } = {}): Promise<void> {
    if (!options.silent) {
      loading.value = true
    }
    try {
      const result = await listDocuments({
        ...filters.value,
        // 期間フィルタのToは終端を含める(日付のみ入力のため終日扱い)
        created_to: filters.value.created_to ? `${filters.value.created_to}T23:59:59` : '',
        page: page.value,
        per_page: PER_PAGE,
      })
      items.value = result.items
      total.value = result.total
    } finally {
      loading.value = false
    }
  }

  async function search(): Promise<void> {
    page.value = 1
    await load()
  }

  // 解析中の行がある間のみ自動更新(screen-design.md)
  let timer: ReturnType<typeof setInterval> | undefined

  function startPolling(): void {
    stopPolling()
    timer = setInterval(() => {
      if (hasActiveDocuments.value && !loading.value) {
        void load({ silent: true })
      }
    }, POLLING_INTERVAL_MS)
  }

  function stopPolling(): void {
    if (timer !== undefined) {
      clearInterval(timer)
      timer = undefined
    }
  }

  return {
    items,
    total,
    page,
    loading,
    filters,
    pageCount,
    hasActiveDocuments,
    load,
    search,
    startPolling,
    stopPolling,
  }
})
