import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

import {
  analyzeDocument,
  confirmDocument,
  getAnalysis,
  getDocument,
  getValues,
  selectLineItemTable,
  updateValues,
} from '@/api/documents'
import type {
  AnalysisOverlay,
  Document,
  ExtractedValue,
  TranscriptionField,
  ValueUpdateItem,
} from '@/api/types'
import { useMastersStore } from '@/stores/masters'

export interface CellRow {
  rowNo: number
  pageNo: number | null
  cells: Map<number, ExtractedValue>
}

/** 転記確定画面の状態(解析結果オーバレイ・転記値・編集バッファ) */
export const useDocumentDetailStore = defineStore('documentDetail', () => {
  const document = ref<Document | null>(null)
  const fields = ref<TranscriptionField[]>([])
  const analysis = ref<AnalysisOverlay | null>(null)
  const values = ref<ExtractedValue[]>([])
  const loading = ref(false)
  const saving = ref(false)

  // 未保存の編集(ヘッダ: fieldId→値 / 明細セル: "row:col"→値)
  const editedHeaders = ref<Record<string, string>>({})
  const editedCells = ref<Record<string, string>>({})

  const isEditable = computed(() => document.value?.status === 'analyzed')
  const dirty = computed(
    () =>
      Object.keys(editedHeaders.value).length > 0 || Object.keys(editedCells.value).length > 0,
  )

  const headerValueByField = computed(() => {
    const map = new Map<string, ExtractedValue>()
    for (const value of values.value) {
      if (value.transcription_field_id !== null) {
        map.set(value.transcription_field_id, value)
      }
    }
    return map
  })

  const cellRows = computed<CellRow[]>(() => {
    const rows = new Map<number, CellRow>()
    for (const value of values.value) {
      if (value.row_no === null || value.column_no === null) {
        continue
      }
      let row = rows.get(value.row_no)
      if (!row) {
        row = { rowNo: value.row_no, pageNo: value.page_no, cells: new Map() }
        rows.set(value.row_no, row)
      }
      row.cells.set(value.column_no, value)
    }
    return [...rows.values()].sort((a, b) => a.rowNo - b.rowNo)
  })

  async function load(documentId: string): Promise<void> {
    loading.value = true
    try {
      document.value = await getDocument(documentId)
      editedHeaders.value = {}
      editedCells.value = {}
      analysis.value = null
      values.value = []
      fields.value = await useMastersStore().loadFields(document.value.document_type_id)
      if (document.value.status === 'analyzed' || document.value.status === 'confirmed') {
        ;[analysis.value, values.value] = await Promise.all([
          getAnalysis(documentId),
          getValues(documentId),
        ])
      }
    } finally {
      loading.value = false
    }
  }

  /** ポーリング用の軽量な状態更新。解析完了を検知したら全体を読み直す */
  async function refreshStatus(): Promise<void> {
    if (!document.value) {
      return
    }
    const latest = await getDocument(document.value.id)
    if (latest.status !== document.value.status) {
      await load(latest.id)
    }
  }

  function editHeader(fieldId: string, raw: string): void {
    const original = headerValueByField.value.get(fieldId)?.value_raw ?? ''
    if (raw === original) {
      delete editedHeaders.value[fieldId]
    } else {
      editedHeaders.value[fieldId] = raw
    }
  }

  function editCell(rowNo: number, columnNo: number, raw: string): void {
    const key = `${rowNo}:${columnNo}`
    const original = values.value.find(
      (v) => v.row_no === rowNo && v.column_no === columnNo,
    )?.value_raw
    if (raw === original) {
      delete editedCells.value[key]
    } else {
      editedCells.value[key] = raw
    }
  }

  async function save(): Promise<void> {
    if (!document.value || !dirty.value) {
      return
    }
    const items: ValueUpdateItem[] = [
      ...Object.entries(editedHeaders.value).map(([fieldId, raw]) => ({
        transcription_field_id: fieldId,
        value_raw: raw,
      })),
      ...Object.entries(editedCells.value).map(([key, raw]) => {
        const [rowNo, columnNo] = key.split(':')
        return { row_no: Number(rowNo), column_no: Number(columnNo), value_raw: raw }
      }),
    ]
    saving.value = true
    try {
      values.value = await updateValues(document.value.id, items)
      editedHeaders.value = {}
      editedCells.value = {}
    } finally {
      saving.value = false
    }
  }

  async function selectTable(pageNo: number, tableIndex: number): Promise<void> {
    if (!document.value) {
      return
    }
    saving.value = true
    try {
      const result = await selectLineItemTable(document.value.id, pageNo, tableIndex)
      document.value.line_item_table = result.line_item_table
      // 明細セルを入れ替え(ヘッダ項目は保持)
      values.value = [...values.value.filter((v) => v.row_no === null), ...result.values]
      editedCells.value = {}
    } finally {
      saving.value = false
    }
  }

  async function confirm(): Promise<void> {
    if (!document.value) {
      return
    }
    await save()
    document.value = await confirmDocument(document.value.id)
  }

  async function requestAnalyze(): Promise<void> {
    if (!document.value) {
      return
    }
    await analyzeDocument(document.value.id)
    document.value = { ...document.value, status: 'uploaded', error_message: null }
  }

  return {
    document,
    fields,
    analysis,
    values,
    loading,
    saving,
    editedHeaders,
    editedCells,
    isEditable,
    dirty,
    headerValueByField,
    cellRows,
    load,
    refreshStatus,
    editHeader,
    editCell,
    save,
    selectTable,
    confirm,
    requestAnalyze,
  }
})
