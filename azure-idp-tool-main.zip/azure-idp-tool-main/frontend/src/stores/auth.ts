import { defineStore } from 'pinia'
import { ref } from 'vue'

import { getMe } from '@/api/admin'
import { isKeycloakMode, logout as keycloakLogout } from '@/auth/keycloak'

/**
 * 認証状態。
 *
 * ロールは**JWTのクレームではなく `users` テーブル**で解決する(data-model.md)。
 * そのため表示名・ロールはログイン後に `GET /me` から取得する。
 * `AUTH_MODE=local` ではバックエンドがダミーユーザを返すので同じ経路で動く。
 */
export const useAuthStore = defineStore('auth', () => {
  const displayName = ref('')
  const role = ref<'tenant_admin' | 'member'>('member')
  const tenantName = ref('')
  const loaded = ref(false)

  /** アプリ表示前に一度だけ呼ぶ。未登録ユーザの場合はAPIが403を返す */
  async function load(): Promise<void> {
    if (loaded.value) return
    const me = await getMe()
    displayName.value = me.display_name
    role.value = me.role
    tenantName.value = me.tenant_name
    loaded.value = true
  }

  async function signOut(): Promise<void> {
    loaded.value = false
    if (isKeycloakMode()) {
      await keycloakLogout()
    }
  }

  return { displayName, role, tenantName, loaded, load, signOut }
})
