import { defineStore } from 'pinia'
import { ref } from 'vue'

/**
 * 認証状態。ローカル開発(AUTH_MODE=local)ではバックエンドがダミー認証のため固定値。
 * TODO: Entra External ID対応時にMSAL.jsのトークン・ユーザ情報・ロールを保持する
 */
export const useAuthStore = defineStore('auth', () => {
  const displayName = ref('開発ユーザ')
  const role = ref<'tenant_admin' | 'member'>('tenant_admin')
  return { displayName, role }
})
