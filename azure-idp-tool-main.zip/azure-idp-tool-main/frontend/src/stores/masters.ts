import { defineStore } from 'pinia'
import { ref } from 'vue'

import { listDocumentTypes, listTranscriptionFields } from '@/api/documentTypes'
import type { DocumentType, TranscriptionField } from '@/api/types'

/** 書類種別・転記項目定義のキャッシュ */
export const useMastersStore = defineStore('masters', () => {
  const documentTypes = ref<DocumentType[]>([])
  const fieldsByType = ref<Record<string, TranscriptionField[]>>({})

  async function loadDocumentTypes(): Promise<void> {
    if (documentTypes.value.length === 0) {
      documentTypes.value = await listDocumentTypes()
    }
  }

  async function loadFields(documentTypeId: string): Promise<TranscriptionField[]> {
    if (!fieldsByType.value[documentTypeId]) {
      fieldsByType.value[documentTypeId] = await listTranscriptionFields(documentTypeId)
    }
    return fieldsByType.value[documentTypeId]
  }

  function typeName(documentTypeId: string): string {
    return documentTypes.value.find((t) => t.id === documentTypeId)?.name ?? ''
  }

  /** 管理画面での変更後にキャッシュを破棄する */
  async function invalidate(): Promise<void> {
    documentTypes.value = []
    fieldsByType.value = {}
    await loadDocumentTypes()
  }

  return { documentTypes, fieldsByType, loadDocumentTypes, loadFields, typeName, invalidate }
})
