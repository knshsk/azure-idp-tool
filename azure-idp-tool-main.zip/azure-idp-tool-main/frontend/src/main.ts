import { createPinia } from 'pinia'
import { createApp } from 'vue'

import App from './App.vue'
import { initAuth } from './auth/keycloak'
import vuetify from './plugins/vuetify'
import router from './router'

// Keycloakの初期化(check-sso)はルータガードより先に済ませる必要があるため、
// マウント前に待つ。AUTH_MODE=local では何もしないので即座に解決する。
initAuth()
  .then(() => {
    createApp(App).use(createPinia()).use(router).use(vuetify).mount('#app')
  })
  .catch((error) => {
    // 認証基盤に到達できない場合、白画面のままだと原因が分からないので表示する
    console.error('認証の初期化に失敗しました', error)
    const root = document.getElementById('app')
    if (root) {
      root.textContent = '認証の初期化に失敗しました。時間をおいて再読み込みしてください。'
    }
  })
