/**
 * Keycloak連携(Authorization Code + PKCE)。
 *
 * `VITE_AUTH_MODE=local` のときは何もしない。バックエンドの `AUTH_MODE=local` と
 * 対になっていて、ローカル開発ではKeycloakを立てずに済むようにするため。
 *
 * 規約: コンポーネントからKeycloakインスタンスを直接触らず、このモジュールと
 * `stores/auth` を経由する。
 */

import Keycloak from 'keycloak-js'

export type AuthMode = 'local' | 'keycloak'

export const authMode: AuthMode =
  (import.meta.env.VITE_AUTH_MODE as AuthMode | undefined) ?? 'local'

let keycloak: Keycloak | null = null

/** アクセストークンの残り有効期間がこれを下回っていたら更新する(秒) */
const TOKEN_MIN_VALIDITY_SECONDS = 30

export function isKeycloakMode(): boolean {
  return authMode === 'keycloak'
}

/**
 * アプリ起動時に一度だけ呼ぶ。
 *
 * `check-sso` を使うのは、共有ビュー(`/share/:token`)が未認証で開ける必要が
 * あるため。ログインの強制はルータガードが保護対象のルートだけに対して行う。
 */
export async function initAuth(): Promise<void> {
  if (!isKeycloakMode()) return

  const issuer = import.meta.env.VITE_OIDC_ISSUER
  const clientId = import.meta.env.VITE_OIDC_CLIENT_ID
  if (!issuer || !clientId) {
    throw new Error('VITE_OIDC_ISSUER と VITE_OIDC_CLIENT_ID を設定してください')
  }

  // issuer は <url>/realms/<realm> の形。keycloak-js は url と realm を別々に要求する
  const match = /^(.*)\/realms\/([^/]+)\/?$/.exec(issuer)
  if (!match) {
    throw new Error(`VITE_OIDC_ISSUER の形式が不正です(例: https://host/realms/idp): ${issuer}`)
  }
  const [, url, realm] = match

  keycloak = new Keycloak({ url, realm, clientId })
  await keycloak.init({
    onLoad: 'check-sso',
    pkceMethod: 'S256',
    // 認可コードをURLに残さない(履歴・Referer経由の漏洩を避ける)
    responseMode: 'query',
    checkLoginIframe: false,
  })
}

export function isAuthenticated(): boolean {
  if (!isKeycloakMode()) return true
  return keycloak?.authenticated === true
}

/** Keycloakのログイン画面へリダイレクトする(戻り先を指定できる) */
export async function login(redirectPath?: string): Promise<void> {
  if (!isKeycloakMode()) return
  const redirectUri = redirectPath
    ? new URL(redirectPath, window.location.origin).toString()
    : window.location.origin
  await keycloak?.login({ redirectUri })
}

export async function logout(): Promise<void> {
  if (!isKeycloakMode()) return
  await keycloak?.logout({ redirectUri: window.location.origin })
}

/**
 * APIへ付けるアクセストークンを返す。期限が近ければ更新する。
 *
 * **未認証のときは null を返すだけでログインへ飛ばさない。** 共有ビュー
 * (`/share/:token`)は未認証で開ける必要があり、ここでリダイレクトすると
 * 受領者がログインを求められてしまうため。保護された経路への未認証アクセスは
 * ルータガードが `/login` へ誘導する。
 */
export async function getAccessToken(): Promise<string | null> {
  if (!isKeycloakMode() || !keycloak?.authenticated) return null
  try {
    await keycloak.updateToken(TOKEN_MIN_VALIDITY_SECONDS)
  } catch {
    // リフレッシュトークンも失効している。ここは認証済みだった経路なので
    // セッションを作り直しに行ってよい
    await login()
    return null
  }
  return keycloak.token ?? null
}

/** JWTの `sub`。usersテーブルの `idp_subject` に対応する(照合・デバッグ用) */
export function subject(): string | null {
  return keycloak?.subject ?? null
}
