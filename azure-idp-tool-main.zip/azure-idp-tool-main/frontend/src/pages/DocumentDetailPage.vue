<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import { pageImageUrl } from '@/api/documents'
import { ApiError } from '@/api/http'
import PageViewer, { type ViewerRect } from '@/components/PageViewer.vue'
import StatusChip from '@/components/StatusChip.vue'
import { useDocumentDetailStore } from '@/stores/documentDetail'
import { useMastersStore } from '@/stores/masters'

const route = useRoute()
const router = useRouter()
const store = useDocumentDetailStore()
const masters = useMastersStore()

const documentId = route.params.id as string
const tab = ref<'header' | 'lineItems'>('header')
const currentPage = ref(1)
const showWords = ref(false)
const selectedFieldId = ref<string | null>(null)
const confirmDialog = ref(false)
const snackbar = ref({ open: false, text: '', color: 'success' })

const POLLING_INTERVAL_MS = 4000
let timer: ReturnType<typeof setInterval> | undefined

onMounted(async () => {
  await masters.loadDocumentTypes()
  await store.load(documentId)
  timer = setInterval(() => {
    const status = store.document?.status
    if (status === 'uploaded' || status === 'analyzing') {
      void store.refreshStatus()
    }
  }, POLLING_INTERVAL_MS)
})
onUnmounted(() => {
  if (timer !== undefined) {
    clearInterval(timer)
  }
})

const isAnalyzing = computed(
  () => store.document?.status === 'uploaded' || store.document?.status === 'analyzing',
)
const pages = computed(() => store.analysis?.pages ?? [])
const pageMeta = computed(() => pages.value.find((p) => p.page_no === currentPage.value))

const overlayRects = computed<ViewerRect[]>(() => {
  const rects: ViewerRect[] = []
  if (!store.analysis) {
    return rects
  }
  if (showWords.value) {
    const layoutPage = store.analysis.layout.pages.find((p) => p.page_no === currentPage.value)
    for (const [index, word] of (layoutPage?.words ?? []).entries()) {
      rects.push({ id: `word:${index}`, bbox: word.bbox, kind: 'word' })
    }
  }
  if (tab.value === 'header') {
    for (const field of store.fields) {
      const value = store.headerValueByField.get(field.id)
      if (value?.bbox && value.page_no === currentPage.value) {
        rects.push({
          id: `field:${field.id}`,
          bbox: value.bbox,
          kind: 'field',
          selected: selectedFieldId.value === field.id,
          clickable: true,
        })
      }
    }
  } else {
    for (const table of store.analysis.layout.tables) {
      if (table.bbox && table.page_no === currentPage.value) {
        rects.push({
          id: `table:${table.table_index}`,
          bbox: table.bbox,
          kind: 'table',
          selected: store.document?.line_item_table?.table_index === table.table_index,
          clickable: store.isEditable,
        })
      }
    }
    for (const value of store.values) {
      if (value.row_no !== null && value.bbox && value.page_no === currentPage.value) {
        rects.push({ id: `cell:${value.row_no}:${value.column_no}`, bbox: value.bbox, kind: 'cell' })
      }
    }
  }
  return rects
})

function onRectClick(id: string): void {
  const [kind, key] = id.split(':')
  if (kind === 'field') {
    selectedFieldId.value = key
  } else if (kind === 'table') {
    void runAction(() => store.selectTable(currentPage.value, Number(key)), '明細領域を取り込みました')
  }
}

function selectField(fieldId: string): void {
  selectedFieldId.value = fieldId
  const pageNo = store.headerValueByField.get(fieldId)?.page_no
  if (pageNo !== null && pageNo !== undefined) {
    currentPage.value = pageNo
  }
}

const tableOptions = computed(() =>
  (store.analysis?.layout.tables ?? []).map((table) => ({
    title: `テーブル${table.table_index + 1}(${table.row_count}行×${table.column_count}列 / p.${table.page_no})`,
    value: table.table_index,
  })),
)

const selectedTableIndex = computed({
  get: () => store.document?.line_item_table?.table_index ?? null,
  set: (tableIndex: number | null) => {
    if (tableIndex === null) {
      return
    }
    const table = store.analysis?.layout.tables.find((t) => t.table_index === tableIndex)
    if (table?.page_no != null) {
      currentPage.value = table.page_no
      void runAction(() => store.selectTable(table.page_no!, tableIndex), '明細領域を取り込みました')
    }
  },
})

async function runAction(action: () => Promise<void>, successText: string): Promise<void> {
  try {
    await action()
    snackbar.value = { open: true, color: 'success', text: successText }
  } catch (error) {
    snackbar.value = {
      open: true,
      color: 'error',
      text: error instanceof ApiError ? error.message : '操作に失敗しました',
    }
  }
}

async function onConfirm(): Promise<void> {
  confirmDialog.value = false
  await runAction(() => store.confirm(), '転記項目を確定しました')
}
</script>

<template>
  <v-container fluid>
    <div class="d-flex align-center ga-3 mb-3 flex-wrap">
      <v-btn variant="text" prepend-icon="mdi-arrow-left" @click="router.push('/')">
        一覧へ
      </v-btn>
      <template v-if="store.document">
        <span class="text-h6">{{ store.document.file_name }}</span>
        <v-chip size="small" variant="outlined">
          {{ masters.typeName(store.document.document_type_id) }}
        </v-chip>
        <StatusChip
          :status="store.document.status"
          :error-message="store.document.error_message"
        />
        <v-spacer />
        <template v-if="store.isEditable">
          <v-btn
            variant="tonal"
            :disabled="!store.dirty || store.saving"
            :loading="store.saving"
            @click="runAction(() => store.save(), '変更を保存しました')"
          >
            変更を保存
          </v-btn>
          <v-btn color="primary" variant="flat" :disabled="store.saving" @click="confirmDialog = true">
            確定
          </v-btn>
        </template>
      </template>
    </div>

    <v-progress-linear v-if="store.loading" indeterminate class="mb-4" />

    <!-- 解析待ち・解析中: ポーリング表示 -->
    <v-card v-if="isAnalyzing" class="pa-12 text-center">
      <v-progress-circular indeterminate size="48" class="mb-4" />
      <div class="text-h6">解析中です…</div>
      <div class="text-medium-emphasis">完了すると自動で表示されます</div>
    </v-card>

    <!-- 失敗: エラー表示+再解析 -->
    <v-alert
      v-else-if="store.document?.status === 'failed'"
      type="error"
      :text="store.document.error_message ?? '解析に失敗しました'"
    >
      <template #append>
        <v-btn
          variant="outlined"
          @click="runAction(() => store.requestAnalyze(), '解析を再実行します')"
        >
          再解析
        </v-btn>
      </template>
    </v-alert>

    <!-- 解析済み・確定済み: オーバレイ+転記項目パネル -->
    <v-row v-else-if="store.document && store.analysis">
      <v-col cols="12" md="7">
        <PageViewer
          v-if="pageMeta"
          v-model:page="currentPage"
          v-model:overlay="showWords"
          :page-count="pages.length"
          overlay-toggle
          :image-url="pageImageUrl(documentId, currentPage)"
          :width-px="pageMeta.width_px"
          :height-px="pageMeta.height_px"
          :rects="overlayRects"
          @rect-click="onRectClick"
        />
      </v-col>

      <v-col cols="12" md="5">
        <v-card>
          <v-tabs v-model="tab" color="primary">
            <v-tab value="header">ヘッダ</v-tab>
            <v-tab value="lineItems">明細</v-tab>
          </v-tabs>
          <v-card-text>
            <!-- ヘッダタブ -->
            <div v-if="tab === 'header'">
              <div
                v-for="field in store.fields"
                :key="field.id"
                class="field-row d-flex align-center ga-2 mb-2"
                :class="{ 'field-row--selected': selectedFieldId === field.id }"
                @click="selectField(field.id)"
              >
                <span class="field-label">{{ field.label_ja }}</span>
                <v-text-field
                  :model-value="
                    store.editedHeaders[field.id] ??
                    store.headerValueByField.get(field.id)?.value_raw ??
                    ''
                  "
                  density="compact"
                  hide-details
                  :readonly="!store.isEditable"
                  @update:model-value="store.editHeader(field.id, $event)"
                  @focus="selectField(field.id)"
                />
                <v-icon
                  v-if="field.id in store.editedHeaders"
                  icon="mdi-pencil-circle-outline"
                  color="orange"
                  title="未保存の変更"
                />
                <v-icon
                  v-else-if="store.headerValueByField.get(field.id)?.manually_edited"
                  icon="mdi-pencil-circle"
                  color="blue"
                  title="手動修正済"
                />
                <v-icon
                  v-else-if="store.headerValueByField.get(field.id)?.normalization_failed"
                  icon="mdi-alert-circle"
                  color="warning"
                  title="正規化失敗"
                />
                <v-icon v-else icon="mdi-circle-small" color="transparent" />
              </div>
              <div class="text-caption text-medium-emphasis mt-2">
                項目クリックで抽出元の矩形をハイライトします
              </div>
            </div>

            <!-- 明細タブ -->
            <div v-else>
              <v-select
                v-model="selectedTableIndex"
                :items="tableOptions"
                label="明細領域(DI検出テーブルから選択)"
                density="compact"
                :readonly="!store.isEditable"
                :hint="store.isEditable ? '再選択すると明細セルは取り込み直されます' : ''"
                persistent-hint
              />
              <v-table v-if="store.document.line_item_table" density="compact" class="mt-3">
                <thead>
                  <tr>
                    <th v-for="column in store.document.line_item_table.columns" :key="column.column_no">
                      {{ column.header_text || `列${column.column_no + 1}` }}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="row in store.cellRows" :key="row.rowNo">
                    <td
                      v-for="column in store.document.line_item_table.columns"
                      :key="column.column_no"
                      class="cell-td"
                    >
                      <v-text-field
                        :model-value="
                          store.editedCells[`${row.rowNo}:${column.column_no}`] ??
                          row.cells.get(column.column_no)?.value_raw ??
                          ''
                        "
                        density="compact"
                        variant="plain"
                        hide-details
                        :readonly="!store.isEditable"
                        @update:model-value="store.editCell(row.rowNo, column.column_no, $event)"
                      />
                    </td>
                  </tr>
                </tbody>
              </v-table>
              <div v-else class="text-medium-emphasis mt-4">
                明細領域が未選択です。左のページ上の破線枠、または上のセレクトから選択してください。
              </div>
              <div class="text-caption text-medium-emphasis mt-2">
                ※列⇔転記項目の対応付けは行いません(列の意味づけは業務システム側)
              </div>
            </div>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>

    <v-dialog v-model="confirmDialog" max-width="420">
      <v-card title="転記項目の確定">
        <v-card-text>
          確定すると転記値は変更できなくなります。よろしいですか?
          <span v-if="store.dirty">(未保存の変更は確定時に保存されます)</span>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn @click="confirmDialog = false">キャンセル</v-btn>
          <v-btn color="primary" variant="flat" @click="onConfirm">確定する</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar.open" :color="snackbar.color" timeout="4000">
      {{ snackbar.text }}
    </v-snackbar>
  </v-container>
</template>

<style scoped>
.field-row {
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 4px;
}

.field-row--selected {
  background: rgba(25, 118, 210, 0.08);
}

.field-label {
  min-width: 88px;
  font-weight: 500;
}

.cell-td {
  min-width: 90px;
}
</style>
