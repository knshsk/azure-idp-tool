<script setup lang="ts">
import { ref } from 'vue'

import { login } from '@/auth/keycloak'

/**
 * ログイン画面(screen-design.md 1)。
 * 自前のID/パスワードフォームは持たず、Keycloakのログイン画面へ委譲する。
 * ローカルアカウントか顧客IdPかの選択はKeycloak側が提供する。
 */
const redirecting = ref(false)

async function signIn() {
  redirecting.value = true
  try {
    await login('/')
  } finally {
    // login() はリダイレクトするため通常ここへは戻らない
    redirecting.value = false
  }
}
</script>

<template>
  <v-container class="fill-height" fluid>
    <v-row justify="center" align="center">
      <v-col cols="12" sm="8" md="5" lg="4">
        <div class="text-center mb-8">
          <div class="text-h5 mb-2">取引書類読み取りツール</div>
          <div class="text-body-2 text-medium-emphasis">続けるにはログインしてください</div>
        </div>
        <v-btn
          block
          color="primary"
          size="large"
          :loading="redirecting"
          @click="signIn"
        >
          ログイン
        </v-btn>
      </v-col>
    </v-row>
  </v-container>
</template>
