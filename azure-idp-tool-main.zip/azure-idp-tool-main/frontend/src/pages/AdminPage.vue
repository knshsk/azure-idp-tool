<script setup lang="ts">
const tabs = [
  { to: '/admin/document-types', label: '書類種別・転記項目定義' },
  { to: '/admin/usage', label: '利用状況' },
  { to: '/admin/tenant', label: 'テナント設定' },
]
</script>

<template>
  <div>
    <v-tabs color="primary" class="px-4 pt-2">
      <v-tab v-for="t in tabs" :key="t.to" :to="t.to">{{ t.label }}</v-tab>
    </v-tabs>
    <v-divider />
    <router-view />
  </div>
</template>
