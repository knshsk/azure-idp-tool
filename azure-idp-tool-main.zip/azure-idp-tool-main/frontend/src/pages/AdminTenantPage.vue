<script setup lang="ts">
import { onMounted, ref } from 'vue'

import { getTenantSettings, updateTenantSettings } from '@/api/admin'
import { ApiError } from '@/api/http'
import type { TenantSettings } from '@/api/types'

const settings = ref<TenantSettings | null>(null)
const retentionDays = ref(90)
const saving = ref(false)
const snackbar = ref({ open: false, text: '', color: 'success' })

// APIM経由の公開エンドポイントが決まるまでローカルAPIのURLを表示
const batchEndpoint = `${window.location.origin}/api/v1/batch`

onMounted(async () => {
  settings.value = await getTenantSettings()
  retentionDays.value = settings.value.retention_days
})

async function save(): Promise<void> {
  saving.value = true
  try {
    settings.value = await updateTenantSettings(retentionDays.value)
    snackbar.value = { open: true, color: 'success', text: '保存しました' }
  } catch (error) {
    snackbar.value = {
      open: true,
      color: 'error',
      text: error instanceof ApiError ? error.message : '保存に失敗しました',
    }
  } finally {
    saving.value = false
  }
}

async function copyEndpoint(): Promise<void> {
  await navigator.clipboard.writeText(batchEndpoint)
  snackbar.value = { open: true, color: 'success', text: 'コピーしました' }
}
</script>

<template>
  <v-container max-width="800">
    <v-card class="pa-4 mb-4" title="データ保持">
      <v-card-text>
        <div class="d-flex align-center ga-3 flex-wrap">
          <span>保持期間: 転記完了後</span>
          <v-text-field
            v-model.number="retentionDays"
            type="number"
            min="1"
            max="3650"
            density="compact"
            hide-details
            style="max-width: 100px"
          />
          <span>日で自動削除</span>
          <v-btn color="primary" variant="flat" :loading="saving" @click="save">保存</v-btn>
        </div>
        <div class="text-caption text-medium-emphasis mt-3">
          ※保持期間を過ぎたPDF・解析結果は復元できません<br />
          ※原本の法定保存(法人税法・電子帳簿保存法)は貴社側の責務です
        </div>
      </v-card-text>
    </v-card>

    <v-card class="pa-4 mb-4" title="バッチ連携">
      <v-card-text>
        <div class="d-flex align-center ga-2 mb-3">
          <span class="text-medium-emphasis">バッチAPIエンドポイント:</span>
          <code>{{ batchEndpoint }}</code>
          <v-btn size="x-small" variant="tonal" icon="mdi-content-copy" @click="copyEndpoint" />
        </div>
        <div class="d-flex align-center ga-2">
          <span class="text-medium-emphasis">サブスクリプションキー:</span>
          <span class="text-disabled">APIM導入後に提供予定</span>
          <!-- TODO: APIM管理API経由の表示・再生成(screen-design.md) -->
        </div>
      </v-card-text>
    </v-card>

    <v-card class="pa-4" title="テナント情報">
      <v-card-text>
        <div>テナント名: {{ settings?.name ?? '—' }}</div>
      </v-card-text>
    </v-card>

    <v-snackbar v-model="snackbar.open" :color="snackbar.color" timeout="3000">
      {{ snackbar.text }}
    </v-snackbar>
  </v-container>
</template>
