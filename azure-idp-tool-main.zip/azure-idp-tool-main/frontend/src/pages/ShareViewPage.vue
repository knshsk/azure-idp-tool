<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'

import { getShareMeta, shareDownloadUrl, sharePageImageUrl, type ShareMeta } from '@/api/share'
import PageViewer from '@/components/PageViewer.vue'

const route = useRoute()
const token = route.params.token as string

const meta = ref<ShareMeta | null>(null)
const invalid = ref(false)
const loading = ref(true)
const currentPage = ref(1)

onMounted(async () => {
  try {
    meta.value = await getShareMeta(token)
  } catch {
    // 不存在・失効・期限切れを区別しない(存在有無を推測させない)
    invalid.value = true
  } finally {
    loading.value = false
  }
})

const pageCount = computed(() => meta.value?.page_count ?? 0)

function formatExpiry(iso: string): string {
  return new Date(iso).toLocaleString('ja-JP', { dateStyle: 'medium', timeStyle: 'short' })
}
</script>

<template>
  <div class="share-view">
    <v-app-bar color="primary" density="comfortable">
      <v-app-bar-title class="flex-0-0 mr-6">取引書類読み取りツール</v-app-bar-title>
      <template v-if="meta">
        <span class="text-body-1">{{ meta.file_name }}</span>
        <v-spacer />
        <v-btn
          :href="shareDownloadUrl(token)"
          prepend-icon="mdi-download"
          variant="tonal"
          color="white"
        >
          原本ダウンロード
        </v-btn>
      </template>
    </v-app-bar>

    <v-main>
      <v-container class="d-flex flex-column align-center">
        <v-progress-circular v-if="loading" indeterminate size="48" class="mt-12" />

        <!-- 無効なURL: 専用エラー表示のみ -->
        <v-card v-else-if="invalid" class="pa-12 mt-12 text-center" max-width="480">
          <v-icon icon="mdi-link-off" size="48" class="mb-4 text-medium-emphasis" />
          <div class="text-h6">このURLは無効です</div>
        </v-card>

        <template v-else-if="meta">
          <!-- 転記確定画面と同じビューアを流用(オーバレイ切替のみ非表示) -->
          <PageViewer
            v-if="pageCount >= 1"
            v-model:page="currentPage"
            :page-count="pageCount"
            :image-url="sharePageImageUrl(token, currentPage)"
            class="share-viewer my-3"
          />
          <div v-else class="text-medium-emphasis mt-12">表示できるページがありません</div>

          <div class="text-caption text-medium-emphasis mb-6">
            この共有URLの有効期限: {{ formatExpiry(meta.expires_at) }}
          </div>
        </template>
      </v-container>
    </v-main>
  </div>
</template>

<style scoped>
.share-viewer {
  max-width: 900px;
}
</style>
