<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'

import { getUsageSummary } from '@/api/admin'
import type { UsageSummary } from '@/api/types'
import UsageBarChart from '@/components/UsageBarChart.vue'

function currentMonth(): string {
  const now = new Date()
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
}

const month = ref(currentMonth())
const summary = ref<UsageSummary | null>(null)
const loading = ref(false)

async function load(): Promise<void> {
  loading.value = true
  try {
    summary.value = await getUsageSummary(month.value)
  } finally {
    loading.value = false
  }
}

onMounted(load)
watch(month, () => {
  if (/^\d{4}-\d{2}$/.test(month.value)) {
    void load()
  }
})

/** 課金根拠の数字のためCSVダウンロードを設ける(screen-design.md) */
function downloadCsv(): void {
  if (!summary.value) {
    return
  }
  const header = 'date,di_calls,di_pages'
  const rows = summary.value.days.map((d) => `${d.date},${d.di_calls},${d.di_pages}`)
  // BOM付きUTF-8(Excelでの文字化け防止)
  const blob = new Blob(['﻿' + [header, ...rows].join('\r\n')], {
    type: 'text/csv;charset=utf-8',
  })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `usage-${summary.value.month}.csv`
  link.click()
  URL.revokeObjectURL(link.href)
}
</script>

<template>
  <v-container>
    <div class="d-flex align-center mb-4">
      <v-spacer />
      <v-text-field
        v-model="month"
        type="month"
        label="対象月"
        density="compact"
        hide-details
        style="max-width: 180px"
      />
    </div>

    <v-progress-linear v-if="loading" indeterminate class="mb-4" />

    <template v-if="summary">
      <v-row dense class="mb-2">
        <v-col cols="12" sm="4">
          <v-card class="pa-4">
            <div class="text-caption text-medium-emphasis">APIリクエスト数</div>
            <div v-if="summary.api_requests !== null" class="text-h4">
              {{ summary.api_requests.toLocaleString() }}
            </div>
            <div v-else class="text-body-2 text-medium-emphasis mt-2">
              未連携(APIM導入後に表示)
            </div>
          </v-card>
        </v-col>
        <v-col cols="12" sm="4">
          <v-card class="pa-4">
            <div class="text-caption text-medium-emphasis">Document Intelligence コール数</div>
            <div class="text-h4">{{ summary.di_calls.toLocaleString() }}</div>
          </v-card>
        </v-col>
        <v-col cols="12" sm="4">
          <v-card class="pa-4">
            <div class="text-caption text-medium-emphasis">Document Intelligence ページ数</div>
            <div class="text-h4">{{ summary.di_pages.toLocaleString() }}</div>
          </v-card>
        </v-col>
      </v-row>

      <v-card class="pa-4 mb-4">
        <UsageBarChart v-if="summary.days.length > 0" :month="summary.month" :days="summary.days" />
        <div v-else class="text-medium-emphasis text-center py-8">この月の利用はありません</div>
      </v-card>

      <v-card>
        <div class="d-flex align-center px-4 pt-3">
          <span class="text-subtitle-1">内訳</span>
          <v-spacer />
          <v-btn
            size="small"
            variant="tonal"
            prepend-icon="mdi-download"
            :disabled="summary.days.length === 0"
            @click="downloadCsv"
          >
            CSVダウンロード
          </v-btn>
        </div>
        <v-table density="compact">
          <thead>
            <tr>
              <th>日付</th>
              <th class="text-right">APIリクエスト</th>
              <th class="text-right">DIコール</th>
              <th class="text-right">ページ数</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="day in summary.days" :key="day.date">
              <td>{{ day.date }}</td>
              <td class="text-right text-medium-emphasis">—</td>
              <td class="text-right">{{ day.di_calls }}</td>
              <td class="text-right">{{ day.di_pages }}</td>
            </tr>
            <tr v-if="summary.days.length === 0">
              <td colspan="4" class="text-center text-medium-emphasis py-6">データがありません</td>
            </tr>
          </tbody>
        </v-table>
      </v-card>
    </template>
  </v-container>
</template>
