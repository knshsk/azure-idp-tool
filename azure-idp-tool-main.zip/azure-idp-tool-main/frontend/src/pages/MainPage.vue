<script setup lang="ts">
import DocumentsModal from '@/components/DocumentsModal.vue'
</script>

<template>
  <!-- 背景はプレースホルダのみ。操作はモーダル(一覧・アップロード)から始まる -->
  <v-container fluid class="fill-height justify-center">
    <div class="text-center text-medium-emphasis">
      <v-icon icon="mdi-file-document-outline" size="64" />
      <div class="mt-2">ドキュメントを選択してください</div>
    </div>
  </v-container>
  <DocumentsModal />
</template>
