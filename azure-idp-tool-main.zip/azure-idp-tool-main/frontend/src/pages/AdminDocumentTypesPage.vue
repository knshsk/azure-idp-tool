<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'

import {
  createDocumentType,
  deleteDocumentType,
  listTranscriptionFields,
  updateDocumentType,
  updateTranscriptionFields,
} from '@/api/documentTypes'
import { ApiError } from '@/api/http'
import type { FieldUpsert } from '@/api/types'
import { useMastersStore } from '@/stores/masters'

const masters = useMastersStore()

const selectedTypeId = ref<string | null>(null)
const typeCode = ref('')
const typeName = ref('')
const fieldRows = ref<FieldUpsert[]>([])
const loading = ref(false)
const saving = ref(false)
const createDialog = ref(false)
const deleteDialog = ref(false)
const newCode = ref('')
const newName = ref('')
const snackbar = ref({ open: false, text: '', color: 'success' })

const valueTypeOptions = [
  { title: '文字列', value: 'string' },
  { title: '数値', value: 'number' },
  { title: '日付', value: 'date' },
]

const selectedType = computed(() =>
  masters.documentTypes.find((t) => t.id === selectedTypeId.value),
)

onMounted(async () => {
  await masters.loadDocumentTypes()
  selectedTypeId.value = masters.documentTypes[0]?.id ?? null
})

watch(selectedTypeId, async (typeId) => {
  if (!typeId) {
    fieldRows.value = []
    return
  }
  const type = masters.documentTypes.find((t) => t.id === typeId)
  typeCode.value = type?.code ?? ''
  typeName.value = type?.name ?? ''
  loading.value = true
  try {
    fieldRows.value = (await listTranscriptionFields(typeId)).map((f) => ({
      id: f.id,
      json_key: f.json_key,
      label_ja: f.label_ja,
      value_type: f.value_type,
      query_field_key: f.query_field_key,
      sort_order: f.sort_order,
    }))
  } finally {
    loading.value = false
  }
})

function notify(color: string, text: string): void {
  snackbar.value = { open: true, color, text }
}

function errorText(error: unknown): string {
  return error instanceof ApiError ? error.message : '操作に失敗しました'
}

async function createType(): Promise<void> {
  try {
    const created = await createDocumentType(newCode.value, newName.value)
    await masters.invalidate()
    selectedTypeId.value = created.id
    createDialog.value = false
    newCode.value = ''
    newName.value = ''
    notify('success', '書類種別を作成しました')
  } catch (error) {
    notify('error', errorText(error))
  }
}

async function saveType(): Promise<void> {
  if (!selectedTypeId.value) {
    return
  }
  saving.value = true
  try {
    await updateDocumentType(selectedTypeId.value, typeCode.value, typeName.value)
    const keep = selectedTypeId.value
    await masters.invalidate()
    selectedTypeId.value = keep
    notify('success', '書類種別を保存しました')
  } catch (error) {
    notify('error', errorText(error))
  } finally {
    saving.value = false
  }
}

async function removeType(): Promise<void> {
  if (!selectedTypeId.value) {
    return
  }
  deleteDialog.value = false
  try {
    await deleteDocumentType(selectedTypeId.value)
    await masters.invalidate()
    selectedTypeId.value = masters.documentTypes[0]?.id ?? null
    notify('success', '書類種別を削除しました')
  } catch (error) {
    notify('error', errorText(error))
  }
}

function addFieldRow(): void {
  fieldRows.value.push({
    json_key: '',
    label_ja: '',
    value_type: 'string',
    query_field_key: null,
    sort_order: fieldRows.value.length + 1,
  })
}

function removeFieldRow(index: number): void {
  fieldRows.value.splice(index, 1)
}

/** 並べ替え(↑↓ボタン)。並び順=JSON出力順(sort_orderは保存時に振り直す) */
function moveFieldRow(index: number, delta: number): void {
  const target = index + delta
  if (target < 0 || target >= fieldRows.value.length) {
    return
  }
  const rows = fieldRows.value
  ;[rows[index], rows[target]] = [rows[target], rows[index]]
}

async function saveFields(): Promise<void> {
  if (!selectedTypeId.value) {
    return
  }
  saving.value = true
  try {
    const payload = fieldRows.value.map((row, index) => ({
      ...row,
      query_field_key: row.query_field_key || null,
      sort_order: index + 1,
    }))
    const saved = await updateTranscriptionFields(selectedTypeId.value, payload)
    fieldRows.value = saved.map((f) => ({
      id: f.id,
      json_key: f.json_key,
      label_ja: f.label_ja,
      value_type: f.value_type,
      query_field_key: f.query_field_key,
      sort_order: f.sort_order,
    }))
    delete masters.fieldsByType[selectedTypeId.value]
    notify('success', '転記項目を保存しました')
  } catch (error) {
    notify('error', errorText(error))
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <v-container>
    <div class="d-flex align-center ga-2 mb-4 flex-wrap">
      <v-tabs v-model="selectedTypeId" color="primary" density="compact">
        <v-tab v-for="type in masters.documentTypes" :key="type.id" :value="type.id">
          {{ type.name }}
        </v-tab>
      </v-tabs>
      <v-btn size="small" variant="tonal" prepend-icon="mdi-plus" @click="createDialog = true">
        種別を追加
      </v-btn>
    </div>

    <template v-if="selectedType">
      <v-card class="pa-4 mb-4">
        <div class="d-flex align-center ga-3 flex-wrap">
          <span class="text-subtitle-2">種別情報:</span>
          <v-text-field
            v-model="typeCode"
            label="コード"
            density="compact"
            hide-details
            style="max-width: 200px"
          />
          <v-text-field
            v-model="typeName"
            label="名称"
            density="compact"
            hide-details
            style="max-width: 200px"
          />
          <v-btn color="primary" variant="flat" :loading="saving" @click="saveType">保存</v-btn>
          <v-btn color="error" variant="outlined" @click="deleteDialog = true">削除</v-btn>
        </div>
        <div class="text-caption text-medium-emphasis mt-2">
          ※コードはバッチAPIの document_type_code として使用します
        </div>
      </v-card>

      <v-card>
        <div class="d-flex align-center px-4 pt-3">
          <span class="text-subtitle-1">転記項目(並び順=JSON出力順)</span>
          <v-spacer />
          <v-btn size="small" variant="tonal" prepend-icon="mdi-plus" @click="addFieldRow">
            項目を追加
          </v-btn>
          <v-btn
            size="small"
            color="primary"
            variant="flat"
            class="ml-2"
            :loading="saving"
            @click="saveFields"
          >
            保存
          </v-btn>
        </div>
        <v-progress-linear v-if="loading" indeterminate />
        <v-table density="compact">
          <thead>
            <tr>
              <th style="width: 90px">並び順</th>
              <th>ラベル</th>
              <th>JSONキー</th>
              <th style="width: 130px">型</th>
              <th>Query Fieldsキー</th>
              <th style="width: 60px" />
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in fieldRows" :key="row.id ?? `new-${index}`">
              <td>
                <v-btn
                  icon="mdi-chevron-up"
                  size="x-small"
                  variant="text"
                  :disabled="index === 0"
                  @click="moveFieldRow(index, -1)"
                />
                <v-btn
                  icon="mdi-chevron-down"
                  size="x-small"
                  variant="text"
                  :disabled="index === fieldRows.length - 1"
                  @click="moveFieldRow(index, 1)"
                />
              </td>
              <td>
                <v-text-field v-model="row.label_ja" density="compact" variant="plain" hide-details />
              </td>
              <td>
                <v-text-field v-model="row.json_key" density="compact" variant="plain" hide-details />
              </td>
              <td>
                <v-select
                  v-model="row.value_type"
                  :items="valueTypeOptions"
                  density="compact"
                  variant="plain"
                  hide-details
                />
              </td>
              <td>
                <v-text-field
                  v-model="row.query_field_key"
                  density="compact"
                  variant="plain"
                  hide-details
                />
              </td>
              <td>
                <v-btn
                  icon="mdi-delete-outline"
                  size="x-small"
                  variant="text"
                  @click="removeFieldRow(index)"
                />
              </td>
            </tr>
            <tr v-if="fieldRows.length === 0">
              <td colspan="6" class="text-center text-medium-emphasis py-6">
                転記項目がありません
              </td>
            </tr>
          </tbody>
        </v-table>
        <div class="text-caption text-medium-emphasis px-4 pb-3">
          ※転記項目はヘッダ項目のみ(明細列の意味づけは業務システム側の責務)。
          転記値が残っている項目の削除は保存時にエラーになります(確定済みドキュメントとの互換性保護)
        </div>
      </v-card>
    </template>

    <v-dialog v-model="createDialog" max-width="420">
      <v-card title="書類種別を追加">
        <v-card-text>
          <v-text-field v-model="newCode" label="コード(バッチAPI指定用)" density="comfortable" />
          <v-text-field v-model="newName" label="名称" density="comfortable" />
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn @click="createDialog = false">キャンセル</v-btn>
          <v-btn
            color="primary"
            variant="flat"
            :disabled="!newCode || !newName"
            @click="createType"
          >
            作成
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="deleteDialog" max-width="420">
      <v-card title="書類種別の削除">
        <v-card-text>
          「{{ selectedType?.name }}」を削除しますか?
          ドキュメントで使用中の種別は削除できません。
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn @click="deleteDialog = false">キャンセル</v-btn>
          <v-btn color="error" variant="flat" @click="removeType">削除する</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar.open" :color="snackbar.color" timeout="4000">
      {{ snackbar.text }}
    </v-snackbar>
  </v-container>
</template>
