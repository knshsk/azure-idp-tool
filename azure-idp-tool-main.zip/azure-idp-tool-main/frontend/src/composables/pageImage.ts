/**
 * ページ画像を認証付きで取得し、`<img>` / SVG `<image>` に渡せるURLを返す。
 *
 * ページPNGのエンドポイントは他のAPIと同じくJWTを要求するが、URLをそのまま
 * `src` / `href` に渡すとブラウザが直接GETするためAuthorizationヘッダが付かず、
 * AUTH_MODE=keycloak では401になる。認証付きfetchで受けたBlobをobject URLに
 * 変換してこの経路を通す。
 *
 * 共有ビュー(api/share.ts)のページ画像はAPIが認証なしで返すため対象外。
 */

import { onScopeDispose, ref, watch, type Ref } from 'vue'

import { fetchPageImage } from '@/api/documents'

export function usePageImageUrl(documentId: string, pageNo: Ref<number>): Ref<string> {
  // 未取得・取得失敗時は空文字。PageViewerは寸法をpage_metaから受け取るため、
  // 画像が出ないだけで座標オーバレイは表示できる
  const url = ref('')

  function release(): void {
    if (url.value !== '') {
      URL.revokeObjectURL(url.value)
      url.value = ''
    }
  }

  watch(
    pageNo,
    async (page) => {
      let blob: Blob
      try {
        blob = await fetchPageImage(documentId, page)
      } catch (error) {
        // 画面全体を落とすほどではないが、黙って消えると原因が追えない
        console.error('ページ画像の取得に失敗しました', error)
        release()
        return
      }
      // 取得中にページが切り替わっていたら捨てる(古い画像で上書きしない)
      if (pageNo.value !== page) return
      release()
      url.value = URL.createObjectURL(blob)
    },
    { immediate: true },
  )

  // object URLはページを離れても解放されないので明示的に破棄する
  onScopeDispose(release)

  return url
}
