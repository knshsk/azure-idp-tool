<script setup lang="ts">
import { computed, watchEffect } from 'vue'
import { useRoute } from 'vue-router'

import { isAuthenticated } from '@/auth/keycloak'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const route = useRoute()
// 共有ビュー・ログインは共通レイアウト(アプリバー)を使わない(screen-design.md)
const plainLayout = computed(() => route.meta.plain === true)

// 表示名とロールは GET /me から取る(ロールはJWTではなくusersテーブルが正)。
// 共通レイアウトを使う画面に入った時点で一度だけ読み込む。
//
// isAuthenticated() の判定を入れているのは、初回描画時点ではルータガードが
// まだ走っておらず route.meta が既定値のため。これが無いと未認証でも /me を
// 呼んでしまい、ログイン画面を出す前にKeycloakへ飛ばされる。
watchEffect(() => {
  if (!plainLayout.value && isAuthenticated() && !auth.loaded) {
    void auth.load()
  }
})
</script>

<template>
  <v-app>
    <template v-if="plainLayout">
      <router-view />
    </template>
    <template v-else>
      <v-app-bar color="primary" density="comfortable">
        <v-app-bar-title class="flex-0-0 mr-6">取引書類読み取りツール</v-app-bar-title>
        <v-btn to="/" variant="text">ドキュメント</v-btn>
        <v-btn v-if="auth.role === 'tenant_admin'" to="/admin" variant="text">管理</v-btn>
        <v-spacer />
        <v-menu>
          <template #activator="{ props }">
            <v-btn variant="text" v-bind="props">
              {{ auth.displayName || '...' }}
              <v-icon end icon="mdi-chevron-down" />
            </v-btn>
          </template>
          <v-list density="compact">
            <v-list-item :subtitle="auth.role" :title="auth.tenantName" />
            <v-divider />
            <v-list-item title="ログアウト" @click="auth.signOut()" />
          </v-list>
        </v-menu>
      </v-app-bar>
      <v-main>
        <router-view />
      </v-main>
    </template>
  </v-app>
</template>
