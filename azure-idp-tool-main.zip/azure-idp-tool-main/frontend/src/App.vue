<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const route = useRoute()
// 共有ビュー・ログインは共通レイアウト(アプリバー)を使わない(screen-design.md)
const plainLayout = computed(() => route.meta.plain === true)
</script>

<template>
  <v-app>
    <template v-if="plainLayout">
      <router-view />
    </template>
    <template v-else>
      <v-app-bar color="primary" density="comfortable">
        <v-app-bar-title class="flex-0-0 mr-6">取引書類読み取りツール</v-app-bar-title>
        <v-btn to="/" variant="text">ドキュメント</v-btn>
        <v-btn v-if="auth.role === 'tenant_admin'" to="/admin" variant="text">管理</v-btn>
        <v-spacer />
        <span class="text-body-2 mr-2">{{ auth.displayName }}({{ auth.role }})</span>
      </v-app-bar>
      <v-main>
        <router-view />
      </v-main>
    </template>
  </v-app>
</template>
