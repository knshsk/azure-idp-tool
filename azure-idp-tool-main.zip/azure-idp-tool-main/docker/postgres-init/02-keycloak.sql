-- Keycloak(認証基盤)用のデータベースとロール
-- 検証環境の infra/verify/scripts/init-keycloak-db.sql に相当する。
--
--   keycloak データベース : Keycloak が自分でテーブルを作るストア(Liquibase管理)
--   keycloak_user ロール  : Keycloak の接続ロール。アプリの app_user とは無関係
--
-- アプリDB(idp)と権限境界を分けるのが目的なので、**このロールに idp データベースの
-- 権限を与えてはならない**。逆も同様。
--
-- このスクリプトはPostgreSQLコンテナの初回起動時(データボリュームが空のとき)のみ
-- 自動実行される。既存ボリュームに適用する場合は手動で実行する:
--   docker exec -i idp-postgres psql -U app -d idp < docker/postgres-init/02-keycloak.sql

CREATE ROLE keycloak_user LOGIN PASSWORD 'keycloak'
    NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;

CREATE DATABASE keycloak OWNER app;

-- 既定では PUBLIC に CONNECT が付いており、app_user から接続できてしまう。
-- 権限境界を実際に成立させるために剥がす(01-roles.sql の idp 側と対)
REVOKE CONNECT ON DATABASE keycloak FROM PUBLIC;

GRANT CONNECT ON DATABASE keycloak TO keycloak_user;

-- 以降は keycloak データベース側の権限。接続を切り替える必要がある
\connect keycloak

-- PostgreSQL 15 以降、public スキーマは PUBLIC ロールへ CREATE を与えなくなった。
-- Keycloak は初回起動時に Liquibase で自分のテーブルを作るため CREATE が要る。
-- 作成したテーブルは keycloak_user が所有者になるので、以後の ALTER / DROP に
-- 追加の権限は要らない。
GRANT ALL ON SCHEMA public TO keycloak_user;
