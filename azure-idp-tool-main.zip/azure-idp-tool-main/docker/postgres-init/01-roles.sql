-- ローカル開発用のロール分離(data-model.md / azure-architecture_v2.md §3.4)
--   app      : 所有者ロール(POSTGRES_USER。マイグレーション・シード用)
--   app_user : アプリ接続ロール。RLS適用対象(BYPASSRLSなし)
--
-- このスクリプトはPostgreSQLコンテナの初回起動時(データボリュームが空のとき)のみ
-- 自動実行される。既存ボリュームに適用する場合は手動で実行する:
--   docker exec -i idp-postgres psql -U app -d idp < docker/postgres-init/01-roles.sql

CREATE ROLE app_user LOGIN PASSWORD 'app'
    NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;

-- PostgreSQL は既定で PUBLIC ロールに CONNECT を与えるため、明示的に剥がさないと
-- 任意のロール(Keycloak の keycloak_user 等)がアプリDBへ接続できてしまう。
-- 所有者(app)と app_user は個別に権限を持つので影響しない
REVOKE CONNECT ON DATABASE idp FROM PUBLIC;

GRANT CONNECT ON DATABASE idp TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;

-- 既存テーブルへの権限(手動適用時のため)
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;

-- appが今後作成するテーブル(マイグレーション)にも自動で権限を付与
ALTER DEFAULT PRIVILEGES FOR ROLE app IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;
