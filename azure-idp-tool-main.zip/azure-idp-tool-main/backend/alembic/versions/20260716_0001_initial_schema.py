"""初回スキーマ(全9テーブル+RLS)

Revision ID: 0001
Revises:
Create Date: 2026-07-16

テーブル定義は docs/01_design/data-model.md に従う。
RLSは全テナントスコープテーブルにENABLE+FORCE+同型ポリシーを適用する。
FORCEによりテーブル所有者にもRLSが効くため、マイグレーション・シードは
スーパーユーザまたはBYPASSRLSを持つロールで実行すること(ローカルは`app`)。
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

# tenant_id列を持つRLS適用対象テーブル
TENANT_SCOPED_TABLES = [
    "users",
    "document_types",
    "transcription_fields",
    "documents",
    "extracted_values",
    "share_links",
    "usage_logs",
    "di_call_logs",
]


def _uuid_pk() -> sa.Column:
    return sa.Column(
        "id",
        postgresql.UUID(as_uuid=True),
        nullable=False,
        server_default=sa.text("gen_random_uuid()"),
    )


def _tenant_id() -> sa.Column:
    return sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=False)


def _created_at() -> sa.Column:
    return sa.Column(
        "created_at",
        sa.DateTime(timezone=True),
        nullable=False,
        server_default=sa.func.now(),
    )


def upgrade() -> None:
    op.create_table(
        "tenants",
        _uuid_pk(),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("retention_days", sa.Integer(), nullable=False, server_default=sa.text("90")),
        _created_at(),
        sa.PrimaryKeyConstraint("id", name="pk_tenants"),
    )

    op.create_table(
        "users",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("entra_object_id", sa.Text(), nullable=False),
        sa.Column("email", sa.Text(), nullable=False),
        sa.Column("display_name", sa.Text(), nullable=False),
        sa.Column("role", sa.Text(), nullable=False),
        _created_at(),
        sa.PrimaryKeyConstraint("id", name="pk_users"),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name="fk_users_tenant_id_tenants", ondelete="CASCADE"
        ),
        sa.UniqueConstraint("entra_object_id", name="uq_users_entra_object_id"),
        sa.CheckConstraint("role IN ('tenant_admin', 'member')", name="ck_users_role"),
    )

    op.create_table(
        "document_types",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("code", sa.Text(), nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        _created_at(),
        sa.PrimaryKeyConstraint("id", name="pk_document_types"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_document_types_tenant_id_tenants",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("tenant_id", "code", name="uq_document_types_tenant_id_code"),
    )

    op.create_table(
        "transcription_fields",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("document_type_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("json_key", sa.Text(), nullable=False),
        sa.Column("label_ja", sa.Text(), nullable=False),
        sa.Column("value_type", sa.Text(), nullable=False),
        sa.Column("query_field_key", sa.Text(), nullable=True),
        sa.Column("sort_order", sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint("id", name="pk_transcription_fields"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_transcription_fields_tenant_id_tenants",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["document_type_id"],
            ["document_types.id"],
            name="fk_transcription_fields_document_type_id_document_types",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint(
            "document_type_id", "json_key", name="uq_transcription_fields_document_type_id_json_key"
        ),
        sa.CheckConstraint(
            "value_type IN ('string', 'number', 'date')",
            name="ck_transcription_fields_value_type",
        ),
    )

    op.create_table(
        "documents",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("document_type_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("status", sa.Text(), nullable=False, server_default=sa.text("'uploaded'")),
        sa.Column("file_name", sa.Text(), nullable=False),
        sa.Column("file_hash", sa.Text(), nullable=False),
        sa.Column("page_count", sa.Integer(), nullable=True),
        sa.Column("pages", postgresql.JSONB(), nullable=True),
        sa.Column("source", sa.Text(), nullable=False),
        sa.Column("uploaded_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("layout_blob_path", sa.Text(), nullable=True),
        sa.Column("query_fields_result", postgresql.JSONB(), nullable=True),
        sa.Column("line_item_table", postgresql.JSONB(), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        _created_at(),
        sa.Column("analyzed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("confirmed_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id", name="pk_documents"),
        sa.ForeignKeyConstraint(
            ["tenant_id"], ["tenants.id"], name="fk_documents_tenant_id_tenants", ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(
            ["document_type_id"],
            ["document_types.id"],
            name="fk_documents_document_type_id_document_types",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["uploaded_by"],
            ["users.id"],
            name="fk_documents_uploaded_by_users",
            ondelete="SET NULL",
        ),
        sa.UniqueConstraint("tenant_id", "file_hash", name="uq_documents_tenant_id_file_hash"),
        sa.CheckConstraint(
            "status IN ('uploaded', 'analyzing', 'analyzed', 'confirmed', 'failed')",
            name="ck_documents_status",
        ),
        sa.CheckConstraint("source IN ('frontend', 'batch')", name="ck_documents_source"),
    )
    op.create_index("ix_documents_tenant_id_status", "documents", ["tenant_id", "status"])

    op.create_table(
        "extracted_values",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("transcription_field_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("row_no", sa.Integer(), nullable=True),
        sa.Column("column_no", sa.Integer(), nullable=True),
        sa.Column("page_no", sa.Integer(), nullable=True),
        sa.Column("bbox", postgresql.JSONB(), nullable=True),
        sa.Column("value_raw", sa.Text(), nullable=False),
        sa.Column("value_normalized", sa.Text(), nullable=True),
        sa.Column(
            "normalization_failed", sa.Boolean(), nullable=False, server_default=sa.text("false")
        ),
        sa.Column("manually_edited", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
        ),
        sa.PrimaryKeyConstraint("id", name="pk_extracted_values"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_extracted_values_tenant_id_tenants",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["documents.id"],
            name="fk_extracted_values_document_id_documents",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["transcription_field_id"],
            ["transcription_fields.id"],
            name="fk_extracted_values_transcription_field_id_transcription_fields",
            ondelete="RESTRICT",
        ),
        sa.CheckConstraint(
            "(transcription_field_id IS NOT NULL AND row_no IS NULL AND column_no IS NULL)"
            " OR "
            "(transcription_field_id IS NULL AND row_no IS NOT NULL AND column_no IS NOT NULL)",
            name="ck_extracted_values_header_or_cell",
        ),
    )
    op.create_index("ix_extracted_values_document_id", "extracted_values", ["document_id"])
    op.create_index(
        "uq_extracted_values_header",
        "extracted_values",
        ["document_id", "transcription_field_id"],
        unique=True,
        postgresql_where=sa.text("transcription_field_id IS NOT NULL"),
    )
    op.create_index(
        "uq_extracted_values_cell",
        "extracted_values",
        ["document_id", "row_no", "column_no"],
        unique=True,
        postgresql_where=sa.text("row_no IS NOT NULL"),
    )

    op.create_table(
        "share_links",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("token_hash", sa.Text(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        _created_at(),
        sa.PrimaryKeyConstraint("id", name="pk_share_links"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_share_links_tenant_id_tenants",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["documents.id"],
            name="fk_share_links_document_id_documents",
            ondelete="CASCADE",
        ),
        sa.UniqueConstraint("token_hash", name="uq_share_links_token_hash"),
    )
    op.create_index("ix_share_links_document_id", "share_links", ["document_id"])

    op.create_table(
        "usage_logs",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("action", sa.Text(), nullable=False),
        sa.Column("resource_type", sa.Text(), nullable=False),
        sa.Column("resource_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column(
            "detail", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")
        ),
        _created_at(),
        sa.PrimaryKeyConstraint("id", name="pk_usage_logs"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_usage_logs_tenant_id_tenants",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["user_id"], ["users.id"], name="fk_usage_logs_user_id_users", ondelete="SET NULL"
        ),
    )
    op.create_index("ix_usage_logs_tenant_id_created_at", "usage_logs", ["tenant_id", "created_at"])

    op.create_table(
        "di_call_logs",
        _uuid_pk(),
        _tenant_id(),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("pages", sa.Integer(), nullable=False),
        _created_at(),
        sa.PrimaryKeyConstraint("id", name="pk_di_call_logs"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_di_call_logs_tenant_id_tenants",
            ondelete="CASCADE",
        ),
        # 課金記録はドキュメント削除後も保持するためSET NULL
        sa.ForeignKeyConstraint(
            ["document_id"],
            ["documents.id"],
            name="fk_di_call_logs_document_id_documents",
            ondelete="SET NULL",
        ),
    )
    op.create_index(
        "ix_di_call_logs_tenant_id_created_at", "di_call_logs", ["tenant_id", "created_at"]
    )

    # --- Row-Level Security ---
    # アプリ接続ロールにはBYPASSRLSを付与しない(data-model.md)。
    # FORCEにより所有者にも適用される(所有者=マイグレーションロールの素通り防止)
    for table in TENANT_SCOPED_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"CREATE POLICY tenant_isolation ON {table} "
            f"USING (tenant_id = current_setting('app.tenant_id')::uuid)"
        )
    # tenantsは自身が親のためid列で自テナント行のみ許可
    op.execute("ALTER TABLE tenants ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE tenants FORCE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY tenant_isolation ON tenants "
        "USING (id = current_setting('app.tenant_id')::uuid)"
    )


def downgrade() -> None:
    # ポリシーはテーブルと一緒に削除される。依存の逆順でDROP
    op.drop_table("di_call_logs")
    op.drop_table("usage_logs")
    op.drop_table("share_links")
    op.drop_table("extracted_values")
    op.drop_table("documents")
    op.drop_table("transcription_fields")
    op.drop_table("document_types")
    op.drop_table("users")
    op.drop_table("tenants")
