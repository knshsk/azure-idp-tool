"""Keycloak認証のユーザ解決経路とidp_subjectへの改名

Revision ID: 0004
Revises: 0003
Create Date: 2026-08-14

KeycloakのJWTでユーザを解決できるようにするための2点:

1. users.entra_object_id を idp_subject へ改名する。
   IdP名を列名に含めていると乗り換えのたびに改名が要るため、IdP非依存の名前にする。
   値はKeycloakが発行するJWTの `sub`。

2. subからユーザ(tenant_id / role)を解決するRLS外の検索経路を作る。
   認証時点ではまだテナントが未知でRLSコンテキストを設定できないため、
   usersのtenant_isolationポリシー下ではこの検索ができない。共有トークン検証(0002)・
   定期ジョブ(0003)と同じSECURITY DEFINERパターンで限定的な経路を作る:

     - NOLOGINロール user_reader(usersのSELECTのみ)
     - user_reader限定の許可ポリシー(FOR SELECT USING (true))
     - user_reader所有のSECURITY DEFINER関数 lookup_user_by_idp_subject(text)

   関数は認証に必要な最小限(id / tenant_id / role)だけを返す。email や
   display_name は返さない(認証経路から全テナントの個人情報を引けないようにする)。
"""

from collections.abc import Sequence

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0004"
down_revision: str | None = "0003"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # --- 1. 改名 ---
    op.alter_column("users", "entra_object_id", new_column_name="idp_subject")
    op.execute(
        "ALTER TABLE users RENAME CONSTRAINT uq_users_entra_object_id TO uq_users_idp_subject"
    )

    # --- 2. RLS外のユーザ解決経路 ---
    op.execute(
        """
        DO $do$
        BEGIN
            IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'user_reader') THEN
                CREATE ROLE user_reader NOLOGIN;
            END IF;
        END
        $do$
        """
    )
    op.execute("GRANT SELECT ON users TO user_reader")
    op.execute(
        """
        CREATE POLICY user_idp_subject_lookup ON users
            FOR SELECT TO user_reader USING (true)
        """
    )
    op.execute(
        """
        CREATE FUNCTION lookup_user_by_idp_subject(p_idp_subject text)
        RETURNS TABLE (
            id uuid,
            tenant_id uuid,
            role text
        )
        LANGUAGE sql STABLE SECURITY DEFINER
        SET search_path = public
        AS $func$
            SELECT id, tenant_id, role
            FROM users
            WHERE idp_subject = p_idp_subject
        $func$
        """
    )
    # 所有者変更は「新しい所有者がそのスキーマにCREATE権限を持つこと」を要求する
    # (0002のコメント参照)。付与は所有者変更の間だけに留める。
    op.execute("GRANT CREATE ON SCHEMA public TO user_reader")
    op.execute("ALTER FUNCTION lookup_user_by_idp_subject(text) OWNER TO user_reader")
    op.execute("REVOKE CREATE ON SCHEMA public FROM user_reader")
    op.execute("GRANT EXECUTE ON FUNCTION lookup_user_by_idp_subject(text) TO PUBLIC")


def downgrade() -> None:
    op.execute("DROP FUNCTION IF EXISTS lookup_user_by_idp_subject(text)")
    op.execute("DROP POLICY IF EXISTS user_idp_subject_lookup ON users")
    op.execute("REVOKE SELECT ON users FROM user_reader")
    # ロール自体はクラスタ共有のため残す

    op.execute(
        "ALTER TABLE users RENAME CONSTRAINT uq_users_idp_subject TO uq_users_entra_object_id"
    )
    op.alter_column("users", "idp_subject", new_column_name="entra_object_id")
