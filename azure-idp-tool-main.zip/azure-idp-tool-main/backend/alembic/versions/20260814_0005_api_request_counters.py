"""テナント別APIリクエスト数の日次カウンタ

Revision ID: 0005
Revises: 0004
Create Date: 2026-08-14

APIリクエスト数(FR-LOG-2)は、公開接点のアクセスログにテナント識別子が出ず
ログ集計ではテナント別に割れないため、アプリ側で計上する
(app/core/usage_counter.py)。

リクエストごとに1行入れるとテーブルがリクエスト数に比例して膨れるため、
(tenant_id, day) の1行をUPSERTでインクリメントする日次カウンタにする。
画面が必要とするのは月次合計と日次推移(screen-design.md 3-2)なので
この粒度で足りる。
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "0005"
down_revision: str | None = "0004"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "api_request_counters",
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=False),
        # JSTの日付。集計タイムゾーンはdi_call_logs側の集計と揃える【仮】
        sa.Column("day", sa.Date(), nullable=False),
        sa.Column("count", sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint("tenant_id", "day", name="pk_api_request_counters"),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["tenants.id"],
            name="fk_api_request_counters_tenant_id_tenants",
            ondelete="CASCADE",
        ),
    )

    # 他のテナントスコープテーブルと同型のRLS(0001参照)。
    # USINGのみのポリシーはINSERT時のWITH CHECKにも同じ式が使われるため、
    # UPSERT(INSERT ... ON CONFLICT DO UPDATE)も自テナント行に限定される。
    op.execute("ALTER TABLE api_request_counters ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE api_request_counters FORCE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY tenant_isolation ON api_request_counters "
        "USING (tenant_id = current_setting('app.tenant_id')::uuid)"
    )


def downgrade() -> None:
    # ポリシーはテーブルと一緒に削除される
    op.drop_table("api_request_counters")
