"""共有トークン検証用のRLS外検索経路

Revision ID: 0002
Revises: 0001
Create Date: 2026-07-16

共有ビューは認証なし経路のためテナントが未知であり、share_linksのトークン検索は
RLS(tenant_id一致)の外で行う必要がある。BYPASSRLSロールはAzure PostgreSQLでは
作成できないため、以下の構成で限定的な検索経路を作る:

1. NOLOGINロール share_link_reader(share_linksのSELECTのみ)
2. share_link_reader限定の許可ポリシー(FOR SELECT USING (true))
3. share_link_reader所有のSECURITY DEFINER関数 lookup_share_link(token_hash)

アプリはこの関数経由でのみ全テナントのshare_linksを検索できる(他テーブルは不可)。
同じパターンはentra認証のユーザ解決(users横断検索)でも使う想定。
"""

from collections.abc import Sequence

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0002"
down_revision: str | None = "0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.execute(
        """
        DO $do$
        BEGIN
            IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'share_link_reader') THEN
                CREATE ROLE share_link_reader NOLOGIN;
            END IF;
        END
        $do$
        """
    )
    op.execute("GRANT SELECT ON share_links TO share_link_reader")
    op.execute(
        """
        CREATE POLICY share_token_lookup ON share_links
            FOR SELECT TO share_link_reader USING (true)
        """
    )
    op.execute(
        """
        CREATE FUNCTION lookup_share_link(p_token_hash text)
        RETURNS TABLE (
            id uuid,
            tenant_id uuid,
            document_id uuid,
            expires_at timestamptz,
            revoked_at timestamptz
        )
        LANGUAGE sql STABLE SECURITY DEFINER
        SET search_path = public
        AS $func$
            SELECT id, tenant_id, document_id, expires_at, revoked_at
            FROM share_links
            WHERE token_hash = p_token_hash
        $func$
        """
    )
    op.execute("ALTER FUNCTION lookup_share_link(text) OWNER TO share_link_reader")
    op.execute("GRANT EXECUTE ON FUNCTION lookup_share_link(text) TO PUBLIC")


def downgrade() -> None:
    op.execute("DROP FUNCTION IF EXISTS lookup_share_link(text)")
    op.execute("DROP POLICY IF EXISTS share_token_lookup ON share_links")
    op.execute("REVOKE SELECT ON share_links FROM share_link_reader")
    # ロール自体はクラスタ共有のため残す
