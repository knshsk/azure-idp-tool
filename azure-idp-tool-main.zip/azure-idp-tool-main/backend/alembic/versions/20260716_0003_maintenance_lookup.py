"""定期ジョブ(回収・保持期間削除)用のRLS外検索経路

Revision ID: 0003
Revises: 0002
Create Date: 2026-07-16

回収処理(uploaded/analyzing滞留の再投入)と保持期間超過削除はテナント横断の
検索が必要なため、共有トークン検証(0002)と同じSECURITY DEFINERパターンで
限定的な検索経路を作る。関数は対象の特定のみを行い、実際の更新・削除は
アプリがテナントコンテキストを設定したRLS下で行う。
"""

from collections.abc import Sequence

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0003"
down_revision: str | None = "0002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.execute(
        """
        DO $do$
        BEGIN
            IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'maintenance_reader') THEN
                CREATE ROLE maintenance_reader NOLOGIN;
            END IF;
        END
        $do$
        """
    )
    op.execute("GRANT SELECT ON documents, tenants TO maintenance_reader")
    op.execute(
        """
        CREATE POLICY maintenance_lookup ON documents
            FOR SELECT TO maintenance_reader USING (true)
        """
    )
    op.execute(
        """
        CREATE POLICY maintenance_lookup ON tenants
            FOR SELECT TO maintenance_reader USING (true)
        """
    )
    op.execute(
        """
        CREATE FUNCTION find_stalled_documents(p_before timestamptz)
        RETURNS TABLE (id uuid, tenant_id uuid, status text, source text)
        LANGUAGE sql STABLE SECURITY DEFINER
        SET search_path = public
        AS $func$
            SELECT id, tenant_id, status, source
            FROM documents
            WHERE status IN ('uploaded', 'analyzing')
              AND created_at < p_before
        $func$
        """
    )
    op.execute(
        """
        CREATE FUNCTION find_expired_documents(p_now timestamptz)
        RETURNS TABLE (id uuid, tenant_id uuid)
        LANGUAGE sql STABLE SECURITY DEFINER
        SET search_path = public
        AS $func$
            SELECT d.id, d.tenant_id
            FROM documents d
            JOIN tenants t ON t.id = d.tenant_id
            WHERE d.status = 'confirmed'
              AND d.confirmed_at + make_interval(days => t.retention_days) < p_now
        $func$
        """
    )
    # 所有者変更に必要なCREATE権限を一時的に付与する(理由は0002と同じ)
    op.execute("GRANT CREATE ON SCHEMA public TO maintenance_reader")
    op.execute("ALTER FUNCTION find_stalled_documents(timestamptz) OWNER TO maintenance_reader")
    op.execute("ALTER FUNCTION find_expired_documents(timestamptz) OWNER TO maintenance_reader")
    op.execute("REVOKE CREATE ON SCHEMA public FROM maintenance_reader")
    op.execute("GRANT EXECUTE ON FUNCTION find_stalled_documents(timestamptz) TO PUBLIC")
    op.execute("GRANT EXECUTE ON FUNCTION find_expired_documents(timestamptz) TO PUBLIC")


def downgrade() -> None:
    op.execute("DROP FUNCTION IF EXISTS find_stalled_documents(timestamptz)")
    op.execute("DROP FUNCTION IF EXISTS find_expired_documents(timestamptz)")
    op.execute("DROP POLICY IF EXISTS maintenance_lookup ON documents")
    op.execute("DROP POLICY IF EXISTS maintenance_lookup ON tenants")
    op.execute("REVOKE SELECT ON documents, tenants FROM maintenance_reader")
    # ロール自体はクラスタ共有のため残す
