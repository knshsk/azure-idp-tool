import uuid
from datetime import datetime

from sqlalchemy import func, text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Tenant(Base):
    __tablename__ = "tenants"

    id: Mapped[uuid.UUID] = mapped_column(
        primary_key=True, server_default=text("gen_random_uuid()")
    )
    name: Mapped[str]
    # 転記完了後この日数で自動削除(データ保持期間)
    retention_days: Mapped[int] = mapped_column(server_default=text("90"))
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
