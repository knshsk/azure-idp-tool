import uuid

from sqlalchemy import CheckConstraint, ForeignKey, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class TranscriptionField(Base):
    """転記項目定義。ヘッダ項目のみ(明細列の意味づけは業務システム側の責務)。"""

    __tablename__ = "transcription_fields"
    __table_args__ = (
        UniqueConstraint("document_type_id", "json_key"),
        CheckConstraint("value_type IN ('string', 'number', 'date')", name="value_type"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        primary_key=True, server_default=text("gen_random_uuid()")
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"))
    document_type_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("document_types.id", ondelete="CASCADE")
    )
    # 出力JSONのキー名(書類種別内UNIQUE)
    json_key: Mapped[str]
    label_ja: Mapped[str]
    value_type: Mapped[str]
    # DI Query Fieldsで指定するキー名
    query_field_key: Mapped[str | None]
    sort_order: Mapped[int]
