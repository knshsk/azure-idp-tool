import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class ApiRequestCounter(Base):
    """テナント別APIリクエスト数の日次カウンタ(FR-LOG-2)。

    リクエストごとに1行入れるのではなく (tenant_id, day) の1行をUPSERTで
    インクリメントする。書き込み量がリクエスト数ではなく「テナント数×日数」に
    収まり、画面が必要とする月次合計・日次推移もこの粒度で足りるため。

    dayはJSTの日付。集計タイムゾーンはdi_call_logs側と揃えてJST固定【仮】。
    """

    __tablename__ = "api_request_counters"

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), primary_key=True
    )
    day: Mapped[date] = mapped_column(Date, primary_key=True)
    count: Mapped[int]
