import uuid
from datetime import datetime

from sqlalchemy import CheckConstraint, ForeignKey, Index, func, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class ExtractedValue(Base):
    """転記値(候補〜確定)。

    ヘッダ項目は transcription_field_id、明細セルは row_no + column_no で識別する
    (documents.line_item_table の列定義に対応)。
    """

    __tablename__ = "extracted_values"
    __table_args__ = (
        # ヘッダ項目 XOR 明細セルのどちらかの形であることを強制
        CheckConstraint(
            "(transcription_field_id IS NOT NULL AND row_no IS NULL AND column_no IS NULL)"
            " OR "
            "(transcription_field_id IS NULL AND row_no IS NOT NULL AND column_no IS NOT NULL)",
            name="header_or_cell",
        ),
        Index("ix_extracted_values_document_id", "document_id"),
        # ヘッダ項目: ドキュメント×転記項目で一意
        Index(
            "uq_extracted_values_header",
            "document_id",
            "transcription_field_id",
            unique=True,
            postgresql_where=text("transcription_field_id IS NOT NULL"),
        ),
        # 明細セル: ドキュメント×行×列で一意
        Index(
            "uq_extracted_values_cell",
            "document_id",
            "row_no",
            "column_no",
            unique=True,
            postgresql_where=text("row_no IS NOT NULL"),
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        primary_key=True, server_default=text("gen_random_uuid()")
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"))
    document_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("documents.id", ondelete="CASCADE"))
    # 転記値が残っている転記項目定義は削除させない
    transcription_field_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("transcription_fields.id", ondelete="RESTRICT")
    )
    # NULL=ヘッダ項目 / 0始まり=明細行
    row_no: Mapped[int | None]
    column_no: Mapped[int | None]
    page_no: Mapped[int | None]
    # 抽出元矩形 {x0, y0, x1, y1}(正規化座標0〜1。手入力時はNULL)。JSON出力には含めない
    bbox: Mapped[dict | None] = mapped_column(JSONB)
    value_raw: Mapped[str]
    # 型に従い正規化した値(ヘッダ項目のみ。明細セルは正規化しない)
    value_normalized: Mapped[str | None]
    normalization_failed: Mapped[bool] = mapped_column(server_default=text("false"))
    manually_edited: Mapped[bool] = mapped_column(server_default=text("false"))
    updated_at: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())
