import uuid
from datetime import datetime

from sqlalchemy import ForeignKey, Index, func, text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class DiCallLog(Base):
    """DIコール記録。テナント別DIコール数・コスト集計の源泉(課金根拠)。"""

    __tablename__ = "di_call_logs"
    __table_args__ = (Index("ix_di_call_logs_tenant_id_created_at", "tenant_id", "created_at"),)

    id: Mapped[uuid.UUID] = mapped_column(
        primary_key=True, server_default=text("gen_random_uuid()")
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"))
    # 課金記録は保持期間によるドキュメント削除後も残す必要があるためSET NULL
    document_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("documents.id", ondelete="SET NULL")
    )
    # 課金ページ数(全コールがLayout + Query Fieldsのためフラグは持たない)
    pages: Mapped[int]
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
