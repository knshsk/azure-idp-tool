import uuid
from datetime import datetime

from sqlalchemy import CheckConstraint, ForeignKey, Index, UniqueConstraint, func, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Document(Base):
    __tablename__ = "documents"
    __table_args__ = (
        # ハッシュ重複検知(重複時は既存ドキュメントの参照を返す【仮】)
        UniqueConstraint("tenant_id", "file_hash"),
        CheckConstraint(
            "status IN ('uploaded', 'analyzing', 'analyzed', 'confirmed', 'failed')",
            name="status",
        ),
        CheckConstraint("source IN ('frontend', 'batch')", name="source"),
        # 回収処理(uploaded滞留の検出)・一覧表示用
        Index("ix_documents_tenant_id_status", "tenant_id", "status"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        primary_key=True, server_default=text("gen_random_uuid()")
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("tenants.id", ondelete="CASCADE"))
    # 使用中の書類種別は削除させない
    document_type_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("document_types.id", ondelete="RESTRICT")
    )
    status: Mapped[str] = mapped_column(server_default=text("'uploaded'"))
    file_name: Mapped[str]
    file_hash: Mapped[str]
    # 解析完了時に設定(アップロード時点では不明)
    page_count: Mapped[int | None]
    # ページ情報: [{page_no, width_px, height_px}](座標変換用)。解析完了時に設定
    pages: Mapped[list | None] = mapped_column(JSONB)
    source: Mapped[str]
    uploaded_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    # DI Layout生JSONのBlobパス(解析完了時に設定)
    layout_blob_path: Mapped[str | None]
    # Query Fields結果(値+座標)。解析完了時に設定
    query_fields_result: Mapped[dict | None] = mapped_column(JSONB)
    # ユーザが選択した明細領域: {page_no, table_index, columns: [{column_no, header_text}]}
    line_item_table: Mapped[dict | None] = mapped_column(JSONB)
    error_message: Mapped[str | None]
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    analyzed_at: Mapped[datetime | None]
    confirmed_at: Mapped[datetime | None]
