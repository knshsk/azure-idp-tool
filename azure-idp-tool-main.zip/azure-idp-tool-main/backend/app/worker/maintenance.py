"""ワーカーの定期ジョブ(回収処理・保持期間超過の自動削除)。

- 回収処理: uploaded/analyzingのまま滞留したドキュメントを解析キューへ再投入する
  (キュー投入失敗・ワーカークラッシュ・メッセージTTL切れからの回復)。
  再投入は冪等(ワーカー側のstatus検査+候補値UPSERT)なので誤検知しても安全
- 保持期間超過削除: confirmed_at + tenants.retention_days を過ぎたドキュメントの
  Blobプレフィックス配下とDBレコードを削除する(blob-storage.md)

どちらもテナント横断の検索が必要なため、SECURITY DEFINER関数(マイグレーション0003)
で対象を特定し、個別の削除はテナントコンテキストを設定したRLS下で行う。
"""

import asyncio
import logging
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import text as sql_text

from app.clients import blob, queue
from app.config import settings
from app.core.db import session_factory, set_tenant_context
from app.models import Document, UsageLog

logger = logging.getLogger(__name__)


async def run_periodically() -> None:
    """メンテナンスループ。ジョブ内の例外は記録して次周期へ続行する。"""
    logger.info(
        "maintenance loop started (interval=%ss, stalled_threshold=%smin)",
        settings.maintenance_interval_seconds,
        settings.stalled_threshold_minutes,
    )
    while True:
        try:
            await recover_stalled_documents()
        except Exception:
            logger.exception("recovery job failed")
        try:
            await delete_expired_documents()
        except Exception:
            logger.exception("retention cleanup job failed")
        await asyncio.sleep(settings.maintenance_interval_seconds)


async def recover_stalled_documents() -> int:
    """滞留ドキュメントを解析キューへ再投入する。戻り値: 再投入件数。

    しきい値はcreated_at基準のため、古いドキュメントの再解析中に誤って再投入する
    可能性があるが、ワーカーの冪等性(解析済みならスキップ)により実害はない。
    """
    threshold = datetime.now(UTC) - timedelta(minutes=settings.stalled_threshold_minutes)
    async with session_factory() as session:
        rows = (
            await session.execute(
                sql_text("SELECT * FROM find_stalled_documents(:before)"),
                {"before": threshold},
            )
        ).all()

    for row in rows:
        queue_name = (
            settings.service_bus_queue_batch
            if row.source == "batch"
            else settings.service_bus_queue_interactive
        )
        await queue.enqueue_analysis(queue_name, row.id, row.tenant_id)
        logger.info(
            "stalled document re-enqueued (status=%s, queue=%s)",
            row.status,
            queue_name,
            extra={"tenant_id": str(row.tenant_id), "document_id": str(row.id)},
        )
    return len(rows)


async def delete_expired_documents() -> int:
    """保持期間を過ぎた確定済みドキュメントを削除する。戻り値: 削除件数。"""
    now = datetime.now(UTC)
    async with session_factory() as session:
        rows = (
            await session.execute(
                sql_text("SELECT * FROM find_expired_documents(:now)"), {"now": now}
            )
        ).all()

    for row in rows:
        await _delete_document(row.tenant_id, row.id)
    return len(rows)


async def _delete_document(tenant_id: uuid.UUID, document_id: uuid.UUID) -> None:
    deleted_blobs = await blob.delete_document_blobs(tenant_id, document_id)
    async with session_factory() as session:
        await set_tenant_context(session, tenant_id)
        document = await session.get(Document, document_id)
        if document is not None:
            await session.delete(document)
            session.add(
                UsageLog(
                    tenant_id=tenant_id,
                    user_id=None,
                    action="delete",
                    resource_type="document",
                    resource_id=document_id,
                    detail={"reason": "retention"},
                )
            )
        await session.commit()
    logger.info(
        "expired document deleted (%d blobs)",
        deleted_blobs,
        extra={"tenant_id": str(tenant_id), "document_id": str(document_id)},
    )
