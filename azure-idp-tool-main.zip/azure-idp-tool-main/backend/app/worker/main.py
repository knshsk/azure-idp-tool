"""ワーカーのエントリポイント。

起動: python -m app.worker.main
APIと同一イメージで、起動コマンドのみ切り替える(設計決定事項)。

interactive / batch の2キューを購読し、interactiveを優先消化する(ブレスト決定事項)。
リトライ可能なエラーはabandonでService Busの再配信に委ね、配信回数上限で
DLQ + status=failed + error_message記録(api-design.md)。
"""

import asyncio
import json
import logging
import uuid

from azure.servicebus import ServiceBusReceivedMessage
from azure.servicebus.aio import AutoLockRenewer, ServiceBusReceiver

from app.clients.queue import create_client
from app.config import settings
from app.core.logging import setup_logging
from app.services import analysis
from app.worker import maintenance

logger = logging.getLogger(__name__)


async def run() -> None:
    logger.info("worker started")
    # 定期ジョブ(回収処理・保持期間超過削除)をキュー消化と並行して動かす
    maintenance_task = asyncio.create_task(maintenance.run_periodically())
    renewer = AutoLockRenewer(max_lock_renewal_duration=settings.worker_lock_renewal_seconds)
    try:
        async with create_client() as client:
            interactive = client.get_queue_receiver(settings.service_bus_queue_interactive)
            batch = client.get_queue_receiver(settings.service_bus_queue_batch)
            async with interactive, batch:
                while True:
                    # interactive優先: 先にinteractiveを見て、空のときだけbatchを見る
                    receiver = interactive
                    messages = await interactive.receive_messages(
                        max_message_count=1, max_wait_time=5
                    )
                    if not messages:
                        receiver = batch
                        messages = await batch.receive_messages(
                            max_message_count=1, max_wait_time=1
                        )
                    if not messages:
                        continue
                    renewer.register(receiver, messages[0])
                    await _handle_message(receiver, messages[0])
    finally:
        maintenance_task.cancel()


async def _handle_message(receiver: ServiceBusReceiver, message: ServiceBusReceivedMessage) -> None:
    try:
        payload = json.loads(str(message))
        document_id = uuid.UUID(payload["document_id"])
        tenant_id = uuid.UUID(payload["tenant_id"])
    except ValueError, KeyError, TypeError:
        logger.exception("malformed message")
        await receiver.dead_letter_message(message, reason="malformed-message")
        return

    log_context = {"tenant_id": str(tenant_id), "document_id": str(document_id)}
    try:
        await analysis.run_analysis(document_id, tenant_id)
    except analysis.SkipMessage as exc:
        logger.info("message skipped: %s", exc, extra=log_context)
        await receiver.complete_message(message)
    except Exception as exc:
        logger.exception("analysis failed", extra=log_context)
        # delivery_countはAMQPヘッダ由来の0始まり(初回配信=0)。今回が最後の
        # 許容試行なら、エミュレータ/サービス側の自動DLQに先んじて明示的にDLQへ送る
        if (message.delivery_count or 0) + 1 >= settings.worker_max_delivery_count:
            # 配信回数上限: status=failedを記録してDLQへ
            await analysis.mark_failed(document_id, tenant_id, str(exc))
            await receiver.dead_letter_message(
                message,
                reason="max-delivery-exceeded",
                error_description=str(exc)[:512],
            )
        else:
            # abandonで再配信させる(リトライ)
            await receiver.abandon_message(message)
    else:
        await receiver.complete_message(message)


def main() -> None:
    setup_logging()
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        logger.info("worker stopped")


if __name__ == "__main__":
    main()
