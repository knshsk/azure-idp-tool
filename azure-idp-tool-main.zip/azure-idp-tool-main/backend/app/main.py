"""FastAPI エントリポイント(APIサーバ)。

ワーカーのエントリポイントは app/worker/main.py(同一イメージ・起動コマンド違い)。
"""

from fastapi import APIRouter, FastAPI

from app.core.errors import register_error_handlers
from app.core.logging import setup_logging
from app.core.usage_counter import count_requests_middleware
from app.routers import admin, batch, document_types, documents, health, share

setup_logging()

app = FastAPI(title="idp-tool API")
register_error_handlers(app)

# テナント別APIリクエスト数の計上(FR-LOG-2)。エッジのログはテナント別に割れないため
# アプリ側で数える(core/usage_counter.py)
app.middleware("http")(count_requests_middleware)

app.include_router(health.router)

api_v1 = APIRouter(prefix="/api/v1")
api_v1.include_router(documents.router)
api_v1.include_router(document_types.router)
api_v1.include_router(batch.router)
api_v1.include_router(share.router)
api_v1.include_router(admin.router)
app.include_router(api_v1)

# api-design.mdのエンドポイントは一通り実装済み。残りの主要バックエンドタスク:
#   - 回収処理(uploaded/analyzing滞留の再投入)・保持期間超過の自動削除(日次ジョブ)
#   - テナント別レート制限・クォータ(azure-architecture_v2.md §3.1 #8。
#     Application GatewayのWAFはテナント単位のキーを持てないためAPI側の責務)
