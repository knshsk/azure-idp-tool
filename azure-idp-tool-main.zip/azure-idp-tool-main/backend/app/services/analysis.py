"""解析ジョブ(ワーカーの業務ロジック)。

フロー: status=analyzing → 原本PDF取得 → ページPNG生成 → DI解析(Layout+Query Fields)
 → layout.json格納 → ヘッダ項目候補のUPSERT → status=analyzed

冪等性(api-design.md): 同一メッセージの再配信・回収処理による再投入があるため、
status検査で二重解析を防ぎ、候補値はUPSERTで重複INSERTを防ぐ。
"""

import asyncio
import json
import logging
import uuid
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import blob, di
from app.core.db import session_factory, set_tenant_context
from app.models import DiCallLog, Document, ExtractedValue, TranscriptionField, UsageLog
from app.services import di_result, pdf_render
from app.services.normalize import normalize_value

logger = logging.getLogger(__name__)


class SkipMessage(Exception):
    """処理不要(削除済み・解析済み等)。メッセージは完了扱いにする。"""


async def run_analysis(document_id: uuid.UUID, tenant_id: uuid.UUID) -> None:
    log_context = {"tenant_id": str(tenant_id), "document_id": str(document_id)}

    # 1. status検査と解析開始マーク(短いトランザクション)
    async with session_factory() as session:
        await set_tenant_context(session, tenant_id)
        document = await session.get(Document, document_id)
        if document is None:
            raise SkipMessage("document not found(削除済みの可能性)")
        if document.status in ("analyzed", "confirmed"):
            raise SkipMessage(f"already {document.status}")
        fields = (
            await session.scalars(
                select(TranscriptionField)
                .where(TranscriptionField.document_type_id == document.document_type_id)
                .order_by(TranscriptionField.sort_order)
            )
        ).all()
        document.status = "analyzing"
        await session.commit()

    # 2. トランザクション外で重い処理(Blob・PDF変換・DI呼び出し)を行う
    pdf = await blob.download_bytes(tenant_id, blob.original_pdf_path(document_id))

    rendered = await asyncio.to_thread(pdf_render.render_pages, pdf)
    for page_meta, png in rendered:
        await blob.upload_bytes(
            tenant_id, blob.page_image_path(document_id, page_meta["page_no"]), png, "image/png"
        )
    pages_meta = [meta for meta, _ in rendered]
    logger.info("pages rendered: %d", len(pages_meta), extra=log_context)

    query_field_keys = [f.query_field_key for f in fields if f.query_field_key]
    raw = await di.analyze_layout(pdf, query_field_keys)
    di_pages = len(raw.get("pages", [])) or len(pages_meta)

    # DIコールは課金根拠のため、後続処理の成否に関わらず直ちに記録する
    async with session_factory() as session:
        await set_tenant_context(session, tenant_id)
        session.add(DiCallLog(tenant_id=tenant_id, document_id=document_id, pages=di_pages))
        await session.commit()

    layout_path = blob.layout_json_path(document_id)
    await blob.upload_bytes(
        tenant_id, layout_path, json.dumps(raw, ensure_ascii=False).encode(), "application/json"
    )
    query_fields = di_result.extract_query_fields(raw)

    # 3. 解析結果の確定(候補値UPSERT+ドキュメント更新)
    async with session_factory() as session:
        await set_tenant_context(session, tenant_id)
        document = await session.get(Document, document_id)
        if document is None:
            raise SkipMessage("document not found(解析中に削除された)")

        for field in fields:
            await _upsert_header_candidate(session, document, field, query_fields)

        document.pages = pages_meta
        document.page_count = len(pages_meta)
        document.layout_blob_path = layout_path
        document.query_fields_result = query_fields
        document.status = "analyzed"
        document.analyzed_at = datetime.now(UTC)
        document.error_message = None
        session.add(
            UsageLog(
                tenant_id=tenant_id,
                user_id=None,
                action="analyze",
                resource_type="document",
                resource_id=document_id,
            )
        )
        await session.commit()
    logger.info("analysis completed", extra=log_context)


async def _upsert_header_candidate(
    session: AsyncSession,
    document: Document,
    field: TranscriptionField,
    query_fields: dict[str, dict],
) -> None:
    """Query Fields結果をヘッダ項目の初期候補としてUPSERTする。

    DIが値を返さなかった項目も空値で行を作る(画面上で手入力可能にするため)。
    """
    entry = query_fields.get(field.query_field_key or "", {})
    value_raw = entry.get("value_raw", "")
    value_normalized, normalization_failed = normalize_value(field.value_type, value_raw)

    values = {
        "tenant_id": document.tenant_id,
        "document_id": document.id,
        "transcription_field_id": field.id,
        "page_no": entry.get("page_no"),
        "bbox": entry.get("bbox"),
        "value_raw": value_raw,
        "value_normalized": value_normalized,
        "normalization_failed": normalization_failed,
        "manually_edited": False,
    }
    stmt = insert(ExtractedValue).values(**values)
    # 再解析(メッセージ再配信)時は候補を上書きする
    stmt = stmt.on_conflict_do_update(
        index_elements=["document_id", "transcription_field_id"],
        index_where=ExtractedValue.transcription_field_id.isnot(None),
        set_={k: v for k, v in values.items() if k not in ("tenant_id", "document_id")},
    )
    await session.execute(stmt)


async def mark_failed(document_id: uuid.UUID, tenant_id: uuid.UUID, error_message: str) -> None:
    """リトライ上限超過時にstatus=failedと理由を記録する(DLQ行きと対で呼ぶ)。"""
    async with session_factory() as session:
        await set_tenant_context(session, tenant_id)
        document = await session.get(Document, document_id)
        if document is None or document.status in ("analyzed", "confirmed"):
            return
        document.status = "failed"
        document.error_message = error_message[:1000]
        await session.commit()
