"""転記値の正規化(ヘッダ項目のみ。明細セルは正規化しない)。

対応パターン範囲は未確定(ブレスト未解決事項)のため、以下をベースラインとする:
- 共通: NFKC正規化(全角数字・全角記号→半角)+前後空白除去
- date: 西暦(YYYY-MM-DD / YYYY/M/D / YYYY.M.D / YYYY年M月D日)と
        和暦(令和・平成・昭和+元年表記)をISO形式(YYYY-MM-DD)へ
- number: 通貨記号(¥$)・カンマ・「円」を除去した数値文字列へ
"""

import re
import unicodedata
from datetime import date

# 和暦→西暦変換のオフセット(元号N年 + オフセット = 西暦)
_ERA_OFFSETS = {"令和": 2018, "平成": 1988, "昭和": 1925}

_ERA_DATE_RE = re.compile(r"^(令和|平成|昭和)(元|\d{1,2})年(\d{1,2})月(\d{1,2})日?$")
_WESTERN_DATE_RE = re.compile(r"^(\d{4})[\-/.年](\d{1,2})[\-/.月](\d{1,2})日?$")
_NUMBER_RE = re.compile(r"^-?\d+(\.\d+)?$")
_NUMBER_STRIP_RE = re.compile(r"[¥$,、\s]|円")


def normalize_value(value_type: str, raw: str) -> tuple[str | None, bool]:
    """(正規化値, 正規化失敗フラグ) を返す。

    - 空文字・空白のみ: (None, False)(値なし。失敗ではない)
    - 正規化不能: (None, True)
    """
    cleaned = unicodedata.normalize("NFKC", raw).strip()
    if not cleaned:
        return None, False

    if value_type == "string":
        return cleaned, False
    if value_type == "date":
        return _normalize_date(cleaned)
    if value_type == "number":
        return _normalize_number(cleaned)
    raise ValueError(f"unknown value_type: {value_type}")


def _normalize_date(cleaned: str) -> tuple[str | None, bool]:
    match = _ERA_DATE_RE.match(cleaned)
    if match:
        era, year_str, month, day = match.groups()
        year = 1 if year_str == "元" else int(year_str)
        return _build_date(_ERA_OFFSETS[era] + year, int(month), int(day))

    match = _WESTERN_DATE_RE.match(cleaned)
    if match:
        year, month, day = (int(g) for g in match.groups())
        return _build_date(year, month, day)

    return None, True


def _build_date(year: int, month: int, day: int) -> tuple[str | None, bool]:
    try:
        return date(year, month, day).isoformat(), False
    except ValueError:
        return None, True


def _normalize_number(cleaned: str) -> tuple[str | None, bool]:
    stripped = _NUMBER_STRIP_RE.sub("", cleaned)
    if not _NUMBER_RE.match(stripped):
        return None, True
    return stripped, False
