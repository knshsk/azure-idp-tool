"""確定済みドキュメントの出力JSON生成(api-design.md「出力JSON形式」)。

- headerのキー名はテナントの転記項目定義(json_key)に従う
- valueは型定義に従い正規化した値。正規化失敗時はvalueに生文字列+normalization_failed: true
- line_itemsは列ヘッダテキスト+行×列のセル値(生文字列)。座標は含めない
"""

import uuid
from collections.abc import Sequence
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext
from app.core.errors import ApiError
from app.models import Document, DocumentType, ExtractedValue, TranscriptionField, UsageLog
from app.services.documents import get_document


async def get_output_json(session: AsyncSession, auth: AuthContext, document_id: uuid.UUID) -> dict:
    """確定済みドキュメントの出力JSONを返す(未確定は409)。取込元は問わない。"""
    document = await get_document(session, document_id)
    if document.status != "confirmed":
        raise ApiError(
            409, "not_confirmed", f"確定済みドキュメントのみ取得できます(現在: {document.status})"
        )
    document_type = await session.get(DocumentType, document.document_type_id)
    fields = (
        await session.scalars(
            select(TranscriptionField)
            .where(TranscriptionField.document_type_id == document.document_type_id)
            .order_by(TranscriptionField.sort_order)
        )
    ).all()
    values = (
        await session.scalars(
            select(ExtractedValue).where(ExtractedValue.document_id == document_id)
        )
    ).all()
    payload = build_output_json(
        document, document_type.code if document_type else "", fields, values
    )
    session.add(
        UsageLog(
            tenant_id=document.tenant_id,
            user_id=auth.user_id,
            action="export",
            resource_type="document",
            resource_id=document.id,
        )
    )
    return payload


def build_output_json(
    document: Document,
    document_type_code: str,
    fields: Sequence[TranscriptionField],
    values: Sequence[ExtractedValue],
) -> dict:
    header_values = {
        v.transcription_field_id: v for v in values if v.transcription_field_id is not None
    }
    header = {}
    for field in fields:
        value = header_values.get(field.id)
        raw = value.value_raw if value else ""
        failed = value.normalization_failed if value else False
        normalized = value.value_normalized if value else None
        if failed:
            typed = raw
        elif normalized is None:
            typed = None
        else:
            typed = _typed_value(field.value_type, normalized)
        header[field.json_key] = {
            "value": typed,
            "raw": raw,
            "normalization_failed": failed,
        }

    return {
        "document_id": str(document.id),
        "document_type": document_type_code,
        "confirmed_at": document.confirmed_at.isoformat() if document.confirmed_at else None,
        "header": header,
        "line_items": _build_line_items(document, values),
    }


def _typed_value(value_type: str, normalized: str) -> str | int | float:
    """number型はJSON数値として出力する(それ以外は正規化文字列のまま)。"""
    if value_type != "number":
        return normalized
    decimal_value = Decimal(normalized)
    if decimal_value == decimal_value.to_integral_value():
        return int(decimal_value)
    return float(decimal_value)


def _build_line_items(document: Document, values: Sequence[ExtractedValue]) -> dict | None:
    """明細領域が未選択(または明細なしの書類)の場合はnull。"""
    if document.line_item_table is None:
        return None
    columns = document.line_item_table["columns"]

    cells_by_row: dict[int, dict[int, ExtractedValue]] = {}
    for value in values:
        if value.row_no is None or value.column_no is None:
            continue
        cells_by_row.setdefault(value.row_no, {})[value.column_no] = value

    rows = []
    for row_no in sorted(cells_by_row):
        row_cells = cells_by_row[row_no]
        page_no = next(
            (cell.page_no for cell in row_cells.values() if cell.page_no is not None), None
        )
        rows.append(
            {
                "page_no": page_no,
                "cells": [
                    row_cells[column["column_no"]].value_raw
                    if column["column_no"] in row_cells
                    else ""
                    for column in columns
                ],
            }
        )
    return {"columns": columns, "rows": rows}
