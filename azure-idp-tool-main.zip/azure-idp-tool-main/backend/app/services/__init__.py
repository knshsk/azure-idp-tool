"""業務ロジック層。routers から呼ばれ、models / clients を組み合わせる。"""
