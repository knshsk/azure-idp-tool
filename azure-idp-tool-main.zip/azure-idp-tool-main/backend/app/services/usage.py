"""月次利用状況の集計(api-design.md「管理・計測」)。

DIコール数・ページ数はdi_call_logsの集計(課金根拠)。
APIリクエスト数はapi_request_countersの集計(core/usage_counter.pyが計上)。
集計タイムゾーンはJST固定【仮: テナント別タイムゾーンは要件化されたら検討】。
"""

import re
from datetime import UTC, datetime, timedelta, timezone

from sqlalchemy import Date, cast, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import ApiError
from app.models import ApiRequestCounter, DiCallLog

JST = timezone(timedelta(hours=9))

_MONTH_RE = re.compile(r"^(\d{4})-(\d{2})$")


def parse_month(month: str) -> tuple[datetime, datetime]:
    """'YYYY-MM' をJSTの月初〜翌月初の期間(UTC aware)に変換する。"""
    match = _MONTH_RE.match(month)
    if not match:
        raise ApiError(400, "invalid_month", "monthはYYYY-MM形式で指定してください")
    year, month_no = int(match.group(1)), int(match.group(2))
    if not 1 <= month_no <= 12:
        raise ApiError(400, "invalid_month", "monthはYYYY-MM形式で指定してください")
    start = datetime(year, month_no, 1, tzinfo=JST)
    if month_no == 12:
        end = datetime(year + 1, 1, 1, tzinfo=JST)
    else:
        end = datetime(year, month_no + 1, 1, tzinfo=JST)
    return start.astimezone(UTC), end.astimezone(UTC)


async def get_summary(session: AsyncSession, month: str) -> dict:
    start, end = parse_month(month)
    day = cast(func.timezone("Asia/Tokyo", DiCallLog.created_at), Date)
    di_rows = (
        await session.execute(
            select(
                day.label("day"),
                func.count().label("di_calls"),
                func.coalesce(func.sum(DiCallLog.pages), 0).label("di_pages"),
            )
            .where(DiCallLog.created_at >= start, DiCallLog.created_at < end)
            .group_by(day)
            .order_by(day)
        )
    ).all()

    # api_request_countersのdayは計上時点でJSTの日付に丸めてあるため、
    # ここでは期間の端をJSTの日付に戻して比較する
    api_rows = (
        await session.execute(
            select(ApiRequestCounter.day, ApiRequestCounter.count).where(
                ApiRequestCounter.day >= start.astimezone(JST).date(),
                ApiRequestCounter.day < end.astimezone(JST).date(),
            )
        )
    ).all()

    di_by_day = {row.day: row for row in di_rows}
    api_by_day = {row.day: row.count for row in api_rows}

    days = [
        {
            "date": d.isoformat(),
            "api_requests": api_by_day.get(d, 0),
            "di_calls": di_by_day[d].di_calls if d in di_by_day else 0,
            "di_pages": di_by_day[d].di_pages if d in di_by_day else 0,
        }
        # DIコールがあった日とAPIリクエストがあった日は一致しないため和集合を取る
        for d in sorted(di_by_day.keys() | api_by_day.keys())
    ]

    return {
        "month": month,
        "api_requests": sum(d["api_requests"] for d in days),
        "di_calls": sum(d["di_calls"] for d in days),
        "di_pages": sum(d["di_pages"] for d in days),
        "days": days,
    }
