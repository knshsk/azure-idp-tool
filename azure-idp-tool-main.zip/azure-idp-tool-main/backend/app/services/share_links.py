"""共有URLの発行・一覧・失効。

発行・一覧・失効はバッチAPI経由のみ(api-design.md)。バッチ経路の認証は
テナント単位のサービスアカウント(OAuth2クライアントクレデンシャル)で、
トークンはユーザを指さないため発行者ユーザは持たず、監査はusage_logsで行う。
トークンは256bit(要件128bit以上)、DBにはSHA-256ハッシュのみ保存する。
"""

import hashlib
import secrets
import uuid
from collections.abc import Sequence
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext
from app.core.errors import ApiError
from app.models import ShareLink, UsageLog
from app.services.documents import get_document

_TOKEN_BYTES = 32  # token_urlsafeの引数はバイト数(=256bit)


def hash_token(token: str) -> str:
    """共有トークンの保存用ハッシュ。検証側(共有ビューAPI)もこの関数を使うこと。"""
    return hashlib.sha256(token.encode()).hexdigest()


def link_status(link: ShareLink) -> str:
    if link.revoked_at is not None:
        return "revoked"
    if link.expires_at <= datetime.now(UTC):
        return "expired"
    return "active"


async def create_share_link(
    session: AsyncSession, auth: AuthContext, document_id: uuid.UUID, expires_in_hours: int
) -> tuple[ShareLink, str]:
    """共有URLを発行する。戻り値: (リンク, トークン平文)。

    トークン平文はこの応答にのみ含め、以後取得する手段はない。
    """
    document = await get_document(session, document_id)
    token = secrets.token_urlsafe(_TOKEN_BYTES)
    link = ShareLink(
        tenant_id=document.tenant_id,
        document_id=document.id,
        token_hash=hash_token(token),
        expires_at=datetime.now(UTC) + timedelta(hours=expires_in_hours),
    )
    session.add(link)
    session.add(
        UsageLog(
            tenant_id=document.tenant_id,
            user_id=auth.user_id,
            action="share_create",
            resource_type="document",
            resource_id=document.id,
        )
    )
    await session.flush()
    return link, token


async def list_share_links(session: AsyncSession, document_id: uuid.UUID) -> Sequence[ShareLink]:
    await get_document(session, document_id)
    rows = await session.scalars(
        select(ShareLink)
        .where(ShareLink.document_id == document_id)
        .order_by(ShareLink.created_at.desc())
    )
    return rows.all()


async def revoke_share_link(
    session: AsyncSession, auth: AuthContext, share_link_id: uuid.UUID
) -> None:
    """失効(冪等: 失効済みへの再実行も成功扱い)。"""
    link = await session.get(ShareLink, share_link_id)
    if link is None:
        raise ApiError(404, "share_link_not_found", "指定された共有URLが見つかりません")
    if link.revoked_at is None:
        link.revoked_at = datetime.now(UTC)
        session.add(
            UsageLog(
                tenant_id=link.tenant_id,
                user_id=auth.user_id,
                action="share_revoke",
                resource_type="share_link",
                resource_id=link.id,
            )
        )
