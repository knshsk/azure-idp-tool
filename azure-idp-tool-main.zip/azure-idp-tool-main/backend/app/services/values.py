"""転記値(候補〜確定)の照会・更新と明細領域の選択。

ヘッダ項目は transcription_field_id、明細セルは row_no + column_no で識別する
(data-model.md)。
"""

import json
import uuid
from collections.abc import Sequence

from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import blob
from app.core.errors import ApiError
from app.models import Document, ExtractedValue, TranscriptionField
from app.services import di_result
from app.services.documents import get_document
from app.services.normalize import normalize_value


async def list_values(session: AsyncSession, document_id: uuid.UUID) -> Sequence[ExtractedValue]:
    await get_document(session, document_id)
    rows = await session.scalars(
        select(ExtractedValue)
        .where(ExtractedValue.document_id == document_id)
        # ヘッダ項目(row_no NULL)→明細セル(行・列順)
        .order_by(
            ExtractedValue.row_no.asc().nulls_first(),
            ExtractedValue.column_no.asc().nulls_first(),
            ExtractedValue.updated_at.asc(),
        )
    )
    return rows.all()


async def update_values(
    session: AsyncSession, document_id: uuid.UUID, items: list[dict]
) -> Sequence[ExtractedValue]:
    """転記値の一括更新(手動修正)。manually_editedを記録する。

    itemsの各要素: {"transcription_field_id": ...} または {"row_no": .., "column_no": ..}
    のどちらかで対象を指定し、"value_raw" に新しい値を入れる。
    """
    document = await get_document(session, document_id)
    if document.status == "confirmed":
        raise ApiError(409, "already_confirmed", "確定済みドキュメントの転記値は変更できません")

    for item in items:
        if item.get("transcription_field_id") is not None:
            await _update_header_value(session, document, item)
        else:
            await _update_cell_value(session, document, item)
    return await list_values(session, document_id)


async def _update_header_value(session: AsyncSession, document: Document, item: dict) -> None:
    field = await session.get(TranscriptionField, item["transcription_field_id"])
    if field is None or field.document_type_id != document.document_type_id:
        raise ApiError(
            400, "invalid_transcription_field", "この書類種別に属さない転記項目が指定されました"
        )
    value_raw = item["value_raw"]
    value_normalized, normalization_failed = normalize_value(field.value_type, value_raw)
    stmt = insert(ExtractedValue).values(
        tenant_id=document.tenant_id,
        document_id=document.id,
        transcription_field_id=field.id,
        value_raw=value_raw,
        value_normalized=value_normalized,
        normalization_failed=normalization_failed,
        manually_edited=True,
    )
    # 既存候補がある場合は値のみ上書きし、抽出元座標(page_no/bbox)は保持する
    stmt = stmt.on_conflict_do_update(
        index_elements=["document_id", "transcription_field_id"],
        index_where=ExtractedValue.transcription_field_id.isnot(None),
        set_={
            "value_raw": value_raw,
            "value_normalized": value_normalized,
            "normalization_failed": normalization_failed,
            "manually_edited": True,
        },
    )
    await session.execute(stmt)


async def _update_cell_value(session: AsyncSession, document: Document, item: dict) -> None:
    """明細セルの値修正。明細セルは正規化しない(data-model.md)。"""
    if document.line_item_table is None:
        raise ApiError(409, "line_item_table_not_selected", "明細領域が選択されていません")
    value_raw = item["value_raw"]
    stmt = insert(ExtractedValue).values(
        tenant_id=document.tenant_id,
        document_id=document.id,
        row_no=item["row_no"],
        column_no=item["column_no"],
        value_raw=value_raw,
        manually_edited=True,
    )
    stmt = stmt.on_conflict_do_update(
        index_elements=["document_id", "row_no", "column_no"],
        index_where=ExtractedValue.row_no.isnot(None),
        set_={"value_raw": value_raw, "manually_edited": True},
    )
    await session.execute(stmt)


async def select_line_item_table(
    session: AsyncSession, document_id: uuid.UUID, page_no: int, table_index: int
) -> tuple[Document, Sequence[ExtractedValue]]:
    """明細領域の選択。DI検出テーブルから明細セルをextracted_valuesへ取り込む。

    再選択時は既存の明細セル(手動修正を含む)を破棄して取り込み直す。
    """
    document = await get_document(session, document_id)
    if document.status == "confirmed":
        raise ApiError(409, "already_confirmed", "確定済みドキュメントは変更できません")
    if document.layout_blob_path is None:
        raise ApiError(409, "not_analyzed", "解析が完了していません")

    raw = json.loads(await blob.download_bytes(document.tenant_id, document.layout_blob_path))
    try:
        table = di_result.extract_table_cells(raw, table_index)
    except IndexError:
        raise ApiError(404, "table_not_found", "指定されたテーブルが見つかりません") from None
    if table["page_no"] != page_no:
        raise ApiError(400, "page_mismatch", "指定ページに該当テーブルがありません")

    document.line_item_table = {
        "page_no": table["page_no"],
        "table_index": table_index,
        "columns": table["columns"],
    }
    await session.execute(
        delete(ExtractedValue).where(
            ExtractedValue.document_id == document_id,
            ExtractedValue.row_no.isnot(None),
        )
    )
    for row in table["rows"]:
        for cell in row["cells"]:
            session.add(
                ExtractedValue(
                    tenant_id=document.tenant_id,
                    document_id=document_id,
                    row_no=row["row_no"],
                    column_no=cell["column_no"],
                    page_no=cell["page_no"],
                    bbox=cell["bbox"],
                    value_raw=cell["value_raw"],
                )
            )
    await session.flush()
    cells = await session.scalars(
        select(ExtractedValue)
        .where(ExtractedValue.document_id == document_id, ExtractedValue.row_no.isnot(None))
        .order_by(ExtractedValue.row_no, ExtractedValue.column_no)
    )
    return document, cells.all()
