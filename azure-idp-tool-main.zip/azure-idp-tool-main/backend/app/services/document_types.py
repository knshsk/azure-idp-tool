"""書類種別・転記項目定義の管理(tenant_adminのみ)。"""

import uuid
from collections.abc import Sequence

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext
from app.core.errors import ApiError
from app.models import DocumentType, TranscriptionField


async def get_document_type(session: AsyncSession, document_type_id: uuid.UUID) -> DocumentType:
    document_type = await session.get(DocumentType, document_type_id)
    if document_type is None:
        raise ApiError(404, "document_type_not_found", "指定された書類種別が見つかりません")
    return document_type


async def create_document_type(
    session: AsyncSession, auth: AuthContext, *, code: str, name: str
) -> DocumentType:
    await _ensure_code_unique(session, code)
    document_type = DocumentType(tenant_id=auth.tenant_id, code=code, name=name)
    session.add(document_type)
    await session.flush()
    return document_type


async def update_document_type(
    session: AsyncSession, document_type_id: uuid.UUID, *, code: str, name: str
) -> DocumentType:
    document_type = await get_document_type(session, document_type_id)
    if code != document_type.code:
        await _ensure_code_unique(session, code)
    document_type.code = code
    document_type.name = name
    return document_type


async def delete_document_type(session: AsyncSession, document_type_id: uuid.UUID) -> None:
    """削除。所属ドキュメントや転記値が存在する場合は削除できない(FK RESTRICT)。"""
    document_type = await get_document_type(session, document_type_id)
    try:
        await session.delete(document_type)
        await session.flush()
    except IntegrityError:
        raise ApiError(
            409,
            "document_type_in_use",
            "この書類種別はドキュメントで使用されているため削除できません",
        ) from None


async def sync_fields(
    session: AsyncSession, document_type_id: uuid.UUID, items: list[dict]
) -> Sequence[TranscriptionField]:
    """転記項目定義の一括更新(追加・更新・削除を差分同期)。

    itemsに含まれない既存項目は削除する。転記値が残っている項目の削除は
    FK RESTRICTにより拒否される(過去の確定済みドキュメントとの互換性保護)。
    """
    document_type = await get_document_type(session, document_type_id)
    existing = {
        field.id: field
        for field in (
            await session.scalars(
                select(TranscriptionField).where(
                    TranscriptionField.document_type_id == document_type_id
                )
            )
        ).all()
    }

    incoming_ids = {item["id"] for item in items if item.get("id") is not None}
    unknown_ids = incoming_ids - existing.keys()
    if unknown_ids:
        raise ApiError(400, "invalid_field_id", "この書類種別に属さない転記項目IDが含まれています")

    try:
        # 先に削除を確定させる(json_keyの付け替えとの衝突を減らす)
        for field_id, field in existing.items():
            if field_id not in incoming_ids:
                await session.delete(field)
        await session.flush()

        for item in items:
            if item.get("id") is not None:
                field = existing[item["id"]]
                field.json_key = item["json_key"]
                field.label_ja = item["label_ja"]
                field.value_type = item["value_type"]
                field.query_field_key = item["query_field_key"]
                field.sort_order = item["sort_order"]
            else:
                session.add(
                    TranscriptionField(
                        tenant_id=document_type.tenant_id,
                        document_type_id=document_type_id,
                        json_key=item["json_key"],
                        label_ja=item["label_ja"],
                        value_type=item["value_type"],
                        query_field_key=item["query_field_key"],
                        sort_order=item["sort_order"],
                    )
                )
        await session.flush()
    except IntegrityError as exc:
        message = str(exc.orig)
        if "uq_transcription_fields" in message:
            raise ApiError(409, "duplicate_json_key", "JSONキーが重複しています") from None
        raise ApiError(
            409,
            "field_in_use",
            "転記値が存在する項目は削除できません(確定済みドキュメントとの互換性保護)",
        ) from None

    rows = await session.scalars(
        select(TranscriptionField)
        .where(TranscriptionField.document_type_id == document_type_id)
        .order_by(TranscriptionField.sort_order)
    )
    return rows.all()


async def _ensure_code_unique(session: AsyncSession, code: str) -> None:
    duplicate = await session.scalar(select(DocumentType).where(DocumentType.code == code))
    if duplicate is not None:
        raise ApiError(409, "duplicate_code", f"コード '{code}' は既に使用されています")
