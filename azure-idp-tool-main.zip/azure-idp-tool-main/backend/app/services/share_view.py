"""共有ビュー(認証なし経路)のトークン検証とデータ取得。

セキュリティ要件(azure-architecture_v2.md §3.1 #5):
- トークンはハッシュでDB照合(提示値の内容がタイミングに現れない)
- 不存在・失効・期限切れは同一エラー(存在有無を推測させない)
- 検証失敗のIP単位レート制限+失敗ログ
"""

import logging
import time
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import text as sql_text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import set_tenant_context
from app.core.errors import ApiError
from app.models import Document, UsageLog
from app.services.share_links import hash_token

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ShareContext:
    tenant_id: uuid.UUID
    document: Document
    expires_at: datetime


class FailureRateLimiter:
    """トークン検証失敗のIP単位レート制限(簡易・インメモリ)。

    本番の主防御はAPIM/Front Doorのレート制限で、これは多層防御の最後の砦。
    インメモリのためレプリカ単位の制限になる点は許容する。
    """

    def __init__(self, max_failures: int = 10, window_seconds: int = 300) -> None:
        self.max_failures = max_failures
        self.window_seconds = window_seconds
        # ip -> (ウィンドウ開始時刻, 失敗回数)
        self._failures: dict[str, tuple[float, int]] = {}

    def is_blocked(self, ip: str, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        entry = self._failures.get(ip)
        if entry is None:
            return False
        window_start, count = entry
        if now - window_start > self.window_seconds:
            del self._failures[ip]
            return False
        return count >= self.max_failures

    def record_failure(self, ip: str, now: float | None = None) -> None:
        now = time.monotonic() if now is None else now
        entry = self._failures.get(ip)
        if entry is None or now - entry[0] > self.window_seconds:
            self._failures[ip] = (now, 1)
        else:
            self._failures[ip] = (entry[0], entry[1] + 1)


_limiter = FailureRateLimiter()


def _invalid() -> ApiError:
    # 不存在・失効・期限切れを区別しない(存在有無を推測させない)
    return ApiError(404, "invalid_share_link", "このURLは無効です")


async def resolve_document(session: AsyncSession, token: str, client_ip: str) -> ShareContext:
    """共有トークンを検証し、対象ドキュメントを返す。

    検証成功時はセッションにテナントコンテキストを設定済みの状態で返す。
    """
    if _limiter.is_blocked(client_ip):
        raise ApiError(
            429, "too_many_requests", "リクエストが多すぎます。しばらく待って再試行してください"
        )

    # RLS外の専用検索経路(SECURITY DEFINER関数。マイグレーション0002)
    row = (
        await session.execute(
            sql_text("SELECT * FROM lookup_share_link(:token_hash)"),
            {"token_hash": hash_token(token)},
        )
    ).one_or_none()

    if row is None or row.revoked_at is not None or row.expires_at <= datetime.now(UTC):
        _limiter.record_failure(client_ip)
        logger.warning("share token validation failed", extra={"client_ip": client_ip})
        raise _invalid()

    await set_tenant_context(session, row.tenant_id)
    document = await session.get(Document, row.document_id)
    if document is None:
        _limiter.record_failure(client_ip)
        raise _invalid()
    return ShareContext(tenant_id=row.tenant_id, document=document, expires_at=row.expires_at)


async def record_access(session: AsyncSession, tenant_id: uuid.UUID, document: Document) -> None:
    """共有ビューへのアクセスを利用ログに記録する(受領者は匿名のためuser_idなし)。"""
    session.add(
        UsageLog(
            tenant_id=tenant_id,
            user_id=None,
            action="share_access",
            resource_type="document",
            resource_id=document.id,
        )
    )
