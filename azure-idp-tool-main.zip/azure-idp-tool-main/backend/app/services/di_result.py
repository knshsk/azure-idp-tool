"""DI解析結果(生JSON)からの抽出と座標正規化。

座標はページサイズで正規化した0〜1の {x0, y0, x1, y1} で扱う(data-model.md)。
DIのpolygonはページ単位(PDFはインチ)の [x1,y1, x2,y2, x3,y3, x4,y4] 形式。
"""


def polygon_to_bbox(polygon: list[float], page_width: float, page_height: float) -> dict:
    """DIのpolygonを正規化bboxへ変換する。"""
    xs = polygon[0::2]
    ys = polygon[1::2]
    return {
        "x0": min(xs) / page_width,
        "y0": min(ys) / page_height,
        "x1": max(xs) / page_width,
        "y1": max(ys) / page_height,
    }


def extract_layout_overlay(raw: dict) -> dict:
    """Layout解析結果をオーバレイ描画用データへ整形する(GET /documents/{id}/analysis)。

    戻り値: {
      "pages": [{page_no, words: [{content, bbox}], lines: [{content, bbox}]}],
      "tables": [{table_index, page_no, row_count, column_count, bbox,
                  cells: [{row, column, kind, content, page_no, bbox}]}],
    }
    """
    page_dims: dict[int, tuple[float, float]] = {}
    pages_out = []
    for page in raw.get("pages", []):
        page_no = page["pageNumber"]
        width, height = page["width"], page["height"]
        page_dims[page_no] = (width, height)
        pages_out.append(
            {
                "page_no": page_no,
                "words": [
                    {
                        "content": w.get("content", ""),
                        "bbox": polygon_to_bbox(w["polygon"], width, height),
                    }
                    for w in page.get("words", [])
                    if w.get("polygon")
                ],
                "lines": [
                    {
                        "content": ln.get("content", ""),
                        "bbox": polygon_to_bbox(ln["polygon"], width, height),
                    }
                    for ln in page.get("lines", [])
                    if ln.get("polygon")
                ],
            }
        )

    tables_out = []
    for table_index, table in enumerate(raw.get("tables", [])):
        region = (table.get("boundingRegions") or [{}])[0]
        tables_out.append(
            {
                "table_index": table_index,
                "page_no": region.get("pageNumber"),
                "row_count": table.get("rowCount", 0),
                "column_count": table.get("columnCount", 0),
                "bbox": _region_bbox(region, page_dims),
                "cells": [
                    {
                        "row": cell.get("rowIndex", 0),
                        "column": cell.get("columnIndex", 0),
                        "kind": cell.get("kind", "content"),
                        "content": cell.get("content", ""),
                        "page_no": (cell.get("boundingRegions") or [{}])[0].get("pageNumber"),
                        "bbox": _region_bbox((cell.get("boundingRegions") or [{}])[0], page_dims),
                    }
                    for cell in table.get("cells", [])
                ],
            }
        )
    return {"pages": pages_out, "tables": tables_out}


def extract_table_cells(raw: dict, table_index: int) -> dict:
    """指定テーブルを明細取り込み用に整形する(PUT /documents/{id}/line-item-table)。

    列ヘッダ行(kind=columnHeader)を列定義とし、残りをデータ行として0始まりで
    振り直す。列⇔転記項目の対応付けは行わない(業務システム側の責務)。

    戻り値: {page_no, columns: [{column_no, header_text}],
             rows: [{row_no, cells: [{column_no, value_raw, page_no, bbox}]}]}
    """
    tables = raw.get("tables", [])
    if not 0 <= table_index < len(tables):
        raise IndexError(f"table_index {table_index} out of range (tables={len(tables)})")
    table = tables[table_index]
    page_dims = {p["pageNumber"]: (p["width"], p["height"]) for p in raw.get("pages", [])}

    header_rows = {
        cell.get("rowIndex", 0)
        for cell in table.get("cells", [])
        if cell.get("kind") == "columnHeader"
    }
    header_texts: dict[int, list[str]] = {}
    data_rows: dict[int, dict[int, dict]] = {}
    for cell in table.get("cells", []):
        row = cell.get("rowIndex", 0)
        column = cell.get("columnIndex", 0)
        if row in header_rows:
            if cell.get("kind") == "columnHeader" and cell.get("content"):
                header_texts.setdefault(column, []).append(cell["content"])
            continue
        region = (cell.get("boundingRegions") or [{}])[0]
        data_rows.setdefault(row, {})[column] = {
            "value_raw": cell.get("content", ""),
            "page_no": region.get("pageNumber"),
            "bbox": _region_bbox(region, page_dims),
        }

    columns = [
        {"column_no": column, "header_text": " ".join(header_texts.get(column, []))}
        for column in range(table.get("columnCount", 0))
    ]
    rows = [
        {
            "row_no": row_no,
            "cells": [
                {"column_no": column, **data_rows[original_row][column]}
                for column in sorted(data_rows[original_row])
            ],
        }
        for row_no, original_row in enumerate(sorted(data_rows))
    ]
    region0 = (table.get("boundingRegions") or [{}])[0]
    return {"page_no": region0.get("pageNumber"), "columns": columns, "rows": rows}


def _region_bbox(region: dict, page_dims: dict[int, tuple[float, float]]) -> dict | None:
    dims = page_dims.get(region.get("pageNumber"))
    if not dims or not region.get("polygon"):
        return None
    return polygon_to_bbox(region["polygon"], dims[0], dims[1])


def extract_query_fields(raw: dict) -> dict[str, dict]:
    """Query Fields結果を {query_field_key: {value_raw, page_no, bbox}} へ整形する。

    documents.query_fields_result にそのまま保存し、ヘッダ項目候補のINSERT元にもなる。
    """
    pages = {p["pageNumber"]: p for p in raw.get("pages", [])}
    result: dict[str, dict] = {}
    for document in raw.get("documents") or []:
        for key, field in (document.get("fields") or {}).items():
            content = field.get("content") or field.get("valueString") or ""
            page_no = None
            bbox = None
            regions = field.get("boundingRegions") or []
            if regions:
                region = regions[0]
                page_no = region.get("pageNumber")
                page = pages.get(page_no)
                if page and region.get("polygon"):
                    bbox = polygon_to_bbox(region["polygon"], page["width"], page["height"])
            result[key] = {"value_raw": content, "page_no": page_no, "bbox": bbox}
    return result
