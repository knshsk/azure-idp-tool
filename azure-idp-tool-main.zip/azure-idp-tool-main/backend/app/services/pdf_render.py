"""PDF→ページPNG変換(pypdfium2)。

生成タイミングは解析ジョブ冒頭(ワーカー)。アップロード受付時に同期生成すると
大容量PDF(上限500MB・2,000ページ)で応答をブロックするため(blob-storage.md)。
"""

import io

import pypdfium2 as pdfium

from app.config import settings


def render_pages(pdf_bytes: bytes) -> list[tuple[dict, bytes]]:
    """各ページを [(documents.pages要素, PNGバイト列)] で返す。page_noは1始まり。"""
    document = pdfium.PdfDocument(pdf_bytes)
    try:
        results: list[tuple[dict, bytes]] = []
        scale = settings.png_render_dpi / 72  # PDFポイント(1/72インチ)→指定DPI
        for index, page in enumerate(document):
            image = page.render(scale=scale).to_pil()
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
            results.append(
                (
                    {"page_no": index + 1, "width_px": image.width, "height_px": image.height},
                    buffer.getvalue(),
                )
            )
        return results
    finally:
        document.close()
