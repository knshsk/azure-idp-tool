"""ドキュメントの業務ロジック(アップロード・照会・解析指示・確定・削除)。"""

import hashlib
import json
import logging
import uuid
from collections.abc import Sequence
from datetime import UTC, datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import blob, queue
from app.config import settings
from app.core.auth import AuthContext
from app.core.errors import ApiError
from app.models import Document, DocumentType, UsageLog
from app.services import di_result

logger = logging.getLogger(__name__)

PDF_MAGIC = b"%PDF-"


def validate_pdf(data: bytes) -> None:
    """アップロード検証(マジックバイト・サイズ上限)。API側で必ず実施する。"""
    if not data.startswith(PDF_MAGIC):
        raise ApiError(400, "invalid_file", "PDFファイルではありません")
    max_bytes = settings.max_upload_size_mb * 1024 * 1024
    if len(data) > max_bytes:
        raise ApiError(
            413,
            "file_too_large",
            f"ファイルサイズ上限({settings.max_upload_size_mb}MB)を超えています",
        )


async def upload_document(
    session: AsyncSession,
    auth: AuthContext,
    *,
    file_name: str,
    data: bytes,
    document_type_id: uuid.UUID,
    source: str,
    queue_name: str | None = None,
) -> tuple[Document, bool]:
    """アップロードを受け付け、解析キュー投入まで行う。

    戻り値: (ドキュメント, 新規作成か)。
    ハッシュ重複時は既存ドキュメントと False を返す(api-design.md【仮】)。
    """
    validate_pdf(data)

    document_type = await session.get(DocumentType, document_type_id)
    if document_type is None:
        raise ApiError(404, "document_type_not_found", "指定された書類種別が見つかりません")

    file_hash = hashlib.sha256(data).hexdigest()
    existing = await session.scalar(select(Document).where(Document.file_hash == file_hash))
    if existing is not None:
        return existing, False

    document = Document(
        id=uuid.uuid4(),
        tenant_id=auth.tenant_id,
        document_type_id=document_type_id,
        status="uploaded",
        file_name=file_name,
        file_hash=file_hash,
        source=source,
        uploaded_by=auth.user_id,
    )
    # Blobを先に格納し、DB行がコミットされた時点で原本の存在を保証する
    await blob.upload_original_pdf(auth.tenant_id, document.id, data)

    session.add(document)
    session.add(
        UsageLog(
            tenant_id=auth.tenant_id,
            user_id=auth.user_id,
            action="upload",
            resource_type="document",
            resource_id=document.id,
        )
    )
    # キュー投入前にコミットする(ワーカーがメッセージ受信時に行を読めるようにする)。
    # コミット後はRLSコンテキストが消えるため、以降このセッションでDBを触らないこと
    await session.commit()

    try:
        await queue.enqueue_analysis(
            queue_name or settings.service_bus_queue_interactive, document.id, auth.tenant_id
        )
    except Exception:
        # 投入失敗してもアップロード自体は成立している。uploaded滞留の回収処理
        # (未実装)で再投入する前提とし、ここでは失敗を記録するに留める
        logger.exception(
            "failed to enqueue analysis",
            extra={"tenant_id": str(auth.tenant_id), "document_id": str(document.id)},
        )
    return document, True


async def list_documents(
    session: AsyncSession,
    *,
    status: str | None,
    document_type_id: uuid.UUID | None,
    source: str | None,
    created_from: datetime | None,
    created_to: datetime | None,
    page: int,
    per_page: int,
) -> tuple[Sequence[Document], int]:
    """一覧(RLSによりテナント内のみ)。戻り値: (対象ページの行, 総件数)。"""
    stmt = select(Document)
    if status is not None:
        stmt = stmt.where(Document.status == status)
    if document_type_id is not None:
        stmt = stmt.where(Document.document_type_id == document_type_id)
    if source is not None:
        stmt = stmt.where(Document.source == source)
    if created_from is not None:
        stmt = stmt.where(Document.created_at >= created_from)
    if created_to is not None:
        stmt = stmt.where(Document.created_at <= created_to)

    total = await session.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = await session.scalars(
        stmt.order_by(Document.created_at.desc()).limit(per_page).offset((page - 1) * per_page)
    )
    return rows.all(), total or 0


async def get_document(session: AsyncSession, document_id: uuid.UUID) -> Document:
    document = await session.get(Document, document_id)
    if document is None:
        raise ApiError(404, "document_not_found", "指定されたドキュメントが見つかりません")
    return document


async def request_analysis(session: AsyncSession, document_id: uuid.UUID) -> Document:
    """解析実行(interactiveキュー投入)。解析中・解析済み・確定済みは409。"""
    document = await get_document(session, document_id)
    if document.status in ("analyzing", "analyzed", "confirmed"):
        raise ApiError(
            409, "already_analyzed", f"このドキュメントは解析できない状態です({document.status})"
        )
    await queue.enqueue_analysis(
        settings.service_bus_queue_interactive, document.id, document.tenant_id
    )
    return document


async def get_analysis_overlay(session: AsyncSession, document_id: uuid.UUID) -> dict:
    """オーバレイ用データ(Layoutの単語/行/テーブル+Query Fields結果。正規化座標)。"""
    document = await get_document(session, document_id)
    if document.layout_blob_path is None:
        raise ApiError(409, "not_analyzed", "解析が完了していません")
    # TODO: layout.jsonは大きくなり得る(数千ページ)。性能検証時にページ単位の
    #   分割取得やキャッシュを検討する
    raw = json.loads(await blob.download_bytes(document.tenant_id, document.layout_blob_path))
    return {
        "pages": document.pages,
        "layout": di_result.extract_layout_overlay(raw),
        "query_fields": document.query_fields_result,
    }


async def get_page_image(session: AsyncSession, document_id: uuid.UUID, page_no: int) -> bytes:
    """ページPNGを返す(パスは命名規約から導出)。"""
    document = await get_document(session, document_id)
    if document.page_count is None or not 1 <= page_no <= document.page_count:
        raise ApiError(404, "page_not_found", "指定されたページが見つかりません")
    return await blob.download_bytes(document.tenant_id, blob.page_image_path(document_id, page_no))


async def confirm_document(
    session: AsyncSession, auth: AuthContext, document_id: uuid.UUID
) -> Document:
    """転記項目確定(status=confirmed)。解析完了後のみ。"""
    document = await get_document(session, document_id)
    if document.status != "analyzed":
        raise ApiError(409, "not_analyzed", f"解析完了後のみ確定できます(現在: {document.status})")
    document.status = "confirmed"
    document.confirmed_at = datetime.now(UTC)
    session.add(
        UsageLog(
            tenant_id=document.tenant_id,
            user_id=auth.user_id,
            action="confirm",
            resource_type="document",
            resource_id=document.id,
        )
    )
    return document


async def delete_document(session: AsyncSession, auth: AuthContext, document_id: uuid.UUID) -> None:
    """削除(原本・ページ画像・解析結果のBlobとDBレコード)。"""
    document = await get_document(session, document_id)
    tenant_id = document.tenant_id
    deleted = await blob.delete_document_blobs(tenant_id, document_id)
    logger.info(
        "document blobs deleted: %d",
        deleted,
        extra={"tenant_id": str(tenant_id), "document_id": str(document_id)},
    )
    # extracted_values / share_links はFKのON DELETE CASCADEで消える
    await session.delete(document)
    session.add(
        UsageLog(
            tenant_id=tenant_id,
            user_id=auth.user_id,
            action="delete",
            resource_type="document",
            resource_id=document_id,
        )
    )
