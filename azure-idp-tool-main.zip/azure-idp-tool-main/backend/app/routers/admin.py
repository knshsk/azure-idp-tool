"""管理・計測API(api-design.md「管理・計測」)。

/me以外はtenant_adminのみ。
"""

from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext, get_admin_auth_context, get_auth_context
from app.core.deps import get_tenant_session
from app.core.errors import ApiError
from app.models import Tenant, User
from app.schemas.admin import MeOut, TenantSettingsIn, TenantSettingsOut, UsageSummaryOut
from app.services import usage as usage_service

router = APIRouter(tags=["admin"])

SessionDep = Annotated[AsyncSession, Depends(get_tenant_session)]
AuthDep = Annotated[AuthContext, Depends(get_auth_context)]
AdminDep = Annotated[AuthContext, Depends(get_admin_auth_context)]


@router.get("/me")
async def get_me(session: SessionDep, auth: AuthDep) -> MeOut:
    """ログインユーザ情報(ロール・テナント)。"""
    user = await session.get(User, auth.user_id) if auth.user_id else None
    if user is None:
        raise ApiError(404, "user_not_found", "ユーザが見つかりません")
    tenant = await session.get(Tenant, auth.tenant_id)
    if tenant is None:
        raise ApiError(404, "tenant_not_found", "テナントが見つかりません")
    return MeOut(
        user_id=user.id,
        display_name=user.display_name,
        email=user.email,
        role=user.role,
        tenant_id=tenant.id,
        tenant_name=tenant.name,
    )


@router.get("/usage/summary")
async def get_usage_summary(session: SessionDep, _admin: AdminDep, month: str) -> UsageSummaryOut:
    """テナントの月次利用状況(month=YYYY-MM)。

    DIコール数・ページ数はdi_call_logs集計。APIリクエスト数はAPIMメトリクスが
    源泉のため、APIM未導入の間はnull。
    """
    return UsageSummaryOut.model_validate(await usage_service.get_summary(session, month))


@router.get("/tenant/settings")
async def get_tenant_settings(session: SessionDep, _admin: AdminDep) -> TenantSettingsOut:
    tenant = await _get_tenant(session, _admin)
    return TenantSettingsOut(name=tenant.name, retention_days=tenant.retention_days)


@router.put("/tenant/settings")
async def update_tenant_settings(
    session: SessionDep, _admin: AdminDep, body: TenantSettingsIn
) -> TenantSettingsOut:
    """保持期間等の設定(tenant_adminのみ)。"""
    tenant = await _get_tenant(session, _admin)
    tenant.retention_days = body.retention_days
    return TenantSettingsOut(name=tenant.name, retention_days=tenant.retention_days)


async def _get_tenant(session: AsyncSession, auth: AuthContext) -> Tenant:
    tenant = await session.get(Tenant, auth.tenant_id)
    if tenant is None:
        raise ApiError(404, "tenant_not_found", "テナントが見つかりません")
    return tenant
