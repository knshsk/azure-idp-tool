"""共有ビューAPI(api-design.md「共有URL」)。認証なし・URLトークンのみ。

発行・一覧・失効はバッチAPI側(routers/batch.py)。ここは受領者向けの参照のみ。
"""

from typing import Annotated
from urllib.parse import quote

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients import blob
from app.core.deps import get_plain_session
from app.core.errors import ApiError
from app.schemas.share_view import ShareViewOut
from app.services import share_view as share_view_service

router = APIRouter(prefix="/share", tags=["share"])

SessionDep = Annotated[AsyncSession, Depends(get_plain_session)]


def _client_ip(request: Request) -> str:
    # 本番はAPIM/Front Door経由のためX-Forwarded-Forの先頭を優先する
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


@router.get("/{token}")
async def get_share_meta(session: SessionDep, request: Request, token: str) -> ShareViewOut:
    """共有ビュー用メタデータ。アクセスを利用ログに記録する。"""
    context = await share_view_service.resolve_document(session, token, _client_ip(request))
    await share_view_service.record_access(session, context.tenant_id, context.document)
    return ShareViewOut(
        file_name=context.document.file_name,
        page_count=context.document.page_count,
        expires_at=context.expires_at,
    )


@router.get("/{token}/pages/{page_no}/image")
async def get_share_page_image(
    session: SessionDep, request: Request, token: str, page_no: int
) -> Response:
    """ページPNG(閲覧のみ)。"""
    context = await share_view_service.resolve_document(session, token, _client_ip(request))
    document = context.document
    if document.page_count is None or not 1 <= page_no <= document.page_count:
        raise ApiError(404, "page_not_found", "指定されたページが見つかりません")
    png = await blob.download_bytes(document.tenant_id, blob.page_image_path(document.id, page_no))
    return Response(content=png, media_type="image/png")


@router.get("/{token}/download")
async def download_original(session: SessionDep, request: Request, token: str) -> Response:
    """原本PDFダウンロード。"""
    context = await share_view_service.resolve_document(session, token, _client_ip(request))
    document = context.document
    pdf = await blob.download_bytes(document.tenant_id, blob.original_pdf_path(document.id))
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(document.file_name)}"
        },
    )
