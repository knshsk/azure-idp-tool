"""エンドポイント定義(api-design.md に対応)。"""
