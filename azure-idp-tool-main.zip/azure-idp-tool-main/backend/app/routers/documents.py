"""ドキュメントAPI(api-design.md「ドキュメント」)。"""

import uuid
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Form, Query, Response, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext, get_auth_context
from app.core.deps import get_tenant_session
from app.schemas.document import DocumentOut
from app.schemas.value import (
    AnalysisOut,
    ExtractedValueOut,
    LineItemTableIn,
    LineItemTableOut,
    ValuesUpdateIn,
)
from app.services import documents as documents_service
from app.services import values as values_service

router = APIRouter(prefix="/documents", tags=["documents"])

SessionDep = Annotated[AsyncSession, Depends(get_tenant_session)]
AuthDep = Annotated[AuthContext, Depends(get_auth_context)]


@router.post("", status_code=202)
async def upload_document(
    session: SessionDep,
    auth: AuthDep,
    response: Response,
    file: UploadFile,
    document_type_id: Annotated[uuid.UUID, Form()],
) -> DocumentOut:
    """PDFアップロード。受付後にinteractiveキュー投入まで行う(202)。

    ハッシュ重複時は既存ドキュメントを200で返す【仮】。
    """
    # TODO: 大容量PDF(DI上限500MB)のストリーミング受信は性能検証時に検討
    data = await file.read()
    document, created = await documents_service.upload_document(
        session,
        auth,
        file_name=file.filename or "unknown.pdf",
        data=data,
        document_type_id=document_type_id,
        source="frontend",
    )
    if not created:
        response.status_code = 200
    return DocumentOut.model_validate(document)


@router.get("")
async def list_documents(
    session: SessionDep,
    response: Response,
    status: str | None = None,
    document_type_id: uuid.UUID | None = None,
    source: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    page: Annotated[int, Query(ge=1)] = 1,
    per_page: Annotated[int, Query(ge=1, le=100)] = 20,
) -> list[DocumentOut]:
    documents, total = await documents_service.list_documents(
        session,
        status=status,
        document_type_id=document_type_id,
        source=source,
        created_from=created_from,
        created_to=created_to,
        page=page,
        per_page=per_page,
    )
    response.headers["X-Total-Count"] = str(total)
    return [DocumentOut.model_validate(d) for d in documents]


@router.get("/{document_id}")
async def get_document(session: SessionDep, document_id: uuid.UUID) -> DocumentOut:
    document = await documents_service.get_document(session, document_id)
    return DocumentOut.model_validate(document)


@router.delete("/{document_id}", status_code=204)
async def delete_document(session: SessionDep, auth: AuthDep, document_id: uuid.UUID) -> None:
    """削除(原本・ページ画像・解析結果を含む)。"""
    await documents_service.delete_document(session, auth, document_id)


@router.get("/{document_id}/pages/{page_no}/image")
async def get_page_image(session: SessionDep, document_id: uuid.UUID, page_no: int) -> Response:
    png = await documents_service.get_page_image(session, document_id, page_no)
    return Response(content=png, media_type="image/png")


@router.post("/{document_id}/analyze", status_code=202)
async def analyze_document(session: SessionDep, document_id: uuid.UUID) -> DocumentOut:
    """解析実行(interactiveキュー投入)。解析中・解析済みなら409。"""
    document = await documents_service.request_analysis(session, document_id)
    return DocumentOut.model_validate(document)


@router.get("/{document_id}/analysis")
async def get_analysis(session: SessionDep, document_id: uuid.UUID) -> AnalysisOut:
    """オーバレイ用データ(Layoutの単語/行/テーブル・Query Fields結果。正規化座標)。"""
    return AnalysisOut.model_validate(
        await documents_service.get_analysis_overlay(session, document_id)
    )


@router.get("/{document_id}/values")
async def list_values(session: SessionDep, document_id: uuid.UUID) -> list[ExtractedValueOut]:
    values = await values_service.list_values(session, document_id)
    return [ExtractedValueOut.model_validate(v) for v in values]


@router.put("/{document_id}/values")
async def update_values(
    session: SessionDep, document_id: uuid.UUID, body: ValuesUpdateIn
) -> list[ExtractedValueOut]:
    """転記値の一括更新(手動修正はmanually_editedを記録)。"""
    values = await values_service.update_values(
        session, document_id, [item.model_dump() for item in body.values]
    )
    return [ExtractedValueOut.model_validate(v) for v in values]


@router.put("/{document_id}/line-item-table")
async def select_line_item_table(
    session: SessionDep, document_id: uuid.UUID, body: LineItemTableIn
) -> LineItemTableOut:
    """明細領域の選択。DI検出テーブルから明細セルを取り込む。"""
    document, cells = await values_service.select_line_item_table(
        session, document_id, body.page_no, body.table_index
    )
    return LineItemTableOut(
        line_item_table=document.line_item_table,
        values=[ExtractedValueOut.model_validate(c) for c in cells],
    )


@router.post("/{document_id}/confirm")
async def confirm_document(
    session: SessionDep, auth: AuthDep, document_id: uuid.UUID
) -> DocumentOut:
    """転記項目確定(status=confirmed)。"""
    document = await documents_service.confirm_document(session, auth, document_id)
    return DocumentOut.model_validate(document)
