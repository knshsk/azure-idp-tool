"""バッチAPI(api-design.md「バッチAPI」)。テナント社内システム向け。

認証はKeycloakのOAuth2クライアントクレデンシャルで取得した短命JWT(Bearer)。
テナント解決はトークンの `tenant_id` クレーム(core/auth.py の get_batch_auth_context)。
"""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Form, Query, Response, UploadFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.auth import AuthContext, get_batch_auth_context
from app.core.deps import get_batch_tenant_session
from app.core.errors import ApiError
from app.models import DocumentType
from app.schemas.document import DocumentOut
from app.schemas.share_link import ShareLinkCreatedOut, ShareLinkCreateIn, ShareLinkOut
from app.services import documents as documents_service
from app.services import export as export_service
from app.services import share_links as share_links_service

router = APIRouter(prefix="/batch", tags=["batch"])

SessionDep = Annotated[AsyncSession, Depends(get_batch_tenant_session)]
AuthDep = Annotated[AuthContext, Depends(get_batch_auth_context)]


@router.post("/documents", status_code=202)
async def upload_document(
    session: SessionDep,
    auth: AuthDep,
    response: Response,
    file: UploadFile,
    document_type_code: Annotated[str, Form()],
) -> DocumentOut:
    """PDFアップロード(batchキュー投入まで実行)。ハッシュ重複時は既存参照を200で返す【仮】。"""
    document_type = await session.scalar(
        select(DocumentType).where(DocumentType.code == document_type_code)
    )
    if document_type is None:
        raise ApiError(404, "document_type_not_found", "指定された書類種別コードが見つかりません")
    data = await file.read()
    document, created = await documents_service.upload_document(
        session,
        auth,
        file_name=file.filename or "unknown.pdf",
        data=data,
        document_type_id=document_type.id,
        source="batch",
        queue_name=settings.service_bus_queue_batch,
    )
    if not created:
        response.status_code = 200
    return DocumentOut.model_validate(document)


@router.get("/documents")
async def list_documents(
    session: SessionDep,
    response: Response,
    status: str | None = None,
    page: Annotated[int, Query(ge=1)] = 1,
    per_page: Annotated[int, Query(ge=1, le=100)] = 20,
) -> list[DocumentOut]:
    """一覧+処理状況(ポーリング用)。"""
    documents, total = await documents_service.list_documents(
        session,
        status=status,
        document_type_id=None,
        source=None,
        created_from=None,
        created_to=None,
        page=page,
        per_page=per_page,
    )
    response.headers["X-Total-Count"] = str(total)
    return [DocumentOut.model_validate(d) for d in documents]


@router.get("/documents/{document_id}")
async def get_document(session: SessionDep, document_id: uuid.UUID) -> DocumentOut:
    """個別の処理状況。"""
    document = await documents_service.get_document(session, document_id)
    return DocumentOut.model_validate(document)


@router.get("/documents/{document_id}/json")
async def get_document_json(session: SessionDep, auth: AuthDep, document_id: uuid.UUID) -> dict:
    """確定済みドキュメントの出力JSON(未確定は409)。取込元を問わず取得可能。"""
    return await export_service.get_output_json(session, auth, document_id)


@router.post("/documents/{document_id}/share-links", status_code=201)
async def create_share_link(
    session: SessionDep, auth: AuthDep, document_id: uuid.UUID, body: ShareLinkCreateIn
) -> ShareLinkCreatedOut:
    """共有URL発行。トークン平文はこの応答にのみ含める。"""
    link, token = await share_links_service.create_share_link(
        session, auth, document_id, body.expires_in_hours
    )
    return ShareLinkCreatedOut(
        id=link.id,
        url=f"{settings.share_base_url.rstrip('/')}/{token}",
        expires_at=link.expires_at,
    )


@router.get("/documents/{document_id}/share-links")
async def list_share_links(session: SessionDep, document_id: uuid.UUID) -> list[ShareLinkOut]:
    """発行済み一覧(有効/失効/期限切れ)。"""
    links = await share_links_service.list_share_links(session, document_id)
    return [
        ShareLinkOut(
            id=link.id,
            status=share_links_service.link_status(link),  # type: ignore[arg-type]
            expires_at=link.expires_at,
            revoked_at=link.revoked_at,
            created_at=link.created_at,
        )
        for link in links
    ]


@router.delete("/share-links/{share_link_id}", status_code=204)
async def revoke_share_link(session: SessionDep, auth: AuthDep, share_link_id: uuid.UUID) -> None:
    """失効(冪等)。"""
    await share_links_service.revoke_share_link(session, auth, share_link_id)
