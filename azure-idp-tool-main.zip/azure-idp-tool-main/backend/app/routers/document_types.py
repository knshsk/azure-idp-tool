"""書類種別・転記項目定義API(api-design.md)。

参照系は全ユーザ、作成・更新・削除はtenant_adminのみ。
"""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext, get_admin_auth_context
from app.core.deps import get_tenant_session
from app.core.errors import ApiError
from app.models import DocumentType, TranscriptionField
from app.schemas.admin import DocumentTypeCreateIn, FieldsUpdateIn
from app.schemas.document_type import DocumentTypeOut, TranscriptionFieldOut
from app.services import document_types as document_types_service

router = APIRouter(prefix="/document-types", tags=["document-types"])

SessionDep = Annotated[AsyncSession, Depends(get_tenant_session)]
AdminDep = Annotated[AuthContext, Depends(get_admin_auth_context)]


@router.get("")
async def list_document_types(session: SessionDep) -> list[DocumentTypeOut]:
    rows = await session.scalars(select(DocumentType).order_by(DocumentType.created_at))
    return [DocumentTypeOut.model_validate(r) for r in rows.all()]


@router.post("", status_code=201)
async def create_document_type(
    session: SessionDep, admin: AdminDep, body: DocumentTypeCreateIn
) -> DocumentTypeOut:
    """作成(tenant_adminのみ)。codeはバッチAPIのdocument_type_codeとして使用。"""
    document_type = await document_types_service.create_document_type(
        session, admin, code=body.code, name=body.name
    )
    return DocumentTypeOut.model_validate(document_type)


@router.put("/{document_type_id}")
async def update_document_type(
    session: SessionDep, _admin: AdminDep, document_type_id: uuid.UUID, body: DocumentTypeCreateIn
) -> DocumentTypeOut:
    """更新(tenant_adminのみ)。"""
    document_type = await document_types_service.update_document_type(
        session, document_type_id, code=body.code, name=body.name
    )
    return DocumentTypeOut.model_validate(document_type)


@router.delete("/{document_type_id}", status_code=204)
async def delete_document_type(
    session: SessionDep, _admin: AdminDep, document_type_id: uuid.UUID
) -> None:
    """削除(tenant_adminのみ)。使用中の種別は409。"""
    await document_types_service.delete_document_type(session, document_type_id)


@router.get("/{document_type_id}/fields")
async def list_fields(
    session: SessionDep, document_type_id: uuid.UUID
) -> list[TranscriptionFieldOut]:
    document_type = await session.get(DocumentType, document_type_id)
    if document_type is None:
        raise ApiError(404, "document_type_not_found", "指定された書類種別が見つかりません")
    rows = await session.scalars(
        select(TranscriptionField)
        .where(TranscriptionField.document_type_id == document_type_id)
        .order_by(TranscriptionField.sort_order)
    )
    return [TranscriptionFieldOut.model_validate(r) for r in rows.all()]


@router.put("/{document_type_id}/fields")
async def update_fields(
    session: SessionDep, _admin: AdminDep, document_type_id: uuid.UUID, body: FieldsUpdateIn
) -> list[TranscriptionFieldOut]:
    """転記項目定義の一括更新(tenant_adminのみ)。ヘッダ項目のみ。

    リストに含まれない既存項目は削除される(転記値が残る項目の削除は409)。
    """
    fields = await document_types_service.sync_fields(
        session, document_type_id, [item.model_dump() for item in body.fields]
    )
    return [TranscriptionFieldOut.model_validate(f) for f in fields]
