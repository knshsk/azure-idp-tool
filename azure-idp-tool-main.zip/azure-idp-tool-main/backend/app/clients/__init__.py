"""Azure SDKラッパ(Blob / Service Bus / Document Intelligence)。

Blobコンテナ名のテナントIDからの導出は、テナント越境防止のため
必ずこの層の単一関数を経由する(azure-architecture_v2.md §3.4)。
"""
