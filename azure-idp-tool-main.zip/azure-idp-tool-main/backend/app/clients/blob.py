"""Blob Storageクライアント。

コンテナ名・Blobパスの導出は、テナント越境防止のため必ずこのモジュールの関数を
経由する(単一コード経路: azure-architecture_v2.md §3.4)。パス規約は
docs/01_design/blob-storage.md に従う。
"""

import uuid

from azure.core.exceptions import ResourceExistsError
from azure.storage.blob import ContentSettings
from azure.storage.blob.aio import BlobServiceClient

from app.config import settings


def tenant_container_name(tenant_id: uuid.UUID) -> str:
    """テナント専用コンテナ名。導出経路はこの関数のみとする。"""
    return f"tenant-{tenant_id}"


def original_pdf_path(document_id: uuid.UUID) -> str:
    return f"documents/{document_id}/original.pdf"


def page_image_path(document_id: uuid.UUID, page_no: int) -> str:
    return f"documents/{document_id}/pages/{page_no}.png"


def layout_json_path(document_id: uuid.UUID) -> str:
    return f"documents/{document_id}/analysis/layout.json"


def _service_client() -> BlobServiceClient:
    # ローカル(Azurite)は接続文字列、本番はManaged Identity
    if settings.blob_connection_string:
        return BlobServiceClient.from_connection_string(settings.blob_connection_string)
    from azure.identity.aio import DefaultAzureCredential

    return BlobServiceClient(settings.blob_account_url, credential=DefaultAzureCredential())


async def upload_bytes(tenant_id: uuid.UUID, path: str, data: bytes, content_type: str) -> str:
    """テナントコンテナへアップロードしBlobパスを返す。コンテナがなければ作成する(冪等)。"""
    async with _service_client() as client:
        container = client.get_container_client(tenant_container_name(tenant_id))
        try:
            await container.create_container()
        except ResourceExistsError:
            pass
        await container.upload_blob(
            path,
            data,
            overwrite=True,
            content_settings=ContentSettings(content_type=content_type),
        )
    return path


async def download_bytes(tenant_id: uuid.UUID, path: str) -> bytes:
    async with _service_client() as client:
        container = client.get_container_client(tenant_container_name(tenant_id))
        downloader = await container.download_blob(path)
        return await downloader.readall()


async def upload_original_pdf(tenant_id: uuid.UUID, document_id: uuid.UUID, data: bytes) -> str:
    """原本PDFをアップロードしBlobパスを返す。"""
    return await upload_bytes(tenant_id, original_pdf_path(document_id), data, "application/pdf")


async def delete_document_blobs(tenant_id: uuid.UUID, document_id: uuid.UUID) -> int:
    """ドキュメント配下のBlobを一括削除し、削除件数を返す。

    document_idプレフィックス配下の削除で完結する(blob-storage.mdのパス設計)。
    誤削除はBlobソフトデリートが復旧手段。
    """
    prefix = f"documents/{document_id}/"
    deleted = 0
    async with _service_client() as client:
        container = client.get_container_client(tenant_container_name(tenant_id))
        async for item in container.list_blobs(name_starts_with=prefix):
            await container.delete_blob(item.name)
            deleted += 1
    return deleted
