"""Service Busクライアント。

メッセージはdocument ID等の参照のみ・PII禁止(azure-architecture_v2.md §3.3)。
"""

import json
import uuid
from datetime import UTC, datetime

from azure.servicebus import ServiceBusMessage
from azure.servicebus.aio import ServiceBusClient

from app.config import settings


def create_client() -> ServiceBusClient:
    # ローカル(エミュレータ)は接続文字列、本番はManaged Identity
    if settings.service_bus_connection_string:
        return ServiceBusClient.from_connection_string(settings.service_bus_connection_string)
    from azure.identity.aio import DefaultAzureCredential

    return ServiceBusClient(
        fully_qualified_namespace=settings.service_bus_namespace,
        credential=DefaultAzureCredential(),
    )


async def enqueue_analysis(queue_name: str, document_id: uuid.UUID, tenant_id: uuid.UUID) -> None:
    """解析ジョブを投入する(api-design.md「非同期処理の内部インターフェース」)。"""
    body = json.dumps(
        {
            "document_id": str(document_id),
            "tenant_id": str(tenant_id),
            "requested_at": datetime.now(UTC).isoformat(),
        }
    )
    async with create_client() as client:
        sender = client.get_queue_sender(queue_name)
        async with sender:
            await sender.send_messages(ServiceBusMessage(body))
