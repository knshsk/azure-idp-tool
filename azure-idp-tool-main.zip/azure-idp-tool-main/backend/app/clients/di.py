"""Document Intelligenceクライアント。

全書類をLayout + Query Fieldsの1本のフローで解析する(ブレスト決定事項)。
ローカルエミュレータは存在しないため、開発時も共有の実リソースを使う
(dev-environment.md。エンドポイント・キーは.envで設定)。
"""

from azure.ai.documentintelligence.aio import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import DocumentAnalysisFeature
from azure.core.credentials import AzureKeyCredential

from app.config import settings


def _client() -> DocumentIntelligenceClient:
    if not settings.di_endpoint:
        raise RuntimeError("DI_ENDPOINTが未設定です(backend/.envに開発用リソースの値を設定する)")
    # ローカルはキー認証、本番はManaged Identity(キー無効化)
    if settings.di_key:
        return DocumentIntelligenceClient(settings.di_endpoint, AzureKeyCredential(settings.di_key))
    from azure.identity.aio import DefaultAzureCredential

    return DocumentIntelligenceClient(settings.di_endpoint, DefaultAzureCredential())


async def analyze_layout(pdf: bytes, query_field_keys: list[str]) -> dict:
    """prebuilt-layout(+Query Fields)で解析し、結果の生JSON(dict)を返す。"""
    features = [DocumentAnalysisFeature.QUERY_FIELDS] if query_field_keys else []
    async with _client() as client:
        poller = await client.begin_analyze_document(
            "prebuilt-layout",
            pdf,
            content_type="application/pdf",
            features=features,
            query_fields=query_field_keys or None,
        )
        result = await poller.result()
    return result.as_dict()
