"""環境変数からの設定読み込み(変数一覧は backend/.env.example を参照)。"""

from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ランタイム用(RLS適用対象のアプリロールで接続)
    database_url: str = "postgresql+asyncpg://app_user:app@localhost:5432/idp"
    # マイグレーション・シード用(所有者ロールで接続)。未設定時はdatabase_urlを使う
    migration_database_url: str = ""

    blob_account_url: str = ""
    blob_connection_string: str = ""

    service_bus_namespace: str = ""
    service_bus_connection_string: str = ""
    service_bus_queue_interactive: str = "interactive"
    service_bus_queue_batch: str = "batch"

    di_endpoint: str = ""
    di_key: str = ""

    auth_mode: Literal["local", "keycloak"] = "local"
    local_tenant_id: str = ""
    local_user_id: str = "00000000-0000-0000-0000-000000000002"
    local_user_role: str = "tenant_admin"

    # auth_mode="keycloak" のときだけ使う。JWKSのURLは issuer の
    # ディスカバリ文書から取得する(core/oidc.py)
    oidc_issuer: str = ""
    oidc_audience: str = ""

    # アップロードサイズ上限(DI S0制約の500MBに準拠)
    max_upload_size_mb: int = 500

    # 共有URLのベースURL(フロントエンドの共有ビュー。発行時のURL組み立てに使用)
    share_base_url: str = "http://localhost:5173/share"

    # --- ワーカー ---
    # ページPNGの描画解像度
    png_render_dpi: int = 150
    # この配信回数で失敗したらDLQ+status=failed(キュー定義のMaxDeliveryCountと揃える)
    worker_max_delivery_count: int = 5
    # メッセージロックの自動更新上限秒(DI解析がロック時間を超えるため)
    worker_lock_renewal_seconds: int = 600
    # 定期ジョブ(回収処理・保持期間超過削除)の実行間隔
    maintenance_interval_seconds: int = 600
    # この時間を超えてuploaded/analyzingのまま滞留したら再投入する
    stalled_threshold_minutes: int = 30


settings = Settings()
