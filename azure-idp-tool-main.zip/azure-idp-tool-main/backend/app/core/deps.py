"""FastAPI依存関係(DBセッション+RLSテナントコンテキスト)。"""

import uuid
from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.auth import AuthContext, get_auth_context, get_batch_auth_context
from app.core.db import session_factory, set_tenant_context


async def _tenant_session(tenant_id: uuid.UUID) -> AsyncIterator[AsyncSession]:
    """テナントのRLSコンテキストを設定したセッションを払い出す。

    テナントコンテキストはトランザクションローカルのため、ハンドラ内で明示的に
    commitした場合は以降のクエリでコンテキストが失われる点に注意
    (アップロードの「commit→キュー投入」のように、commit後にDBを触らない用途に限る)。
    """
    async with session_factory() as session:
        # set_configの実行でトランザクションが自動開始される
        await set_tenant_context(session, tenant_id)
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_tenant_session(
    auth: Annotated[AuthContext, Depends(get_auth_context)],
) -> AsyncIterator[AsyncSession]:
    """フロントエンドAPI経路(JWT認証)のセッション。"""
    async for session in _tenant_session(auth.tenant_id):
        yield session


async def get_plain_session() -> AsyncIterator[AsyncSession]:
    """認証なし経路(共有ビュー)用のセッション。

    テナントコンテキストは未設定で払い出す。ハンドラ側でトークン検証後に
    set_tenant_contextを呼ぶまで、RLS対象テーブルは実質見えない。
    """
    async with session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_batch_tenant_session(
    auth: Annotated[AuthContext, Depends(get_batch_auth_context)],
) -> AsyncIterator[AsyncSession]:
    """バッチAPI経路(サービスアカウントのJWT)のセッション。"""
    async for session in _tenant_session(auth.tenant_id):
        yield session
