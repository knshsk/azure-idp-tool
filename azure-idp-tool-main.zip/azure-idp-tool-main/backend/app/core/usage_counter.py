"""テナント別APIリクエスト数の計上(FR-LOG-2)。

公開接点(Application Gateway)のアクセスログにはテナント識別子が出ず、
ログ集計ではテナント別に割れない。このためアプリ側で計上する。

計上の流れ:
1. 認証依存関係が解決したテナントIDを `request.state` に置く(set_request_tenant)
2. ミドルウェアがレスポンス確定後に `request.state` を見て日次カウンタをUPSERTする

認証依存関係ではなくミドルウェアで数えるのは、計上をリクエスト処理の成否から
切り離すため。依存関係の中で数えると、ハンドラが例外を投げてトランザクションが
巻き戻る経路と計上の成否が絡む。ミドルウェアならレスポンス確定後に1回だけ走る。
"""

import logging
import uuid
from datetime import UTC, datetime, timedelta, timezone

from fastapi import Request
from sqlalchemy.dialects.postgresql import insert

from app.core.db import session_factory, set_tenant_context
from app.models import ApiRequestCounter

logger = logging.getLogger(__name__)

# 集計タイムゾーン。services/usage.py の JST と揃える【仮】
JST = timezone(timedelta(hours=9))

_STATE_KEY = "usage_tenant_id"


def set_request_tenant(request: Request, tenant_id: uuid.UUID) -> None:
    """認証で解決したテナントIDをリクエストに記録する。

    `request.state` は ASGI scope に載るため、ミドルウェア側の Request からも
    同じ値が読める。
    """
    setattr(request.state, _STATE_KEY, tenant_id)


def get_request_tenant(request: Request) -> uuid.UUID | None:
    return getattr(request.state, _STATE_KEY, None)


async def increment(tenant_id: uuid.UUID, now: datetime | None = None) -> None:
    """(tenant_id, 当日) のカウンタを1増やす。

    RLSのポリシーは他テーブルと同型のため、UPSERT前にテナントコンテキストの
    設定が必要(未設定だと current_setting が落ちて弾かれる)。
    """
    moment = now or datetime.now(UTC)
    day = moment.astimezone(JST).date()

    async with session_factory() as session:
        await set_tenant_context(session, tenant_id)
        stmt = insert(ApiRequestCounter).values(tenant_id=tenant_id, day=day, count=1)
        await session.execute(
            stmt.on_conflict_do_update(
                index_elements=["tenant_id", "day"],
                set_={"count": ApiRequestCounter.count + 1},
            )
        )
        await session.commit()


async def count_requests_middleware(request: Request, call_next):  # type: ignore[no-untyped-def]
    """APIリクエスト数を計上するHTTPミドルウェア。

    テナントが解決できたリクエストのみ数える。認証前に弾かれた401/403は
    どのテナント宛か決められないため対象外(共有URL経路も同様に数えない)。

    計上の失敗はリクエストを失敗させない。この数字は利用状況の目安であり、
    テナント課金の根拠は di_call_logs(FR-LOG-3)のため、
    計上できないことより本来のレスポンスを返せないことのほうが損失が大きい。
    """
    response = await call_next(request)

    tenant_id = get_request_tenant(request)
    if tenant_id is not None:
        try:
            await increment(tenant_id)
        except Exception:
            logger.warning("APIリクエスト数の計上に失敗しました", exc_info=True)

    return response
