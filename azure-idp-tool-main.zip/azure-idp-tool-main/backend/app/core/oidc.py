"""OIDCプロバイダ(Keycloak)の署名鍵の取得とキャッシュ。

JWTの検証には発行者の公開鍵が要る。鍵はJWKSエンドポイントで公開されており、
リクエストのたびに取りに行くのは非現実的なのでキャッシュする。

鍵はローテーションされうるため、未知の `kid` が来たら再取得する。ただし
存在しない `kid` を大量に投げられると再取得が連打されるので、最短再取得間隔を
設けて歯止めをかける。
"""

import asyncio
import time

import aiohttp
from jwt import PyJWK, PyJWKSet

from app.core.errors import ApiError


class OidcKeyStore:
    """issuerのJWKSをkid単位でキャッシュして払い出す。"""

    def __init__(
        self,
        issuer: str,
        *,
        cache_ttl_seconds: float = 3600,
        min_refresh_interval_seconds: float = 60,
        request_timeout_seconds: float = 10,
    ) -> None:
        self._issuer = issuer.rstrip("/")
        self._cache_ttl = cache_ttl_seconds
        self._min_refresh_interval = min_refresh_interval_seconds
        self._request_timeout = request_timeout_seconds

        self._jwks_uri: str | None = None
        self._keys: dict[str, PyJWK] = {}
        # None は「一度も取得していない」。time.monotonic() の原点は起点不定
        # (Linuxではブート時刻)なので、0 を「十分過去」の代わりには使えない。
        # 起点の直後にプロセスが立ち上がると、初回取得の前に最短再取得間隔の
        # 抑止に掛かり、JWKSを一度も取りに行かないまま401を返してしまう
        self._last_refresh: float | None = None
        self._lock = asyncio.Lock()

    async def get_signing_key(self, kid: str) -> PyJWK:
        """kidに対応する署名鍵を返す。見つからなければ401。"""
        if (key := self._cached(kid)) is not None:
            return key

        async with self._lock:
            # ロック待ちの間に他のリクエストが取得済みかもしれない
            if (key := self._cached(kid)) is not None:
                return key
            if (
                self._last_refresh is not None
                and time.monotonic() - self._last_refresh < self._min_refresh_interval
            ):
                # 直近で取得したのに見つからない = 実在しないkid。再取得しても無駄
                raise ApiError(401, "unauthorized", "トークンの署名鍵が見つかりません")
            await self._refresh()

        if (key := self._cached(kid)) is None:
            raise ApiError(401, "unauthorized", "トークンの署名鍵が見つかりません")
        return key

    def _cached(self, kid: str) -> PyJWK | None:
        if self._last_refresh is None or time.monotonic() - self._last_refresh > self._cache_ttl:
            return None
        return self._keys.get(kid)

    async def _refresh(self) -> None:
        try:
            if self._jwks_uri is None:
                discovery = await self._fetch_json(
                    f"{self._issuer}/.well-known/openid-configuration"
                )
                self._jwks_uri = discovery["jwks_uri"]
            jwks = await self._fetch_json(self._jwks_uri)
        except (aiohttp.ClientError, TimeoutError, KeyError) as exc:
            # 認証基盤へ到達できないのはこちら側の障害。401(資格情報の誤り)ではない
            raise ApiError(503, "auth_unavailable", "認証基盤に接続できません") from exc

        # 署名用でない鍵(Keycloakは暗号用の鍵も返す)はPyJWKSetが読み飛ばす
        self._keys = {key.key_id: key for key in PyJWKSet.from_dict(jwks).keys if key.key_id}
        self._last_refresh = time.monotonic()

    async def _fetch_json(self, url: str) -> dict:
        # 取得は1時間に1回程度なので、接続プールは持たず都度セッションを作る
        timeout = aiohttp.ClientTimeout(total=self._request_timeout)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as response:
                response.raise_for_status()
                return await response.json()
