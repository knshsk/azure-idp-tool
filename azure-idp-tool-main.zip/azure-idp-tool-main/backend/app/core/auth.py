"""認証とテナント解決(api-design.md「認証と経路」)。

AUTH_MODE:
- local: JWT検証をスキップし、環境変数のダミーユーザ・テナントとして動作(ローカル開発用)
- entra: Entra External IDのJWT検証(未実装)
"""

import uuid
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Header

from app.config import settings
from app.core.errors import ApiError


@dataclass(frozen=True)
class AuthContext:
    tenant_id: uuid.UUID
    # バッチ・共有URL経路ではNone
    user_id: uuid.UUID | None
    role: str


async def get_auth_context() -> AuthContext:
    """フロントエンドAPI経路の認証依存関係。"""
    if settings.auth_mode == "local":
        return AuthContext(
            tenant_id=uuid.UUID(settings.local_tenant_id),
            user_id=uuid.UUID(settings.local_user_id),
            role=settings.local_user_role,
        )
    # TODO: entraモードの実装
    # - Authorization: Bearer のJWTを検証(署名/issuer/audience。APIM検証との多層防御)
    # - クレームのoid → users.entra_object_id → tenant_id 解決。RLS下ではこの
    #   テナント横断検索ができないため、SECURITY DEFINER関数など認証専用の
    #   検索経路が必要(実装時に設計する)
    raise ApiError(501, "not_implemented", "entra認証は未実装です")


async def get_batch_auth_context(
    x_tenant_id: Annotated[str | None, Header()] = None,
) -> AuthContext:
    """バッチAPI経路の認証依存関係。

    APIMがサブスクリプションキーを検証し、紐づくテナントIDをX-Tenant-Idとして
    付与して転送する(受信ヘッダはAPIMポリシーで無条件削除されるため偽装不可:
    azure-architecture_v2.md §3.1)。API側はこのヘッダを信頼してテナント解決する。
    """
    if x_tenant_id is None and settings.auth_mode == "local":
        # ローカル開発ではヘッダ省略時にダミーテナントへフォールバック
        x_tenant_id = settings.local_tenant_id
    if not x_tenant_id:
        raise ApiError(401, "unauthorized", "X-Tenant-Idヘッダがありません")
    try:
        tenant_id = uuid.UUID(x_tenant_id)
    except ValueError:
        raise ApiError(401, "unauthorized", "X-Tenant-Idヘッダが不正です") from None
    return AuthContext(tenant_id=tenant_id, user_id=None, role="batch")


def require_tenant_admin(auth: AuthContext) -> None:
    """tenant_adminのみ許可される操作のロール検査。"""
    if auth.role != "tenant_admin":
        raise ApiError(403, "forbidden", "この操作にはシステム管理者権限が必要です")


async def get_admin_auth_context(
    auth: Annotated[AuthContext, Depends(get_auth_context)],
) -> AuthContext:
    """tenant_admin限定エンドポイント用の認証依存関係。"""
    require_tenant_admin(auth)
    return auth
