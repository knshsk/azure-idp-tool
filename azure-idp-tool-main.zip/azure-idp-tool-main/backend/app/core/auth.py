"""認証とテナント解決(api-design.md「認証と経路」)。

AUTH_MODE:
- local: JWT検証をスキップし、環境変数のダミーユーザ・テナントとして動作(ローカル開発用)
- keycloak: KeycloakのJWTを検証し、クレームからテナント(・ユーザ・ロール)を解決する

フロントエンド経路とバッチ経路はどちらも同じKeycloakがissuerのため、検証処理
(verify_token)は共通で、差分はテナントの解決元だけ:

- フロントエンド: ユーザトークンの `sub` → users.idp_subject → tenant_id
- バッチ: サービスアカウント(OAuth2クライアントクレデンシャル)トークンの
  `tenant_id` クレーム → tenant_id。user_idは持たずロールは "batch"
"""

import uuid
from dataclasses import dataclass
from functools import cache
from typing import Annotated

import jwt
from fastapi import Depends, Header, Request
from sqlalchemy import text

from app.config import settings
from app.core.db import session_factory
from app.core.errors import ApiError
from app.core.oidc import OidcKeyStore
from app.core.usage_counter import set_request_tenant

# Keycloakの既定の署名アルゴリズム。ここを広げると "alg": "none" 等の
# 混乱攻撃の余地が生まれるため、明示的に1つに絞る
_ALLOWED_ALGORITHMS = ["RS256"]

# バッチ用Keycloakクライアントにprotocol mapperで持たせるテナントIDのクレーム名。
# ユーザ向けクライアント(idp-frontend)にはこのマッパーを付けないため、ユーザトークンで
# バッチAPIを呼んでもクレームが無く弾かれる(infra/verify/keycloak/realm-idp.json)
_TENANT_CLAIM = "tenant_id"


@dataclass(frozen=True)
class AuthContext:
    tenant_id: uuid.UUID
    # バッチ・共有URL経路ではNone
    user_id: uuid.UUID | None
    role: str


@cache
def _key_store() -> OidcKeyStore:
    """署名鍵のキャッシュはプロセス内で1つだけ持つ。"""
    if not settings.oidc_issuer:
        raise ApiError(500, "configuration_error", "OIDC_ISSUERが設定されていません")
    return OidcKeyStore(settings.oidc_issuer)


def _extract_bearer_token(authorization: str | None) -> str:
    if not authorization:
        raise ApiError(401, "unauthorized", "Authorizationヘッダがありません")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise ApiError(401, "unauthorized", "Authorizationヘッダの形式が不正です")
    return token


async def verify_token(token: str) -> dict:
    """JWTを検証してクレームを返す。

    公開接点(Application Gateway)にJWT検証層は無く、この関数がJWT検証の唯一の
    強制点。フロントエンド経路・バッチ経路の両方がここを通る
    (azure-architecture_v2.md §3.1 #2)。
    """
    if not settings.oidc_audience:
        raise ApiError(500, "configuration_error", "OIDC_AUDIENCEが設定されていません")

    try:
        kid = jwt.get_unverified_header(token).get("kid")
    except jwt.InvalidTokenError as exc:
        raise ApiError(401, "unauthorized", "トークンの形式が不正です") from exc
    if not kid:
        raise ApiError(401, "unauthorized", "トークンにkidがありません")

    signing_key = await _key_store().get_signing_key(kid)
    try:
        return jwt.decode(
            token,
            signing_key.key,
            algorithms=_ALLOWED_ALGORITHMS,
            issuer=settings.oidc_issuer,
            audience=settings.oidc_audience,
            # 欠けていると検証が素通りするクレームを必須にする
            options={"require": ["exp", "iss", "aud", "sub"]},
        )
    except jwt.InvalidTokenError as exc:
        # 失効・issuer違い・aud違いなどを区別して返すと総当たりの手がかりになるため、
        # 呼び出し元には一律で同じメッセージを返す(詳細はログに任せる)
        raise ApiError(401, "unauthorized", "トークンが無効です") from exc


async def _resolve_user(idp_subject: str) -> AuthContext:
    """JWTのsubからユーザ・テナント・ロールを解決する。

    認証時点ではテナントが未知でRLSコンテキストを設定できないため、
    テナント横断検索ができるSECURITY DEFINER関数を経由する
    (マイグレーション0004。共有トークン検証0002と同じパターン)。
    """
    async with session_factory() as session:
        result = await session.execute(
            text("SELECT id, tenant_id, role FROM lookup_user_by_idp_subject(:idp_subject)"),
            {"idp_subject": idp_subject},
        )
        row = result.one_or_none()

    if row is None:
        # Keycloak側の認証は通っているが、テナントに紐づくユーザとして登録されていない。
        # 初回ログイン時の自動作成は、単一レルム構成のトークンだけでは所属テナントを
        # 決められないため実装していない(要件のGAP-F5 / OI-19が未決)。
        # 当面はテナントのオンボーディング時にusersへ事前登録する運用とする。
        raise ApiError(403, "forbidden", "このユーザはテナントに登録されていません")

    return AuthContext(tenant_id=row.tenant_id, user_id=row.id, role=row.role)


async def get_auth_context(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
) -> AuthContext:
    """フロントエンドAPI経路の認証依存関係。"""
    if settings.auth_mode == "local":
        auth = AuthContext(
            tenant_id=uuid.UUID(settings.local_tenant_id),
            user_id=uuid.UUID(settings.local_user_id),
            role=settings.local_user_role,
        )
    else:
        claims = await verify_token(_extract_bearer_token(authorization))
        auth = await _resolve_user(claims["sub"])

    # APIリクエスト数の計上はミドルウェアが行う(core/usage_counter.py)
    set_request_tenant(request, auth.tenant_id)
    return auth


def _resolve_batch_tenant(claims: dict) -> AuthContext:
    """サービスアカウントトークンのクレームからテナントを解決する。

    クライアントクレデンシャルで発行されたトークンの `sub` はユーザではなく
    サービスアカウントを指すため、_resolve_user()のusers経由の解決は使えない。
    テナントごとのKeycloakクライアントにprotocol mapperで持たせた `tenant_id`
    クレームを唯一の解決元とする(azure-architecture_v2.md §4.2.1)。

    クレームはKeycloakが署名済みトークンに埋めるものでクライアントからは指定できない。
    クレームが無いトークン(ユーザ向けクライアントで取得したものなど)は、署名・issuer・
    audienceが正しくてもバッチAPIを利用できない。
    """
    raw = claims.get(_TENANT_CLAIM)
    # 不正な値はKeycloak側のクライアント設定ミスであり呼び出し側では直せないが、
    # 「テナントが解決できないトークン」である点は欠落時と同じなので同じ扱いにする
    if not isinstance(raw, str):
        raise ApiError(403, "forbidden", "このトークンはバッチAPIを利用できません")
    try:
        tenant_id = uuid.UUID(raw)
    except ValueError:
        raise ApiError(403, "forbidden", "このトークンはバッチAPIを利用できません") from None
    return AuthContext(tenant_id=tenant_id, user_id=None, role="batch")


async def get_batch_auth_context(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
) -> AuthContext:
    """バッチAPI経路の認証依存関係。

    テナント社内システムはKeycloakのOAuth2クライアントクレデンシャルで短命トークンを
    取得し、`Authorization: Bearer` で送る(api-design.md「認証と経路」)。

    テナントIDはリクエストヘッダから受け取らない。Application Gatewayが受信
    `X-Tenant-Id` をヘッダ書き換えで無条件削除するが、削除ルールが漏れても成立
    しないよう、API側もこのヘッダを一切参照しない(azure-architecture_v2.md §3.1 #1)。
    """
    if settings.auth_mode == "local":
        # ローカル開発ではJWT検証をスキップしてダミーテナントとして動作する
        # (get_auth_contextと同じ扱い)
        auth = AuthContext(
            tenant_id=uuid.UUID(settings.local_tenant_id),
            user_id=None,
            role="batch",
        )
    else:
        claims = await verify_token(_extract_bearer_token(authorization))
        auth = _resolve_batch_tenant(claims)

    # APIリクエスト数の計上はミドルウェアが行う(core/usage_counter.py)
    set_request_tenant(request, auth.tenant_id)
    return auth


def require_tenant_admin(auth: AuthContext) -> None:
    """tenant_adminのみ許可される操作のロール検査。"""
    if auth.role != "tenant_admin":
        raise ApiError(403, "forbidden", "この操作にはシステム管理者権限が必要です")


async def get_admin_auth_context(
    auth: Annotated[AuthContext, Depends(get_auth_context)],
) -> AuthContext:
    """tenant_admin限定エンドポイント用の認証依存関係。"""
    require_tenant_admin(auth)
    return auth
