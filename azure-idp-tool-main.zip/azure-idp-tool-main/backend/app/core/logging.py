"""構造化(JSON)ログ設定。

規約(coding-standards.md): tenant_id / document_id を必ず含める。
使い方: logger.info("uploaded", extra={"tenant_id": ..., "document_id": ...})
"""

import json
import logging
from datetime import UTC, datetime

_CONTEXT_FIELDS = ("tenant_id", "document_id")


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        entry: dict[str, object] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for field in _CONTEXT_FIELDS:
            value = getattr(record, field, None)
            if value is not None:
                entry[field] = str(value)
        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, ensure_ascii=False)


def setup_logging(level: int = logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level)
    # Azure SDK内部(AMQP接続状態等)のINFOログはノイズが大きいため抑制する
    logging.getLogger("azure").setLevel(logging.WARNING)
