"""DBエンジン・セッション管理とRLSテナントコンテキスト。

接続ロールは2種類(data-model.md / azure-architecture_v2.md §3.4):
- ランタイム(DATABASE_URL): RLS適用対象のアプリロール(BYPASSRLSなし)
- マイグレーション・運用(MIGRATION_DATABASE_URL): 所有者ロール
"""

import uuid

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import settings

engine = create_async_engine(settings.database_url)
session_factory = async_sessionmaker(engine, expire_on_commit=False)


async def set_tenant_context(session: AsyncSession, tenant_id: uuid.UUID | str) -> None:
    """RLSポリシーが参照するテナントコンテキストを現在のトランザクションに設定する。

    set_config(..., is_local=true) はトランザクション終了で消えるため、
    必ずトランザクション内で呼び、同一トランザクション内でクエリを実行すること。
    APIリクエスト処理ではセッション取得時に必ず設定する(素通り防止)。
    """
    await session.execute(
        text("SELECT set_config('app.tenant_id', :tenant_id, true)"),
        {"tenant_id": str(tenant_id)},
    )
