"""書類種別・転記項目定義APIのスキーマ。"""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class DocumentTypeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    code: str
    name: str
    created_at: datetime


class TranscriptionFieldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    document_type_id: uuid.UUID
    json_key: str
    label_ja: str
    value_type: str
    query_field_key: str | None
    sort_order: int
