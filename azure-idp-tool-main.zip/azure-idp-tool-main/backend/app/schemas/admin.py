"""管理・計測APIのスキーマ。"""

import uuid
from typing import Literal

from pydantic import BaseModel, Field


class MeOut(BaseModel):
    """ログインユーザ情報(ロール・テナント)。"""

    user_id: uuid.UUID
    display_name: str
    email: str
    role: str
    tenant_id: uuid.UUID
    tenant_name: str


class TenantSettingsOut(BaseModel):
    name: str
    retention_days: int


class TenantSettingsIn(BaseModel):
    # 転記完了後この日数で自動削除。上限10年【仮】
    retention_days: int = Field(ge=1, le=3650)


class UsageDayOut(BaseModel):
    date: str
    api_requests: int
    di_calls: int
    di_pages: int


class UsageSummaryOut(BaseModel):
    month: str
    di_calls: int
    di_pages: int
    # api_request_countersの集計(core/usage_counter.pyが計上)
    api_requests: int
    days: list[UsageDayOut]


class DocumentTypeCreateIn(BaseModel):
    code: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=128)


class FieldUpsertIn(BaseModel):
    """転記項目の一括更新要素。idなし=新規作成、リストに含まれない既存項目は削除。"""

    id: uuid.UUID | None = None
    json_key: str = Field(min_length=1, max_length=64)
    label_ja: str = Field(min_length=1, max_length=128)
    value_type: Literal["string", "number", "date"]
    query_field_key: str | None = None
    sort_order: int


class FieldsUpdateIn(BaseModel):
    fields: list[FieldUpsertIn]
