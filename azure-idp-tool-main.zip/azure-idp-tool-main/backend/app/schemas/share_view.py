"""共有ビューAPI(認証なし)のスキーマ。転記項目・解析結果は含めない(screen-design.md)。"""

from datetime import datetime

from pydantic import BaseModel


class ShareViewOut(BaseModel):
    file_name: str
    page_count: int | None
    expires_at: datetime
