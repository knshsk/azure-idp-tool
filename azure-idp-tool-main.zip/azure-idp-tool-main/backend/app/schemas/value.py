"""転記値・解析結果APIのスキーマ。"""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, model_validator


class ExtractedValueOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    transcription_field_id: uuid.UUID | None
    row_no: int | None
    column_no: int | None
    page_no: int | None
    bbox: dict | None
    value_raw: str
    value_normalized: str | None
    normalization_failed: bool
    manually_edited: bool
    updated_at: datetime


class ValueUpdateItem(BaseModel):
    """ヘッダはtranscription_field_id、明細セルはrow_no+column_noで指定(排他)。"""

    transcription_field_id: uuid.UUID | None = None
    row_no: int | None = None
    column_no: int | None = None
    value_raw: str

    @model_validator(mode="after")
    def validate_target(self) -> ValueUpdateItem:
        is_header = self.transcription_field_id is not None
        is_cell = self.row_no is not None and self.column_no is not None
        if is_header == is_cell:  # 両方指定 or どちらも未指定
            raise ValueError(
                "transcription_field_id か row_no+column_no のどちらか一方を指定してください"
            )
        return self


class ValuesUpdateIn(BaseModel):
    values: list[ValueUpdateItem]


class LineItemTableIn(BaseModel):
    page_no: int
    table_index: int


class LineItemTableOut(BaseModel):
    line_item_table: dict
    values: list[ExtractedValueOut]


class AnalysisOut(BaseModel):
    """オーバレイ用データ。座標はすべて正規化(0〜1)済み。"""

    pages: list | None
    layout: dict
    query_fields: dict | None
