"""ドキュメントAPIのスキーマ。"""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    document_type_id: uuid.UUID
    status: str
    file_name: str
    file_hash: str
    page_count: int | None
    # ユーザが選択した明細領域(明細プレビューの列定義に使用)
    line_item_table: dict | None
    source: str
    uploaded_by: uuid.UUID | None
    error_message: str | None
    created_at: datetime
    analyzed_at: datetime | None
    confirmed_at: datetime | None
