"""共有URL APIのスキーマ。"""

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class ShareLinkCreateIn(BaseModel):
    # 上限30日【仮】
    expires_in_hours: int = Field(ge=1, le=720)


class ShareLinkCreatedOut(BaseModel):
    """トークン平文を含むURLはこの応答にのみ含める(DBはハッシュのみ)。"""

    id: uuid.UUID
    url: str
    expires_at: datetime


class ShareLinkOut(BaseModel):
    id: uuid.UUID
    status: Literal["active", "revoked", "expired"]
    expires_at: datetime
    revoked_at: datetime | None
    created_at: datetime
