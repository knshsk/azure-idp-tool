"""開発用シードデータ投入(dev-environment.md)。

実行: uv run python scripts/seed.py(何度実行しても安全な冪等実装)

投入内容:
- 開発用テナント1件(.env の LOCAL_TENANT_ID のIDで作成)
- 書類種別「見積書」+転記項目定義(取引日付・取引先名・合計金額)
  ※転記項目はヘッダ項目のみ(明細列は項目定義を持たない)

テナント作成はテナント外の運用操作のため、所有者ロール(MIGRATION_DATABASE_URL)で
接続してRLSの外で実行する。
"""

import asyncio
import logging
import sys
import uuid

sys.path.insert(0, ".")  # backend/ 直下からの実行用

from sqlalchemy import select  # noqa: E402
from sqlalchemy.dialects.postgresql import insert  # noqa: E402
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine  # noqa: E402

from app.config import settings  # noqa: E402
from app.core.logging import setup_logging  # noqa: E402
from app.models import DocumentType, Tenant, TranscriptionField, User  # noqa: E402

logger = logging.getLogger(__name__)

DOCUMENT_TYPE_CODE = "quotation"
DOCUMENT_TYPE_NAME = "見積書"

# (json_key, label_ja, value_type, query_field_key, sort_order)
FIELDS = [
    ("transaction_date", "取引日付", "date", "TransactionDate", 1),
    ("partner_name", "取引先名", "string", "PartnerName", 2),
    ("total_amount", "合計金額", "number", "TotalAmount", 3),
]


async def seed() -> None:
    if not settings.local_tenant_id:
        raise SystemExit("LOCAL_TENANT_ID を .env に設定してください(.env.example参照)")
    tenant_id = uuid.UUID(settings.local_tenant_id)

    engine = create_async_engine(settings.migration_database_url or settings.database_url)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async with session_factory() as session, session.begin():
        await session.execute(
            insert(Tenant)
            .values(id=tenant_id, name="開発テナント")
            .on_conflict_do_nothing(index_elements=["id"])
        )

        # AUTH_MODE=local時のダミー認証で使う開発ユーザ(.env の LOCAL_USER_ID)
        await session.execute(
            insert(User)
            .values(
                id=uuid.UUID(settings.local_user_id),
                tenant_id=tenant_id,
                idp_subject="local-dev-user",
                email="dev@example.com",
                display_name="開発ユーザ",
                role="tenant_admin",
            )
            .on_conflict_do_nothing(index_elements=["id"])
        )

        await session.execute(
            insert(DocumentType)
            .values(tenant_id=tenant_id, code=DOCUMENT_TYPE_CODE, name=DOCUMENT_TYPE_NAME)
            .on_conflict_do_nothing(index_elements=["tenant_id", "code"])
        )
        document_type_id = await session.scalar(
            select(DocumentType.id).where(
                DocumentType.tenant_id == tenant_id,
                DocumentType.code == DOCUMENT_TYPE_CODE,
            )
        )

        for json_key, label_ja, value_type, query_field_key, sort_order in FIELDS:
            await session.execute(
                insert(TranscriptionField)
                .values(
                    tenant_id=tenant_id,
                    document_type_id=document_type_id,
                    json_key=json_key,
                    label_ja=label_ja,
                    value_type=value_type,
                    query_field_key=query_field_key,
                    sort_order=sort_order,
                )
                .on_conflict_do_nothing(index_elements=["document_type_id", "json_key"])
            )

    await engine.dispose()
    logger.info(
        "seed completed",
        extra={"tenant_id": str(tenant_id)},
    )


def main() -> None:
    setup_logging()
    asyncio.run(seed())


if __name__ == "__main__":
    main()
