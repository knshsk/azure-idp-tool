from app.services.share_view import FailureRateLimiter


class TestFailureRateLimiter:
    def test_not_blocked_until_max_failures(self):
        limiter = FailureRateLimiter(max_failures=3, window_seconds=300)
        limiter.record_failure("1.2.3.4", now=0)
        limiter.record_failure("1.2.3.4", now=1)
        assert not limiter.is_blocked("1.2.3.4", now=2)
        limiter.record_failure("1.2.3.4", now=2)
        assert limiter.is_blocked("1.2.3.4", now=3)

    def test_window_expiry_resets_block(self):
        limiter = FailureRateLimiter(max_failures=1, window_seconds=300)
        limiter.record_failure("1.2.3.4", now=0)
        assert limiter.is_blocked("1.2.3.4", now=10)
        assert not limiter.is_blocked("1.2.3.4", now=301)

    def test_ips_are_isolated(self):
        limiter = FailureRateLimiter(max_failures=1, window_seconds=300)
        limiter.record_failure("1.2.3.4", now=0)
        assert limiter.is_blocked("1.2.3.4", now=1)
        assert not limiter.is_blocked("5.6.7.8", now=1)

    def test_new_window_starts_after_expiry(self):
        limiter = FailureRateLimiter(max_failures=2, window_seconds=300)
        limiter.record_failure("1.2.3.4", now=0)
        # ウィンドウ経過後の失敗は新しいウィンドウとして数え直す
        limiter.record_failure("1.2.3.4", now=400)
        assert not limiter.is_blocked("1.2.3.4", now=401)
