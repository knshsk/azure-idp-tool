import pytest

from app.config import settings
from app.core.errors import ApiError
from app.services.documents import validate_pdf


def test_validate_pdf_accepts_pdf_magic_bytes():
    validate_pdf(b"%PDF-1.7\n...")


def test_validate_pdf_rejects_non_pdf():
    with pytest.raises(ApiError) as exc_info:
        validate_pdf(b"PK\x03\x04 zip content")
    assert exc_info.value.code == "invalid_file"
    assert exc_info.value.status_code == 400


def test_validate_pdf_rejects_empty():
    with pytest.raises(ApiError) as exc_info:
        validate_pdf(b"")
    assert exc_info.value.code == "invalid_file"


def test_validate_pdf_rejects_oversize(monkeypatch):
    monkeypatch.setattr(settings, "max_upload_size_mb", 1)
    with pytest.raises(ApiError) as exc_info:
        validate_pdf(b"%PDF-" + b"0" * (1024 * 1024 + 1))
    assert exc_info.value.code == "file_too_large"
    assert exc_info.value.status_code == 413
