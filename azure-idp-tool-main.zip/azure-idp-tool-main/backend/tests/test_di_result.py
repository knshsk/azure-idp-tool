import pytest

from app.services.di_result import (
    extract_layout_overlay,
    extract_query_fields,
    extract_table_cells,
    polygon_to_bbox,
)

# DI解析結果(生JSON)の最小フィクスチャ。A4縦(8.5x11インチ相当)1ページ
RAW_RESULT = {
    "pages": [{"pageNumber": 1, "width": 8.5, "height": 11.0, "unit": "inch"}],
    "documents": [
        {
            "fields": {
                "TransactionDate": {
                    "type": "string",
                    "content": "令和8年7月1日",
                    "boundingRegions": [
                        {"pageNumber": 1, "polygon": [1.0, 1.0, 3.0, 1.0, 3.0, 1.5, 1.0, 1.5]}
                    ],
                },
                "TotalAmount": {
                    "type": "string",
                    "content": "¥1,234,567",
                    "boundingRegions": [],
                },
            }
        }
    ],
}


def test_polygon_to_bbox_normalizes_to_page_size():
    bbox = polygon_to_bbox([1.0, 1.0, 3.0, 1.0, 3.0, 1.5, 1.0, 1.5], 8.5, 11.0)
    assert bbox == {
        "x0": 1.0 / 8.5,
        "y0": 1.0 / 11.0,
        "x1": 3.0 / 8.5,
        "y1": 1.5 / 11.0,
    }


def test_extract_query_fields():
    result = extract_query_fields(RAW_RESULT)

    date_entry = result["TransactionDate"]
    assert date_entry["value_raw"] == "令和8年7月1日"
    assert date_entry["page_no"] == 1
    assert date_entry["bbox"]["x0"] == 1.0 / 8.5

    # boundingRegionsなし: 値のみで座標はNone
    amount_entry = result["TotalAmount"]
    assert amount_entry["value_raw"] == "¥1,234,567"
    assert amount_entry["page_no"] is None
    assert amount_entry["bbox"] is None


def test_extract_query_fields_handles_missing_documents():
    assert extract_query_fields({"pages": []}) == {}


# テーブル入りのLayout結果フィクスチャ(1ページ・ヘッダ行1+データ行2)
RAW_WITH_TABLE = {
    "pages": [
        {
            "pageNumber": 1,
            "width": 8.5,
            "height": 11.0,
            "words": [{"content": "見積書", "polygon": [1, 1, 2, 1, 2, 1.2, 1, 1.2]}],
            "lines": [{"content": "見積書", "polygon": [1, 1, 2, 1, 2, 1.2, 1, 1.2]}],
        }
    ],
    "tables": [
        {
            "rowCount": 3,
            "columnCount": 2,
            "boundingRegions": [{"pageNumber": 1, "polygon": [1, 3, 7, 3, 7, 6, 1, 6]}],
            "cells": [
                {
                    "kind": "columnHeader",
                    "rowIndex": 0,
                    "columnIndex": 0,
                    "content": "品名",
                    "boundingRegions": [{"pageNumber": 1, "polygon": [1, 3, 4, 3, 4, 4, 1, 4]}],
                },
                {
                    "kind": "columnHeader",
                    "rowIndex": 0,
                    "columnIndex": 1,
                    "content": "数量",
                    "boundingRegions": [{"pageNumber": 1, "polygon": [4, 3, 7, 3, 7, 4, 4, 4]}],
                },
                {
                    "rowIndex": 1,
                    "columnIndex": 0,
                    "content": "商品A",
                    "boundingRegions": [{"pageNumber": 1, "polygon": [1, 4, 4, 4, 4, 5, 1, 5]}],
                },
                {
                    "rowIndex": 1,
                    "columnIndex": 1,
                    "content": "10",
                    "boundingRegions": [{"pageNumber": 1, "polygon": [4, 4, 7, 4, 7, 5, 4, 5]}],
                },
                {
                    "rowIndex": 2,
                    "columnIndex": 0,
                    "content": "商品B",
                    "boundingRegions": [{"pageNumber": 1, "polygon": [1, 5, 4, 5, 4, 6, 1, 6]}],
                },
                {
                    "rowIndex": 2,
                    "columnIndex": 1,
                    "content": "5",
                    "boundingRegions": [{"pageNumber": 1, "polygon": [4, 5, 7, 5, 7, 6, 4, 6]}],
                },
            ],
        }
    ],
}


class TestExtractLayoutOverlay:
    def test_pages_and_tables_are_normalized(self):
        overlay = extract_layout_overlay(RAW_WITH_TABLE)

        page = overlay["pages"][0]
        assert page["page_no"] == 1
        assert page["words"][0]["content"] == "見積書"
        assert page["words"][0]["bbox"]["x0"] == 1 / 8.5
        assert page["lines"][0]["bbox"]["y1"] == 1.2 / 11.0

        table = overlay["tables"][0]
        assert table["table_index"] == 0
        assert table["page_no"] == 1
        assert table["row_count"] == 3
        assert table["column_count"] == 2
        assert len(table["cells"]) == 6
        header_cell = table["cells"][0]
        assert header_cell["kind"] == "columnHeader"
        assert header_cell["bbox"]["x1"] == 4 / 8.5

    def test_empty_result(self):
        assert extract_layout_overlay({}) == {"pages": [], "tables": []}


class TestExtractTableCells:
    def test_header_and_data_rows_are_separated(self):
        table = extract_table_cells(RAW_WITH_TABLE, 0)

        assert table["page_no"] == 1
        assert table["columns"] == [
            {"column_no": 0, "header_text": "品名"},
            {"column_no": 1, "header_text": "数量"},
        ]
        # データ行はヘッダ行を除いて0始まりで振り直される
        assert len(table["rows"]) == 2
        first_row = table["rows"][0]
        assert first_row["row_no"] == 0
        assert first_row["cells"][0]["value_raw"] == "商品A"
        assert first_row["cells"][1]["value_raw"] == "10"
        assert first_row["cells"][0]["bbox"]["y0"] == 4 / 11.0
        assert table["rows"][1]["cells"][0]["value_raw"] == "商品B"

    def test_out_of_range_table_index_raises(self):
        with pytest.raises(IndexError):
            extract_table_cells(RAW_WITH_TABLE, 1)
