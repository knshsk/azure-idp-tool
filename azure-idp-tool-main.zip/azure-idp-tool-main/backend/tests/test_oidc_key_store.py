"""署名鍵のキャッシュ(core/oidc.py)のテスト。

HTTPは張らず `_fetch_json` を差し替える — ここで確かめたいのはJWKSの取り方ではなく
「いつ取りに行き、いつ行かないか」のため。この判断を誤ると、鍵ローテーション後に
正当なトークンを弾く / 存在しないkidで再取得を連打する、のどちらかになる。
"""

import base64
import time

import aiohttp
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

from app.core.errors import ApiError
from app.core.oidc import OidcKeyStore

ISSUER = "https://keycloak.example.com/realms/idp"


class FakeJwks:
    """JWKSエンドポイントの応答を返し、取得回数を数えるスタブ。"""

    def __init__(self, kids: list[str]) -> None:
        self.kids = kids
        self.fetch_count = 0

    async def fetch(self, url: str) -> dict:
        self.fetch_count += 1
        if url.endswith("/.well-known/openid-configuration"):
            return {"jwks_uri": f"{ISSUER}/protocol/openid-connect/certs"}
        return {"keys": [_rsa_jwk(kid) for kid in self.kids]}


def _rsa_jwk(kid: str) -> dict:
    """PyJWKSetが読める最小のRSA公開鍵JWK。"""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    numbers = key.public_key().public_numbers()

    def b64(value: int) -> str:
        raw = value.to_bytes((value.bit_length() + 7) // 8, "big")
        return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()

    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": kid,
        "n": b64(numbers.n),
        "e": b64(numbers.e),
    }


def make_store(fake: FakeJwks, **kwargs) -> OidcKeyStore:
    store = OidcKeyStore(ISSUER, **kwargs)
    store._fetch_json = fake.fetch  # type: ignore[method-assign]
    return store


async def test_first_lookup_fetches_the_jwks():
    fake = FakeJwks(["key-1"])
    store = make_store(fake)

    assert await store.get_signing_key("key-1") is not None
    # ディスカバリ文書 + JWKS
    assert fake.fetch_count == 2


async def test_first_lookup_fetches_even_when_the_clock_is_near_its_origin(monkeypatch):
    """プロセス起動が単調増加時計の原点に近くても初回取得を飛ばさないこと。

    「一度も取得していない」を 0 で表すと、time.monotonic() がまだ小さい環境
    (Linuxではブート直後)で最短再取得間隔の抑止に掛かり、JWKSを一度も取りに
    行かないまま401を返してしまう。
    """
    monkeypatch.setattr(time, "monotonic", lambda: 0.5)

    fake = FakeJwks(["key-1"])
    store = make_store(fake, min_refresh_interval_seconds=60)

    assert await store.get_signing_key("key-1") is not None
    assert fake.fetch_count == 2


async def test_cached_key_is_reused_without_refetching():
    fake = FakeJwks(["key-1"])
    store = make_store(fake)

    await store.get_signing_key("key-1")
    await store.get_signing_key("key-1")

    assert fake.fetch_count == 2


async def test_unknown_kid_triggers_a_refetch_after_the_min_interval():
    """鍵ローテーション後の新しいkidを拾えること。"""
    fake = FakeJwks(["key-1"])
    store = make_store(fake, min_refresh_interval_seconds=0)
    await store.get_signing_key("key-1")

    fake.kids = ["key-1", "key-2"]
    assert await store.get_signing_key("key-2") is not None
    assert fake.fetch_count == 3


async def test_unknown_kid_does_not_refetch_within_the_min_interval():
    """存在しないkidを投げ続けられてもJWKS取得を連打しないこと。"""
    fake = FakeJwks(["key-1"])
    store = make_store(fake, min_refresh_interval_seconds=3600)
    await store.get_signing_key("key-1")

    for _ in range(5):
        with pytest.raises(ApiError) as exc_info:
            await store.get_signing_key("unknown")
        assert exc_info.value.status_code == 401

    assert fake.fetch_count == 2


async def test_unreachable_provider_is_not_reported_as_a_credential_error():
    """認証基盤へ到達できないのはこちら側の障害。401(資格情報の誤り)にしない。"""

    async def boom(url: str) -> dict:
        raise aiohttp.ClientError("接続できない")

    store = OidcKeyStore(ISSUER)
    store._fetch_json = boom  # type: ignore[method-assign]

    with pytest.raises(ApiError) as exc_info:
        await store.get_signing_key("key-1")
    assert exc_info.value.status_code == 503
