import uuid
from datetime import UTC, datetime

from app.models import Document, ExtractedValue, TranscriptionField
from app.services.export import build_output_json

TENANT_ID = uuid.uuid4()
TYPE_ID = uuid.uuid4()
DOC_ID = uuid.uuid4()


def _field(json_key: str, value_type: str, sort_order: int) -> TranscriptionField:
    return TranscriptionField(
        id=uuid.uuid4(),
        tenant_id=TENANT_ID,
        document_type_id=TYPE_ID,
        json_key=json_key,
        label_ja=json_key,
        value_type=value_type,
        query_field_key=None,
        sort_order=sort_order,
    )


def _header_value(
    field: TranscriptionField, raw: str, normalized: str | None, failed: bool = False
) -> ExtractedValue:
    return ExtractedValue(
        id=uuid.uuid4(),
        tenant_id=TENANT_ID,
        document_id=DOC_ID,
        transcription_field_id=field.id,
        value_raw=raw,
        value_normalized=normalized,
        normalization_failed=failed,
        manually_edited=False,
    )


def _cell(row_no: int, column_no: int, raw: str, page_no: int = 1) -> ExtractedValue:
    return ExtractedValue(
        id=uuid.uuid4(),
        tenant_id=TENANT_ID,
        document_id=DOC_ID,
        transcription_field_id=None,
        row_no=row_no,
        column_no=column_no,
        page_no=page_no,
        value_raw=raw,
        normalization_failed=False,
        manually_edited=False,
    )


def _document(line_item_table: dict | None) -> Document:
    return Document(
        id=DOC_ID,
        tenant_id=TENANT_ID,
        document_type_id=TYPE_ID,
        status="confirmed",
        file_name="test.pdf",
        file_hash="x",
        source="frontend",
        line_item_table=line_item_table,
        confirmed_at=datetime(2026, 7, 14, 12, 34, 56, tzinfo=UTC),
    )


def test_build_output_json_full():
    date_field = _field("issue_date", "date", 1)
    name_field = _field("vendor_name", "string", 2)
    amount_field = _field("total_amount", "number", 3)
    fields = [date_field, name_field, amount_field]

    document = _document(
        {
            "page_no": 1,
            "table_index": 0,
            "columns": [
                {"column_no": 0, "header_text": "品名"},
                {"column_no": 1, "header_text": "数量"},
            ],
        }
    )
    values = [
        _header_value(date_field, "令和8年7月1日", "2026-07-01"),
        _header_value(name_field, "株式会社A", "株式会社A"),
        _header_value(amount_field, "¥1,234,567", "1234567"),
        _cell(0, 0, "商品A"),
        _cell(0, 1, "10"),
        _cell(1, 0, "商品B", page_no=2),
        # 行1の列1は欠損 → 空文字で埋める
    ]

    output = build_output_json(document, "quotation", fields, values)

    assert output["document_id"] == str(DOC_ID)
    assert output["document_type"] == "quotation"
    assert output["confirmed_at"] == "2026-07-14T12:34:56+00:00"
    # number型はJSON数値、date/stringは正規化文字列
    assert output["header"]["issue_date"] == {
        "value": "2026-07-01",
        "raw": "令和8年7月1日",
        "normalization_failed": False,
    }
    assert output["header"]["total_amount"]["value"] == 1234567
    assert isinstance(output["header"]["total_amount"]["value"], int)
    # 明細: 列ヘッダ+行×列の生文字列。欠損セルは空文字
    assert output["line_items"]["columns"][0]["header_text"] == "品名"
    assert output["line_items"]["rows"] == [
        {"page_no": 1, "cells": ["商品A", "10"]},
        {"page_no": 2, "cells": ["商品B", ""]},
    ]


def test_normalization_failed_value_falls_back_to_raw():
    amount_field = _field("total_amount", "number", 1)
    values = [_header_value(amount_field, "¥6,050(", None, failed=True)]

    output = build_output_json(_document(None), "quotation", [amount_field], values)

    assert output["header"]["total_amount"] == {
        "value": "¥6,050(",
        "raw": "¥6,050(",
        "normalization_failed": True,
    }


def test_line_items_null_when_not_selected():
    output = build_output_json(_document(None), "quotation", [], [])
    assert output["line_items"] is None


def test_decimal_number_is_float():
    field = _field("unit_price", "number", 1)
    values = [_header_value(field, "1,234.50", "1234.50")]
    output = build_output_json(_document(None), "quotation", [field], values)
    assert output["header"]["unit_price"]["value"] == 1234.5


def test_missing_header_value_is_null():
    field = _field("issue_date", "date", 1)
    output = build_output_json(_document(None), "quotation", [field], [])
    assert output["header"]["issue_date"] == {
        "value": None,
        "raw": "",
        "normalization_failed": False,
    }
