import pytest

from app.services.normalize import normalize_value


class TestDateNormalization:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("2026-07-01", "2026-07-01"),
            ("2026/7/1", "2026-07-01"),
            ("2026.07.01", "2026-07-01"),
            ("2026年7月1日", "2026-07-01"),
            ("令和8年7月1日", "2026-07-01"),
            ("令和元年5月1日", "2019-05-01"),
            ("平成31年4月30日", "2019-04-30"),
            ("昭和64年1月7日", "1989-01-07"),
            # 全角数字・全角スラッシュ(NFKCで半角化)
            ("２０２６／７／１", "2026-07-01"),
            ("令和８年７月１日", "2026-07-01"),
        ],
    )
    def test_valid_dates(self, raw, expected):
        assert normalize_value("date", raw) == (expected, False)

    @pytest.mark.parametrize("raw", ["不明", "2026年13月1日", "令和8年2月30日", "7月1日"])
    def test_invalid_dates(self, raw):
        assert normalize_value("date", raw) == (None, True)


class TestNumberNormalization:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("1234567", "1234567"),
            ("1,234,567", "1234567"),
            ("¥1,234,567", "1234567"),
            ("1,234,567円", "1234567"),
            ("1234.50", "1234.50"),
            ("-500", "-500"),
            ("１２３", "123"),  # 全角数字
            ("￥１，２３４", "1234"),  # 全角円記号・全角カンマ
        ],
    )
    def test_valid_numbers(self, raw, expected):
        assert normalize_value("number", raw) == (expected, False)

    @pytest.mark.parametrize("raw", ["12個", "約1000", "1.2.3"])
    def test_invalid_numbers(self, raw):
        assert normalize_value("number", raw) == (None, True)


class TestCommon:
    def test_string_is_nfkc_normalized_and_stripped(self):
        assert normalize_value("string", " 株式会社ABC ") == ("株式会社ABC", False)

    def test_empty_value_is_not_a_failure(self):
        assert normalize_value("date", "") == (None, False)
        assert normalize_value("number", "  ") == (None, False)

    def test_unknown_value_type_raises(self):
        with pytest.raises(ValueError):
            normalize_value("boolean", "true")
