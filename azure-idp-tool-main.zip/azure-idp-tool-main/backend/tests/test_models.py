from app.models import Base

EXPECTED_TABLES = {
    "tenants",
    "users",
    "document_types",
    "transcription_fields",
    "documents",
    "extracted_values",
    "share_links",
    "usage_logs",
    "di_call_logs",
}


def test_all_tables_defined():
    """data-model.mdの全9テーブルがモデル定義されている。"""
    assert set(Base.metadata.tables) == EXPECTED_TABLES


def test_tenant_scoped_tables_have_tenant_id():
    """tenants以外の全テーブルがtenant_id列を持つ(RLS一律適用の前提)。"""
    for name, table in Base.metadata.tables.items():
        if name == "tenants":
            continue
        assert "tenant_id" in table.c, f"{name} に tenant_id 列がない"
