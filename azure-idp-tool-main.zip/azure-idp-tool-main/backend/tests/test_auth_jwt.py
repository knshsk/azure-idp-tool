"""KeycloakのJWT検証(core/auth.py)のテスト。

実際のKeycloakは立てず、テスト内で生成したRSA鍵で署名したトークンを使う。
署名鍵の取得(OidcKeyStore)は差し替える — ここで確かめたいのは鍵の取り方ではなく
「どのトークンを受け入れ、どれを弾くか」のため。
"""

import base64
import hashlib
import hmac
import inspect
import json
import time
import uuid
from types import SimpleNamespace

import jwt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import Request

from app.config import settings
from app.core import auth as auth_module
from app.core.auth import _extract_bearer_token, get_batch_auth_context, verify_token
from app.core.errors import ApiError

KID = "test-key"
OTHER_KID = "rotated-key"
ISSUER = "https://keycloak.example.com/realms/idp"
AUDIENCE = "idp-api"
BATCH_TENANT_ID = uuid.UUID("11111111-1111-1111-1111-111111111111")


def make_request() -> Request:
    """認証依存関係に渡す最小のRequest。

    テナントIDの記録先(request.state)としてだけ使う。stateはASGI scopeに載るため
    scopeにキーを用意しておけば足りる(core/usage_counter.py)。
    """
    return Request({"type": "http", "method": "GET", "path": "/", "headers": [], "state": {}})


@pytest.fixture(scope="module")
def signing_key() -> rsa.RSAPrivateKey:
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture(scope="module")
def other_key() -> rsa.RSAPrivateKey:
    """正規の鍵とは別の鍵(署名の付け替えを検出できるか確かめる用)。"""
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


@pytest.fixture(autouse=True)
def _configure(monkeypatch, signing_key):
    """keycloakモードの設定と、署名鍵ストアの差し替え。"""
    monkeypatch.setattr(settings, "auth_mode", "keycloak")
    monkeypatch.setattr(settings, "oidc_issuer", ISSUER)
    monkeypatch.setattr(settings, "oidc_audience", AUDIENCE)

    class FakeKeyStore:
        async def get_signing_key(self, kid: str):
            if kid != KID:
                raise ApiError(401, "unauthorized", "トークンの署名鍵が見つかりません")
            return SimpleNamespace(key=signing_key.public_key())

    monkeypatch.setattr(auth_module, "_key_store", lambda: FakeKeyStore())


def make_token(key: rsa.RSAPrivateKey, *, kid: str = KID, **overrides) -> str:
    now = int(time.time())
    claims = {
        "iss": ISSUER,
        "aud": AUDIENCE,
        "sub": "0f3b1a2c-user",
        "iat": now,
        "exp": now + 300,
    }
    claims.update(overrides)
    for k, v in list(claims.items()):
        if v is None:  # None を渡したクレームは「欠落」として扱う
            del claims[k]
    headers = {"kid": kid} if kid is not None else {}
    return jwt.encode(claims, key, algorithm="RS256", headers=headers)


# --- Authorizationヘッダの解釈 ---


def test_bearer_token_is_extracted():
    assert _extract_bearer_token("Bearer abc.def.ghi") == "abc.def.ghi"


def test_bearer_scheme_is_case_insensitive():
    assert _extract_bearer_token("bearer abc") == "abc"


@pytest.mark.parametrize(
    "header",
    [None, "", "abc.def.ghi", "Basic dXNlcjpwYXNz", "Bearer", "Bearer "],
)
def test_invalid_authorization_header_is_rejected(header):
    with pytest.raises(ApiError) as exc_info:
        _extract_bearer_token(header)
    assert exc_info.value.status_code == 401


# --- トークン検証 ---


async def test_valid_token_is_accepted(signing_key):
    claims = await verify_token(make_token(signing_key))
    assert claims["sub"] == "0f3b1a2c-user"


async def test_expired_token_is_rejected(signing_key):
    now = int(time.time())
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(signing_key, iat=now - 600, exp=now - 300))
    assert exc_info.value.status_code == 401


async def test_token_from_another_issuer_is_rejected(signing_key):
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(signing_key, iss="https://evil.example.com/realms/idp"))
    assert exc_info.value.status_code == 401


async def test_token_for_another_audience_is_rejected(signing_key):
    """別クライアント向けに発行されたトークンを使い回せないこと。"""
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(signing_key, aud="another-client"))
    assert exc_info.value.status_code == 401


async def test_token_signed_by_another_key_is_rejected(other_key):
    """kidは正規のものを名乗りつつ、別の鍵で署名したトークン。"""
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(other_key))
    assert exc_info.value.status_code == 401


async def test_token_with_unknown_kid_is_rejected(signing_key):
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(signing_key, kid=OTHER_KID))
    assert exc_info.value.status_code == 401


async def test_token_without_kid_is_rejected(signing_key):
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(signing_key, kid=None))
    assert exc_info.value.status_code == 401


@pytest.mark.parametrize("missing", ["exp", "sub", "aud", "iss"])
async def test_token_missing_required_claim_is_rejected(signing_key, missing):
    with pytest.raises(ApiError) as exc_info:
        await verify_token(make_token(signing_key, **{missing: None}))
    assert exc_info.value.status_code == 401


async def test_hmac_signed_token_is_rejected(signing_key):
    """アルゴリズム混乱攻撃: 公開鍵を共有鍵に見立ててHS256で署名する。

    検証側が algorithms を絞っていないと、公開情報(JWKSで誰でも取れる)だけで
    有効なトークンを作れてしまう。RS256のみ許可していることを確かめる。

    PyJWTはPEM鍵をHMACの共有鍵として使う encode を拒否するので、攻撃者と同じく
    ライブラリを介さずに手で組み立てる。
    """
    public_pem = signing_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    now = int(time.time())

    def b64(raw: bytes) -> str:
        return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()

    header = b64(json.dumps({"alg": "HS256", "typ": "JWT", "kid": KID}).encode())
    payload = b64(
        json.dumps(
            {"iss": ISSUER, "aud": AUDIENCE, "sub": "attacker", "iat": now, "exp": now + 300}
        ).encode()
    )
    signing_input = f"{header}.{payload}".encode()
    signature = b64(hmac.new(public_pem, signing_input, hashlib.sha256).digest())

    with pytest.raises(ApiError) as exc_info:
        await verify_token(f"{header}.{payload}.{signature}")
    assert exc_info.value.status_code == 401


async def test_garbage_token_is_rejected():
    with pytest.raises(ApiError) as exc_info:
        await verify_token("not-a-jwt")
    assert exc_info.value.status_code == 401


# --- バッチAPI経路(OAuth2クライアントクレデンシャル) ---
#
# テナントはヘッダではなくサービスアカウントのJWTだけで決まる
# (api-design.md「認証と経路」/ azure-architecture_v2.md §4.2.1)。


def make_batch_token(key: rsa.RSAPrivateKey, **overrides) -> str:
    """サービスアカウントトークン。subはユーザではなくサービスアカウントを指す。"""
    claims = {
        "sub": "9c2d4e6f-service-account",
        "tenant_id": str(BATCH_TENANT_ID),
        "azp": "idp-batch-acme",
    }
    claims.update(overrides)
    return make_token(key, **claims)


async def test_batch_token_resolves_tenant_from_claim(signing_key):
    auth = await get_batch_auth_context(make_request(), f"Bearer {make_batch_token(signing_key)}")
    assert auth.tenant_id == BATCH_TENANT_ID
    # バッチ経路はユーザを持たない。ロールはbatch固定
    assert auth.user_id is None
    assert auth.role == "batch"


async def test_batch_request_without_token_is_rejected():
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), None)
    assert exc_info.value.status_code == 401


async def test_batch_token_signed_by_another_key_is_rejected(other_key):
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), f"Bearer {make_batch_token(other_key)}")
    assert exc_info.value.status_code == 401


async def test_batch_token_from_another_issuer_is_rejected(signing_key):
    token = make_batch_token(signing_key, iss="https://evil.example.com/realms/idp")
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), f"Bearer {token}")
    assert exc_info.value.status_code == 401


async def test_batch_token_for_another_audience_is_rejected(signing_key):
    token = make_batch_token(signing_key, aud="another-client")
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), f"Bearer {token}")
    assert exc_info.value.status_code == 401


async def test_expired_batch_token_is_rejected(signing_key):
    now = int(time.time())
    token = make_batch_token(signing_key, iat=now - 600, exp=now - 300)
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), f"Bearer {token}")
    assert exc_info.value.status_code == 401


async def test_batch_token_without_tenant_claim_is_forbidden(signing_key):
    """ユーザ向けクライアントで取得したトークンではバッチAPIを使えないこと。

    idp-frontend には tenant_id のマッパーを付けていないため、署名・issuer・audience
    がすべて正しいユーザトークンでもこの経路は通らない。
    """
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), f"Bearer {make_token(signing_key)}")
    assert exc_info.value.status_code == 403


@pytest.mark.parametrize("claim_value", ["", "not-a-uuid", 12345])
async def test_batch_token_with_unusable_tenant_claim_is_forbidden(signing_key, claim_value):
    """クレームがUUIDとして読めない場合にテナントを推測で埋めないこと。"""
    token = make_batch_token(signing_key, tenant_id=claim_value)
    with pytest.raises(ApiError) as exc_info:
        await get_batch_auth_context(make_request(), f"Bearer {token}")
    assert exc_info.value.status_code == 403


def test_batch_auth_does_not_read_tenant_headers():
    """テナントIDをヘッダから受け取る経路を復活させないための番人。

    Application Gateway側でも受信X-Tenant-Idを削除するが、削除ルールが漏れても
    成立しないようAPI側も読まない二重の担保(azure-architecture_v2.md §3.1 #1)。
    FastAPIはシグネチャの引数からヘッダを読むため、Authorization以外を取らないことを見る。
    requestはAPIリクエスト数の計上先(core/usage_counter.py)で、ヘッダは読まない。
    """
    params = inspect.signature(get_batch_auth_context).parameters
    assert list(params) == ["request", "authorization"]


async def test_local_mode_falls_back_to_dummy_tenant(monkeypatch):
    """ローカル開発ではKeycloakを立てずにバッチAPIを叩けること。"""
    monkeypatch.setattr(settings, "auth_mode", "local")
    monkeypatch.setattr(settings, "local_tenant_id", str(BATCH_TENANT_ID))

    auth = await get_batch_auth_context(make_request(), None)
    assert auth.tenant_id == BATCH_TENANT_ID
    assert auth.user_id is None
    assert auth.role == "batch"
