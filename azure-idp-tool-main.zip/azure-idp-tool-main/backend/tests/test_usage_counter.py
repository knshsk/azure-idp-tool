"""APIリクエスト数の計上(core/usage_counter.py)のテスト。

DBは触らない — ここで確かめたいのはUPSERTのSQLではなく、
「どのリクエストを、どのテナントの、どの日付に数えるか」と
「計上が失敗してもレスポンスを壊さないか」のため。
"""

import uuid
from datetime import UTC, datetime

import pytest
from fastapi import Request

from app.core import usage_counter
from app.core.usage_counter import (
    count_requests_middleware,
    get_request_tenant,
    set_request_tenant,
)

TENANT_ID = uuid.UUID("11111111-1111-1111-1111-111111111111")


def make_request() -> Request:
    return Request({"type": "http", "method": "GET", "path": "/", "headers": [], "state": {}})


class TestRequestTenant:
    def test_tenant_round_trips_through_request_state(self):
        request = make_request()
        set_request_tenant(request, TENANT_ID)
        assert get_request_tenant(request) == TENANT_ID

    def test_unauthenticated_request_has_no_tenant(self):
        assert get_request_tenant(make_request()) is None

    def test_state_is_shared_across_request_objects_of_same_scope(self):
        """ミドルウェアとエンドポイントで別のRequestが作られても同じstateを見ること。

        stateはASGI scopeに載るため成立する。ここが崩れるとミドルウェアが
        テナントを読めず、計上が黙って0件になる。
        """
        scope = {"type": "http", "method": "GET", "path": "/", "headers": [], "state": {}}
        set_request_tenant(Request(scope), TENANT_ID)
        assert get_request_tenant(Request(scope)) == TENANT_ID


class TestMiddleware:
    async def test_counts_once_for_authenticated_request(self, monkeypatch):
        calls: list[uuid.UUID] = []
        monkeypatch.setattr(
            usage_counter, "increment", lambda tenant_id: calls.append(tenant_id) or _noop()
        )

        request = make_request()

        async def call_next(_request):
            set_request_tenant(_request, TENANT_ID)
            return "response"

        result = await count_requests_middleware(request, call_next)

        assert result == "response"
        assert calls == [TENANT_ID]

    async def test_does_not_count_when_tenant_is_unresolved(self, monkeypatch):
        """認証前に弾かれたリクエストは数えないこと(どのテナント宛か決められない)。"""
        calls: list[uuid.UUID] = []
        monkeypatch.setattr(
            usage_counter, "increment", lambda tenant_id: calls.append(tenant_id) or _noop()
        )

        async def call_next(_request):
            return "unauthorized"

        result = await count_requests_middleware(make_request(), call_next)

        assert result == "unauthorized"
        assert calls == []

    async def test_counting_failure_does_not_break_the_response(self, monkeypatch):
        """計上できないことよりレスポンスを返せないことのほうが損失が大きい。

        この数字は利用状況の目安であり、課金根拠はdi_call_logs(FR-LOG-3)のため。
        """

        async def boom(tenant_id):
            raise RuntimeError("DBに繋がらない")

        monkeypatch.setattr(usage_counter, "increment", boom)

        async def call_next(_request):
            set_request_tenant(_request, TENANT_ID)
            return "response"

        assert await count_requests_middleware(make_request(), call_next) == "response"


class TestCountedDay:
    """計上先の日付がJSTで決まること(集計側 services/usage.py と揃える)。"""

    @pytest.mark.parametrize(
        ("moment", "expected"),
        [
            # UTC 2026-07-01 14:59 = JST 2026-07-01 23:59 → 7/1
            (datetime(2026, 7, 1, 14, 59, tzinfo=UTC), "2026-07-01"),
            # UTC 2026-07-01 15:00 = JST 2026-07-02 00:00 → 7/2
            (datetime(2026, 7, 1, 15, 0, tzinfo=UTC), "2026-07-02"),
        ],
    )
    def test_day_boundary_is_jst(self, moment, expected):
        assert moment.astimezone(usage_counter.JST).date().isoformat() == expected


async def _noop() -> None:
    return None
