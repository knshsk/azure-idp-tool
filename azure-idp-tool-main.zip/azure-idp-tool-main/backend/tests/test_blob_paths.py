"""Blobコンテナ名・パス導出のテスト。

コンテナ名の導出はテナント越境防止の要のため、単一経路(app.clients.blob)の
出力形式を固定する(azure-architecture_v2.md §3.4)。
"""

import uuid

from app.clients.blob import (
    layout_json_path,
    original_pdf_path,
    page_image_path,
    tenant_container_name,
)

TENANT_ID = uuid.UUID("00000000-0000-0000-0000-000000000001")
DOCUMENT_ID = uuid.UUID("11111111-2222-3333-4444-555555555555")


def test_tenant_container_name():
    assert tenant_container_name(TENANT_ID) == "tenant-00000000-0000-0000-0000-000000000001"


def test_container_names_differ_between_tenants():
    other = uuid.UUID("00000000-0000-0000-0000-000000000099")
    assert tenant_container_name(TENANT_ID) != tenant_container_name(other)


def test_blob_paths_follow_naming_convention():
    prefix = f"documents/{DOCUMENT_ID}"
    assert original_pdf_path(DOCUMENT_ID) == f"{prefix}/original.pdf"
    assert page_image_path(DOCUMENT_ID, 1) == f"{prefix}/pages/1.png"
    assert layout_json_path(DOCUMENT_ID) == f"{prefix}/analysis/layout.json"
