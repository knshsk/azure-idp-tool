from datetime import UTC, datetime

import pytest

from app.core.errors import ApiError
from app.services.usage import parse_month


class TestParseMonth:
    def test_month_boundaries_are_jst(self):
        start, end = parse_month("2026-07")
        # JST月初=前日15:00 UTC
        assert start == datetime(2026, 6, 30, 15, 0, tzinfo=UTC)
        assert end == datetime(2026, 7, 31, 15, 0, tzinfo=UTC)

    def test_december_rolls_to_next_year(self):
        start, end = parse_month("2026-12")
        assert start == datetime(2026, 11, 30, 15, 0, tzinfo=UTC)
        assert end == datetime(2026, 12, 31, 15, 0, tzinfo=UTC)

    @pytest.mark.parametrize("month", ["2026-13", "2026-00", "2026/07", "202607", "abc"])
    def test_invalid_month_raises(self, month):
        with pytest.raises(ApiError) as exc_info:
            parse_month(month)
        assert exc_info.value.code == "invalid_month"
