import uuid

import pytest

from app.core.auth import AuthContext, require_tenant_admin
from app.core.errors import ApiError


def _auth(role: str) -> AuthContext:
    return AuthContext(tenant_id=uuid.uuid4(), user_id=uuid.uuid4(), role=role)


def test_tenant_admin_is_allowed():
    require_tenant_admin(_auth("tenant_admin"))


def test_member_is_forbidden():
    with pytest.raises(ApiError) as exc_info:
        require_tenant_admin(_auth("member"))
    assert exc_info.value.status_code == 403
    assert exc_info.value.code == "forbidden"
