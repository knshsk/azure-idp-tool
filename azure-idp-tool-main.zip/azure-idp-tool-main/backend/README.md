# backend

Python 3.14 + FastAPI によるバックエンド。APIサーバとワーカーを同一パッケージ・同一Dockerイメージで実装し、起動コマンドのみ切り替える(設計決定事項)。

パッケージ管理は [uv](https://docs.astral.sh/uv/)、DBマイグレーションは Alembic、Lint/Format は Ruff を使用する。

## ディレクトリ構成

| パス | 内容 |
|---|---|
| `app/main.py` | FastAPI アプリのエントリポイント |
| `app/worker/` | ワーカーのエントリポイント(`python -m app.worker.main`)と定期ジョブ(回収処理・保持期間超過削除) |
| `app/routers/` | APIルーター(documents / document_types / share / admin / batch / health) |
| `app/services/` | ビジネスロジック(DI解析・正規化・エクスポート・共有リンク・利用量集計など) |
| `app/models/` | SQLAlchemy モデル(tenant / user / document / extracted_value など) |
| `app/schemas/` | Pydantic スキーマ(リクエスト/レスポンス) |
| `app/clients/` | 外部サービスクライアント(Blob Storage / Service Bus / Document Intelligence) |
| `app/core/` | 横断機能(認証・DB・DI(依存注入)・エラー・ロギング) |
| `app/config.py` | 設定(pydantic-settings。環境変数 / `.env` から読み込み) |
| `alembic/` | DBマイグレーション |
| `scripts/seed.py` | 開発用シードデータ投入 |
| `tests/` | ユニットテスト(pytest + pytest-asyncio) |

## セットアップと起動(WSL内)

前提: リポジトリルートで `docker compose up -d` 済み(PostgreSQL / Azurite / Service Busエミュレータ)。

```bash
cp .env.example .env   # DI_ENDPOINT / DI_KEY は各自受領した値を設定
uv sync
uv run alembic upgrade head
uv run python scripts/seed.py

# APIサーバ
uv run uvicorn app.main:app --reload --port 8000

# ワーカー(別ターミナル)
uv run python -m app.worker.main
```

環境変数の詳細は [.env.example](.env.example) と [docs/02_development/dev-environment.md](../docs/02_development/dev-environment.md) を参照。

## 開発コマンド

```bash
uv run pytest                 # テスト
uv run ruff check .           # Lint
uv run ruff format .          # Format
uv run alembic revision --autogenerate -m "説明"   # マイグレーション作成
```

## 補足

- **DB接続は2系統**: ランタイムはRLS適用対象の `app_user` ロール(`DATABASE_URL`)、マイグレーション・シードは所有者ロール(`MIGRATION_DATABASE_URL`)を使う。
- **認証**: `AUTH_MODE=local` でJWT検証をスキップし `LOCAL_*` の固定ユーザーとして動作(ローカル開発用)。`entra` でJWT検証。
- **キュー**: interactive / batch の2キューを購読し、interactive を優先消化する。リトライ可能なエラーは abandon で再配信に委ね、配信回数上限で DLQ + `status=failed` を記録する。
- 設計の詳細は [docs/01_design/api-design.md](../docs/01_design/api-design.md)、[data-model.md](../docs/01_design/data-model.md)、[blob-storage.md](../docs/01_design/blob-storage.md) を参照。
