// コンピュート: Managed Identity / ACR / Container Apps(API・ワーカー・Keycloak)
//                / Static Web Apps / DB初期化ジョブ / ロール割り当て
//
// 1モジュールにまとめている理由:
//   Keycloak は自身の公開URLを、API はその Keycloak の issuer URL を必要とし、
//   ACR pull のロール割り当ては Container Apps の作成より先に完了している必要がある。
//   モジュールを分けると compute → keycloak → compute の循環参照になるが、
//   同一モジュール内なら参照順で解決できる。
//
// イメージが ACR に存在しないと Container Apps は作成できないため、
// deployApps パラメータで2段階に分けてデプロイする(infra/README.md 参照)。

@description('アプリ名(リソース名の一部に使用)')
param appName string

@description('環境名(dev / prod)')
param env string

@description('リージョン')
param location string

@description('ネットワーク強化(VNet統合 + internal ingress)を有効にする')
param networkEnabled bool = false

@description('Container Apps 環境を配置するサブネットID(network.bicep の snet-aca)')
param acaSubnetId string = ''

@description('VNetのリソースID。internal環境のPrivate DNSゾーンをリンクするのに使う')
param vnetId string = ''

@description('ログ出力先の Log Analytics ワークスペース名(monitoring.bicep の出力)')
param logAnalyticsName string

@description('Static Web Apps のリージョン。SWAは対応リージョンが限られるため日本からは eastasia を使う')
param swaLocation string = 'eastasia'

// --- 公開URL ---

@description('''サービスの公開ホスト名(例: idp.example.com)。Application Gateway に
向けたDNS Aレコードを指す。Keycloakの KC_HOSTNAME と共有URLの組み立てに使う。

空の場合は Static Web Apps の既定ホスト名にフォールバックする(Application Gateway を
置かないdevフェーズ向け)。AppGWでHTTPSを終端するには証明書とカスタムドメインが要るため、
prodでは必ず指定する。''')
param publicHostname string = ''

// --- コンテナイメージ ---

@description('バックエンド(API・ワーカー)のイメージタグ。latest 禁止・必ず固定する(NFR-SEC-20)')
param imageTag string = 'v1'

@description('Keycloak のイメージタグ。同上')
param keycloakImageTag string = 'v1'

@description('Container Apps(API / ワーカー / Keycloak)をデプロイする。ACRへのイメージpush後に true にする')
param deployApps bool = false

// --- データ層への接続情報(data.bicep / ai.bicep の出力) ---

@description('PostgreSQL の FQDN')
param postgresFqdn string

@description('アプリ用データベース名')
param databaseName string

@description('Keycloak 用データベース名')
param keycloakDatabaseName string

@description('PostgreSQL 管理者ログイン名(所有者ロール)。DB初期化ジョブでのみ使う')
param postgresAdminLogin string

@description('PostgreSQL 管理者パスワード')
@secure()
param postgresAdminPassword string

@description('アプリ接続ロール(app_user)のパスワード。DBの初期化SQLで設定する値と揃える')
@secure()
param appUserPassword string

@description('Keycloak が DB へ接続するロール名')
param keycloakDbUser string = 'keycloak_user'

@description('同ロールのパスワード')
@secure()
param keycloakDbPassword string = ''

@description('Blob のエンドポイントURL')
param blobEndpoint string

@description('Service Bus の FQDN')
param serviceBusFqdn string

@description('Document Intelligence のエンドポイント')
param documentIntelligenceEndpoint string

// --- ロール割り当てのスコープになるリソース名 ---

param storageAccountName string
param serviceBusName string
param documentIntelligenceName string

// --- Keycloak ---

@description('レルム名。issuer URL の組み立てに使う')
param keycloakRealmName string = 'idp'

@description('Keycloak 初期管理者のユーザ名。レルム構成後は恒久的な管理者を作り無効化する(NFR-SEC-19)')
param keycloakAdminUsername string = 'kcadmin'

@description('Keycloak 初期管理者のパスワード')
@secure()
param keycloakAdminPassword string = ''

@description('APIが検証するJWTの aud。SPAのクライアントIDとは別の、API自身を指す識別子')
param oidcAudience string = 'idp-api'

// ---------------------------------------------------------------------------
// リソース名
// ---------------------------------------------------------------------------

var baseName = '${appName}-${env}'
var flatName = replace(baseName, '-', '')
var uniq = uniqueString(resourceGroup().id)
var isProd = env == 'prod'

var names = {
  identity: 'id-${baseName}'
  registry: 'cr${flatName}${uniq}'
  containerAppsEnv: 'cae-${baseName}'
  apiApp: 'ca-${baseName}-api'
  workerApp: 'ca-${baseName}-worker'
  keycloakApp: 'ca-${baseName}-keycloak'
  dbInitJob: 'caj-${baseName}-dbinit'
  staticWebApp: 'stapp-${baseName}'
}

var imageRepository = 'idp-backend'
var keycloakRepository = 'idp-keycloak'

// ---------------------------------------------------------------------------
// マネージドID
// ACR pull / Blob / Service Bus / Document Intelligence へのアクセスを集約する。
// システム割り当てだとアプリ作成前にRBACを付与できず初回のイメージpullに失敗するため
// ユーザ割り当てを使う。
// ---------------------------------------------------------------------------

resource appIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.identity
  location: location
}

// ---------------------------------------------------------------------------
// Container Registry
//
// 理想形は Premium + Private Endpoint だが、ここでは Standard(パブリック + MI pull)
// を既定にする。§2.2 で「イメージpullがパブリック経路になる(認証はMIで維持)」
// トレードオフを受容したダウングレード案として明記済み。脆弱性スキャンはCI側で行う。
// Premium化する場合は privatelink.azurecr.io ゾーンとPEの追加が要る。
// ---------------------------------------------------------------------------

resource registry 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: names.registry
  location: location
  sku: {
    name: 'Standard'
  }
  properties: {
    // 認証は Managed Identity に寄せる。管理者ユーザ(ユーザ名/パスワード)は使わない
    adminUserEnabled: false
  }
}

// ---------------------------------------------------------------------------
// ロール割り当て
// Container Apps は作成時点で ACR から pull するため、アプリより先に完了させる
// (各アプリの dependsOn で順序を固定する)。
// ---------------------------------------------------------------------------

var roleIds = {
  // pull のみ。push は az acr build 実行者の権限で行う
  acrPull: '7f951dda-4ed3-4680-a7ca-43fe172d538d'
  // テナント別コンテナを実行時に作成するため Reader ではなく Contributor
  storageBlobDataContributor: 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
  serviceBusDataSender: '69a216fc-b8fb-44d8-bc22-1f3c2cd27a39'
  serviceBusDataReceiver: '4f6d3b9b-027b-4f4c-9142-0e5a2a2247e0'
  cognitiveServicesUser: 'a97b65f3-24c7-4388-baec-2e87135dc908'
}

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' existing = {
  name: storageAccountName
}

resource serviceBus 'Microsoft.ServiceBus/namespaces@2024-01-01' existing = {
  name: serviceBusName
}

resource documentIntelligence 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = {
  name: documentIntelligenceName
}

resource acrPullAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: registry
  // 再デプロイで同じ割り当てになるよう決定的なGUIDを名前にする
  name: guid(registry.id, appIdentity.id, roleIds.acrPull)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.acrPull)
    principalId: appIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource blobAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: storageAccount
  name: guid(storageAccount.id, appIdentity.id, roleIds.storageBlobDataContributor)
  properties: {
    roleDefinitionId: subscriptionResourceId(
      'Microsoft.Authorization/roleDefinitions',
      roleIds.storageBlobDataContributor
    )
    principalId: appIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource sbSenderAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: serviceBus
  name: guid(serviceBus.id, appIdentity.id, roleIds.serviceBusDataSender)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.serviceBusDataSender)
    principalId: appIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource sbReceiverAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: serviceBus
  name: guid(serviceBus.id, appIdentity.id, roleIds.serviceBusDataReceiver)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.serviceBusDataReceiver)
    principalId: appIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

resource diAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: documentIntelligence
  name: guid(documentIntelligence.id, appIdentity.id, roleIds.cognitiveServicesUser)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.cognitiveServicesUser)
    principalId: appIdentity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// ---------------------------------------------------------------------------
// Container Apps 環境
// networkEnabled のときはVNet統合 + internal ingress にし、到達経路を
// Application Gateway のサブネットからのみに絞る(§3.2 #6)。
// ---------------------------------------------------------------------------

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: logAnalyticsName
}

resource containerAppsEnv 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: names.containerAppsEnv
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logAnalytics.properties.customerId
        sharedKey: logAnalytics.listKeys().primarySharedKey
      }
    }
    vnetConfiguration: networkEnabled
      ? {
          infrastructureSubnetId: acaSubnetId
          // 環境のFQDNをVNet内プライベートIPに解決させる。
          // これによりAppGW以外からは到達できなくなる
          internal: true
        }
      : null
    // ワークロードプロファイル型。消費専用(レガシー)環境は/23以上のサブネットが要る
    workloadProfiles: [
      {
        name: 'Consumption'
        workloadProfileType: 'Consumption'
      }
    ]
  }
}

// internal 環境の既定ドメインはパブリックDNSで引けないため、VNet内から名前解決
// できるようPrivate DNSゾーンを作る。Application Gateway のバックエンドプールが
// FQDNでバックエンドを引くのに必要(azure-architecture.md「Private DNSゾーン」)。
//
// ゾーン名になる既定ドメインは環境の作成後にしか確定せず、ARMはデプロイ開始時点で
// リソース名を解決する必要があるため、ネストしたデプロイに逃がしている(BCP120)。
module acaPrivateDns 'aca-private-dns.bicep' = if (networkEnabled) {
  name: 'aca-private-dns'
  params: {
    defaultDomain: containerAppsEnv.properties.defaultDomain
    staticIp: containerAppsEnv.properties.staticIp
    vnetId: vnetId
    linkName: 'link-vnet-${baseName}'
  }
}

// ---------------------------------------------------------------------------
// Static Web Apps
// SPAの配信。Application Gateway のバックエンドプールに載せ、APIと同一オリジンに
// する(§1.2 #8)。SWAのAPIリンク(linkedBackend)は使わない —
// 使うとAPIトラフィックがAppGWを迂回してWAFが意味をなさなくなる。
// ---------------------------------------------------------------------------

resource staticWebApp 'Microsoft.Web/staticSites@2023-12-01' = {
  name: names.staticWebApp
  location: swaLocation
  sku: {
    // Private Endpoint化(§1.2 #8の段階導入)にはStandard以上が要る
    name: isProd ? 'Standard' : 'Free'
    tier: isProd ? 'Standard' : 'Free'
  }
  properties: {
    // デプロイはCI/CDまたは az staticwebapp から行う。リポジトリ連携は張らない
    allowConfigFileUpdates: true
  }
}

// ---------------------------------------------------------------------------
// アプリケーション設定
// ---------------------------------------------------------------------------

// 公開ホスト名。未指定ならSWAの既定ホスト名にフォールバックする(AppGWなしのdev想定)。
// SPAの配信元・共有URLの組み立て先はこれでよい
var effectiveHost = empty(publicHostname) ? staticWebApp.properties.defaultHostname : publicHostname
var publicBaseUrl = 'https://${effectiveHost}'

var keycloakAppFqdn = '${names.keycloakApp}.${containerAppsEnv.properties.defaultDomain}'

// Keycloakの公開URL(= issuer のベース)は publicBaseUrl とは別に決める。
// Application Gateway を置く構成では /realms/* をKeycloakへ転送するので同一オリジンだが、
// AppGWを置かないdevフェーズ(azure-architecture_v2.md §4.1)ではブラウザも社内利用者も
// KeycloakのContainer Apps ingressへ直接来る。publicBaseUrl はそこでSWAのホスト名に
// フォールバックするため、そのまま使うと issuer が「Keycloakが居ないホスト」を指し、
// SPAのログインリダイレクトもAPIのJWKS取得も成立しなくなる。
var keycloakPublicUrl = empty(publicHostname) ? 'https://${keycloakAppFqdn}' : publicBaseUrl
var keycloakIssuer = '${keycloakPublicUrl}/realms/${keycloakRealmName}'

var backendImage = '${registry.properties.loginServer}/${imageRepository}:${imageTag}'
var keycloakImage = '${registry.properties.loginServer}/${keycloakRepository}:${keycloakImageTag}'

// アプリ接続ロール(app_user)。RLSの対象になるランタイム用ロール
var databaseUrl = 'postgresql+asyncpg://app_user:${appUserPassword}@${postgresFqdn}:5432/${databaseName}?ssl=require'
// 所有者ロール。マイグレーション・シード専用でDB初期化ジョブにしか渡さない
var migrationDatabaseUrl = 'postgresql+asyncpg://${postgresAdminLogin}:${postgresAdminPassword}@${postgresFqdn}:5432/${databaseName}?ssl=require'

// 接続文字列・キーを空にすることで、各クライアントが Managed Identity
// (DefaultAzureCredential)経路にフォールバックする実装になっている
// (backend/app/clients/{blob,queue,di}.py)
var commonEnv = [
  {
    name: 'DATABASE_URL'
    secretRef: 'database-url'
  }
  {
    // ユーザ割り当てMIを使う場合、DefaultAzureCredential にどのIDを使うかを明示する
    name: 'AZURE_CLIENT_ID'
    value: appIdentity.properties.clientId
  }
  {
    name: 'BLOB_ACCOUNT_URL'
    value: blobEndpoint
  }
  {
    name: 'BLOB_CONNECTION_STRING'
    value: ''
  }
  {
    name: 'SERVICE_BUS_NAMESPACE'
    value: serviceBusFqdn
  }
  {
    name: 'SERVICE_BUS_CONNECTION_STRING'
    value: ''
  }
  {
    name: 'SERVICE_BUS_QUEUE_INTERACTIVE'
    value: 'interactive'
  }
  {
    name: 'SERVICE_BUS_QUEUE_BATCH'
    value: 'batch'
  }
  {
    name: 'DI_ENDPOINT'
    value: documentIntelligenceEndpoint
  }
  {
    name: 'DI_KEY'
    value: ''
  }
  {
    // 本番構成ではKeycloakのJWT検証が唯一の認証強制点になる(§1.2 #3)。
    // local へ落とすと全員が tenant_admin になるため、この環境では使わない
    name: 'AUTH_MODE'
    value: 'keycloak'
  }
  {
    name: 'OIDC_ISSUER'
    value: keycloakIssuer
  }
  {
    name: 'OIDC_AUDIENCE'
    value: oidcAudience
  }
  {
    name: 'SHARE_BASE_URL'
    // 共有URLの受領者もApplication Gateway経由で来るため公開ホスト名で組み立てる
    value: '${publicBaseUrl}/share'
  }
]

var commonSecrets = [
  {
    name: 'database-url'
    value: databaseUrl
  }
]


var commonRegistries = [
  {
    server: registry.properties.loginServer
    identity: appIdentity.id
  }
]

var commonIdentity = {
  type: 'UserAssigned'
  userAssignedIdentities: {
    '${appIdentity.id}': {}
  }
}

var roleAssignmentDependencies = [
  acrPullAssignment
  blobAssignment
  sbSenderAssignment
  sbReceiverAssignment
  diAssignment
]

// ---------------------------------------------------------------------------
// API(FastAPI / uvicorn)
// ---------------------------------------------------------------------------

resource apiApp 'Microsoft.App/containerApps@2024-03-01' = if (deployApps) {
  name: names.apiApp
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      secrets: commonSecrets
      registries: commonRegistries
      ingress: {
        // networkEnabled のときは internal。到達経路をAppGWのサブネットに絞る
        external: !networkEnabled
        targetPort: 8000
        transport: 'auto'
        allowInsecure: false
        traffic: [
          {
            latestRevision: true
            weight: 100
          }
        ]
      }
    }
    template: {
      containers: [
        {
          name: 'api'
          image: backendImage
          // 起動コマンドは指定しない(Dockerfile の CMD = uvicorn を使う)
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: commonEnv
          probes: [
            {
              type: 'Readiness'
              httpGet: {
                path: '/healthz'
                port: 8000
              }
              initialDelaySeconds: 10
              periodSeconds: 10
              failureThreshold: 6
            }
          ]
        }
      ]
      scale: {
        // 本番はコールドスタートを避けるため常時1レプリカ(§1.1)
        minReplicas: isProd ? 1 : 0
        maxReplicas: isProd ? 5 : 2
      }
    }
  }
  dependsOn: roleAssignmentDependencies
}

// ---------------------------------------------------------------------------
// ワーカー(キュー消化・DI解析・定期ジョブ)
// ingress なし。定期ジョブ(回収処理・保持期間超過削除)がレプリカごとに動くため、
// 多重起動を避ける意味でも最小構成では1レプリカに寄せる。
// ---------------------------------------------------------------------------

resource workerApp 'Microsoft.App/containerApps@2024-03-01' = if (deployApps) {
  name: names.workerApp
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      secrets: commonSecrets
      registries: commonRegistries
    }
    template: {
      containers: [
        {
          name: 'worker'
          image: backendImage
          // APIと同一イメージ。起動コマンドでワーカーに切り替える
          command: [
            'python'
            '-m'
            'app.worker.main'
          ]
          resources: {
            // ページPNG生成(pypdfium2 + Pillow)があるためAPIより多めに取る
            cpu: json('1.0')
            memory: '2Gi'
          }
          env: commonEnv
        }
      ]
      scale: {
        minReplicas: isProd ? 1 : 0
        maxReplicas: 1
      }
    }
  }
  dependsOn: roleAssignmentDependencies
}

// ---------------------------------------------------------------------------
// Keycloak(認証基盤)
//
// 前提となる手作業: Keycloak が使うDBロールはBicepでは作れないため、
// デプロイ前に初期化SQLを流しておく。ロールが無い状態で起動すると
// コンテナが起動失敗を繰り返す。
// ---------------------------------------------------------------------------

resource keycloakApp 'Microsoft.App/containerApps@2024-03-01' = if (deployApps) {
  name: names.keycloakApp
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      registries: commonRegistries
      secrets: [
        {
          name: 'keycloak-db-password'
          value: keycloakDbPassword
        }
        {
          name: 'keycloak-admin-password'
          value: keycloakAdminPassword
        }
      ]
      ingress: {
        external: !networkEnabled
        targetPort: 8080
        transport: 'auto'
        allowInsecure: false
        traffic: [
          {
            latestRevision: true
            weight: 100
          }
        ]
      }
    }
    template: {
      containers: [
        {
          name: 'keycloak'
          image: keycloakImage
          args: [
            'start'
            '--optimized'
            '--import-realm'
          ]
          resources: {
            // JVMアプリなのでAPIより多めに取る
            cpu: json('1.0')
            memory: '2Gi'
          }
          env: [
            {
              // Azure PostgreSQL は TLS 必須
              name: 'KC_DB_URL'
              value: 'jdbc:postgresql://${postgresFqdn}:5432/${keycloakDatabaseName}?sslmode=require'
            }
            {
              name: 'KC_DB_USERNAME'
              value: keycloakDbUser
            }
            {
              name: 'KC_DB_PASSWORD'
              secretRef: 'keycloak-db-password'
            }
            {
              // ブラウザから見える公開URL。AppGWを置く構成ではそのホスト名、
              // 置かない構成では自身のContainer Apps ingressのFQDNになる
              name: 'KC_HOSTNAME'
              value: keycloakPublicUrl
            }
            {
              // AppGW / ACA ingress が TLS を終端し、コンテナへは HTTP で届く
              name: 'KC_HTTP_ENABLED'
              value: 'true'
            }
            {
              name: 'KC_PROXY_HEADERS'
              value: 'xforwarded'
            }
            {
              // 初回起動時にのみ作られる。レルム構成後は恒久的な管理者を作って
              // このアカウントを無効化する(NFR-SEC-19)
              name: 'KC_BOOTSTRAP_ADMIN_USERNAME'
              value: keycloakAdminUsername
            }
            {
              name: 'KC_BOOTSTRAP_ADMIN_PASSWORD'
              secretRef: 'keycloak-admin-password'
            }
          ]
          probes: [
            {
              // 初回起動は構成ビルド + DBスキーマ作成が走るため長めに待つ
              type: 'Startup'
              httpGet: {
                // Keycloak 25以降、ヘルスは9000番の管理ポートで待ち受ける
                path: '/health/started'
                port: 9000
              }
              periodSeconds: 10
              failureThreshold: 30
            }
            {
              type: 'Readiness'
              httpGet: {
                path: '/health/ready'
                port: 9000
              }
              periodSeconds: 10
              failureThreshold: 3
            }
          ]
        }
      ]
      scale: {
        // 起動が遅くセッションを保持するためスケールゼロにしない。
        // 複数レプリカにはInfinispanのクラスタ構成が必要
        minReplicas: 1
        maxReplicas: 1
      }
    }
  }
  dependsOn: roleAssignmentDependencies
}

// ---------------------------------------------------------------------------
// DB初期化ジョブ(マニュアル実行)
//
// マイグレーション(alembic)とシード(scripts/seed.py)をAzure内から実行する。
// どちらも冪等なため何度実行してもよい。
//
// 所有者ロールの接続文字列を持つのはこのジョブだけにする。API・ワーカーには
// アプリ接続ロール(app_user)しか渡さない(RLSのロール分離: §3.4 #11)。
// ---------------------------------------------------------------------------

resource dbInitJob 'Microsoft.App/jobs@2024-03-01' = if (deployApps) {
  name: names.dbInitJob
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnv.id
    configuration: {
      triggerType: 'Manual'
      replicaTimeout: 1800
      // 失敗を握り潰さず、ログを見て対処する
      replicaRetryLimit: 0
      manualTriggerConfig: {
        parallelism: 1
        replicaCompletionCount: 1
      }
      secrets: [
        {
          // 接続文字列は @secure() パラメータから組み立てた変数。変数はsecureの印を
          // 引き継がないためlinterが警告するが、値の出どころはsecureで、ここでは
          // Container Apps のシークレットとして格納される
          name: 'migration-database-url'
          #disable-next-line use-secure-value-for-secure-inputs
          value: migrationDatabaseUrl
        }
        {
          name: 'database-url'
          #disable-next-line use-secure-value-for-secure-inputs
          value: databaseUrl
        }
      ]
      registries: commonRegistries
    }
    template: {
      containers: [
        {
          name: 'db-init'
          image: backendImage
          command: [
            'sh'
            '-c'
          ]
          args: [
            'alembic upgrade head && python scripts/seed.py'
          ]
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: [
            {
              // alembic と seed.py は所有者ロールで実行する
              // (RLS FORCE下ではアプリロールはDDL不可。backend/alembic/env.py)
              name: 'MIGRATION_DATABASE_URL'
              secretRef: 'migration-database-url'
            }
            {
              name: 'DATABASE_URL'
              secretRef: 'database-url'
            }
          ]
        }
      ]
    }
  }
  dependsOn: roleAssignmentDependencies
}

// ---------------------------------------------------------------------------
// 出力
// ---------------------------------------------------------------------------

output identityId string = appIdentity.id
output identityPrincipalId string = appIdentity.properties.principalId
output registryLoginServer string = registry.properties.loginServer
output containerAppsEnvName string = containerAppsEnv.name
output containerAppsDefaultDomain string = containerAppsEnv.properties.defaultDomain
output staticWebAppHostname string = staticWebApp.properties.defaultHostname

// Application Gateway のバックエンドプールが引くFQDN。
// アプリ未デプロイでも <アプリ名>.<既定ドメイン> で確定するため常に組み立てられる
output apiFqdn string = '${names.apiApp}.${containerAppsEnv.properties.defaultDomain}'
output keycloakFqdn string = keycloakAppFqdn
@description('バックエンドの OIDC_ISSUER・フロントエンドの VITE_OIDC_ISSUER に設定する値')
output keycloakIssuerUrl string = keycloakIssuer
@description('サービスの公開URL。publicHostname 未指定時はSWAの既定ホスト名にフォールバックしている')
output publicBaseUrl string = publicBaseUrl
