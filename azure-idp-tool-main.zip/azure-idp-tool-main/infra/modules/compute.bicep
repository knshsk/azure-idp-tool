// Container Apps環境(API + ワーカー) / Container Registry / Static Web Apps
param appName string
param env string
param location string
param networkEnabled bool = false

// TODO: 実装
// - Container Apps環境(dev: external ingress+社内IP制限 / networkEnabled時: internal ingress)
// - API・ワーカーは同一イメージ・起動コマンド違いの2アプリ
//   ワーカーはKEDAスケール(dev: 最小0 / prod: 最小1)
// - ACR(MI pull。dev: Basic / prod: Standard〜Premium)
// - Static Web Apps(dev: Free / prod: Standard)
// - Managed Identity(Blob / Service Bus / DI / PostgreSQLへのロール割り当て)

output placeholder string = 'compute-${appName}-${env}-${location}-${networkEnabled}'
