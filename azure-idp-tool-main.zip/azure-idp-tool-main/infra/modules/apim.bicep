// API Management + ポリシー
param appName string
param env string
param location string

// TODO: 実装
// - APIM(dev検証: Basic v2 / PoC以降: Standard v2)
// - ポリシーは infra/policies/*.xml を loadTextContent() で読み込む
//   (validate-jwt / X-Tenant-Id 無条件削除→再設定 / サブスクキーはヘッダのみ /
//    ボディサイズ上限 / レート制限 — azure-architecture_v2.md §3.1)

output placeholder string = 'apim-${appName}-${env}-${location}'
