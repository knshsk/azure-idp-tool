// Log Analytics / 診断設定 / アラート
param appName string
param env string
param location string

// TODO: 実装
// - Log Analyticsワークスペース(dev: 最小構成)
// - 診断設定(APIM診断 / ACAログ / pgaudit / Blobアクセスログ)
// - アラート(認証失敗急増 / 共有トークン検証失敗連続 / DLQ滞留 / SBファイアウォール拒否)
//   ※アラート整備はリリースフェーズ(azure-architecture_v2.md §4.3)

output placeholder string = 'log-${appName}-${env}-${location}'
