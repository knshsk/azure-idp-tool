// 監視: Log Analytics ワークスペース
//
// Application Gateway のアクセス・WAFログ、Container Apps のログ、
// PostgreSQL の pgaudit、Blob アクセスログの集約先(azure-architecture_v2.md §3.5)。
//
// 各リソースの診断設定は、そのリソースを作るモジュール側で
// このワークスペースを指して張る(appgw.bicep / compute.bicep)。
// アラート(認証失敗急増・DLQ滞留等)はリリースフェーズで整備する(§4.3)。

@description('アプリ名(リソース名の一部に使用)')
param appName string

@description('環境名(dev / prod)')
param env string

@description('リージョン')
param location string

@description('ログの保持日数。devは最小構成、prodは監査の遡及調査を見込んで長めに取る')
@minValue(30)
@maxValue(730)
param retentionInDays int = env == 'prod' ? 90 : 30

@description('日次の取り込み上限(GB)。-1 で無制限。想定外のログ流入で課金が跳ねるのを防ぐ')
param dailyQuotaGb int = env == 'prod' ? 10 : 1

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'log-${appName}-${env}'
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: retentionInDays
    workspaceCapping: {
      dailyQuotaGb: dailyQuotaGb
    }
    features: {
      // ワークスペース単位のRBACに寄せる(リソース単位の権限だけでログを引けると
      // 監査ログの閲覧範囲を絞りにくくなるため)
      enableLogAccessUsingOnlyResourcePermissions: false
    }
  }
}

output id string = logAnalytics.id
output name string = logAnalytics.name
output customerId string = logAnalytics.properties.customerId
