// Container Apps(internal 環境)の Private DNS ゾーン
//
// compute.bicep から切り出している理由:
//   ゾーン名になる環境の既定ドメインは、環境を作ってからでないと確定しない。
//   ARMはデプロイ開始時点でリソース名を解決できる必要があるため、同じテンプレート内では
//   `containerAppsEnv.properties.defaultDomain` をリソース名に使えない(BCP120)。
//   ネストしたデプロイ(モジュール)は親の実行後に評価されるため、実行時に決まる値を
//   パラメータとして受け取ればリソース名に使える。
//
// これがないと Application Gateway のバックエンドプールが internal 環境の
// FQDN を名前解決できない(azure-architecture.md「Private DNSゾーン」)。

@description('Container Apps 環境の既定ドメイン。そのままゾーン名になる')
param defaultDomain string

@description('Container Apps 環境の静的IP。ゾーン内のAレコードが指す先')
param staticIp string

@description('ゾーンをリンクするVNetのリソースID')
param vnetId string

@description('VNetリンク名')
param linkName string

resource zone 'Microsoft.Network/privateDnsZones@2024-06-01' = {
  name: defaultDomain
  location: 'global'
}

resource wildcardRecord 'Microsoft.Network/privateDnsZones/A@2024-06-01' = {
  parent: zone
  // 各アプリのFQDNは <アプリ名>.<既定ドメイン> になるためワイルドカードで受ける
  name: '*'
  properties: {
    ttl: 3600
    aRecords: [
      {
        ipv4Address: staticIp
      }
    ]
  }
}

resource link 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = {
  parent: zone
  name: linkName
  location: 'global'
  properties: {
    virtualNetwork: {
      id: vnetId
    }
    registrationEnabled: false
  }
}

output zoneId string = zone.id
output zoneName string = zone.name
