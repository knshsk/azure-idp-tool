// VNet / サブネット / NSG / NAT Gateway / Private DNS ゾーン
//
// 構成は azure-architecture.md「ネットワーク設計」に対応する。
// 全サブネットにNSGを敷く(azure-architecture_v2.md §3.2 #6)。
//
// Private Endpoint 本体は接続先リソース側(data.bicep)で作る。ここが持つのは
// 受け皿となるサブネットと、名前解決のための Private DNS ゾーン+VNetリンク。

@description('アプリ名(リソース名の一部に使用)')
param appName string

@description('環境名(dev / prod)')
param env string

@description('リージョン')
param location string

@description('VNetのアドレス空間')
param vnetAddressPrefix string = '10.0.0.0/16'

@description('Application Gateway 専用サブネット。AppGW v2 は最小 /24 を推奨')
param appGatewaySubnetPrefix string = '10.0.0.0/24'

@description('Container Apps 環境のサブネット。ワークロードプロファイル型は最小 /27')
param acaSubnetPrefix string = '10.0.1.0/27'

@description('Private Endpoint 集約用サブネット')
param privateEndpointSubnetPrefix string = '10.0.2.0/27'

var baseName = '${appName}-${env}'

// Private Endpoint を張る対象。ゾーン名はサービス側で決まっている。
// Blobのサフィックスはクラウド(Public / Government等)で変わるためenvironment()から取る
var privateDnsZoneNames = [
  'privatelink.postgres.database.azure.com'
  'privatelink.blob.${environment().suffixes.storage}'
  'privatelink.cognitiveservices.azure.com'
]

// ---------------------------------------------------------------------------
// NSG
// ---------------------------------------------------------------------------

// Application Gateway v2 は GatewayManager からの 65200-65535 受信を必須とする。
// これを塞ぐとゲートウェイが Unhealthy のまま起動しない。
resource appGatewayNsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: 'nsg-${baseName}-appgw'
  location: location
  properties: {
    securityRules: [
      {
        name: 'Allow-GatewayManager-Inbound'
        properties: {
          description: 'AppGW v2 の管理・ヘルス通信(必須)'
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourceAddressPrefix: 'GatewayManager'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '65200-65535'
        }
      }
      {
        name: 'Allow-AzureLoadBalancer-Inbound'
        properties: {
          description: 'ヘルスプローブ(必須)'
          priority: 110
          direction: 'Inbound'
          access: 'Allow'
          protocol: '*'
          sourceAddressPrefix: 'AzureLoadBalancer'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
      {
        name: 'Allow-Internet-Https-Inbound'
        properties: {
          description: '利用者からのHTTPS。公開接点はここだけ(azure-architecture_v2.md §1.2)'
          priority: 200
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourceAddressPrefix: 'Internet'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRanges: ['80', '443']
        }
      }
      {
        name: 'Deny-Other-Inbound'
        properties: {
          description: '上記以外の受信を明示的に落とす'
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourceAddressPrefix: '*'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
    ]
  }
}

// Container Apps 環境の受信は Application Gateway サブネットからのみ許可する
// (azure-architecture_v2.md §3.2 #6)。internal ingress でもVNet内から到達できるため、
// 将来サブネットを足したときに穴にならないよう明示的に絞る。
resource acaNsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: 'nsg-${baseName}-aca'
  location: location
  properties: {
    securityRules: [
      {
        name: 'Allow-AppGateway-Inbound'
        properties: {
          description: 'AppGWからのアプリトラフィックのみ'
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourceAddressPrefix: appGatewaySubnetPrefix
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRanges: ['80', '443']
        }
      }
      {
        name: 'Allow-Intra-Subnet-Inbound'
        properties: {
          description: 'Container Apps 環境内のノード間通信(必須)'
          priority: 110
          direction: 'Inbound'
          access: 'Allow'
          protocol: '*'
          sourceAddressPrefix: acaSubnetPrefix
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
      {
        name: 'Allow-AzureLoadBalancer-Inbound'
        properties: {
          description: 'ヘルスプローブ(必須)'
          priority: 120
          direction: 'Inbound'
          access: 'Allow'
          protocol: '*'
          sourceAddressPrefix: 'AzureLoadBalancer'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
      {
        name: 'Deny-Other-Inbound'
        properties: {
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourceAddressPrefix: '*'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
    ]
  }
}

// Private Endpoint への到達も Container Apps からのみに絞る。
// NSGをPEに効かせるにはサブネット側で privateEndpointNetworkPolicies を有効にする必要がある。
resource privateEndpointNsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: 'nsg-${baseName}-pe'
  location: location
  properties: {
    securityRules: [
      {
        name: 'Allow-Aca-Inbound'
        properties: {
          description: 'PostgreSQL / Blob / Document Intelligence への接続元はACAのみ'
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourceAddressPrefix: acaSubnetPrefix
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRanges: ['443', '5432']
        }
      }
      {
        name: 'Deny-Other-Inbound'
        properties: {
          priority: 4096
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourceAddressPrefix: '*'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// NAT Gateway
// Service Bus は Private Endpoint 不可(Premium専用)のため、送信IPを固定して
// IPファイアウォールで絞る。これを削るとファイアウォール自体が成立しない
// (azure-architecture_v2.md §2.2「削るべきでないもの」)。
// ---------------------------------------------------------------------------

resource natGatewayPublicIp 'Microsoft.Network/publicIPAddresses@2024-05-01' = {
  name: 'pip-${baseName}-natgw'
  location: location
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
  }
}

resource natGateway 'Microsoft.Network/natGateways@2024-05-01' = {
  name: 'ng-${baseName}'
  location: location
  sku: {
    name: 'Standard'
  }
  properties: {
    publicIpAddresses: [
      {
        id: natGatewayPublicIp.id
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// VNet / サブネット
// ---------------------------------------------------------------------------

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' = {
  name: 'vnet-${baseName}'
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [vnetAddressPrefix]
    }
    subnets: [
      {
        // AppGW専用。他のリソースと同居できない
        name: 'snet-appgw'
        properties: {
          addressPrefix: appGatewaySubnetPrefix
          networkSecurityGroup: {
            id: appGatewayNsg.id
          }
        }
      }
      {
        name: 'snet-aca'
        properties: {
          addressPrefix: acaSubnetPrefix
          networkSecurityGroup: {
            id: acaNsg.id
          }
          natGateway: {
            id: natGateway.id
          }
          delegations: [
            {
              name: 'aca-delegation'
              properties: {
                serviceName: 'Microsoft.App/environments'
              }
            }
          ]
        }
      }
      {
        name: 'snet-pe'
        properties: {
          addressPrefix: privateEndpointSubnetPrefix
          networkSecurityGroup: {
            id: privateEndpointNsg.id
          }
          // NSGをPrivate Endpointに適用するために有効化する。
          // 既定(Disabled)のままだとPEはNSGを素通りし、上のnsg-peが効かない
          privateEndpointNetworkPolicies: 'Enabled'
        }
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// Private DNS ゾーン
// Private Endpoint の名前解決用。VNetにリンクして初めてVNet内から引ける。
//
// Container Apps 環境の既定ドメインのゾーンはここでは作らない。ドメインが
// 環境作成後にしか確定せず、Aレコードに書く静的IPも同時に必要になるため、
// 環境を作る compute.bicep 側で扱う(azure-architecture.md「Private DNSゾーン」)。
// ---------------------------------------------------------------------------

resource privateDnsZones 'Microsoft.Network/privateDnsZones@2024-06-01' = [
  for zoneName in privateDnsZoneNames: {
    name: zoneName
    location: 'global'
  }
]

resource privateDnsZoneLinks 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = [
  for (zoneName, i) in privateDnsZoneNames: {
    parent: privateDnsZones[i]
    name: 'link-vnet-${baseName}'
    location: 'global'
    properties: {
      virtualNetwork: {
        id: vnet.id
      }
      // 自動登録はPEに不要(AレコードはPEが作る)
      registrationEnabled: false
    }
  }
]

// ---------------------------------------------------------------------------
// 出力
// ---------------------------------------------------------------------------

output vnetId string = vnet.id
output vnetName string = vnet.name
output appGatewaySubnetId string = vnet.properties.subnets[0].id
output acaSubnetId string = vnet.properties.subnets[1].id
output privateEndpointSubnetId string = vnet.properties.subnets[2].id
@description('Service Bus のIPファイアウォールに許可登録する送信IP')
output natGatewayPublicIp string = natGatewayPublicIp.properties.ipAddress

// Private Endpoint の privateDnsZoneGroups から参照する。
// 配列インデックスは privateDnsZoneNames の並びに対応する
output postgresPrivateDnsZoneId string = privateDnsZones[0].id
output blobPrivateDnsZoneId string = privateDnsZones[1].id
output cognitiveServicesPrivateDnsZoneId string = privateDnsZones[2].id
