// VNet / サブネット / NSG / Private Endpoint / NAT Gateway
// 全サブネットにNSGを敷く(azure-architecture_v2.md §3.2 #6)
param appName string
param env string
param location string

// TODO: 実装
// - VNet + サブネット(snet-aca / snet-apim統合 / snet-pe)
// - NSG(snet-acaの受信はAPIM統合サブネットのみ許可)
// - NAT Gateway(固定送信IP。Service BusのIPファイアウォールの成立条件)
// - Private Endpoint(PostgreSQL / Blob / Document Intelligence)

output placeholder string = 'vnet-${appName}-${env}-${location}'
