// PostgreSQL Flexible Server / Blob Storage / Service Bus
param appName string
param env string
param location string
param networkEnabled bool = false

// TODO: 実装
// - PostgreSQL Flexible Server(Entra ID認証。RLS・ロール分離はDBマイグレーション側)
//   dev: Burstable B1ms / prod: B2s〜
// - Blob Storage(テナント別コンテナ / ソフト削除+バージョニング / dev: LRS, prod: ZRS)
// - Service Bus Standard(interactive / batch 2キュー / MI認証・SAS無効)
// - networkEnabled時: パブリックアクセス無効化+Private Endpoint接続(network.bicep側)

output placeholder string = 'data-${appName}-${env}-${location}-${networkEnabled}'
