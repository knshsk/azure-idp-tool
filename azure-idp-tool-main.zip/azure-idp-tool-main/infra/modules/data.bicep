// データ層: PostgreSQL Flexible Server / Blob Storage / Service Bus
//
// networkEnabled のとき、PostgreSQL と Blob はパブリックアクセスを無効化して
// Private Endpoint 経由に切り替える(azure-architecture_v2.md §1.1)。
//
// Service Bus だけは Private Endpoint を張れない(Premium専用)。Standard でも
// IPファイアウォールは使えるため、NAT Gateway で固定した送信IPのみを許可し、
// Managed Identity 認証と併せて防御する(§3.3 #9)。

@description('アプリ名(リソース名の一部に使用)')
param appName string

@description('環境名(dev / prod)')
param env string

@description('リージョン')
param location string

@description('ネットワーク強化(パブリックアクセス無効化 + Private Endpoint)を有効にする')
param networkEnabled bool = false

@description('Private Endpoint を配置するサブネットID(network.bicep の snet-pe)')
param privateEndpointSubnetId string = ''

@description('PostgreSQL 用 Private DNS ゾーンID(network.bicep の出力)')
param postgresPrivateDnsZoneId string = ''

@description('Blob 用 Private DNS ゾーンID(network.bicep の出力)')
param blobPrivateDnsZoneId string = ''

@description('Service Bus のIPファイアウォールで許可する送信IP(NAT Gatewayの固定IP)。空なら制限しない')
param allowedOutboundIp string = ''

// --- PostgreSQL ---

@description('PostgreSQL 管理者ログイン名。マイグレーションを実行する所有者ロールを兼ねる')
param postgresAdminLogin string = 'idpadmin'

@description('PostgreSQL 管理者パスワード。接続URLに埋め込むため @ : / ? # 等のURL予約文字は使わない')
@secure()
param postgresAdminPassword string

@description('Entra ID 認証の管理者にするプリンシパルのオブジェクトID。空なら設定しない')
param entraAdminObjectId string = ''

@description('Entra ID 認証の管理者の表示名(UPN等)')
param entraAdminPrincipalName string = ''

@description('アプリ用データベース名')
param databaseName string = 'idp'

@description('Keycloak 用データベース名。アプリDBとは別データベース・別ロールにする(§1.2)')
param keycloakDatabaseName string = 'keycloak'

// --- Service Bus ---

@description('キュー名の一覧')
param queueNames array = ['interactive', 'batch']

@description('キューの最大配信回数。backend の WORKER_MAX_DELIVERY_COUNT と揃える')
param maxDeliveryCount int = 5

// ---------------------------------------------------------------------------
// リソース名
// グローバル一意が必要なものはリソースグループIDから導いたサフィックスを付ける
// ---------------------------------------------------------------------------

var baseName = '${appName}-${env}'
var flatName = replace(baseName, '-', '')
var uniq = uniqueString(resourceGroup().id)

var storageAccountName = 'st${flatName}${take(uniq, 8)}'
var postgresName = 'psql-${baseName}-${uniq}'
var serviceBusName = 'sb-${baseName}-${uniq}'

var isProd = env == 'prod'

// ---------------------------------------------------------------------------
// Blob Storage
// 原本PDF・ページPNG・DI解析結果JSON の保管先(blob-storage.md)。
// テナント別コンテナはアプリが実行時に作成する(app/clients/blob.py)。
// ---------------------------------------------------------------------------

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageAccountName
  location: location
  sku: {
    // 本番はゾーン冗長(§1.1)。devはコスト優先でローカル冗長
    name: isProd ? 'Standard_ZRS' : 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    supportsHttpsTrafficOnly: true
    // 匿名アクセスは禁止。Blobは必ずAPI経由で配信する
    allowBlobPublicAccess: false
    // アクセスキー・SASを無効化し、Managed Identity認証のみにする(§1.2)
    allowSharedKeyAccess: false
    publicNetworkAccess: networkEnabled ? 'Disabled' : 'Enabled'
    networkAcls: {
      defaultAction: networkEnabled ? 'Deny' : 'Allow'
      bypass: 'AzureServices'
    }
  }
}

// 日次削除ジョブの誤爆に対する安全網(§3.4 #13)。
// 論理削除+バージョニングは安価な保険で、消してはいけない類のもの
resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2023-05-01' = {
  parent: storageAccount
  name: 'default'
  properties: {
    isVersioningEnabled: true
    deleteRetentionPolicy: {
      enabled: true
      days: 7
    }
    containerDeleteRetentionPolicy: {
      enabled: true
      days: 7
    }
  }
}

resource blobPrivateEndpoint 'Microsoft.Network/privateEndpoints@2024-05-01' = if (networkEnabled) {
  name: 'pe-${baseName}-blob'
  location: location
  properties: {
    subnet: {
      id: privateEndpointSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'blob'
        properties: {
          privateLinkServiceId: storageAccount.id
          groupIds: ['blob']
        }
      }
    ]
  }
}

resource blobPrivateDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = if (networkEnabled) {
  parent: blobPrivateEndpoint
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'blob'
        properties: {
          privateDnsZoneId: blobPrivateDnsZoneId
        }
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// PostgreSQL Flexible Server
//
// RLSのロール分離(所有者ロール=管理者 / アプリロール=app_user)はDB側の
// 初期化SQLで構成する。テンプレートで作るのはサーバとデータベースまで。
// ---------------------------------------------------------------------------

resource postgres 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' = {
  name: postgresName
  location: location
  sku: {
    // PoC以降はB2s(§1.3)。devは最小SKU
    name: isProd ? 'Standard_B2s' : 'Standard_B1ms'
    tier: 'Burstable'
  }
  properties: {
    // ローカル開発の docker-compose(postgres:16)と揃える
    version: '16'
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
    storage: {
      storageSizeGB: isProd ? 128 : 32
      autoGrow: 'Enabled'
    }
    backup: {
      // PITRの遡及可能期間(§1.1)
      backupRetentionDays: isProd ? 14 : 7
      geoRedundantBackup: 'Disabled'
    }
    highAvailability: {
      // Burstableティアは高可用性に非対応。必要になったらGeneralPurposeへ上げる
      mode: 'Disabled'
    }
    network: {
      publicNetworkAccess: networkEnabled ? 'Disabled' : 'Enabled'
    }
    authConfig: {
      // Entra ID認証を有効にする(§1.2 #5)。ただしバックエンドは現状
      // DATABASE_URL のパスワード接続のままのため、パスワード認証も残す。
      // トークン取得処理を実装したらpasswordAuthをDisabledにできる
      activeDirectoryAuth: 'Enabled'
      passwordAuth: 'Enabled'
      tenantId: subscription().tenantId
    }
  }
}

// 監査ログ(§3.5)。pgaudit は共有ライブラリのプリロードとログ出力先の両方が要る
resource pgauditSharedPreload 'Microsoft.DBforPostgreSQL/flexibleServers/configurations@2024-08-01' = {
  parent: postgres
  name: 'shared_preload_libraries'
  properties: {
    value: 'pgaudit'
    source: 'user-override'
  }
}

resource pgauditLog 'Microsoft.DBforPostgreSQL/flexibleServers/configurations@2024-08-01' = {
  parent: postgres
  name: 'pgaudit.log'
  properties: {
    // 誰が何を読んだかまで残す。WRITEのみだと越境参照の追跡ができない
    value: isProd ? 'WRITE,DDL,ROLE,READ' : 'WRITE,DDL,ROLE'
    source: 'user-override'
  }
  dependsOn: [
    pgauditSharedPreload
  ]
}

resource database 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: postgres
  name: databaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
  dependsOn: [
    pgauditLog
  ]
}

// Keycloakのストア。アプリDBと同一サーバ上の別データベース・別ロールにして
// アプリのRLS・権限境界と混ぜない(§1.2)。
// 同一サーバへのデータベース作成は同時実行できないため dependsOn で直列化する
resource keycloakDatabase 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: postgres
  name: keycloakDatabaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
  dependsOn: [
    database
  ]
}

resource entraAdmin 'Microsoft.DBforPostgreSQL/flexibleServers/administrators@2024-08-01' = if (!empty(entraAdminObjectId)) {
  parent: postgres
  name: entraAdminObjectId
  properties: {
    principalType: 'User'
    principalName: entraAdminPrincipalName
    tenantId: subscription().tenantId
  }
  dependsOn: [
    keycloakDatabase
  ]
}

resource postgresPrivateEndpoint 'Microsoft.Network/privateEndpoints@2024-05-01' = if (networkEnabled) {
  name: 'pe-${baseName}-psql'
  location: location
  properties: {
    subnet: {
      id: privateEndpointSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'postgres'
        properties: {
          privateLinkServiceId: postgres.id
          groupIds: ['postgresqlServer']
        }
      }
    ]
  }
}

resource postgresPrivateDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = if (networkEnabled) {
  parent: postgresPrivateEndpoint
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'postgres'
        properties: {
          privateDnsZoneId: postgresPrivateDnsZoneId
        }
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// Service Bus
// interactive(対話操作)/ batch(バッチ連携)の2キュー構成。
// ---------------------------------------------------------------------------

resource serviceBus 'Microsoft.ServiceBus/namespaces@2024-01-01' = {
  name: serviceBusName
  location: location
  sku: {
    // Private Endpoint が要るならPremium(月$680〜)だが、規模に対して過剰。
    // Standard + IPファイアウォール + MI認証で受容する(§1.1)
    name: 'Standard'
    tier: 'Standard'
  }
  properties: {
    // SAS(接続文字列)認証を無効化し、Managed Identity 認証のみにする
    disableLocalAuth: true
    minimumTlsVersion: '1.2'
  }
}

// IPファイアウォール。NAT Gatewayで固定した送信IPだけを通す(§3.3 #9)。
//
// 注意点が3つある:
//   1. defaultAction の既定は Allow。Deny を明示しないとルールが評価されない
//   2. ipRules が空だと defaultAction=Deny でも全通しになる。だから
//      allowedOutboundIp が空のときはこのリソース自体を作らない
//   3. Standard SKU は「信頼されたMicrosoftサービスのバイパス」に非対応。
//      またポータルの「ネットワーク」タブはPremiumでしか出ないため、
//      設定の確認・変更は ARM か az servicebus namespace network-rule-set で行う
resource serviceBusNetworkRules 'Microsoft.ServiceBus/namespaces/networkRuleSets@2024-01-01' = if (!empty(allowedOutboundIp)) {
  parent: serviceBus
  name: 'default'
  properties: {
    publicNetworkAccess: 'Enabled'
    defaultAction: 'Deny'
    virtualNetworkRules: []
    ipRules: [
      {
        ipMask: allowedOutboundIp
        action: 'Allow'
      }
    ]
  }
}

resource queues 'Microsoft.ServiceBus/namespaces/queues@2024-01-01' = [
  for queueName in queueNames: {
    parent: serviceBus
    name: queueName
    properties: {
      maxDeliveryCount: maxDeliveryCount
      // DI解析はロック時間を超えるため、ワーカーが AutoLockRenewer で延長する。
      // 初期ロックは最大値の5分にしておく
      lockDuration: 'PT5M'
      defaultMessageTimeToLive: 'P1D'
      deadLetteringOnMessageExpiration: true
    }
  }
]

// ---------------------------------------------------------------------------
// 出力
// ---------------------------------------------------------------------------

output storageAccountName string = storageAccount.name
output blobEndpoint string = storageAccount.properties.primaryEndpoints.blob
output postgresName string = postgres.name
output postgresFqdn string = postgres.properties.fullyQualifiedDomainName
output databaseName string = databaseName
output keycloakDatabaseName string = keycloakDatabaseName
output serviceBusName string = serviceBus.name
output serviceBusFqdn string = '${serviceBus.name}.servicebus.windows.net'
@description('false の場合、Service BusのIPファイアウォールが未設定(全通し)である')
output serviceBusIpFilterEnabled bool = !empty(allowedOutboundIp)
