// Application Gateway v2 + WAF ポリシー
//
// サービスの公開接点(azure-architecture_v2.md §3.1)。
// VNet内の専用サブネットに配置し、Container Apps(internal ingress)へ
// VNet内でプライベートに転送する。
//
// 担う責務:
//   - WAF: OWASP CRS マネージドルール(Preventionモード)
//   - レート制限: 送信元IP単位(テナント単位のクォータはAPI側の責務: §3.1 #8)
//   - ファイルサイズ上限: FR-DOC-8 の 500MB に整合
//   - 受信 X-Tenant-Id のヘッダ削除(§3.1 #1)
//   - Keycloak の管理パス(/admin/master・/admin/realms・/realms/master)遮断(§3.1 #6)
//
// 静的コンテンツ(Static Web Apps)もこのゲートウェイ配下に置く(§1.2 #8)。
// SPAとAPIが同一オリジンになるためCORSが不要になり、公開接点をここ1つに保てる。
// staticWebAppHostname を空にすると経由させない構成にもできるが、その場合は
// API側のCORS設定とフロントエンドの絶対URL指定が別途必要になる。

@description('アプリ名(リソース名の一部に使用)')
param appName string

@description('環境名(dev / prod)')
param env string

@description('リージョン')
param location string

@description('Application Gateway を配置するサブネットID(network.bicep の snet-appgw)')
param appGatewaySubnetId string

@description('APIコンテナの内部FQDN(Container Apps internal ingress)。compute.bicep の出力')
param apiFqdn string

@description('Keycloakコンテナの内部FQDN。compute.bicep の出力')
param keycloakFqdn string

@description('''Static Web Apps の既定ホスト名。既定ルート(/api・/realms・/resources 以外)を
SWAへ転送し、SPAとAPIを同一オリジンにする(azure-architecture_v2.md §1.2 #8)。

空にするとSWAを経由させない構成になるが、SPAが別オリジンからAPIを呼ぶことになるため
API側のCORS設定とフロントエンドの VITE_API_BASE_URL への絶対URL指定が別途必要になる。''')
param staticWebAppHostname string = ''

@description('診断ログの送り先 Log Analytics ワークスペースID。monitoring.bicep の出力')
param logAnalyticsWorkspaceId string

@description('Keycloakのレルム名。認証エンドポイントのヘルスプローブに使う')
param keycloakRealmName string = 'idp'

@description('アップロード上限(MB)。FR-DOC-8 の 500MB に合わせる。WAF_v2 の上限は 750')
@minValue(1)
@maxValue(750)
param fileUploadLimitInMb int = 500

@description('送信元IP単位のレート制限(1分あたりのリクエスト数)。GAP-N2 が確定するまでの暫定値')
param rateLimitThreshold int = 600

@description('受信を許可する送信元IPレンジ。PoCフェーズの上乗せ防御(§4.2.1)。空配列なら制限しない(リリースフェーズ)')
param allowedSourceIpRanges array = []

@description('HTTPSリスナーに使う証明書のKey VaultシークレットID。空の場合はHTTPリスナーのみになる')
@secure()
param sslCertificateKeyVaultSecretId string = ''

@description('Key Vaultから証明書を読むためのユーザ割り当てマネージドID。sslCertificateKeyVaultSecretId 指定時は必須')
param identityId string = ''

@description('自動スケールの最小・最大キャパシティユニット')
param minCapacity int = 1
param maxCapacity int = 3

var baseName = '${appName}-${env}'
var gatewayName = 'agw-${baseName}'
var httpsEnabled = !empty(sslCertificateKeyVaultSecretId)
var routeStaticWebApp = !empty(staticWebAppHostname)
var restrictSourceIp = !empty(allowedSourceIpRanges)

// ---------------------------------------------------------------------------
// WAF ポリシー
// ---------------------------------------------------------------------------

resource wafPolicy 'Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies@2024-05-01' = {
  name: 'waf-${baseName}'
  location: location
  properties: {
    policySettings: {
      state: 'Enabled'
      // 検知のみのDetectionではなく遮断するPreventionで運用する(§3.1 #4)
      mode: 'Prevention'
      requestBodyCheck: true
      // WAFがボディを検査できるのはここまで(上限128KB)。
      // 500MBのPDF本体は検査対象外で通過するため、マジックバイト・サイズの
      // 内容検証はAPI側が唯一の砦になる(§3.2 #8)
      maxRequestBodySizeInKb: 128
      fileUploadLimitInMb: fileUploadLimitInMb
    }
    managedRules: {
      managedRuleSets: [
        {
          ruleSetType: 'OWASP'
          ruleSetVersion: '3.2'
        }
      ]
    }
    customRules: concat(
      // 送信元IP制限。PoCでは参加顧客のIPに絞る上乗せ防御として使い、
      // リリースフェーズでは空配列にしてルールごと外す(§4.2.1 / §4.3)
      restrictSourceIp
        ? [
            {
              name: 'BlockUnknownSourceIp'
              priority: 10
              ruleType: 'MatchRule'
              action: 'Block'
              matchConditions: [
                {
                  matchVariables: [{ variableName: 'RemoteAddr' }]
                  operator: 'IPMatch'
                  // 許可リストの「否定」で、リストにないIPを落とす
                  negationConditon: true
                  matchValues: allowedSourceIpRanges
                }
              ]
            }
          ]
        : [],
      [
        {
          // 認証基盤の管理コンソールを公開経路から遮断する(§3.1 #6)。
          // 運用者は踏み台またはVNet内から到達する。
          //
          // Keycloakの実際の管理パスだけを列挙する:
          //   /admin/master/console/  管理コンソールUI
          //   /admin/realms/...       Admin REST API
          //   /realms/master/...      masterレルムの認証エンドポイント
          //
          // `/admin` で前方一致させるとSPAの管理画面(/admin/document-types・
          // /admin/usage・/admin/tenant)まで巻き込む。SPAも同じゲートウェイ配下に
          // 置くため(§1.2 #8)、ここを広げてはいけない。
          // SPA側に /admin/master・/admin/realms というルートを足す場合も同様に衝突する
          name: 'BlockKeycloakAdmin'
          priority: 20
          ruleType: 'MatchRule'
          action: 'Block'
          matchConditions: [
            {
              matchVariables: [{ variableName: 'RequestUri' }]
              operator: 'BeginsWith'
              negationConditon: false
              transforms: ['Lowercase']
              matchValues: ['/admin/master', '/admin/realms', '/realms/master']
            }
          ]
        }
        {
          // 送信元IP単位の粗いレート制限。テナント単位のクォータはAppGWの
          // レート制限キーにテナントを使えないためAPI側で行う(§3.1 #8)
          name: 'RateLimitPerClientIp'
          priority: 30
          ruleType: 'RateLimitRule'
          action: 'Block'
          rateLimitDuration: 'OneMin'
          rateLimitThreshold: rateLimitThreshold
          groupByUserSession: [
            {
              groupByVariables: [{ variableName: 'ClientAddr' }]
            }
          ]
          matchConditions: [
            {
              matchVariables: [{ variableName: 'RemoteAddr' }]
              operator: 'IPMatch'
              negationConditon: false
              matchValues: ['0.0.0.0/0']
            }
          ]
        }
      ]
    )
  }
}

// ---------------------------------------------------------------------------
// Public IP
// ---------------------------------------------------------------------------

resource publicIp 'Microsoft.Network/publicIPAddresses@2024-05-01' = {
  name: 'pip-${baseName}-agw'
  location: location
  sku: {
    name: 'Standard'
  }
  properties: {
    // v2 は Static 必須
    publicIPAllocationMethod: 'Static'
  }
}

// ---------------------------------------------------------------------------
// Application Gateway
// ---------------------------------------------------------------------------

var gatewayId = resourceId('Microsoft.Network/applicationGateways', gatewayName)
var frontendPortName = httpsEnabled ? 'port-443' : 'port-80'

resource appGateway 'Microsoft.Network/applicationGateways@2024-05-01' = {
  name: gatewayName
  location: location
  identity: empty(identityId)
    ? null
    : {
        type: 'UserAssigned'
        userAssignedIdentities: {
          '${identityId}': {}
        }
      }
  properties: {
    sku: {
      // WAF_v2 と Standard_v2 の差は月$100〜130。公開SaaS+ファイルアップロード
      // 受付でOWASPルールを外す判断はしない(§2.2)
      name: 'WAF_v2'
      tier: 'WAF_v2'
    }
    autoscaleConfiguration: {
      minCapacity: minCapacity
      maxCapacity: maxCapacity
    }
    firewallPolicy: {
      id: wafPolicy.id
    }
    gatewayIPConfigurations: [
      {
        name: 'appgw-ip-config'
        properties: {
          subnet: {
            id: appGatewaySubnetId
          }
        }
      }
    ]
    frontendIPConfigurations: [
      {
        name: 'frontend-public'
        properties: {
          publicIPAddress: {
            id: publicIp.id
          }
        }
      }
    ]
    frontendPorts: [
      {
        name: frontendPortName
        properties: {
          port: httpsEnabled ? 443 : 80
        }
      }
    ]
    sslCertificates: httpsEnabled
      ? [
          {
            name: 'listener-cert'
            properties: {
              keyVaultSecretId: sslCertificateKeyVaultSecretId
            }
          }
        ]
      : []
    backendAddressPools: concat(
      [
        {
          name: 'pool-api'
          properties: {
            backendAddresses: [
              {
                fqdn: apiFqdn
              }
            ]
          }
        }
        {
          name: 'pool-keycloak'
          properties: {
            backendAddresses: [
              {
                fqdn: keycloakFqdn
              }
            ]
          }
        }
      ],
      routeStaticWebApp
        ? [
            {
              name: 'pool-swa'
              properties: {
                backendAddresses: [
                  {
                    fqdn: staticWebAppHostname
                  }
                ]
              }
            }
          ]
        : []
    )
    probes: [
      {
        name: 'probe-api'
        properties: {
          protocol: 'Https'
          path: '/healthz'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          // Container Apps はHostヘッダでアプリを振り分けるため、
          // バックエンドアドレスのFQDNをそのままHostに使う
          pickHostNameFromBackendHttpSettings: true
          match: {
            statusCodes: ['200']
          }
        }
      }
      {
        name: 'probe-keycloak'
        properties: {
          protocol: 'Https'
          // レルムのOIDC discoveryは認証不要で200を返すためプローブに使える
          path: '/realms/${keycloakRealmName}/.well-known/openid-configuration'
          interval: 30
          timeout: 30
          unhealthyThreshold: 3
          pickHostNameFromBackendHttpSettings: true
          match: {
            statusCodes: ['200']
          }
        }
      }
    ]
    backendHttpSettingsCollection: concat(
      [
      {
        name: 'setting-api'
        properties: {
          port: 443
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          // ACAのingressはHostヘッダで振り分けるため、バックエンドFQDNをHostにする
          pickHostNameFromBackendAddress: true
          // アップロードは大きく解析待ちも長いため既定の30秒では足りない
          requestTimeout: 300
          probe: {
            id: '${gatewayId}/probes/probe-api'
          }
        }
      }
      {
        name: 'setting-keycloak'
        properties: {
          port: 443
          protocol: 'Https'
          cookieBasedAffinity: 'Disabled'
          pickHostNameFromBackendAddress: true
          requestTimeout: 60
          probe: {
            id: '${gatewayId}/probes/probe-keycloak'
          }
        }
      }
      ],
      routeStaticWebApp
        ? [
            {
              name: 'setting-swa'
              properties: {
                port: 443
                protocol: 'Https'
                cookieBasedAffinity: 'Disabled'
                pickHostNameFromBackendAddress: true
                requestTimeout: 30
              }
            }
          ]
        : []
    )
    rewriteRuleSets: [
      {
        name: 'rewrite-strip-tenant-header'
        properties: {
          rewriteRules: [
            {
              name: 'StripInboundTenantHeader'
              ruleSequence: 100
              actionSet: {
                requestHeaderConfigurations: [
                  {
                    // 値を空にするとヘッダごと削除される。
                    // テナントIDはAPIが検証済みJWTクレームから解決するため、
                    // 受信ヘッダは無条件に落とす(§3.1 #1)。
                    // APIはこのヘッダを読まないので、ここが漏れても偽装は成立しない
                    headerName: 'X-Tenant-Id'
                    headerValue: ''
                  }
                ]
              }
            }
          ]
        }
      }
    ]
    httpListeners: [
      {
        name: 'listener-main'
        properties: {
          frontendIPConfiguration: {
            id: '${gatewayId}/frontendIPConfigurations/frontend-public'
          }
          frontendPort: {
            id: '${gatewayId}/frontendPorts/${frontendPortName}'
          }
          protocol: httpsEnabled ? 'Https' : 'Http'
          sslCertificate: httpsEnabled
            ? {
                id: '${gatewayId}/sslCertificates/listener-cert'
              }
            : null
        }
      }
    ]
    urlPathMaps: [
      {
        name: 'pathmap-main'
        properties: {
          // SWAを配下に置く場合、既定ルート(SPAの画面遷移)はSWAへ。
          // 置かない場合の既定はAPI(Keycloakへ回すのは認証エンドポイントのパスだけ)
          defaultBackendAddressPool: {
            id: routeStaticWebApp
              ? '${gatewayId}/backendAddressPools/pool-swa'
              : '${gatewayId}/backendAddressPools/pool-api'
          }
          defaultBackendHttpSettings: {
            id: routeStaticWebApp
              ? '${gatewayId}/backendHttpSettingsCollection/setting-swa'
              : '${gatewayId}/backendHttpSettingsCollection/setting-api'
          }
          defaultRewriteRuleSet: {
            id: '${gatewayId}/rewriteRuleSets/rewrite-strip-tenant-header'
          }
          pathRules: [
            {
              name: 'rule-api'
              properties: {
                paths: ['/api/*']
                backendAddressPool: {
                  id: '${gatewayId}/backendAddressPools/pool-api'
                }
                backendHttpSettings: {
                  id: '${gatewayId}/backendHttpSettingsCollection/setting-api'
                }
                rewriteRuleSet: {
                  id: '${gatewayId}/rewriteRuleSets/rewrite-strip-tenant-header'
                }
              }
            }
            {
              name: 'rule-keycloak'
              properties: {
                // ログイン画面の静的アセット(/resources)も同じバックエンドが返す。
                // /realms/master と /admin はWAFカスタムルールで遮断済み
                paths: ['/realms/*', '/resources/*']
                backendAddressPool: {
                  id: '${gatewayId}/backendAddressPools/pool-keycloak'
                }
                backendHttpSettings: {
                  id: '${gatewayId}/backendHttpSettingsCollection/setting-keycloak'
                }
                rewriteRuleSet: {
                  id: '${gatewayId}/rewriteRuleSets/rewrite-strip-tenant-header'
                }
              }
            }
          ]
        }
      }
    ]
    requestRoutingRules: [
      {
        name: 'routing-main'
        properties: {
          ruleType: 'PathBasedRouting'
          priority: 100
          httpListener: {
            id: '${gatewayId}/httpListeners/listener-main'
          }
          urlPathMap: {
            id: '${gatewayId}/urlPathMaps/pathmap-main'
          }
        }
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// 診断設定
// アクセスログはリクエスト状況の、WAFログは遮断状況の観測点(§3.5)。
// テナント別のAPIリクエスト数はこのログからは取れない(テナント識別子が出ない)ため
// アプリ側で計上する(FR-LOG-2 / api_request_counters)。
// ---------------------------------------------------------------------------

resource diagnostics 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'diag-${gatewayName}'
  scope: appGateway
  properties: {
    workspaceId: logAnalyticsWorkspaceId
    logs: [
      {
        category: 'ApplicationGatewayAccessLog'
        enabled: true
      }
      {
        category: 'ApplicationGatewayFirewallLog'
        enabled: true
      }
      {
        category: 'ApplicationGatewayPerformanceLog'
        enabled: true
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// 出力
// ---------------------------------------------------------------------------

output name string = appGateway.name
output publicIpAddress string = publicIp.properties.ipAddress
output wafPolicyId string = wafPolicy.id
@description('false の場合、公開接点がHTTPのままになっている。顧客データ投入前に証明書を設定すること(§4.4)')
output httpsEnabled bool = httpsEnabled
@description('true の場合、送信元IP制限が有効。リリースフェーズでは解除する(§4.3)')
output sourceIpRestricted bool = restrictSourceIp
@description('false の場合、SPAは別オリジンからAPIを呼ぶためAPI側のCORS設定が必要になる')
output staticWebAppRouted bool = routeStaticWebApp
