// Azure AI Document Intelligence
//
// 全書類を prebuilt-layout + Query Fields の1本のフローで解析する
// (backend/app/clients/di.py)。
//
// スケルトン段階ではモジュール一覧に無かったが、Private Endpoint を張る対象
// (azure-architecture_v2.md §1.1)であり data 層とはライフサイクルも
// 課金体系も違うため独立させる(verify/modules/ai.bicep と同じ切り方)。
//
// DIは解析データを最大24時間サービス側に保持する仕様(§3.4 #14)。
// 顧客向けデータ取り扱い説明への記載が必要。

@description('アプリ名(リソース名の一部に使用)')
param appName string

@description('環境名(dev / prod)')
param env string

@description('リージョン。指定リージョンで必要なAPIバージョンが使えない場合は別リージョンにする')
param location string

@description('ネットワーク強化(パブリックアクセス無効化 + Private Endpoint)を有効にする')
param networkEnabled bool = false

@description('Private Endpoint を配置するサブネットID(network.bicep の snet-pe)')
param privateEndpointSubnetId string = ''

@description('Cognitive Services 用 Private DNS ゾーンID(network.bicep の出力)')
param cognitiveServicesPrivateDnsZoneId string = ''

var baseName = '${appName}-${env}'
var accountName = 'di-${baseName}-${uniqueString(resourceGroup().id)}'

resource documentIntelligence 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: accountName
  location: location
  kind: 'FormRecognizer'
  sku: {
    // 無料枠(F0)はページ数・機能に制約があるため S0(従量課金)
    name: 'S0'
  }
  properties: {
    // Entra ID(Managed Identity)認証にはカスタムサブドメインが必須
    customSubDomainName: accountName
    publicNetworkAccess: networkEnabled ? 'Disabled' : 'Enabled'
    // キー認証を止め、Managed Identity のみにする(§1.2 #5)
    disableLocalAuth: true
    networkAcls: {
      defaultAction: networkEnabled ? 'Deny' : 'Allow'
      ipRules: []
      virtualNetworkRules: []
    }
  }
}

resource privateEndpoint 'Microsoft.Network/privateEndpoints@2024-05-01' = if (networkEnabled) {
  name: 'pe-${baseName}-di'
  location: location
  properties: {
    subnet: {
      id: privateEndpointSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'di'
        properties: {
          privateLinkServiceId: documentIntelligence.id
          groupIds: ['account']
        }
      }
    ]
  }
}

resource privateDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2024-05-01' = if (networkEnabled) {
  parent: privateEndpoint
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'di'
        properties: {
          privateDnsZoneId: cognitiveServicesPrivateDnsZoneId
        }
      }
    ]
  }
}

output name string = documentIntelligence.name
output id string = documentIntelligence.id
output endpoint string = documentIntelligence.properties.endpoint
