// 環境全体のオーケストレーション
// フェーズ別構成は docs/01_design/azure-architecture_v2.md §4 を参照。
// ネットワーク強化(VNet/PE/NSG/internal ingress)とWAF(Application Gateway)は
// パラメータで有効化を切り替え、フェーズ移行を「パラメータ変更+差分デプロイ」にする(設計方針)。
//
// コンテナイメージがACRに存在しないとContainer Appsを作成できないため、
// deployApps で2段階に分けてデプロイする(infra/README.md「デプロイ」参照)。
targetScope = 'resourceGroup'

@description('アプリ名(リソース名の一部に使用)')
param appName string = 'idp'

@description('環境名(dev / prod)')
@allowed(['dev', 'prod'])
param env string

@description('リージョン')
param location string = resourceGroup().location

@description('Static Web Apps のリージョン。SWAは対応リージョンが限られるため日本からは eastasia を使う')
param swaLocation string = 'eastasia'

@description('Document Intelligence のリージョン。指定リージョンで必要なAPIバージョンが使えない場合に変える')
param documentIntelligenceLocation string = location

@description('ネットワーク強化(VNet / Private Endpoint / NSG / internal ingress)を有効化する')
param networkEnabled bool = false

@description('Application Gateway + WAF をデプロイする(初期フェーズでは置かない: azure-architecture_v2.md §4.1)。VNetへの配置が前提のため networkEnabled と併せて有効化する')
param appGatewayEnabled bool = false

@description('Container Apps(API / ワーカー / Keycloak)をデプロイする。ACRへのイメージpush後に true にして再デプロイする')
param deployApps bool = false

// ---------------------------------------------------------------------------
// 公開URL
// ---------------------------------------------------------------------------

@description('''サービスの公開ホスト名(例: idp.example.com)。Application Gateway の
Public IP に向けたDNS Aレコードを指す。KeycloakのKC_HOSTNAME・共有URL・
HTTPSリスナーの証明書と揃える必要がある。

空の場合は Static Web Apps の既定ホスト名にフォールバックする(AppGWを置かないdev向け)。''')
param publicHostname string = ''

// ---------------------------------------------------------------------------
// 資格情報
// ---------------------------------------------------------------------------

@description('PostgreSQL 管理者ログイン名。マイグレーションを実行する所有者ロールを兼ねる')
param postgresAdminLogin string = 'idpadmin'

@description('PostgreSQL 管理者パスワード。接続URLに埋め込むため @ : / ? # 等のURL予約文字は使わない')
@secure()
param postgresAdminPassword string

@description('アプリ接続ロール(app_user)のパスワード。DBの初期化SQLで設定する値と揃える')
@secure()
param appUserPassword string

@description('Keycloak の DB 接続ロールのパスワード。同上')
@secure()
param keycloakDbPassword string = ''

@description('Keycloak 初期管理者のパスワード。レルム構成後は恒久的な管理者を作りこのアカウントを無効化する(NFR-SEC-19)')
@secure()
param keycloakAdminPassword string = ''

@description('PostgreSQL の Entra ID 認証の管理者にするプリンシパルのオブジェクトID。空なら設定しない')
param entraAdminObjectId string = ''

@description('同プリンシパルの表示名(UPN等)')
param entraAdminPrincipalName string = ''

// ---------------------------------------------------------------------------
// コンテナイメージ
// ---------------------------------------------------------------------------

@description('バックエンド(API・ワーカー)のイメージタグ。latest 禁止・必ず固定する(NFR-SEC-20)')
param imageTag string = 'v1'

@description('Keycloak のイメージタグ。同上')
param keycloakImageTag string = 'v1'

// ---------------------------------------------------------------------------
// Application Gateway
// ---------------------------------------------------------------------------

@description('受信を許可する送信元IPレンジ。PoCフェーズの上乗せ防御(§4.2.1)。リリースフェーズでは空にする')
param allowedSourceIpRanges array = []

@description('HTTPSリスナーに使う証明書のKey VaultシークレットID。空だとHTTPのままになるため、顧客データ投入前に設定する(§4.4)')
@secure()
param sslCertificateKeyVaultSecretId string = ''

@description('Key Vaultから証明書を読むユーザ割り当てマネージドID。sslCertificateKeyVaultSecretId 指定時は必須')
param appGatewayIdentityId string = ''

// ---------------------------------------------------------------------------
// モジュール
// ---------------------------------------------------------------------------

module network 'modules/network.bicep' = if (networkEnabled) {
  name: 'network'
  params: {
    appName: appName
    env: env
    location: location
  }
}

module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: {
    appName: appName
    env: env
    location: location
  }
}

module data 'modules/data.bicep' = {
  name: 'data'
  params: {
    appName: appName
    env: env
    location: location
    networkEnabled: networkEnabled
    privateEndpointSubnetId: networkEnabled ? network!.outputs.privateEndpointSubnetId : ''
    postgresPrivateDnsZoneId: networkEnabled ? network!.outputs.postgresPrivateDnsZoneId : ''
    blobPrivateDnsZoneId: networkEnabled ? network!.outputs.blobPrivateDnsZoneId : ''
    // Service Bus は Private Endpoint を張れない(Premium専用)。NAT Gatewayで
    // 固定した送信IPをIPファイアウォールに登録して代替する(§3.3 #9)
    allowedOutboundIp: networkEnabled ? network!.outputs.natGatewayPublicIp : ''
    postgresAdminLogin: postgresAdminLogin
    postgresAdminPassword: postgresAdminPassword
    entraAdminObjectId: entraAdminObjectId
    entraAdminPrincipalName: entraAdminPrincipalName
  }
}

module ai 'modules/ai.bicep' = {
  name: 'ai'
  params: {
    appName: appName
    env: env
    location: documentIntelligenceLocation
    networkEnabled: networkEnabled
    privateEndpointSubnetId: networkEnabled ? network!.outputs.privateEndpointSubnetId : ''
    cognitiveServicesPrivateDnsZoneId: networkEnabled ? network!.outputs.cognitiveServicesPrivateDnsZoneId : ''
  }
}

module compute 'modules/compute.bicep' = {
  name: 'compute'
  params: {
    appName: appName
    env: env
    location: location
    networkEnabled: networkEnabled
    acaSubnetId: networkEnabled ? network!.outputs.acaSubnetId : ''
    vnetId: networkEnabled ? network!.outputs.vnetId : ''
    logAnalyticsName: monitoring.outputs.name
    swaLocation: swaLocation
    publicHostname: publicHostname
    imageTag: imageTag
    keycloakImageTag: keycloakImageTag
    deployApps: deployApps
    postgresFqdn: data.outputs.postgresFqdn
    databaseName: data.outputs.databaseName
    keycloakDatabaseName: data.outputs.keycloakDatabaseName
    postgresAdminLogin: postgresAdminLogin
    postgresAdminPassword: postgresAdminPassword
    appUserPassword: appUserPassword
    keycloakDbPassword: keycloakDbPassword
    keycloakAdminPassword: keycloakAdminPassword
    blobEndpoint: data.outputs.blobEndpoint
    serviceBusFqdn: data.outputs.serviceBusFqdn
    documentIntelligenceEndpoint: ai.outputs.endpoint
    storageAccountName: data.outputs.storageAccountName
    serviceBusName: data.outputs.serviceBusName
    documentIntelligenceName: ai.outputs.name
  }
}

module appgw 'modules/appgw.bicep' = if (appGatewayEnabled) {
  name: 'appgw'
  params: {
    appName: appName
    env: env
    location: location
    appGatewaySubnetId: networkEnabled ? network!.outputs.appGatewaySubnetId : ''
    apiFqdn: compute.outputs.apiFqdn
    keycloakFqdn: compute.outputs.keycloakFqdn
    staticWebAppHostname: compute.outputs.staticWebAppHostname
    logAnalyticsWorkspaceId: monitoring.outputs.id
    allowedSourceIpRanges: allowedSourceIpRanges
    sslCertificateKeyVaultSecretId: sslCertificateKeyVaultSecretId
    identityId: appGatewayIdentityId
  }
}

// ---------------------------------------------------------------------------
// 出力
// ---------------------------------------------------------------------------

output deployedEnv string = env
output networkEnabledOut bool = networkEnabled
output appGatewayEnabledOut bool = appGatewayEnabled

@description('イメージのビルド・push 先(az acr build --registry の引数)')
output registryLoginServer string = compute.outputs.registryLoginServer
@description('サービスの公開URL')
output publicBaseUrl string = compute.outputs.publicBaseUrl
@description('バックエンドの OIDC_ISSUER・フロントエンドの VITE_OIDC_ISSUER に設定する値')
output keycloakIssuerUrl string = compute.outputs.keycloakIssuerUrl
@description('SPAの配信元。Application Gateway のバックエンドプールに載る')
output staticWebAppHostname string = compute.outputs.staticWebAppHostname
@description('公開接点のIP。publicHostname のDNS Aレコードをここへ向ける(appGatewayEnabled 時のみ)')
output appGatewayPublicIp string = appGatewayEnabled ? appgw!.outputs.publicIpAddress : ''
@description('Service Bus のIPファイアウォールに登録した送信IP(networkEnabled 時のみ)')
output natGatewayPublicIp string = networkEnabled ? network!.outputs.natGatewayPublicIp : ''
