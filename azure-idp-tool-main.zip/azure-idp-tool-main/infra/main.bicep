// 環境全体のオーケストレーション
// フェーズ別構成は docs/01_design/azure-architecture_v2.md §4 を参照。
// ネットワーク強化(VNet/PE/NSG/internal ingress)はパラメータで有効化を切り替え、
// フェーズ移行を「パラメータ変更+差分デプロイ」にする(設計方針)。
targetScope = 'resourceGroup'

@description('アプリ名(リソース名の一部に使用)')
param appName string = 'idp'

@description('環境名(dev / prod)')
@allowed(['dev', 'prod'])
param env string

@description('リージョン')
param location string = resourceGroup().location

@description('ネットワーク強化(VNet / Private Endpoint / NSG / internal ingress)を有効化する')
param networkEnabled bool = false

@description('APIMをデプロイする(初期フェーズでは置かない: azure-architecture_v2.md §4.1)')
param apimEnabled bool = false

// TODO: モジュールの実装に合わせて順次コメントアウトを解除する
//
// module network 'modules/network.bicep' = if (networkEnabled) {
//   name: 'network'
//   params: { appName: appName, env: env, location: location }
// }
//
// module monitoring 'modules/monitoring.bicep' = {
//   name: 'monitoring'
//   params: { appName: appName, env: env, location: location }
// }
//
// module data 'modules/data.bicep' = {
//   name: 'data'
//   params: { appName: appName, env: env, location: location, networkEnabled: networkEnabled }
// }
//
// module compute 'modules/compute.bicep' = {
//   name: 'compute'
//   params: { appName: appName, env: env, location: location, networkEnabled: networkEnabled }
// }
//
// module apim 'modules/apim.bicep' = if (apimEnabled) {
//   name: 'apim'
//   params: { appName: appName, env: env, location: location }
// }

output deployedEnv string = env
output networkEnabledOut bool = networkEnabled
output apimEnabledOut bool = apimEnabled
