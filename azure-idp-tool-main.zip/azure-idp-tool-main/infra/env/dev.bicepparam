using '../main.bicep'

param env = 'dev'
param location = 'japaneast'

// 初期フェーズ(社内開発): ネットワーク防御は最小化、認証方式のみ本番同等
// (azure-architecture_v2.md §4.1)
param networkEnabled = false
param apimEnabled = false
