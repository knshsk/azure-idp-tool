using '../main.bicep'

param env = 'dev'
param location = 'japaneast'

// 初期フェーズ(社内開発): ネットワーク防御は最小化、認証方式のみ本番同等
// (azure-architecture_v2.md §4.1)
param networkEnabled = false
param appGatewayEnabled = false

// 2段階デプロイ。1回目は false のまま基盤を作り、ACRへイメージをpushしてから
// true にして再デプロイする(infra/README.md「デプロイ」)
param deployApps = false

// 資格情報は環境変数から読む。リポジトリに値を置かない
param postgresAdminPassword = readEnvironmentVariable('IDP_POSTGRES_ADMIN_PASSWORD')
param appUserPassword = readEnvironmentVariable('IDP_APP_USER_PASSWORD')
param keycloakDbPassword = readEnvironmentVariable('IDP_KEYCLOAK_DB_PASSWORD', '')
param keycloakAdminPassword = readEnvironmentVariable('IDP_KEYCLOAK_ADMIN_PASSWORD', '')

// AppGWを置かないため、公開URLはSWAの既定ホスト名にフォールバックさせる
param publicHostname = ''
