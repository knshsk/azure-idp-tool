using '../main.bicep'

param env = 'prod'
param location = 'japaneast'

// PoC以降: データ層・ネットワーク層は本番同等(azure-architecture_v2.md §4.2〜4.3)
param networkEnabled = true
param appGatewayEnabled = true

// 2段階デプロイ。1回目は false のまま基盤を作り、ACRへイメージをpushしてから
// true にして再デプロイする(infra/README.md「デプロイ」)
param deployApps = false

// 資格情報は環境変数から読む。リポジトリに値を置かない
param postgresAdminPassword = readEnvironmentVariable('IDP_POSTGRES_ADMIN_PASSWORD')
param appUserPassword = readEnvironmentVariable('IDP_APP_USER_PASSWORD')
param keycloakDbPassword = readEnvironmentVariable('IDP_KEYCLOAK_DB_PASSWORD')
param keycloakAdminPassword = readEnvironmentVariable('IDP_KEYCLOAK_ADMIN_PASSWORD')

// PostgreSQL の Entra ID 認証の管理者。空なら設定しない
param entraAdminObjectId = readEnvironmentVariable('IDP_ENTRA_ADMIN_OBJECT_ID', '')
param entraAdminPrincipalName = readEnvironmentVariable('IDP_ENTRA_ADMIN_PRINCIPAL_NAME', '')

// 公開ホスト名。Application Gateway の Public IP へDNS Aレコードを向ける。
// HTTPSリスナーの証明書のCN/SANとも揃える必要がある
param publicHostname = readEnvironmentVariable('IDP_PUBLIC_HOSTNAME', '')

// PoCフェーズは参加顧客の送信元IPに絞る上乗せ防御をかける(§4.2.1)。
// 送信元IPを特定できない連携元(D365 / Power Platform)はOAuth2 CCのみで受けるため、
// その顧客が入る時点でこのリストによる制限は成立しなくなる。
// リリースフェーズ(全公開)では空配列にしてルールごと外す(§4.3)。
//
// 注意: リストを埋める場合はデプロイ出力の natGatewayPublicIp も必ず含めること。
// APIはKeycloakのJWKSを公開URL(=AppGW)経由で取りに行くため、NAT Gatewayの
// 送信IPを許可しないとAPI自身がWAFに弾かれ、全リクエストが503になる
// (infra/README.md「送信元IP制限とJWKS取得」)。
param allowedSourceIpRanges = []

// 空のままだと公開接点がHTTPになる。顧客データ投入前に証明書を設定すること(§4.4)。
// Key Vaultの証明書を参照するため appGatewayIdentityId も併せて必要。
param sslCertificateKeyVaultSecretId = readEnvironmentVariable('IDP_SSL_CERT_SECRET_ID', '')
param appGatewayIdentityId = readEnvironmentVariable('IDP_APPGW_IDENTITY_ID', '')
