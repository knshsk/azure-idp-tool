using '../main.bicep'

param env = 'prod'
param location = 'japaneast'

// PoC以降: データ層・ネットワーク層は本番同等(azure-architecture_v2.md §4.2〜4.3)
param networkEnabled = true
param apimEnabled = true
