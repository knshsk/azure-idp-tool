# infra

Bicep による IaC。環境差分(dev / prod)は `.bicepparam` で表現する。

構成の設計は [docs/01_design/azure-architecture_v2.md](../docs/01_design/azure-architecture_v2.md) を参照。フェーズ移行(ネットワーク強化・APIM導入)は `networkEnabled` / `apimEnabled` パラメータの変更+差分デプロイで行う方針。

> **現状**: モジュールは設計方針を記したスケルトン(TODO)段階。`main.bicep` のモジュール呼び出しは実装に合わせて順次コメントアウトを解除する。

## ディレクトリ構成

| パス | 内容 |
|---|---|
| `main.bicep` | 環境全体のオーケストレーション(targetScope: resourceGroup) |
| `env/dev.bicepparam` | dev環境パラメータ(japaneast / ネットワーク防御は最小化) |
| `env/prod.bicepparam` | prod環境パラメータ |
| `modules/network.bicep` | VNet / Private Endpoint / NSG(`networkEnabled` 時のみ) |
| `modules/monitoring.bicep` | Log Analytics / Application Insights |
| `modules/data.bicep` | PostgreSQL / Blob Storage / Service Bus |
| `modules/compute.bicep` | Container Apps(API + ワーカー)/ ACR / Static Web Apps / Managed Identity |
| `modules/apim.bicep` | API Management(`apimEnabled` 時のみ) |
| `policies/api-policy.xml` | APIM全体ポリシー(JWT検証・`X-Tenant-Id` の一方向強制など。apim.bicep から `loadTextContent()` で読み込む) |

## 主要パラメータ

| パラメータ | 既定値 | 説明 |
|---|---|---|
| `appName` | `idp` | リソース名の一部に使用 |
| `env` | (必須) | `dev` / `prod` |
| `networkEnabled` | `false` | VNet / Private Endpoint / NSG / internal ingress を有効化 |
| `apimEnabled` | `false` | APIM をデプロイ(初期フェーズでは置かない) |

## デプロイ

```bash
# 検証(what-if)
az deployment group what-if \
  --resource-group <rg名> \
  --template-file main.bicep \
  --parameters env/dev.bicepparam

# デプロイ
az deployment group create \
  --resource-group <rg名> \
  --template-file main.bicep \
  --parameters env/dev.bicepparam
```
