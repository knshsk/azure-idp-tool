# infra

Bicep による IaC。環境差分(dev / prod)は `.bicepparam` で表現する。

構成の設計は [docs/01_design/azure-architecture_v2.md](../docs/01_design/azure-architecture_v2.md) を参照。フェーズ移行(ネットワーク強化・WAF導入)は `networkEnabled` / `appGatewayEnabled` パラメータの変更+差分デプロイで行う方針。

> **現状**: 全モジュール実装済み。`az bicep build` / `build-params` は通るが、**Azure への what-if・デプロイ検証は未実施**。
>
> **社内検証環境は [verify/](verify/) に独立して実装済み**(azure-architecture_v2.md §4.1「初期: 社内開発」相当)。
> 顧客データを扱わない割り切った構成であり、理想形テンプレートに条件分岐として混ぜず別建てにしている。
> デプロイ手順は [docs/03_deployment/verify-deployment-guide.md](../docs/03_deployment/verify-deployment-guide.md)。

## ディレクトリ構成

| パス | 内容 |
|---|---|
| `main.bicep` | 環境全体のオーケストレーション(targetScope: resourceGroup) |
| `env/dev.bicepparam` | dev環境パラメータ(japaneast / ネットワーク防御は最小化) |
| `env/prod.bicepparam` | prod環境パラメータ |
| `modules/network.bicep` | VNet / サブネット / NSG / NAT Gateway / Private DNSゾーン(`networkEnabled` 時のみ) |
| `modules/monitoring.bicep` | Log Analytics |
| `modules/data.bicep` | PostgreSQL / Blob Storage / Service Bus(+ `networkEnabled` 時は Private Endpoint) |
| `modules/ai.bicep` | Document Intelligence(+ `networkEnabled` 時は Private Endpoint) |
| `modules/compute.bicep` | Managed Identity / ACR / Container Apps環境 / API・ワーカー・Keycloak / Static Web Apps / DB初期化ジョブ / ロール割り当て |
| `modules/aca-private-dns.bicep` | internal環境の既定ドメインのPrivate DNSゾーン(compute から呼ぶ) |
| `modules/appgw.bicep` | Application Gateway v2 + WAFポリシー(`appGatewayEnabled` 時のみ) |
| `verify/` | **社内検証環境のIaC(実装済み・独立)**。詳細は [verify/README.md](verify/README.md) |

## 主要パラメータ

| パラメータ | 既定値 | 説明 |
|---|---|---|
| `appName` | `idp` | リソース名の一部に使用 |
| `env` | (必須) | `dev` / `prod` |
| `networkEnabled` | `false` | VNet / Private Endpoint / NSG / internal ingress を有効化 |
| `appGatewayEnabled` | `false` | Application Gateway + WAF をデプロイ(初期フェーズでは置かない。VNet配置が前提のため `networkEnabled` と併せて有効化する) |
| `allowedSourceIpRanges` | `[]` | WAFカスタムルールで受信を許可する送信元IP。PoCフェーズの上乗せ防御。空なら制限なし。**設定する場合はNAT GatewayのIPも含めること**(下記「送信元IP制限とJWKS取得」) |
| `sslCertificateKeyVaultSecretId` | `''` | HTTPSリスナーの証明書。**空だと公開接点がHTTPのまま**になるため顧客データ投入前に設定する |
| `deployApps` | `false` | Container Apps をデプロイする。ACRへイメージをpushしてから `true` にする(下記「2段階デプロイ」) |
| `publicHostname` | `''` | サービスの公開ホスト名。AppGWのPublic IPへDNS Aレコードを向ける。空ならSWAの既定ホスト名にフォールバック |
| `postgresAdminPassword` / `appUserPassword` / `keycloakDbPassword` / `keycloakAdminPassword` | (必須) | `.bicepparam` が `readEnvironmentVariable()` で環境変数から読む。リポジトリに値を置かない |

## モジュールの依存関係

```
network ─┬─> data ──┬─> compute ──> appgw
         ├─> ai ────┘      ^
monitoring ──────────────┘
```

`appgw` はバックエンドのFQDN・SWAのホスト名を `compute` の出力から、診断ログの送り先を `monitoring` の出力から受け取る。`compute` は逆に Application Gateway を参照しない — 公開URLは `publicHostname` パラメータで先に決めることで循環参照を避けている(HTTPSを終端するにはどのみちカスタムドメインと証明書が要る)。

## 2段階デプロイ

コンテナイメージが ACR に存在しないと Container Apps を作成できないため、デプロイを2回に分ける。

1. `deployApps = false` のままデプロイ → 基盤リソース(ACR含む)が作られる
2. `az acr build` でイメージをビルド・push
3. `deployApps = true` にして再デプロイ → API・ワーカー・Keycloak が作られる

Keycloak は DB ロールが無い状態で起動すると失敗を繰り返すため、2 の前に Keycloak 用ロールを作る初期化SQLを流しておく。

## Application Gateway の構成

| 項目 | 内容 |
|---|---|
| SKU | `WAF_v2`(自動スケール 1〜3 CU) |
| WAF | OWASP CRS 3.2 マネージドルール・**Preventionモード** |
| ボディ検査 | `maxRequestBodySizeInKb: 128`(WAFの上限)。**500MBのPDF本体は検査対象外**で通過するため、内容検証はAPI側が唯一の砦になる |
| アップロード上限 | `fileUploadLimitInMb: 500`(FR-DOC-8 と整合) |
| レート制限 | 送信元IP単位・1分あたり600(暫定値。GAP-N2 が未確定)。テナント単位のクォータはAPI側の責務 |
| ヘッダ書き換え | 受信 `X-Tenant-Id` を無条件削除(APIはこのヘッダを読まないため二重の担保) |
| パス遮断 | `/admin/master`・`/admin/realms`・`/realms/master` をWAFカスタムルールでBlock(Keycloak管理コンソール・Admin REST API)。**`/admin` で前方一致させるとSPAの管理画面(`/admin/usage` 等)を巻き込む**ため範囲を絞っている |
| ルーティング | `/api/*` → API、`/realms/*`・`/resources/*` → Keycloak、既定 → Static Web Apps(SPA)。SPAとAPIが同一オリジンになるためCORSは不要 |
| 診断ログ | アクセス・WAF・パフォーマンスログを Log Analytics へ |

### 送信元IP制限とJWKS取得

JWT 検証は API 側の責務で、API は Keycloak の JWKS を **自分で HTTP 取得する**(`backend/app/core/oidc.py`)。取得先は `OIDC_ISSUER` から導かれる `<公開URL>/realms/<realm>/...` で、AppGW を置く構成ではこれが **Application Gateway の公開ホスト名**になる。

つまり API → JWKS は「Container Apps → NAT Gateway → インターネット → AppGW の Public IP」という折り返しになる。ここから2点。

- **`allowedSourceIpRanges` を設定するときは、`natGatewayPublicIp`(デプロイ出力)を必ず許可リストに含める**。含めないと API 自身の JWKS 取得が WAF に弾かれ、`503 auth_unavailable` で全リクエストが失敗する。顧客IPだけを並べると起きる
- レルムの discovery / JWKS は認証不要で 200 を返すため、`/realms/*` のルーティングとヘルスプローブが生きていれば取得は成立する。**Keycloak のパス遮断ルールを `/realms` まで広げてはいけない**(現状は `/realms/master` のみ)

将来この折り返しを避けるなら、「issuer として検証する文字列」と「JWKS の取得先URL」を分離し、後者に Container Apps の内部FQDNを渡せるようにするのが素直。現状の `OidcKeyStore` は issuer から取得先を導くため、その分離はしていない。

## 実装上の判断と注意点

- **Keycloak の公開URL(`KC_HOSTNAME` / `OIDC_ISSUER`)は `publicHostname` とは別に決めている**。AppGW を置く構成では同一オリジン(`/realms/*` を転送)だが、置かない dev フェーズではブラウザが Keycloak の Container Apps ingress へ直接来る。`publicHostname` 未指定時のフォールバック先は SWA のホスト名なので、そこに issuer を寄せると「Keycloak が居ないホスト」を指してしまう
- **SWA の API リンク(`linkedBackend`)は使っていない**。使うと API トラフィックが Application Gateway を迂回し、WAF が意味をなさなくなる。`verify/` の検証環境はこの方式だが、あちらは AppGW を持たない割り切り構成なので、そのまま持ち込んではいけない
- **Container Apps 環境の Private DNS ゾーンは別モジュール**(`aca-private-dns.bicep`)。ゾーン名になる既定ドメインは環境の作成後にしか確定せず、ARM はデプロイ開始時点でリソース名を解決する必要があるため、ネストしたデプロイに逃がしている
- **Service Bus は Private Endpoint を張れない**(Premium 専用)。Standard でも IP ファイアウォールは使えるため、NAT Gateway で固定した送信IPのみを許可する。`ipRules` が空だと `defaultAction: Deny` でも全通しになるので、IPが無いときはルールセット自体を作らない。また Standard SKU はポータルに「ネットワーク」タブが出ないため、確認・変更は ARM か `az servicebus namespace network-rule-set` で行う
- **PostgreSQL は Entra ID 認証とパスワード認証を併用**している。設計上は Entra ID 認証(§1.2 #5)だが、バックエンドが `DATABASE_URL` のパスワード接続実装のため。トークン取得処理を実装したら `passwordAuth` を無効化できる
- **ACR は Standard**(パブリック + MI pull)。理想形の Premium + Private Endpoint は §2.2 で受容済みのダウングレード。Premium 化するなら `privatelink.azurecr.io` ゾーンと PE の追加が要る
- **Blob はソフト削除+バージョニングを有効化**している(§3.4 #13)。日次削除ジョブの誤爆に対する安価な安全網
- **`snet-pe` は `privateEndpointNetworkPolicies: 'Enabled'`**。既定の `Disabled` のままだと Private Endpoint が NSG を素通りし、敷いた NSG が効かない

## デプロイ

```bash
# 検証(what-if)
az deployment group what-if \
  --resource-group <rg名> \
  --template-file main.bicep \
  --parameters env/dev.bicepparam

# デプロイ
az deployment group create \
  --resource-group <rg名> \
  --template-file main.bicep \
  --parameters env/dev.bicepparam
```
