-- Azure Database for PostgreSQL Flexible Server 用のロール分離
-- (ローカル開発の docker/postgres-init/01-roles.sql に相当)
--
--   管理者ロール(idpadmin 等) : テーブル所有者。マイグレーション・シード用
--   app_user                   : アプリ接続ロール。RLS適用対象(BYPASSRLSなし)
--
-- RLS は FORCE ROW LEVEL SECURITY で所有者にも効くため(alembic 0001)、
-- ロールを分離しないとアプリ側の接続ロールが所有者と同一になり、
-- テナント分離の検証にならない。
--
-- 実行タイミング: データベース作成直後、alembic upgrade head の「前」。
--   ALTER DEFAULT PRIVILEGES は「これから作られるテーブル」に効くため、
--   先に流しておくとマイグレーションで作られる全テーブルに権限が自動で付く。
--   後から流した場合も GRANT ... ON ALL TABLES が既存テーブルを拾うので、
--   本スクリプトは何度実行しても安全(冪等)。
--
-- 実行例(WSL から。パスワードはクォートせず生の値を渡す):
--   psql "host=<PG_FQDN> port=5432 dbname=idp user=<ADMIN> sslmode=require" \
--     -v app_user_password="$APP_USER_PASSWORD" \
--     -v pg_admin_login=<ADMIN> \
--     -f infra/verify/scripts/init-roles.sql

\set ON_ERROR_STOP on

-- app_user が無い場合のみ作成する(SELECT で組み立てた DDL を \gexec で実行)。
-- CREATE ROLE は IF NOT EXISTS を持たないためこの形にしている
SELECT format(
    'CREATE ROLE app_user LOGIN PASSWORD %s NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS',
    quote_literal(:'app_user_password')
)
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_user')
\gexec

-- 既存の場合はパスワードを Bicep の appUserPassword に合わせ直す
ALTER ROLE app_user WITH LOGIN PASSWORD :'app_user_password';

GRANT CONNECT ON DATABASE idp TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;

-- 既存テーブルへの権限(alembic 実行後に流した場合のため)
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;

-- 管理者ロールが今後作成するテーブル(マイグレーション)にも自動で権限を付与
ALTER DEFAULT PRIVILEGES FOR ROLE :"pg_admin_login" IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;

-- 確認: app_user に BYPASSRLS / SUPERUSER が付いていないこと
-- (付いていると RLS が素通りし、テナント分離の検証にならない)
--
-- 管理者ロールの rolbypassrls は t で正常。Azure PostgreSQL フレキシブル サーバーの
-- 管理者は既定で BYPASSRLS を持ち、seed.py がテナントコンテキストなしで tenants へ
-- INSERT するためこの属性が必要になる(外すとシードが失敗する)。
-- ローカル開発の POSTGRES_USER=app がスーパーユーザである状態と等価。
SELECT rolname, rolbypassrls, rolsuper
FROM pg_roles
WHERE rolname IN ('app_user', :'pg_admin_login');
