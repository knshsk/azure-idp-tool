-- Keycloak 用の DB ロールとスキーマ権限
-- (アプリ側のロール分離は init-roles.sql。あちらとは別データベース・別ロールにする)
--
--   keycloak データベース : Keycloak が自分でテーブルを作るストア(Liquibase管理)
--   keycloak_user ロール  : Keycloak の接続ロール。アプリの app_user とは無関係
--
-- アプリDB(idp)と権限境界を分ける目的なので、**このロールに idp データベースの
-- 権限を与えてはならない**。逆も同様。
--
-- 実行タイミング: keycloak データベース作成後(Bicep 1回目のデプロイ後)、
--   Keycloak コンテナを起動する「前」。ロールが無い状態で起動すると
--   コンテナが接続に失敗して再起動を繰り返す。
--   本スクリプトは何度実行しても安全(冪等)。
--
-- 実行例(Azure Cloud Shell から。**keycloak データベースに接続すること**):
--   psql "host=<PG_FQDN> port=5432 dbname=keycloak user=<ADMIN> sslmode=require" \
--     -v keycloak_db_password="$KEYCLOAK_DB_PASSWORD" \
--     -f init-keycloak-db.sql
--
-- データベース名は Bicep の keycloakDatabaseName パラメータと揃える。
-- 既定値(keycloak)から変えた場合は下の検査とGRANTの名前も直すこと。

\set ON_ERROR_STOP on

-- 誤ってアプリDB(idp)に接続したまま流すと、アプリのスキーマに対して
-- Keycloak のロールが CREATE 権限を持ってしまう。接続先を検査して弾く。
DO $$
BEGIN
    IF current_database() <> 'keycloak' THEN
        RAISE EXCEPTION
            '本スクリプトは keycloak データベースに接続して実行してください(現在の接続先: %)',
            current_database();
    END IF;
END
$$;

-- keycloak_user が無い場合のみ作成する(SELECT で組み立てた DDL を \gexec で実行)。
-- CREATE ROLE は IF NOT EXISTS を持たないためこの形にしている
SELECT format(
    'CREATE ROLE keycloak_user LOGIN PASSWORD %s NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS',
    quote_literal(:'keycloak_db_password')
)
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'keycloak_user')
\gexec

-- 既存の場合はパスワードを Bicep の keycloakDbPassword に合わせ直す
ALTER ROLE keycloak_user WITH LOGIN PASSWORD :'keycloak_db_password';

-- PostgreSQL は既定で PUBLIC ロールに CONNECT を与えるため、明示的に剥がさないと
-- app_user から Keycloak のDBへ接続できてしまう(権限境界が成立しない)。
-- 所有者(管理者)と keycloak_user は個別に権限を持つので影響しない
REVOKE CONNECT ON DATABASE keycloak FROM PUBLIC;

GRANT CONNECT ON DATABASE keycloak TO keycloak_user;

-- PostgreSQL 15 以降、public スキーマは PUBLIC ロールへ CREATE を与えなくなった。
-- Keycloak は初回起動時に Liquibase で自分のテーブルを作るため CREATE が要る
-- (アプリ側で `permission denied for schema public` が出たのと同じ原因)。
-- USAGE + CREATE をまとめて付与する。作成したテーブルは keycloak_user が
-- 所有者になるので、以後の ALTER / DROP に追加の権限は要らない。
GRANT ALL ON SCHEMA public TO keycloak_user;

-- 確認1: keycloak_user に SUPERUSER 等の余計な属性が付いていないこと(すべて f)
SELECT rolname, rolsuper, rolcreatedb, rolcreaterole, rolbypassrls
FROM pg_roles
WHERE rolname = 'keycloak_user';

-- 確認2: public スキーマに CREATE できること(t であること)
SELECT has_schema_privilege('keycloak_user', 'public', 'CREATE') AS can_create_in_public;
