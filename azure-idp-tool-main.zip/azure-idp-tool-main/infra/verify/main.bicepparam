// 社内検証環境のパラメータ。
//
// パスワードなどの機微値はファイルに書かず、環境変数から読み込む。
// デプロイ前に以下をエクスポートしておくこと(手順書 §3 参照):
//   export PG_ADMIN_PASSWORD='...'    # PostgreSQL 管理者パスワード
//   export APP_USER_PASSWORD='...'    # アプリ接続ロール app_user のパスワード
//   export CLIENT_IP="$(curl -s ifconfig.me)"   # ローカルPCのグローバルIP
//   export DEPLOY_APPS=false          # 1回目は false、イメージ push 後に true
//   export IMAGE_TAG=v1
//
// Keycloak を立てる場合のみ追加で必要(手順書 付録E):
//   export KEYCLOAK_DB_PASSWORD='...'    # DB ロール keycloak_user のパスワード
//   export KEYCLOAK_ADMIN_PASSWORD='...' # Keycloak 初期管理者のパスワード
//   export KEYCLOAK_IMAGE_TAG=v1         # az acr build で付けたタグ
//   export DEPLOY_KEYCLOAK=true          # DBロール作成とイメージ push の後に true
using 'main.bicep'

param appName = 'idp'
param env = 'verify'

// PostgreSQL / Container Apps / ACR などの主リージョン
param location = 'japaneast'

// Static Web Apps は対応リージョンが限られるため、日本から最も近い eastasia を使う
param swaLocation = 'eastasia'

// Document Intelligence は japaneast を既定にする。
// 指定リージョンで API バージョン 2024-11-30(Query Fields)が使えない場合は
// eastus / westus2 / westeurope などに変更する
param documentIntelligenceLocation = 'japaneast'

// --- 機微値(環境変数から読み込む) ---
param postgresAdminPassword = readEnvironmentVariable('PG_ADMIN_PASSWORD')
param appUserPassword = readEnvironmentVariable('APP_USER_PASSWORD')

// マイグレーション・シードをローカル(WSL)から流すために許可するIP。
// 空文字なら許可しない
param clientIpAddress = readEnvironmentVariable('CLIENT_IP', '')

// --- デプロイ制御(2段階デプロイ) ---
param deployApps = bool(readEnvironmentVariable('DEPLOY_APPS', 'false'))
param imageTag = readEnvironmentVariable('IMAGE_TAG', 'v1')

// --- Keycloak(認証基盤) ---
// アプリの検証だけをする間は DEPLOY_KEYCLOAK 未設定(=false)でよい。
// その場合 keycloak データベースは作られるが、コンテナは起動しない。
param deployKeycloak = bool(readEnvironmentVariable('DEPLOY_KEYCLOAK', 'false'))
param keycloakImageTag = readEnvironmentVariable('KEYCLOAK_IMAGE_TAG', 'v1')
param keycloakDbPassword = readEnvironmentVariable('KEYCLOAK_DB_PASSWORD', '')
param keycloakAdminPassword = readEnvironmentVariable('KEYCLOAK_ADMIN_PASSWORD', '')

// --- アプリケーション設定 ---
// backend/scripts/seed.py が作成する開発テナント・ユーザと揃える
param localTenantId = '00000000-0000-0000-0000-000000000001'
param localUserId = '00000000-0000-0000-0000-000000000002'
