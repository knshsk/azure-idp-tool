# infra/verify — 社内検証環境の IaC

README のクイックスタート(WSL上でのローカル実行)と**同等の動作確認を Azure 上で行う**ための Bicep。
顧客データを扱わない前提のため、ネットワーク防御(VNet / Private Endpoint / NSG / WAF)は設けない。
位置づけは [azure-architecture_v2.md](../../docs/01_design/azure-architecture_v2.md) §4.1「初期: 社内開発」に相当する。

デプロイ手順は **[docs/03_deployment/verify-deployment-guide.md](../../docs/03_deployment/verify-deployment-guide.md)** を参照。

> 本番想定の理想形・フェーズ移行を扱う `infra/main.bicep`(スケルトン)とは別物として独立させている。
> 検証環境は「割り切った構成」であり、理想形テンプレートに条件分岐として混ぜると両方が読みにくくなるため。

## 構成するリソース

| リソース | SKU / 構成 | 用途 |
|---|---|---|
| Static Web Apps | Standard | フロントエンド配信。API リンクで Container Apps(API)へ `/api/*` をプロキシ |
| Container Registry | Basic | コンテナイメージの保管+**ビルド**(`az acr build`) |
| Container Apps 環境 | 消費プラン | API / ワーカーの実行基盤 |
| Container Apps(API) | 0.5 vCPU / 1Gi、external ingress、最小1レプリカ | FastAPI(uvicorn) |
| Container Apps(ワーカー) | 1.0 vCPU / 2Gi、ingress なし、1レプリカ固定 | キュー消化・DI解析・定期ジョブ |
| Document Intelligence | S0 | `prebuilt-layout` + Query Fields による解析 |
| PostgreSQL Flexible Server | B1ms / PostgreSQL 16 / 32GB | アプリDB(RLS・ロール分離) |
| Service Bus | Standard | `interactive` / `batch` キュー |
| Storage Account | Standard_LRS | 原本PDF・ページPNG・解析結果JSON |
| Log Analytics | PerGB2018 / 30日 | Container Apps のログ出力先 |
| ユーザ割り当てマネージドID | — | ACR pull / Blob / Service Bus / DI へのアクセス |

Storage Account と Log Analytics は当初の対象リストにないが、前者はアプリの動作に必須(Blob がないと解析結果を保存できない)、後者は Container Apps のログ出力先として実質必須のため含めている。

## 認証方式

| 接続 | 方式 |
|---|---|
| Container Apps → ACR / Blob / Service Bus / Document Intelligence | **ユーザ割り当てマネージドID**(接続文字列・キーは未設定にして `DefaultAzureCredential` 経路に載せる) |
| Container Apps → PostgreSQL | パスワード認証(`app_user`)。バックエンドが `DATABASE_URL` 固定実装のため Entra ID 認証は使わない |

Storage は `allowSharedKeyAccess: false`、Service Bus は `disableLocalAuth: true`、Document Intelligence は `disableLocalAuth: true` を設定しており、キー/SAS/接続文字列では接続できない。

## ディレクトリ構成

| パス | 内容 |
|---|---|
| `main.bicep` | オーケストレーション(targetScope: resourceGroup) |
| `main.bicepparam` | 検証環境パラメータ。機微値は `readEnvironmentVariable()` で環境変数から読む |
| `modules/monitoring.bicep` | Log Analytics |
| `modules/registry.bicep` | Container Registry |
| `modules/data.bicep` | Storage / PostgreSQL / Service Bus |
| `modules/ai.bicep` | Document Intelligence |
| `modules/rbac.bicep` | マネージドIDへのロール割り当て |
| `modules/compute.bicep` | Container Apps 環境 / API / ワーカー |
| `modules/frontend.bicep` | Static Web Apps |
| `scripts/init-roles.sql` | PostgreSQL のロール分離(`app_user` 作成・権限付与) |

## 2段階デプロイ

コンテナイメージが ACR に存在しないと Container Apps を作成できないため、`deployApps` パラメータでデプロイを2段階に分ける。

```
1回目 (DEPLOY_APPS=false) : ACR・DB・Service Bus・Storage・DI・SWA・Container Apps 環境
        ↓
      az acr build でイメージをビルド・push
        ↓
2回目 (DEPLOY_APPS=true)  : Container Apps(API / ワーカー)
```

## 主要パラメータ

| パラメータ | 既定値 | 説明 |
|---|---|---|
| `appName` | `idp` | リソース名の一部 |
| `env` | `verify` | リソース名の一部 |
| `location` | RGのリージョン | 主リージョン |
| `swaLocation` | `eastasia` | SWA は対応リージョンが限られる |
| `documentIntelligenceLocation` | `location` | 対応リージョンに合わせて変更する |
| `deployApps` | `false` | Container Apps をデプロイするか(2段階デプロイの制御) |
| `imageTag` | `v1` | デプロイするイメージタグ |
| `postgresAdminPassword` | (必須・secure) | PostgreSQL 管理者パスワード |
| `appUserPassword` | (必須・secure) | `app_user` のパスワード。`init-roles.sql` に渡す値と揃える |
| `clientIpAddress` | `''` | PostgreSQL に接続するローカルPCのグローバルIP |
| `localTenantId` / `localUserId` | seed 既定値 | `AUTH_MODE=local` のダミー認証で使うID |

## API リンクをテンプレートに含めていない理由

Static Web Apps の API リンク(`Microsoft.Web/staticSites/linkedBackends`)は Bicep でも表現できるが、本テンプレートでは扱わず手順書の CLI 操作としている。

- リンク先の Container App が起動済みである必要があり、2段階デプロイの後段でしか成立しない
- リンク操作には Container App 側に `Azure Static Web Apps (Linked)` の ID プロバイダが構成される副作用がある。解除は `az staticwebapp backends unlink --remove-backend-auth` で行う必要があり、IaC の管理範囲に入れると「テンプレートから消したのに認証設定が残る」状態になりやすい

## 検証後の後片付け

リソースグループごと削除する。Document Intelligence は論理削除されるため、同名で作り直す場合は完全削除(purge)が必要になる点に注意(手順書 §12)。
