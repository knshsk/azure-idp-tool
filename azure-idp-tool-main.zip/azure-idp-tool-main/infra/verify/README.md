# infra/verify — 社内検証環境の IaC

README のクイックスタート(WSL上でのローカル実行)と**同等の動作確認を Azure 上で行う**ための Bicep。
顧客データを扱わない前提のため、ネットワーク防御(VNet / Private Endpoint / NSG / WAF)は設けない。
位置づけは [azure-architecture_v2.md](../../docs/01_design/azure-architecture_v2.md) §4.1「初期: 社内開発」に相当する。

デプロイ手順は **[docs/03_deployment/verify-deployment-guide.md](../../docs/03_deployment/verify-deployment-guide.md)** を参照。

> 本番想定の理想形・フェーズ移行を扱う `infra/main.bicep`(スケルトン)とは別物として独立させている。
> 検証環境は「割り切った構成」であり、理想形テンプレートに条件分岐として混ぜると両方が読みにくくなるため。

## 構成するリソース

| リソース | SKU / 構成 | 用途 |
|---|---|---|
| Static Web Apps | Standard | フロントエンド配信。API リンクで Container Apps(API)へ `/api/*` をプロキシ |
| Container Registry | Basic | コンテナイメージの保管+**ビルド**(`az acr build`) |
| Container Apps 環境 | 消費プラン | API / ワーカーの実行基盤 |
| Container Apps(API) | 0.5 vCPU / 1Gi、external ingress、最小1レプリカ | FastAPI(uvicorn) |
| Container Apps(ワーカー) | 1.0 vCPU / 2Gi、ingress なし、1レプリカ固定 | キュー消化・DI解析・定期ジョブ |
| Container Apps(Keycloak) | 1.0 vCPU / 2Gi、external ingress、1レプリカ固定 | 認証基盤。**既定では作成しない**(`deployKeycloak`) |
| Container Apps Job(DB初期化) | マニュアル実行 | `alembic upgrade head` + `seed.py` を Azure 内から実行 |
| Document Intelligence | S0 | `prebuilt-layout` + Query Fields による解析 |
| PostgreSQL Flexible Server | B1ms / PostgreSQL 16 / 32GB | アプリDB(`idp`)+ KeycloakDB(`keycloak`)。それぞれ別ロール |
| Service Bus | Standard | `interactive` / `batch` キュー |
| Storage Account | Standard_LRS | 原本PDF・ページPNG・解析結果JSON |
| Log Analytics | PerGB2018 / 30日 | Container Apps のログ出力先 |
| ユーザ割り当てマネージドID | — | ACR pull / Blob / Service Bus / DI へのアクセス |

Storage Account と Log Analytics は当初の対象リストにないが、前者はアプリの動作に必須(Blob がないと解析結果を保存できない)、後者は Container Apps のログ出力先として実質必須のため含めている。

## 認証方式

| 接続 | 方式 |
|---|---|
| Container Apps → ACR / Blob / Service Bus / Document Intelligence | **ユーザ割り当てマネージドID**(接続文字列・キーは未設定にして `DefaultAzureCredential` 経路に載せる) |
| Container Apps → PostgreSQL | パスワード認証(`app_user`)。バックエンドが `DATABASE_URL` 固定実装のため Entra ID 認証は使わない |
| Keycloak → PostgreSQL | パスワード認証(`keycloak_user`)。**アプリDB(`idp`)とは別データベース・別ロール**にし、権限境界を混ぜない |
| DB初期化ジョブ → PostgreSQL | パスワード認証(管理者=所有者ロール)。**所有者ロールの接続文字列を持つのはこのジョブだけ**にし、API・ワーカーには `app_user` しか渡さない |

Storage は `allowSharedKeyAccess: false`、Service Bus は `disableLocalAuth: true`、Document Intelligence は `disableLocalAuth: true` を設定しており、キー/SAS/接続文字列では接続できない。

## ディレクトリ構成

| パス | 内容 |
|---|---|
| `main.bicep` | オーケストレーション(targetScope: resourceGroup) |
| `main.bicepparam` | 検証環境パラメータ。機微値は `readEnvironmentVariable()` で環境変数から読む |
| `modules/monitoring.bicep` | Log Analytics |
| `modules/registry.bicep` | Container Registry |
| `modules/data.bicep` | Storage / PostgreSQL / Service Bus |
| `modules/ai.bicep` | Document Intelligence |
| `modules/rbac.bicep` | マネージドIDへのロール割り当て |
| `modules/container-apps-env.bicep` | Container Apps 環境(API・ワーカー・Keycloak の実行基盤) |
| `modules/compute.bicep` | API / ワーカー / DB初期化ジョブ |
| `modules/keycloak.bicep` | Keycloak(Container App)。既定では作成しない |
| `modules/frontend.bicep` | Static Web Apps |
| `keycloak/Dockerfile` | Keycloak の最適化イメージ(`kc.sh build` 済み+レルム定義同梱) |
| `keycloak/realm-idp.json` | レルム `idp` とクライアント `idp-frontend` の定義(初回起動時に取り込まれる) |
| `scripts/init-roles.sql` | アプリDBのロール分離(`app_user` 作成・権限付与) |
| `scripts/init-keycloak-db.sql` | KeycloakDBのロール作成(`keycloak_user` 作成・`public` への CREATE 付与) |

## 2段階デプロイ

コンテナイメージが ACR に存在しないと Container Apps を作成できないため、`deployApps` パラメータでデプロイを2段階に分ける。

```
1回目 (DEPLOY_APPS=false) : ACR・DB・Service Bus・Storage・DI・SWA・Container Apps 環境
        ↓
      az acr build でイメージをビルド・push
        ↓
2回目 (DEPLOY_APPS=true)  : Container Apps(API / ワーカー)+ DB初期化ジョブ
        ↓
      az containerapp job start でDB初期化(マイグレーション+シード)
```

## DB初期化ジョブについて

マイグレーション(`alembic upgrade head`)とシード(`scripts/seed.py`)を **Azure 内から**実行するマニュアル実行ジョブ。API・ワーカーと同一イメージを使い、起動コマンドだけ差し替えている。

```bash
az containerapp job start --name caj-idp-verify-dbinit --resource-group <RG>
```

ローカルPCから PostgreSQL へ直接接続できない環境(社内ネットワークが 5432 の TCP を終端し、PostgreSQL のプロトコルを通さない構成)でも DB 初期化ができるようにするためのもの。`alembic upgrade head` も `seed.py` も冪等なので、マイグレーション追加のたびに何度でも実行してよい。

`app_user` ロールの作成(`scripts/init-roles.sql`)だけは `psql` のメタコマンドを使うため、このジョブには含めていない。初回のみ Cloud Shell から実行する。

## Keycloak について

認証基盤を Entra External ID から Keycloak(自ホスト)へ変更したことに伴う構成。**`deployKeycloak` の既定は `false`** で、通常のアプリ検証では作成されない。

```
1回目/2回目のデプロイ : keycloak データベースだけが作られる(コンテナは無し)
        ↓
   scripts/init-keycloak-db.sql を Cloud Shell から実行(keycloak_user 作成)
        ↓
   az acr build で keycloak/ のイメージをビルド・push
        ↓
DEPLOY_KEYCLOAK=true で再デプロイ : Keycloak が起動し、レルム定義が取り込まれる
```

設計上のポイント:

- **アプリDBと Keycloak DB は別データベース・別ロール**。同一サーバに同居させるがロールを分け、アプリのRLS・権限境界と混ぜない
- **イメージは自前ビルド**(`keycloak/Dockerfile`)。公式イメージに `kc.sh build` を適用した最適化イメージで、`start --optimized` により起動が速い。ベースイメージのタグは固定する(`latest` は使わない)
- **レルム定義をイメージへ同梱**し、`--import-realm` で初回起動時に取り込む。リダイレクトURIは SPA のオリジンに依存するため、ビルド引数 `APP_ORIGIN` で埋め込む
- **ヘルスプローブは管理ポート 9000**。Keycloak 25 以降、`/health/*` はアプリ本体(8080)ではなく管理インターフェースで待ち受ける
- **レプリカは1固定**。複数レプリカにするとセッション共有のため Infinispan のクラスタ構成が要る
- **Container Apps 環境は独立モジュール**(`container-apps-env.bicep`)。既定ドメインが分かれば各アプリの FQDN が確定するので、Keycloak の公開URLをアプリ作成前に組み立てられ、API・ワーカーへ `OIDC_ISSUER` として渡せる。環境が compute の中にあると compute → keycloak → compute の循環参照になる

制約と未対応:

- **レルム定義の反映は初回のみ。** `--import-realm` は既存レルムがある場合は何もしない。定義を変えたら `keycloak` データベースを作り直す必要がある(手順書 付録E.6)
- **ロールは JWT クレームではなく `users` テーブルで解決する**(data-model.md)。そのためレルム定義にロールは含めていない
- バックエンドの JWT 検証・フロントエンドの `keycloak-js` はどちらも実装済み。それでも `AUTH_MODE` の既定を `local` のままにしているのは、`deployKeycloak` の既定が `false` で Keycloak が居ないため。認証を有効にするには **(1) Keycloak をデプロイ (2) `users` へ利用者を事前登録 (3) `AUTH_MODE=keycloak` と SWA 側 `VITE_AUTH_MODE=keycloak`** の3つが揃う必要がある

## 主要パラメータ

| パラメータ | 既定値 | 説明 |
|---|---|---|
| `appName` | `idp` | リソース名の一部 |
| `env` | `verify` | リソース名の一部 |
| `location` | RGのリージョン | 主リージョン |
| `swaLocation` | `eastasia` | SWA は対応リージョンが限られる |
| `documentIntelligenceLocation` | `location` | 対応リージョンに合わせて変更する |
| `deployApps` | `false` | Container Apps をデプロイするか(2段階デプロイの制御) |
| `imageTag` | `v1` | デプロイするイメージタグ |
| `postgresAdminPassword` | (必須・secure) | PostgreSQL 管理者パスワード |
| `appUserPassword` | (必須・secure) | `app_user` のパスワード。`init-roles.sql` に渡す値と揃える |
| `clientIpAddress` | `''` | PostgreSQL に接続するローカルPCのグローバルIP |
| `localTenantId` / `localUserId` | seed 既定値 | `AUTH_MODE=local` のダミー認証で使うID |
| `deployKeycloak` | `false` | Keycloak をデプロイするか。DBロール作成とイメージ push の後に `true` にする |
| `keycloakImageTag` | `v1` | `az acr build` で `idp-keycloak` に付けたタグ |
| `keycloakDbPassword` | `''`(secure) | `keycloak_user` のパスワード。`init-keycloak-db.sql` に渡す値と揃える |
| `keycloakAdminUsername` / `keycloakAdminPassword` | `kcadmin` / `''`(secure) | Keycloak 初期管理者。レルム構成後は無効化する |
| `keycloakRealmName` | `idp` | issuer URL の組み立てに使う。`realm-idp.json` の `realm` と揃える |
| `keycloakClientId` | `idp-frontend` | SPA が OIDC 認可要求に使うクライアント ID。`realm-idp.json` の `clientId` と揃える |
| `oidcAudience` | `idp-api` | APIが検証するJWTの `aud`。`realm-idp.json` の audience マッパー(`included.custom.audience`)と揃える |

## API リンクをテンプレートに含めていない理由

Static Web Apps の API リンク(`Microsoft.Web/staticSites/linkedBackends`)は Bicep でも表現できるが、本テンプレートでは扱わず手順書の CLI 操作としている。

- リンク先の Container App が起動済みである必要があり、2段階デプロイの後段でしか成立しない
- リンク操作には Container App 側に `Azure Static Web Apps (Linked)` の ID プロバイダが構成される副作用がある。解除は `az staticwebapp backends unlink --remove-backend-auth` で行う必要があり、IaC の管理範囲に入れると「テンプレートから消したのに認証設定が残る」状態になりやすい

## 検証後の後片付け

リソースグループごと削除する。Document Intelligence は論理削除されるため、同名で作り直す場合は完全削除(purge)が必要になる点に注意(手順書 §12)。
