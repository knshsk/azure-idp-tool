// データ層: Storage(Blob)/ PostgreSQL Flexible Server / Service Bus
//
// 検証環境ではネットワーク防御(VNet / Private Endpoint)を設けず、
// パブリックエンドポイント + Managed Identity 認証で構成する
// (azure-architecture_v2.md §4.1)。

@description('リージョン')
param location string

// --- Storage(Blob) ---

@description('ストレージアカウント名(グローバル一意・小文字英数字のみ・24文字以内)')
param storageAccountName string

// --- PostgreSQL ---

@description('PostgreSQL Flexible Server 名(グローバル一意)')
param postgresName string

@description('管理者ログイン名')
param postgresAdminLogin string

@description('管理者パスワード')
@secure()
param postgresAdminPassword string

@description('作成するデータベース名(アプリ用)')
param databaseName string

@description('Keycloak 用データベース名。アプリDBとは別データベース・別ロールにする(azure-architecture_v2.md §1.2)')
param keycloakDatabaseName string = 'keycloak'

@description('接続を許可するローカルPCのグローバルIP。空文字なら追加しない')
param clientIpAddress string = ''

// --- Service Bus ---

@description('Service Bus 名前空間名(グローバル一意)')
param serviceBusName string

@description('作成するキュー名の一覧')
param queueNames array

@description('キューの最大配信回数。backend の WORKER_MAX_DELIVERY_COUNT と揃える')
param maxDeliveryCount int = 5

// ---------------------------------------------------------------------------
// Storage(Blob)
// 原本PDF・ページPNG・DI解析結果JSON の保管先(docs/01_design/blob-storage.md)。
// テナント別コンテナはアプリが実行時に作成する(app/clients/blob.py)。
// ---------------------------------------------------------------------------

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageAccountName
  location: location
  sku: {
    // 検証環境のためローカル冗長。本番想定は ZRS(azure-architecture_v2.md §1.1)
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    supportsHttpsTrafficOnly: true
    // 匿名アクセスは禁止。Blob は必ず API 経由で配信する
    allowBlobPublicAccess: false
    // アクセスキー・SAS を無効化し、Managed Identity(Entra ID)認証のみにする
    // (azure-architecture_v2.md §1.2「キー廃止」。ポータルのストレージブラウザも
    //  Entra ID 認証に切り替えて使う)
    allowSharedKeyAccess: false
    publicNetworkAccess: 'Enabled'
    networkAcls: {
      // Container Apps(消費プラン)の送信IPは固定できないため、IP制限は掛けない。
      // 認可は Managed Identity + RBAC のみで担保する
      defaultAction: 'Allow'
      bypass: 'AzureServices'
    }
  }
}

// ---------------------------------------------------------------------------
// PostgreSQL Flexible Server
// RLS のロール分離(所有者ロール=管理者 / アプリロール=app_user)は
// scripts/init-roles.sql を手動で流して構成する。
// ---------------------------------------------------------------------------

resource postgres 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' = {
  name: postgresName
  location: location
  sku: {
    name: 'Standard_B1ms'
    tier: 'Burstable'
  }
  properties: {
    // ローカル開発の docker-compose(postgres:16)と揃える
    version: '16'
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
    storage: {
      storageSizeGB: 32
      autoGrow: 'Disabled'
    }
    backup: {
      backupRetentionDays: 7
      geoRedundantBackup: 'Disabled'
    }
    highAvailability: {
      mode: 'Disabled'
    }
    network: {
      // パブリックアクセス + ファイアウォール(検証環境)
      publicNetworkAccess: 'Enabled'
    }
    authConfig: {
      // バックエンドが DATABASE_URL 固定実装のためパスワード認証を使う。
      // Entra ID 認証への移行にはトークン取得処理の実装が必要
      activeDirectoryAuth: 'Disabled'
      passwordAuth: 'Enabled'
    }
  }
}

// Container Apps からの接続を許可する。
// 0.0.0.0 の特殊ルールは「Azure サービスからのアクセスを許可」を意味する。
// Container Apps(消費プラン)の送信IPは固定できないためこの形を取る
// (本番想定では NAT Gateway による送信IP固定 + Private Endpoint: §1.2)。
resource allowAzureServices 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2024-08-01' = {
  parent: postgres
  name: 'AllowAllAzureServices'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

// マイグレーション・シードをローカル(WSL)から流すための穴。
// ファイアウォールルールは同時更新できないため dependsOn で直列化する。
resource allowClientIp 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2024-08-01' = if (!empty(clientIpAddress)) {
  parent: postgres
  name: 'AllowClientIp'
  properties: {
    startIpAddress: clientIpAddress
    endIpAddress: clientIpAddress
  }
  dependsOn: [
    allowAzureServices
  ]
}

resource database 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: postgres
  name: databaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
  dependsOn: [
    allowAzureServices
    allowClientIp
  ]
}

// Keycloak(認証基盤)のストア。アプリDBと同一サーバ上の別データベースにする。
// ロールも分けて(scripts/init-keycloak-db.sql)、アプリのRLS・権限境界と混ぜない。
// 同一サーバに対するデータベース作成は同時実行できないため dependsOn で直列化する。
resource keycloakDatabase 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: postgres
  name: keycloakDatabaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
  dependsOn: [
    database
  ]
}

// ---------------------------------------------------------------------------
// Service Bus
// interactive(対話操作)/ batch(バッチ連携)の2キュー構成。
// ローカルの docker/servicebus-config.json と同じキュー名を使う。
// ---------------------------------------------------------------------------

resource serviceBus 'Microsoft.ServiceBus/namespaces@2024-01-01' = {
  name: serviceBusName
  location: location
  sku: {
    // Basic はキューのみで DLQ 等の機能に制約があるため Standard を使う
    name: 'Standard'
    tier: 'Standard'
  }
  properties: {
    // SAS(接続文字列)認証を無効化し、Managed Identity 認証のみにする
    disableLocalAuth: true
    minimumTlsVersion: '1.2'
  }
}

resource queues 'Microsoft.ServiceBus/namespaces/queues@2024-01-01' = [
  for queueName in queueNames: {
    parent: serviceBus
    name: queueName
    properties: {
      // 配信回数の上限。超えるとDLQへ送られる(backend の WORKER_MAX_DELIVERY_COUNT と一致させる)
      maxDeliveryCount: maxDeliveryCount
      // DI解析はロック時間を超えるため、ワーカーが AutoLockRenewer で延長する。
      // 初期ロックは最大値の5分にしておく
      lockDuration: 'PT5M'
      defaultMessageTimeToLive: 'P1D'
      deadLetteringOnMessageExpiration: true
    }
  }
]

// ---------------------------------------------------------------------------
// 出力
// ---------------------------------------------------------------------------

// リソース名はパラメータとして渡しているため、ここでは接続情報のみを返す
// (同名の出力を定義すると識別子が重複してテンプレートが壊れる)
output blobEndpoint string = storageAccount.properties.primaryEndpoints.blob
output postgresFqdn string = postgres.properties.fullyQualifiedDomainName
output serviceBusFqdn string = '${serviceBus.name}.servicebus.windows.net'
