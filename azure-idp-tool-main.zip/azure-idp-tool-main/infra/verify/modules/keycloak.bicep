// 認証基盤: Keycloak(Container Apps)
//
// 自ホストの認証基盤(docs/01_design/azure-architecture_v2.md §1.2 の設計要点6)。
//
// 前提となる手作業:
//   Keycloak が使う DB ロールは Bicep では作れないため、デプロイ前に
//   scripts/init-keycloak-db.sql を流しておくこと(手順書 §7.1)。
//   ロールが無い状態で起動するとコンテナが起動失敗を繰り返す。
//
// 検証環境での割り切り:
//   - ブラウザから直接到達させるため external ingress にする。本番想定では
//     Application Gateway 経由にし、管理パス(/admin/master・/admin/realms)は
//     公開経路から遮断する(NFR-SEC-19)。**検証環境では /admin が公開される**。
//   - レプリカは1固定。複数レプリカにするとセッション共有のため Infinispan の
//     クラスタ構成が必要になる。
//   - レルム・クライアントの作成は管理コンソールでの手作業(手順書 §8)。

@description('リージョン')
param location string

@description('Keycloak の Container App 名')
param keycloakAppName string

@description('Container Apps 環境のリソースID(container-apps-env.bicep の出力)')
param containerAppsEnvId string

@description('Keycloak 自身の公開URL(KC_HOSTNAME)。main.bicep が環境の既定ドメインから組み立てる')
param keycloakBaseUrl string

@description('Keycloak のコンテナイメージ(ACR)。keycloak/Dockerfile を az acr build でビルドしたもの。タグは必ず固定する(NFR-SEC-20)')
param keycloakImage string

@description('ACR pull に使うユーザ割り当てマネージドIDのリソースID')
param identityResourceId string

@description('ACR のログインサーバ(例: crxxxx.azurecr.io)')
param registryLoginServer string

@description('PostgreSQL Flexible Server の FQDN')
param postgresFqdn string

@description('Keycloak 用データベース名(data.bicep が作成する)')
param keycloakDatabaseName string

@description('Keycloak が DB へ接続するロール名。scripts/init-keycloak-db.sql で作成する')
param keycloakDbUser string

@description('同ロールのパスワード。init-keycloak-db.sql に渡す値と揃える。URL予約文字は使わない')
@secure()
param keycloakDbPassword string

@description('Keycloak 初期管理者のユーザ名')
param keycloakAdminUsername string

@description('Keycloak 初期管理者のパスワード')
@secure()
param keycloakAdminPassword string

@description('Keycloak をデプロイする。認証の検証をしない期間は false にして常駐コストを止められる')
param deployKeycloak bool

// Keycloak の管理インターフェース(ヘルス・メトリクス)は 25 以降、
// アプリ本体とは別の 9000 番ポートで待ち受ける。プローブはこちらに向ける。
var managementPort = 9000

resource keycloakApp 'Microsoft.App/containerApps@2024-03-01' = if (deployKeycloak) {
  name: keycloakAppName
  location: location
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identityResourceId}': {}
    }
  }
  properties: {
    environmentId: containerAppsEnvId
    configuration: {
      activeRevisionsMode: 'Single'
      registries: [
        {
          server: registryLoginServer
          identity: identityResourceId
        }
      ]
      secrets: [
        {
          name: 'keycloak-db-password'
          value: keycloakDbPassword
        }
        {
          name: 'keycloak-admin-password'
          value: keycloakAdminPassword
        }
      ]
      // 認証のためブラウザがリダイレクトされてくるので external ingress にする
      ingress: {
        external: true
        targetPort: 8080
        transport: 'auto'
        allowInsecure: false
        traffic: [
          {
            latestRevision: true
            weight: 100
          }
        ]
      }
    }
    template: {
      containers: [
        {
          name: 'keycloak'
          image: keycloakImage
          // ENTRYPOINT は /opt/keycloak/bin/kc.sh(keycloak/Dockerfile)。
          //   --optimized  : ビルド済み構成を使い、起動時の再ビルドを省く
          //   --import-realm: 同梱のレルム定義を取り込む。レルムが既に存在する
          //                   場合は何もしないため、再起動のたびに実行してよい
          args: [
            'start'
            '--optimized'
            '--import-realm'
          ]
          resources: {
            // JVM アプリなので API より多めに取る
            cpu: json('1.0')
            memory: '2Gi'
          }
          // KC_DB と KC_HEALTH_ENABLED はビルド時オプションのためイメージに
          // 焼き込んである(keycloak/Dockerfile)。--optimized 起動では実行時に
          // 指定しても使われないので、ここには置かない
          env: [
            {
              // Azure PostgreSQL は TLS 必須のため sslmode=require を付ける
              name: 'KC_DB_URL'
              value: 'jdbc:postgresql://${postgresFqdn}:5432/${keycloakDatabaseName}?sslmode=require'
            }
            {
              name: 'KC_DB_USERNAME'
              value: keycloakDbUser
            }
            {
              name: 'KC_DB_PASSWORD'
              secretRef: 'keycloak-db-password'
            }
            {
              name: 'KC_HOSTNAME'
              value: keycloakBaseUrl
            }
            {
              // Container Apps の ingress が TLS を終端し、コンテナへは HTTP で届く
              name: 'KC_HTTP_ENABLED'
              value: 'true'
            }
            {
              // ingress が付与する X-Forwarded-* を信頼して外形URLを復元する。
              // 本番では KC_PROXY_TRUSTED_ADDRESSES でプロキシのIPを限定すべきだが、
              // Container Apps の ingress IP は固定できないため検証環境では設定しない
              name: 'KC_PROXY_HEADERS'
              value: 'xforwarded'
            }
            {
              // 初回起動時にのみ作られるブートストラップ管理者。
              // レルム構成後は恒久的な管理者を作ってこのアカウントを無効化する(NFR-SEC-19)
              name: 'KC_BOOTSTRAP_ADMIN_USERNAME'
              value: keycloakAdminUsername
            }
            {
              name: 'KC_BOOTSTRAP_ADMIN_PASSWORD'
              secretRef: 'keycloak-admin-password'
            }
          ]
          probes: [
            {
              // 初回起動は構成ビルド + DBスキーマ作成が走るため長めに待つ(最大5分)
              type: 'Startup'
              httpGet: {
                path: '/health/started'
                port: managementPort
              }
              periodSeconds: 10
              failureThreshold: 30
            }
            {
              type: 'Readiness'
              httpGet: {
                path: '/health/ready'
                port: managementPort
              }
              periodSeconds: 10
              failureThreshold: 3
            }
          ]
        }
      ]
      scale: {
        // 起動が遅くセッションを保持するためスケールゼロにしない。
        // 複数レプリカにはInfinispanのクラスタ構成が必要なため検証環境では1固定
        minReplicas: 1
        maxReplicas: 1
      }
    }
  }
}

// 公開URL・issuer URL は main.bicep が環境の既定ドメインから組み立てて
// API・ワーカー(OIDC_ISSUER)とこのモジュールの両方へ渡すため、ここでは出力しない。
