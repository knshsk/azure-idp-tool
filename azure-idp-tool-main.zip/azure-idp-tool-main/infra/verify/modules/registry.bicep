// コンテナレジストリ(ACR)
//
// コンテナイメージのビルドも ACR で行う(az acr build)。
// 社内認証プロキシ配下のクライアントでも、ビルドは Azure 側で実行されるため
// ベースイメージ(python:3.14-slim / ghcr.io の uv)の取得がプロキシの影響を受けない。
//
// 検証環境では Basic SKU を使う。Basic でも ACR Tasks(az acr build)は利用可能。
// Private Endpoint・イメージ脆弱性スキャンは Premium が必要だが、
// 顧客データを扱わない検証段階ではスコープ外(azure-architecture_v2.md §2)。

@description('コンテナレジストリ名(グローバル一意・英数字のみ)')
param registryName string

@description('リージョン')
param location string

resource registry 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: registryName
  location: location
  sku: {
    name: 'Basic'
  }
  properties: {
    // 管理者ユーザ(ユーザ名/パスワード)は使わない。pull は Managed Identity で行う
    adminUserEnabled: false
    publicNetworkAccess: 'Enabled'
  }
}

output name string = registry.name
output id string = registry.id
output loginServer string = registry.properties.loginServer
