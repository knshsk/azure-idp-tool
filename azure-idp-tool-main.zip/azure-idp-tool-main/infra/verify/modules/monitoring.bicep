// 監視: Log Analytics ワークスペース
//
// Container Apps 環境のコンソールログ・システムログの出力先。
// 検証環境ではアプリのログが追えないと切り分けができないため必須とする。
// (azure-architecture_v2.md §4.1「Log Analytics(最小)」に相当)

@description('Log Analytics ワークスペース名')
param logAnalyticsName string

@description('リージョン')
param location string

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: logAnalyticsName
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    // 検証環境のため保持は最小(30日)。従量課金の取り込み量を抑える
    retentionInDays: 30
  }
}

output name string = logAnalytics.name
output id string = logAnalytics.id
output customerId string = logAnalytics.properties.customerId
