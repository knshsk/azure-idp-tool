// フロントエンド: Static Web Apps
//
// バックエンド(Container Apps)との連携は SWA の API リンク機能を使う。
// リンクすると /api で始まるリクエストが同じパスのままリンク先へプロキシされるため、
// フロントエンドの VITE_API_BASE_URL=/api とバックエンドの /api/v1/* がそのまま噛み合う。
//
// リンク自体はこのテンプレートでは行わない。理由:
//   - リンク先の Container App が起動済みである必要があり、2段階デプロイの後段になる
//   - リンク操作は Container App 側に「Azure Static Web Apps (Linked)」の
//     ID プロバイダを構成する副作用があり、CLI/ポータルの手順として明示したほうが
//     解除(unlink)まで含めて追いやすい
// 手順は docs/03_deployment/verify-deployment-guide.md を参照。

@description('Static Web App 名')
param staticWebAppName string

@description('リージョン。SWAは対応リージョンが限られる')
param location string

resource staticWebApp 'Microsoft.Web/staticSites@2023-12-01' = {
  name: staticWebAppName
  location: location
  sku: {
    // API リンク(バックエンド連携)は Standard 以上が必須。Free では使えない
    name: 'Standard'
    tier: 'Standard'
  }
  properties: {
    // GitHub / Azure DevOps 連携は行わない(SWA CLI による手動デプロイ)
    stagingEnvironmentPolicy: 'Disabled'
    // デプロイ成果物に含めた staticwebapp.config.json を反映させる
    allowConfigFileUpdates: true
  }
}

output name string = staticWebApp.name
output id string = staticWebApp.id
output defaultHostname string = staticWebApp.properties.defaultHostname
