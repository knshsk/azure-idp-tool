// コンピュート: API / ワーカー / DB初期化ジョブ
//
// API とワーカーは同一イメージで、起動コマンドのみ切り替える(backend/Dockerfile)。
//   API    : 既定 CMD(uvicorn)
//   ワーカー: python -m app.worker.main
//
// Container Apps はイメージが ACR に存在しないと作成できないため、
// deployApps パラメータで2段階に分けてデプロイする(main.bicep のコメント参照)。
// 実行基盤の環境(managedEnvironments)は container-apps-env.bicep が作る。

@description('リージョン')
param location string

@description('Container Apps 環境のリソースID(container-apps-env.bicep の出力)')
param containerAppsEnvId string

@description('API の Container App 名')
param apiAppName string

@description('ワーカーの Container App 名')
param workerAppName string

@description('DB初期化ジョブ(Container Apps Job)名')
param dbInitJobName string

@description('アプリに割り当てるユーザ割り当てマネージドIDのリソースID')
param identityResourceId string

@description('同マネージドIDのクライアントID(DefaultAzureCredential の AZURE_CLIENT_ID に渡す)')
param identityClientId string

@description('ACR のログインサーバ(例: crxxxx.azurecr.io)')
param registryLoginServer string

@description('コンテナイメージのリポジトリ名')
param imageRepository string = 'idp-backend'

@description('コンテナイメージのタグ')
param imageTag string

@description('Container Apps(API / ワーカー)をデプロイする')
param deployApps bool

// --- アプリケーション設定(backend/.env.example に対応) ---

@description('DATABASE_URL(アプリ接続ロール app_user)')
@secure()
param databaseUrl string

@description('MIGRATION_DATABASE_URL(所有者ロール=PostgreSQL管理者)。DB初期化ジョブでのみ使う')
@secure()
param migrationDatabaseUrl string

@description('BLOB_ACCOUNT_URL')
param blobAccountUrl string

@description('SERVICE_BUS_NAMESPACE(FQDN)')
param serviceBusNamespaceFqdn string

@description('SERVICE_BUS_QUEUE_INTERACTIVE')
param queueInteractive string

@description('SERVICE_BUS_QUEUE_BATCH')
param queueBatch string

@description('DI_ENDPOINT')
param documentIntelligenceEndpoint string

@description('LOCAL_TENANT_ID')
param localTenantId string

@description('LOCAL_USER_ID')
param localUserId string

@description('SHARE_BASE_URL(SWAの共有ビューURL)')
param shareBaseUrl string

@description('OIDC_ISSUER(KeycloakのレルムURL)。AUTH_MODE=keycloak のときだけ使われる')
param oidcIssuer string

@description('OIDC_AUDIENCE(APIが検証するJWTのaud。API自身を指す識別子で、SPAのクライアントIDとは別物)')
param oidcAudience string

var containerImage = '${registryLoginServer}/${imageRepository}:${imageTag}'

// API とワーカーで共通の環境変数。
// 接続文字列・キーを空にすることで、各クライアントが Managed Identity
// (DefaultAzureCredential)経路にフォールバックする実装になっている
// (backend/app/clients/{blob,queue,di}.py)。
var commonEnv = [
  {
    name: 'DATABASE_URL'
    secretRef: 'database-url'
  }
  {
    // ユーザ割り当てマネージドIDを使う場合、DefaultAzureCredential に
    // どのIDを使うかを明示する必要がある
    name: 'AZURE_CLIENT_ID'
    value: identityClientId
  }
  {
    name: 'BLOB_ACCOUNT_URL'
    value: blobAccountUrl
  }
  {
    name: 'BLOB_CONNECTION_STRING'
    value: ''
  }
  {
    name: 'SERVICE_BUS_NAMESPACE'
    value: serviceBusNamespaceFqdn
  }
  {
    name: 'SERVICE_BUS_CONNECTION_STRING'
    value: ''
  }
  {
    name: 'SERVICE_BUS_QUEUE_INTERACTIVE'
    value: queueInteractive
  }
  {
    name: 'SERVICE_BUS_QUEUE_BATCH'
    value: queueBatch
  }
  {
    name: 'DI_ENDPOINT'
    value: documentIntelligenceEndpoint
  }
  {
    name: 'DI_KEY'
    value: ''
  }
  {
    // ローカル開発と同じダミー認証。JWT検証もログイン導線も実装済みだが、
    // deployKeycloak の既定が false で Keycloak が居ないため local のままにする。
    // 切り替えるときは Keycloak のデプロイと users への事前登録も併せて行う
    name: 'AUTH_MODE'
    value: 'local'
  }
  {
    // AUTH_MODE=keycloak のときだけ使われる。AUTH_MODE=local の間は
    // バックエンドが参照しないため、Keycloak 未デプロイでも害はない
    name: 'OIDC_ISSUER'
    value: oidcIssuer
  }
  {
    name: 'OIDC_AUDIENCE'
    value: oidcAudience
  }
  {
    name: 'LOCAL_TENANT_ID'
    value: localTenantId
  }
  {
    name: 'LOCAL_USER_ID'
    value: localUserId
  }
  {
    name: 'LOCAL_USER_ROLE'
    value: 'tenant_admin'
  }
  {
    name: 'SHARE_BASE_URL'
    value: shareBaseUrl
  }
]

var commonSecrets = [
  {
    name: 'database-url'
    value: databaseUrl
  }
]

var commonRegistries = [
  {
    server: registryLoginServer
    identity: identityResourceId
  }
]

var commonIdentity = {
  type: 'UserAssigned'
  userAssignedIdentities: {
    '${identityResourceId}': {}
  }
}

// ---------------------------------------------------------------------------
// API(FastAPI / uvicorn)
// Static Web Apps の API リンク先になるため external ingress にする。
// リンク後は SWA 経由のトラフィックのみ受け付ける設定が自動で入る。
// ---------------------------------------------------------------------------

resource apiApp 'Microsoft.App/containerApps@2024-03-01' = if (deployApps) {
  name: apiAppName
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnvId
    configuration: {
      activeRevisionsMode: 'Single'
      secrets: commonSecrets
      registries: commonRegistries
      ingress: {
        external: true
        targetPort: 8000
        transport: 'auto'
        allowInsecure: false
        traffic: [
          {
            latestRevision: true
            weight: 100
          }
        ]
      }
    }
    template: {
      containers: [
        {
          name: 'api'
          image: containerImage
          // 起動コマンドは指定しない(Dockerfile の CMD = uvicorn を使う)
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: commonEnv
          probes: [
            {
              type: 'Readiness'
              httpGet: {
                path: '/healthz'
                port: 8000
              }
              initialDelaySeconds: 10
              periodSeconds: 10
              failureThreshold: 6
            }
          ]
        }
      ]
      scale: {
        // 検証中にコールドスタートで待たされないよう常時1レプリカ
        minReplicas: 1
        maxReplicas: 2
      }
    }
  }
}

// ---------------------------------------------------------------------------
// ワーカー(キュー消化・DI解析・定期ジョブ)
// ingress なし。KEDA によるキュー長スケールは Managed Identity 認証の設定が
// 複雑になるため、検証環境では1レプリカ固定にする。
// 定期ジョブ(回収処理・保持期間超過削除)がレプリカごとに動くため、
// 多重起動を避ける意味でも maxReplicas は1にする。
// ---------------------------------------------------------------------------

resource workerApp 'Microsoft.App/containerApps@2024-03-01' = if (deployApps) {
  name: workerAppName
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnvId
    configuration: {
      activeRevisionsMode: 'Single'
      secrets: commonSecrets
      registries: commonRegistries
    }
    template: {
      containers: [
        {
          name: 'worker'
          image: containerImage
          // API と同一イメージ。起動コマンドでワーカーに切り替える
          command: [
            'python'
            '-m'
            'app.worker.main'
          ]
          resources: {
            // ページPNG生成(pypdfium2 + Pillow)があるためAPIより多めに取る
            cpu: json('1.0')
            memory: '2Gi'
          }
          env: commonEnv
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 1
      }
    }
  }
}

// ---------------------------------------------------------------------------
// DB初期化ジョブ(マニュアル実行)
//
// マイグレーション(alembic)とシード(scripts/seed.py)を Azure 内から実行する。
// ローカルPCからPostgreSQLへ直接接続できない環境(社内ネットワークが5432の
// TCPを終端し、PostgreSQLのプロトコルを通さない構成)でもDB初期化ができる。
//
// 実行: az containerapp job start --name <ジョブ名> --resource-group <RG>
//
// alembic の upgrade も seed.py も冪等なため、マイグレーション追加のたびに
// 何度でも実行してよい。
//
// 所有者ロール(PostgreSQL管理者)の接続文字列を持つのはこのジョブだけにする。
// API・ワーカーにはアプリ接続ロール(app_user)しか渡さない(RLSのロール分離)。
// ---------------------------------------------------------------------------

resource dbInitJob 'Microsoft.App/jobs@2024-03-01' = if (deployApps) {
  name: dbInitJobName
  location: location
  identity: commonIdentity
  properties: {
    environmentId: containerAppsEnvId
    configuration: {
      triggerType: 'Manual'
      // マイグレーション+シードの所要時間に対して十分な余裕を取る(秒)
      replicaTimeout: 1800
      // 失敗を握り潰さず、ログを見て対処する
      replicaRetryLimit: 0
      manualTriggerConfig: {
        parallelism: 1
        replicaCompletionCount: 1
      }
      secrets: [
        {
          name: 'migration-database-url'
          value: migrationDatabaseUrl
        }
        {
          name: 'database-url'
          value: databaseUrl
        }
      ]
      registries: commonRegistries
    }
    template: {
      containers: [
        {
          name: 'db-init'
          image: containerImage
          // API・ワーカーと同一イメージ。起動コマンドでDB初期化に切り替える
          command: [
            'sh'
            '-c'
          ]
          args: [
            'alembic upgrade head && python scripts/seed.py'
          ]
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: [
            {
              // alembic と seed.py は所有者ロールで実行する
              // (RLS FORCE下ではアプリロールはDDL不可。backend/alembic/env.py)
              name: 'MIGRATION_DATABASE_URL'
              secretRef: 'migration-database-url'
            }
            {
              name: 'DATABASE_URL'
              secretRef: 'database-url'
            }
            {
              // seed.py が作成する開発テナント・ユーザのID
              name: 'LOCAL_TENANT_ID'
              value: localTenantId
            }
            {
              name: 'LOCAL_USER_ID'
              value: localUserId
            }
          ]
        }
      ]
    }
  }
}

output apiAppResourceId string = deployApps ? apiApp.id : ''
// deployApps=false のときは評価されないため、非null表明(!)で警告を抑止する
output apiAppFqdn string = deployApps ? apiApp!.properties.configuration.ingress.fqdn : ''
