// Container Apps 環境
//
// API・ワーカー・DB初期化ジョブ・Keycloak が同居する実行基盤。
//
// compute.bicep から切り出している理由:
//   Keycloak は自身の公開URL(KC_HOSTNAME)を組み立てるために環境の既定ドメインを
//   必要とし、API・ワーカーはその Keycloak の issuer URL を OIDC_ISSUER として
//   必要とする。環境が compute.bicep の中にあると
//   compute → keycloak → compute の循環参照になるため、環境だけを先に作る。
//   既定ドメインが分かれば FQDN は <アプリ名>.<既定ドメイン> で確定するので、
//   アプリを作る前に両者のURLを組み立てられる。
//
// 作成に数分かかるため、2段階デプロイの1段階目から作っておく。

@description('リージョン')
param location string

@description('Container Apps 環境名')
param containerAppsEnvName string

@description('ログ出力先の Log Analytics ワークスペース名')
param logAnalyticsName string

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: logAnalyticsName
}

resource containerAppsEnv 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: containerAppsEnvName
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logAnalytics.properties.customerId
        sharedKey: logAnalytics.listKeys().primarySharedKey
      }
    }
  }
}

output id string = containerAppsEnv.id
output name string = containerAppsEnv.name

// <アプリ名>.<この既定ドメイン> が各 Container App の FQDN になる
output defaultDomain string = containerAppsEnv.properties.defaultDomain
