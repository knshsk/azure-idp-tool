// Azure AI Document Intelligence
//
// 全書類を prebuilt-layout + Query Fields の1本のフローで解析する
// (backend/app/clients/di.py)。ローカルエミュレータが存在しないため、
// ローカル開発では共有リソースを使うが、検証環境では専用に払い出す。

@description('Document Intelligence アカウント名(グローバル一意。カスタムサブドメインを兼ねる)')
param documentIntelligenceName string

@description('リージョン')
param location string

@description('キー認証を無効化する(Managed Identity のみ許可)')
param disableLocalAuth bool = true

resource documentIntelligence 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: documentIntelligenceName
  location: location
  kind: 'FormRecognizer'
  sku: {
    // 無料枠(F0)はページ数・機能に制約があるため S0(従量課金)を使う
    name: 'S0'
  }
  properties: {
    // Entra ID(Managed Identity)認証にはカスタムサブドメインが必須
    customSubDomainName: documentIntelligenceName
    publicNetworkAccess: 'Enabled'
    // キー認証を止め、Managed Identity のみにする(azure-architecture_v2.md §4.1)
    disableLocalAuth: disableLocalAuth
  }
}

output name string = documentIntelligence.name
output id string = documentIntelligence.id
output endpoint string = documentIntelligence.properties.endpoint
