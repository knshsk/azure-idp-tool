// マネージドIDへのロール割り当て
//
// アプリ(API / ワーカー)が使うユーザ割り当てマネージドIDに、
// 必要最小限の組み込みロールを付与する。
// Container Apps は作成時点で ACR からイメージを pull するため、
// このモジュールは compute より先に完了させる(main.bicep の dependsOn)。

@description('ロールを付与するマネージドIDのプリンシパルID')
param principalId string

@description('コンテナレジストリ名')
param registryName string

@description('ストレージアカウント名')
param storageAccountName string

@description('Service Bus 名前空間名')
param serviceBusName string

@description('Document Intelligence アカウント名')
param documentIntelligenceName string

// 組み込みロール定義ID(サブスクリプション横断で固定のGUID)
var roleIds = {
  // イメージの pull のみ(push は az acr build 実行者の権限で行う)
  acrPull: '7f951dda-4ed3-4680-a7ca-43fe172d538d'
  // コンテナ作成を伴うため Reader ではなく Contributor(app/clients/blob.py が
  // テナント別コンテナを実行時に作成する)
  storageBlobDataContributor: 'ba92f5b4-2d11-453d-a403-e96b0029c9fe'
  // API がジョブを投入し、ワーカーが消化する
  serviceBusDataSender: '69a216fc-b8fb-44d8-bc22-1f3c2cd27a39'
  serviceBusDataReceiver: '4f6d3b9b-027b-4f4c-9142-0e5a2a2247e0'
  // Document Intelligence の解析実行
  cognitiveServicesUser: 'a97b65f3-24c7-4388-baec-2e87135dc908'
}

resource registry 'Microsoft.ContainerRegistry/registries@2023-07-01' existing = {
  name: registryName
}

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' existing = {
  name: storageAccountName
}

resource serviceBus 'Microsoft.ServiceBus/namespaces@2024-01-01' existing = {
  name: serviceBusName
}

resource documentIntelligence 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = {
  name: documentIntelligenceName
}

resource acrPull 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: registry
  // 再デプロイで同じ割り当てになるよう、決定的なGUIDを名前にする
  name: guid(registry.id, principalId, roleIds.acrPull)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.acrPull)
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

resource blobContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: storageAccount
  name: guid(storageAccount.id, principalId, roleIds.storageBlobDataContributor)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.storageBlobDataContributor)
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

resource sbSender 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: serviceBus
  name: guid(serviceBus.id, principalId, roleIds.serviceBusDataSender)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.serviceBusDataSender)
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

resource sbReceiver 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: serviceBus
  name: guid(serviceBus.id, principalId, roleIds.serviceBusDataReceiver)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.serviceBusDataReceiver)
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}

resource diUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  scope: documentIntelligence
  name: guid(documentIntelligence.id, principalId, roleIds.cognitiveServicesUser)
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleIds.cognitiveServicesUser)
    principalId: principalId
    principalType: 'ServicePrincipal'
  }
}
