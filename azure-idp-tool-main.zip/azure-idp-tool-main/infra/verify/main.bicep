// ============================================================================
// 社内検証環境(アプリ動作確認用)のオーケストレーション
//
// 目的: README のクイックスタート(WSL上でのローカル実行)と同等の動作確認を
//       Azure 上で行う。顧客データは扱わない前提のため、ネットワーク防御
//       (VNet / Private Endpoint / NSG)は設けない。
//       対応するフェーズは docs/01_design/azure-architecture_v2.md §4.1(初期: 社内開発)。
//
// 方針:
//   - Azureリソース間の認証は Managed Identity に統一する(§4.1 の「認証方式は本番同等」)。
//     ただし PostgreSQL のみ、バックエンドが DATABASE_URL 固定実装のためパスワード認証。
//   - CI/CD は用意しない。Azure CLI + ポータル操作の手動デプロイを前提とする。
//   - デプロイは2段階に分ける(コンテナイメージが ACR に存在しないと
//     Container Apps が作成できないため):
//       1回目: deployApps=false → 基盤リソース(ACR含む)を作成
//              → az acr build でイメージをビルド・push
//       2回目: deployApps=true  → Container Apps(API / ワーカー)を作成
//
// 手順書: docs/03_deployment/verify-deployment-guide.md
// ============================================================================
targetScope = 'resourceGroup'

// ---------------------------------------------------------------------------
// 共通パラメータ
// ---------------------------------------------------------------------------

@description('アプリ名(リソース名の一部に使用)')
param appName string = 'idp'

@description('環境名(リソース名の一部に使用)。検証環境は verify')
param env string = 'verify'

@description('リージョン。既定はリソースグループのリージョン')
param location string = resourceGroup().location

@description('Static Web Apps のリージョン。SWAは対応リージョンが限られるため日本からは eastasia を使う')
@allowed(['eastasia', 'westus2', 'centralus', 'eastus2', 'westeurope'])
param swaLocation string = 'eastasia'

@description('Document Intelligence のリージョン。指定リージョンで API バージョン 2024-11-30 が使えない場合は eastus 等に変更する')
param documentIntelligenceLocation string = location

// ---------------------------------------------------------------------------
// デプロイ制御
// ---------------------------------------------------------------------------

@description('Container Apps(API / ワーカー)をデプロイする。ACRへのイメージ push 後に true にして再デプロイする')
param deployApps bool = false

@description('デプロイするコンテナイメージのタグ(az acr build で付けたタグと揃える)')
param imageTag string = 'v1'

@description('Keycloak(認証基盤)をデプロイする。scripts/init-keycloak-db.sql を流した後に true にする。認証の検証をしない期間は false にして常駐コストを止められる')
param deployKeycloak bool = false

// ---------------------------------------------------------------------------
// Keycloak(認証基盤)
// ---------------------------------------------------------------------------

@description('Keycloak イメージのタグ(infra/verify/keycloak を az acr build で push したタグと揃える)')
param keycloakImageTag string = 'v1'

@description('Keycloak の DB 接続ロール(keycloak_user)のパスワード。scripts/init-keycloak-db.sql で設定する値と揃える。URL予約文字は使わない')
@secure()
param keycloakDbPassword string = ''

@description('Keycloak 初期管理者のユーザ名')
param keycloakAdminUsername string = 'kcadmin'

@description('Keycloak 初期管理者のパスワード。レルム構成後は恒久的な管理者を作ってこのアカウントを無効化する')
@secure()
param keycloakAdminPassword string = ''

@description('アプリが利用するレルム名。issuer URL の組み立てに使う')
param keycloakRealmName string = 'idp'

@description('フロントエンド(SPA)用の Keycloak クライアント ID。SPA が OIDC 認可要求に使う識別子。keycloak/realm-idp.json の clientId と同じ値にすること')
param keycloakClientId string = 'idp-frontend'

@description('APIが検証するJWTの aud。クライアントIDとは別の、API自身を指す識別子。keycloak/realm-idp.json の audience マッパー(included.custom.audience)と同じ値にすること')
param oidcAudience string = 'idp-api'

// ---------------------------------------------------------------------------
// PostgreSQL
// ---------------------------------------------------------------------------

@description('PostgreSQL 管理者ログイン名。マイグレーション・シードを実行する所有者ロールを兼ねる')
param postgresAdminLogin string = 'idpadmin'

@description('PostgreSQL 管理者パスワード。接続URLに埋め込むため @ : / ? # などのURL予約文字は使わない')
@secure()
param postgresAdminPassword string

@description('アプリ接続ロール(app_user)のパスワード。scripts/init-roles.sql で設定する値と揃える。URL予約文字は使わない')
@secure()
param appUserPassword string

@description('PostgreSQL に接続するローカルPCのグローバルIP。マイグレーション・シードを WSL から流すために許可する。空文字なら許可しない')
param clientIpAddress string = ''

// ---------------------------------------------------------------------------
// アプリケーション設定(backend/.env.example に対応)
// ---------------------------------------------------------------------------

@description('AUTH_MODE=local で使う開発テナントID。scripts/seed.py が作成するテナントと同一にすること')
param localTenantId string = '00000000-0000-0000-0000-000000000001'

@description('AUTH_MODE=local で使う開発ユーザID')
param localUserId string = '00000000-0000-0000-0000-000000000002'

@description('Document Intelligence のキー認証を無効化する(Managed Identity のみ許可)')
param disableDocumentIntelligenceLocalAuth bool = true

// ---------------------------------------------------------------------------
// リソース名
// 命名はCloud Adoption Frameworkの略語規則(coding-standards.md)に従う。
// グローバル一意が必要なもの(ACR / Storage / PostgreSQL / Service Bus / DI)は
// リソースグループIDから導いたサフィックスを付ける。
// ---------------------------------------------------------------------------

var baseName = '${appName}-${env}'
var flatName = replace(baseName, '-', '')
var uniq = uniqueString(resourceGroup().id)

var names = {
  identity: 'id-${baseName}'
  logAnalytics: 'log-${baseName}'
  registry: 'cr${flatName}${uniq}'
  storage: 'st${flatName}${take(uniq, 8)}'
  postgres: 'psql-${baseName}-${uniq}'
  serviceBus: 'sb-${baseName}-${uniq}'
  documentIntelligence: 'di-${baseName}-${uniq}'
  containerAppsEnv: 'cae-${baseName}'
  apiApp: 'ca-${baseName}-api'
  workerApp: 'ca-${baseName}-worker'
  keycloakApp: 'ca-${baseName}-keycloak'
  dbInitJob: 'caj-${baseName}-dbinit'
  staticWebApp: 'stapp-${baseName}'
  database: 'idp'
  // Keycloak のストア。アプリDBと同一サーバ上の別データベースにする
  keycloakDatabase: 'keycloak'
}

// Keycloak の DB 接続ロール。scripts/init-keycloak-db.sql が作成する名前と揃える
var keycloakDbRole = 'keycloak_user'

var queueInteractive = 'interactive'
var queueBatch = 'batch'

// ---------------------------------------------------------------------------
// ユーザ割り当てマネージドID
// API・ワーカーの両方に割り当て、ACR pull / Blob / Service Bus / DI への
// アクセスをこのIDに集約する(システム割り当てだとアプリ作成前にRBACを
// 付与できず、初回起動時のイメージpullに失敗するためユーザ割り当てを使う)。
// ---------------------------------------------------------------------------

resource appIdentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: names.identity
  location: location
}

// ---------------------------------------------------------------------------
// モジュール
// ---------------------------------------------------------------------------

module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: {
    logAnalyticsName: names.logAnalytics
    location: location
  }
}

module registry 'modules/registry.bicep' = {
  name: 'registry'
  params: {
    registryName: names.registry
    location: location
  }
}

module data 'modules/data.bicep' = {
  name: 'data'
  params: {
    location: location
    storageAccountName: names.storage
    postgresName: names.postgres
    postgresAdminLogin: postgresAdminLogin
    postgresAdminPassword: postgresAdminPassword
    databaseName: names.database
    keycloakDatabaseName: names.keycloakDatabase
    clientIpAddress: clientIpAddress
    serviceBusName: names.serviceBus
    queueNames: [queueInteractive, queueBatch]
  }
}

module ai 'modules/ai.bicep' = {
  name: 'ai'
  params: {
    documentIntelligenceName: names.documentIntelligence
    location: documentIntelligenceLocation
    disableLocalAuth: disableDocumentIntelligenceLocalAuth
  }
}

// Container Apps の作成前にロール付与を完了させる必要があるため、
// compute より前に実行し dependsOn で順序を固定する。
module rbac 'modules/rbac.bicep' = {
  name: 'rbac'
  params: {
    principalId: appIdentity.properties.principalId
    registryName: names.registry
    storageAccountName: names.storage
    serviceBusName: names.serviceBus
    documentIntelligenceName: names.documentIntelligence
  }
  dependsOn: [
    registry
    data
    ai
  ]
}

// フロントエンド(SWA)は SHARE_BASE_URL の組み立てに既定ホスト名が必要なため
// compute より先に作成する。
module frontend 'modules/frontend.bicep' = {
  name: 'frontend'
  params: {
    staticWebAppName: names.staticWebApp
    location: swaLocation
  }
}

// Container Apps 環境。API・ワーカー・Keycloak が同居する。
//
// 環境を独立モジュールにしているのは、既定ドメインが分かれば各アプリの FQDN が
// <アプリ名>.<既定ドメイン> で確定するため。これにより Keycloak の公開URLを
// アプリ作成前に組み立てられ、API・ワーカーへ OIDC_ISSUER として渡せる
// (環境が compute の中にあると compute → keycloak → compute の循環になる)。
module containerAppsEnv 'modules/container-apps-env.bicep' = {
  name: 'containerAppsEnv'
  params: {
    location: location
    containerAppsEnvName: names.containerAppsEnv
    logAnalyticsName: monitoring.outputs.name
  }
}

// Keycloak の公開URLと issuer URL。実際に Keycloak をデプロイするかに関わらず
// 値は確定する(deployKeycloak=false のときは向き先が存在しないだけ)。
var keycloakUrl = 'https://${names.keycloakApp}.${containerAppsEnv.outputs.defaultDomain}'
var keycloakIssuer = '${keycloakUrl}/realms/${keycloakRealmName}'

// アプリのイメージと同じ ACR に置く(infra/verify/keycloak/Dockerfile)
var keycloakContainerImage = '${registry.outputs.loginServer}/idp-keycloak:${keycloakImageTag}'

module compute 'modules/compute.bicep' = {
  name: 'compute'
  params: {
    location: location
    containerAppsEnvId: containerAppsEnv.outputs.id
    apiAppName: names.apiApp
    workerAppName: names.workerApp
    dbInitJobName: names.dbInitJob
    identityResourceId: appIdentity.id
    identityClientId: appIdentity.properties.clientId
    registryLoginServer: registry.outputs.loginServer
    deployApps: deployApps
    imageTag: imageTag
    // アプリ設定
    databaseUrl: 'postgresql+asyncpg://app_user:${appUserPassword}@${data.outputs.postgresFqdn}:5432/${names.database}?ssl=require'
    // 所有者ロール。DB初期化ジョブ専用(API・ワーカーには渡さない)
    migrationDatabaseUrl: 'postgresql+asyncpg://${postgresAdminLogin}:${postgresAdminPassword}@${data.outputs.postgresFqdn}:5432/${names.database}?ssl=require'
    blobAccountUrl: data.outputs.blobEndpoint
    serviceBusNamespaceFqdn: data.outputs.serviceBusFqdn
    queueInteractive: queueInteractive
    queueBatch: queueBatch
    documentIntelligenceEndpoint: ai.outputs.endpoint
    localTenantId: localTenantId
    localUserId: localUserId
    shareBaseUrl: 'https://${frontend.outputs.defaultHostname}/share'
    // AUTH_MODE=local の間は参照されない。バックエンドの Keycloak 認証を
    // 実装したら AUTH_MODE を切り替えるだけで効くように先に渡しておく
    oidcIssuer: keycloakIssuer
    oidcAudience: oidcAudience
  }
  dependsOn: [
    rbac
  ]
}

module keycloak 'modules/keycloak.bicep' = {
  name: 'keycloak'
  params: {
    location: location
    keycloakAppName: names.keycloakApp
    containerAppsEnvId: containerAppsEnv.outputs.id
    keycloakBaseUrl: keycloakUrl
    keycloakImage: keycloakContainerImage
    identityResourceId: appIdentity.id
    registryLoginServer: registry.outputs.loginServer
    postgresFqdn: data.outputs.postgresFqdn
    keycloakDatabaseName: names.keycloakDatabase
    keycloakDbUser: keycloakDbRole
    keycloakDbPassword: keycloakDbPassword
    keycloakAdminUsername: keycloakAdminUsername
    keycloakAdminPassword: keycloakAdminPassword
    deployKeycloak: deployKeycloak
  }
  // ACR pull のロール付与を先に完了させる(compute と同じ理由)
  dependsOn: [
    rbac
  ]
}

// ---------------------------------------------------------------------------
// 出力(手順書のコマンドで使う値)
// ---------------------------------------------------------------------------

output registryName string = names.registry
output registryLoginServer string = registry.outputs.loginServer
output storageAccountName string = names.storage
output postgresFqdn string = data.outputs.postgresFqdn
output postgresAdminUser string = postgresAdminLogin
output databaseName string = names.database
output serviceBusNamespace string = data.outputs.serviceBusFqdn
output documentIntelligenceEndpoint string = ai.outputs.endpoint
output staticWebAppName string = names.staticWebApp
output staticWebAppHostname string = frontend.outputs.defaultHostname
output identityClientId string = appIdentity.properties.clientId

// Container Apps は deployApps=true のときだけ作成されるため、未作成時は空文字になる
output apiAppName string = deployApps ? names.apiApp : ''
output apiAppResourceId string = deployApps ? compute.outputs.apiAppResourceId : ''
output apiAppFqdn string = deployApps ? compute.outputs.apiAppFqdn : ''
output workerAppName string = deployApps ? names.workerApp : ''
output dbInitJobName string = deployApps ? names.dbInitJob : ''

// Keycloak(deployKeycloak=true のときだけ作成される)。
// FQDN は環境の既定ドメインから導出するため、未デプロイでも値は確定している
output keycloakDatabaseName string = names.keycloakDatabase
output keycloakDbUser string = keycloakDbRole
output keycloakAppName string = deployKeycloak ? names.keycloakApp : ''
output keycloakBaseUrl string = deployKeycloak ? keycloakUrl : ''
// バックエンドの OIDC_ISSUER に設定する値
output keycloakIssuerUrl string = deployKeycloak ? keycloakIssuer : ''
