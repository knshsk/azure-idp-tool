# デプロイドキュメント

Azure へのデプロイ手順。**CI/CD は未整備のため、いずれも Azure CLI とポータル操作による手動デプロイ**を前提とする。

## ドキュメント一覧

| ドキュメント | 内容 |
|---|---|
| [verify-deployment-guide.md](verify-deployment-guide.md) | **社内検証環境のデプロイ手順書**。READMEのクイックスタートと同等の動作確認をAzure上で行う |

## 対応する IaC

| 環境 | テンプレート | 位置づけ |
|---|---|---|
| 社内検証 | [infra/verify/](../../infra/verify/) | [azure-architecture_v2.md](../01_design/azure-architecture_v2.md) §4.1「初期: 社内開発」相当。顧客データを扱わない前提でネットワーク防御を省く |
| PoC / 本番 | [infra/](../../infra/)(スケルトン) | 同 §4.2 / §4.3。VNet・Private Endpoint・Application Gateway + WAF を `networkEnabled` / `appGatewayEnabled` パラメータで段階的に有効化する設計 |

## 前提

- 検証環境は **URL を知っていれば誰でもアクセスできる**状態(`AUTH_MODE=local`・IP制限なし)。社外に共有しないこと
- **顧客データを1件でも入れる前に** [azure-architecture_v2.md §4.4](../01_design/azure-architecture_v2.md#44-フェーズ移行のゲート条件) のゲート条件を満たすこと
