# 社内検証環境 デプロイ手順書(Azure)

README のクイックスタート([WSL上でのローカル実行](../../README.md#クイックスタートwsl内))と**同等の動作確認を Azure 上で行う**ための手順。
IaC は [infra/verify/](../../infra/verify/)、構成の説明は [infra/verify/README.md](../../infra/verify/README.md) を参照。

- **所要時間目安**: 1〜1.5時間(PostgreSQL の作成に10分前後、Container Apps 環境に5分前後かかる)
- **前提**: 顧客データは投入しない。ネットワーク防御(VNet / Private Endpoint / WAF)は設けない構成
- **作業場所**: すべて WSL(Ubuntu)内。コマンドは上から順に実行する

> CI/CD は使わない。Azure CLI とポータル操作による手動デプロイのみで完結する手順にしている。

## 目次

1. [全体像](#1-全体像)
2. [事前準備](#2-事前準備)
3. [環境変数の準備](#3-環境変数の準備)
4. [基盤リソースのデプロイ(1回目)](#4-基盤リソースのデプロイ1回目)
5. [コンテナイメージのビルド(ACR)](#5-コンテナイメージのビルドacr)
6. [Container Apps と DB初期化ジョブのデプロイ(2回目)](#6-container-apps-と-db初期化ジョブのデプロイ2回目)
7. [データベースの初期化](#7-データベースの初期化)
8. [フロントエンドのビルドとデプロイ](#8-フロントエンドのビルドとデプロイ)
9. [Static Web Apps と API のリンク](#9-static-web-apps-と-api-のリンク)
10. [動作確認(スモークテスト)](#10-動作確認スモークテスト)
11. [運用コマンド集](#11-運用コマンド集)
12. [後片付け](#12-後片付け)
- [付録A: 環境変数対応表(ローカル ↔ Azure)](#付録a-環境変数対応表ローカル--azure)
- [付録B: 検証環境で割り切っている点](#付録b-検証環境で割り切っている点)
- [付録C: コスト目安](#付録c-コスト目安)
- [付録D: トラブルシューティング](#付録d-トラブルシューティング)
- [付録E: Keycloak(認証基盤)のデプロイ](#付録e-keycloak認証基盤のデプロイ)

---

## 1. 全体像

### 構成

```
[ブラウザ]
    |
    v
Static Web Apps (Standard)  ── 静的コンテンツ配信
    |  /api/* を APIリンクでプロキシ
    v
Container Apps (API / FastAPI)  ──> PostgreSQL Flexible Server (B1ms)
    |                            └─> Blob Storage
    | ジョブ投入                  
    v
Service Bus (interactive / batch)
    |
    v
Container Apps (ワーカー) ──> Document Intelligence (S0)
    |                     └─> Blob Storage / PostgreSQL
    v
Log Analytics(API・ワーカー・DB初期化ジョブのログ)

Container Apps Job(DB初期化) ── マイグレーション+シードをAzure内から実行
Container Registry ── API・ワーカー・ジョブ共通のイメージを保管(ビルドもここで実施)
ユーザ割り当てマネージドID ── ACR / Blob / Service Bus / DI へのアクセス
```

ローカル開発との対応:

| ローカル(docker compose) | Azure(本手順) |
|---|---|
| PostgreSQL コンテナ | PostgreSQL Flexible Server (B1ms) |
| Azurite | Storage Account(Blob) |
| Service Bus エミュレータ + SQL Server | Service Bus (Standard) |
| 共有の開発用 Document Intelligence | 検証環境専用の Document Intelligence (S0) |
| `uvicorn app.main:app` | Container Apps(API) |
| `python -m app.worker.main` | Container Apps(ワーカー) |
| `alembic upgrade head` / `seed.py` | Container Apps Job(DB初期化・マニュアル実行) |
| Vite dev サーバ(`/api` を proxy) | Static Web Apps(`/api` を APIリンクでプロキシ) |

### 作業の流れ

デプロイは**2段階**に分かれる。コンテナイメージが ACR に存在しないと Container Apps を作成できないため。

```
§4 基盤リソース(DEPLOY_APPS=false)
      ↓
§5 az acr build でイメージをビルド・push
      ↓
§6 Container Apps + DB初期化ジョブ(DEPLOY_APPS=true)
      ↓
§7 DB初期化(ロール分離 → ジョブ実行でマイグレーション+シード)
      ↓
§8 フロントエンドを SWA へデプロイ
      ↓
§9 SWA と API をリンク
      ↓
§10 スモークテスト
```

認証基盤(Keycloak)は**この流れには含まれない**。アプリは `AUTH_MODE=local` で動くため、
Keycloak が無くても §1〜§10 は完走できる。認証フローを検証したくなった時点で
[付録E](#付録e-keycloak認証基盤のデプロイ)を実施する(常駐コストが増えるため既定では立てない)。

---

## 2. 事前準備

### 2.1 必要なツール(WSL内)

| ツール | 確認コマンド | 補足 |
|---|---|---|
| Azure CLI | `az version` | 2.53 以降。**venv版を使う(§2.2)**。apt / 公式インストールスクリプト版は社内ネットワークで認証エンドポイントに接続できない |
| Bicep CLI | `az bicep version` | 0.22 以降(`readEnvironmentVariable()` を使うため)。無ければ `az bicep install` / 古ければ `az bicep upgrade` |
| PostgreSQL クライアント | `psql --version` | 無ければ `sudo apt install -y postgresql-client` |
| Node.js / npm | `node -v` | フロントエンドのビルドと SWA CLI に使う |
| uv | `uv --version` | マイグレーション・シードの実行に使う |

Docker は不要(イメージのビルドは ACR 側で実行するため)。

> **社内プロキシ配下の注意**: `az` / `npm` / `uv` はいずれもプロキシ設定が必要。
> [setup-guide.md §4](../02_development/setup-guide.md#4-プロキシ設定最重要) の設定が済んでいることが前提。
> なお `az acr build` の**ビルド自体は Azure 上で走る**ため、ベースイメージ(`python:3.14-slim`、ghcr.io の `uv`)の取得はプロキシの影響を受けない。

### 2.2 Azure CLI(venv版)のセットアップ

**本開発では Azure CLI を venv 版に統一する。** apt / 公式インストールスクリプトで入れた Azure CLI は**社内ネットワークで使えない**ため。

理由は次のとおり。社内のインスペクション装置は `login.microsoftonline.com`(Entra ID の認証エンドポイント)の TLS を復号しており、その際に提示する暗号スイートが **TLS 1.2 / `AES256-GCM-SHA384`(静的RSA鍵交換・前方秘匿性なし)のみ**になっている。apt 版 Azure CLI は同梱の Python がこの暗号スイートを既定で除外しているため、共通の暗号スイートが存在せず TLS ハンドシェイクが成立しない。システムの Python はこれを許容するので、システム Python 上の venv に `pip` で入れた Azure CLI であれば接続できる。

> この症状は**アクセストークンの有効期限が切れるまで表面化しない**(それまでは `management.azure.com` としか通信せず、そちらは復号対象外)。デプロイの途中で突然 `SSLV3_ALERT_HANDSHAKE_FAILURE` が出るのはこのため。切り分け手順は付録D。

```bash
# 前提: システム Python が対象の暗号スイートを許容していること(True であること)
python3 -c "import ssl; c=ssl.create_default_context(); print('AES256-GCM-SHA384' in [x['name'] for x in c.get_ciphers()])"
```

```bash
sudo apt update
sudo apt install -y python3-venv python3-dev build-essential libffi-dev libssl-dev

python3 -m venv ~/.venvs/azure-cli
# PyPI も復号対象のため、pip にも社内CAを明示する(pip は独自の certifi を使い、システムストアを見ない)
~/.venvs/azure-cli/bin/pip install --upgrade pip --cert /etc/ssl/certs/ca-certificates.crt
~/.venvs/azure-cli/bin/pip install azure-cli --cert /etc/ssl/certs/ca-certificates.crt
```

PATH と CA バンドルを通す。恒久化する場合は `~/.bashrc` に入れる。

```bash
export PATH="$HOME/.venvs/azure-cli/bin:$PATH"
# ハンドシェイク成立後の証明書検証で社内CAが必要になる(venv の certifi にも入っていない)
export REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
hash -r
```

確認する。

```bash
which az                                  # ~/.venvs/azure-cli/bin/az であること
~/.venvs/azure-cli/bin/python -c "import ssl; c=ssl.create_default_context(); print('AES256-GCM-SHA384' in [x['name'] for x in c.get_ciphers()])"
az version
```

`~/.azure` は apt 版と共有されるため、**ログイン状態と `az bicep install` 済みの Bicep バイナリはそのまま引き継がれる**。apt 版はアンインストールせず残しておいてよい(PATH の優先順で切り替わる)。

### 2.3 必要な権限

デプロイ実行者には、対象サブスクリプション(またはリソースグループ)に対して以下が必要:

- **共同作成者(Contributor)** — リソースの作成
- **ユーザー アクセス管理者(User Access Administrator)** — マネージドIDへのロール割り当て(`infra/verify/modules/rbac.bicep`)

どちらも無い場合は **所有者(Owner)** で実行する。Contributor だけだとロール割り当てで `AuthorizationFailed` になる。

### 2.4 サインインとリソースプロバイダの登録

```bash
# WSL からはブラウザ起動が不安定なため、デバイスコード方式が確実
az login --use-device-code
az account set --subscription "<サブスクリプションID>"

# 未登録のプロバイダがあるとデプロイが失敗するため先に登録しておく(登録済みなら即完了)
for ns in Microsoft.App Microsoft.ContainerRegistry Microsoft.DBforPostgreSQL \
          Microsoft.ServiceBus Microsoft.CognitiveServices Microsoft.Storage \
          Microsoft.OperationalInsights Microsoft.Web Microsoft.ManagedIdentity; do
  az provider register --namespace "$ns"
done
```

登録状況の確認:

```bash
az provider show --namespace Microsoft.App --query registrationState -o tsv
```

---

## 3. 環境変数の準備

`infra/verify/main.bicepparam` は機微値をファイルに持たず、`readEnvironmentVariable()` で環境変数から読む。
以下を**このあとの作業で使うターミナル**にエクスポートする(ターミナルを開き直したら再実行する)。

```bash
cd ~/dev/azure-idp-tool

# --- リソースグループ ---
export RG=rg-idp-verify
export LOCATION=japaneast
export DEPLOYMENT_NAME=idp-verify

# --- パスワード ---
# 接続URLに埋め込むため、URL予約文字(@ : / ? # & %)を含まない英数字にすること
export PG_ADMIN_PASSWORD="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 24)"
export APP_USER_PASSWORD="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 24)"

# --- PostgreSQL に接続するローカルPCのグローバルIP(任意) ---
# ローカルPCから psql で直接接続したい場合のみ設定する。DB初期化は Container Apps Job
# (Azure内)から実行するため、社内ネットワークからの直接接続ができなくても支障はない。
# 空文字ならファイアウォール規則を作らない。
#
# 設定する場合、--noproxy が必須: プロキシ経由で取得すると「プロキシの出口IP」が返るが、
# psql はプロキシを使わず直接出ていくため送信元IPが食い違い、接続がドロップされる
export CLIENT_IP="$(curl --noproxy '*' -s --max-time 10 https://ifconfig.me)"

# --- デプロイ制御(1回目は false) ---
export DEPLOY_APPS=false
export IMAGE_TAG=v1
```

生成したパスワードは**必ず控えておく**(再デプロイ時に同じ値が必要。値が変わると `app_user` のパスワードと Container Apps の `DATABASE_URL` がずれる)。
Azure PostgreSQL のパスワード要件(英大文字・英小文字・数字・記号のうち3種以上)を満たすため、生成結果に**英大文字・英小文字・数字がすべて含まれていること**を確認する(含まれていなければ生成し直す)。

```bash
echo "PG_ADMIN_PASSWORD=$PG_ADMIN_PASSWORD"
echo "APP_USER_PASSWORD=$APP_USER_PASSWORD"
echo "CLIENT_IP=$CLIENT_IP"
```

> **リポジトリにコミットしないこと**。`.env` 相当の扱いとし、チームで共有する場合は別途安全な経路で渡す。

---

## 4. 基盤リソースのデプロイ(1回目)

### 4.1 リソースグループの作成

```bash
az group create --name "$RG" --location "$LOCATION"
```

### 4.2 what-if で差分を確認

```bash
az deployment group what-if \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

`main.bicepparam` の `using 'main.bicep'` からテンプレートが解決されるため、`--template-file` は指定しない。

### 4.3 デプロイ

```bash
az deployment group create \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

PostgreSQL Flexible Server と Container Apps 環境の作成に時間がかかるため、完了まで **10〜15分**程度かかる。

### 4.4 出力値の取り出し

以降の手順で使う値を変数に取り込む。ここで定義する `outputs` 関数は §7 以降でも使うため、ターミナルを開き直したらこのブロックを再実行する。

```bash
outputs() {
  az deployment group show --resource-group "$RG" --name "$DEPLOYMENT_NAME" \
    --query "properties.outputs.$1.value" -o tsv
}

export ACR_NAME="$(outputs registryName)"
export ACR_LOGIN_SERVER="$(outputs registryLoginServer)"
export PG_FQDN="$(outputs postgresFqdn)"
export PG_ADMIN_LOGIN="$(outputs postgresAdminUser)"
export DB_NAME="$(outputs databaseName)"
export SWA_NAME="$(outputs staticWebAppName)"
export SWA_HOST="$(outputs staticWebAppHostname)"
export DI_ENDPOINT="$(outputs documentIntelligenceEndpoint)"
export STORAGE_NAME="$(outputs storageAccountName)"

env | grep -E '^(ACR_|PG_FQDN|SWA_|DI_ENDPOINT|STORAGE_)' | sort
```

---

## 5. コンテナイメージのビルド(ACR)

API とワーカーは**同一イメージ**で、起動コマンドのみ切り替える([backend/Dockerfile](../../backend/Dockerfile))。

```bash
cd ~/dev/azure-idp-tool/backend

az acr build \
  --registry "$ACR_NAME" \
  --image "idp-backend:${IMAGE_TAG}" \
  .
```

- ビルドは Azure 上(ACR Tasks)で実行される。ローカルに Docker は不要
- `backend/.dockerignore` で `.venv` などをビルドコンテキストから除外している。除外が効いていないとアップロードに時間がかかる

push されたことを確認:

```bash
az acr repository show-tags --name "$ACR_NAME" --repository idp-backend -o table
```

```bash
cd ~/dev/azure-idp-tool
```

---

## 6. Container Apps と DB初期化ジョブのデプロイ(2回目)

イメージが ACR に入ったので、`DEPLOY_APPS=true` にして同じテンプレートを再デプロイする。API・ワーカーに加えて、**DB初期化ジョブ(Container Apps Job)**もここで作成される。

```bash
export DEPLOY_APPS=true

az deployment group create \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

出力を取り込む:

```bash
export API_FQDN="$(outputs apiAppFqdn)"
export API_APP_ID="$(outputs apiAppResourceId)"
export API_APP_NAME="$(outputs apiAppName)"
export WORKER_APP_NAME="$(outputs workerAppName)"
export DB_INIT_JOB_NAME="$(outputs dbInitJobName)"

echo "API: https://$API_FQDN"
```

> この時点ではまだテーブルが存在しないため、**API とワーカーは DB アクセスでエラーを出す**。これは想定どおりで、§7 の初期化後に自然に復旧する(接続はリクエストごとに張られるため、再起動は不要)。

---

## 7. データベースの初期化

ローカルの `docker compose` では `docker/postgres-init/01-roles.sql` が初回起動時に自動実行されるが、Azure ではこれを手動で流す。

**マイグレーションとシードは Container Apps Job(Azure 内)から実行する。** ローカルPCから PostgreSQL への直接接続に依存しないため、社内ネットワークの制約を受けない(制約の詳細は付録D)。

> §4 のデプロイでは Keycloak 用のデータベース(`keycloak`)も作られるが、**本節では触らない**。Keycloak のロール作成は [付録E](#付録e-keycloak認証基盤のデプロイ) で扱う。アプリDB(`idp`)とは権限境界を分けるため、`app_user` と `keycloak_user` を相互に混ぜないこと。

### 7.1 ロール分離(初回のみ)

RLS は `FORCE ROW LEVEL SECURITY` で所有者にも効くため、**マイグレーション用の所有者ロール**と**アプリ接続ロール**を分ける必要がある。この作業だけは `psql` のメタコマンドを使うため、**Azure Cloud Shell** から実行する。

1. Azure ポータル右上の **Cloud Shell(bash)** を開く
2. ツールバーの **「ファイルのアップロード/ダウンロード」** から `infra/verify/scripts/init-roles.sql` を**1ファイルだけ**アップロードする
3. 以下を実行する

```bash
RG=rg-idp-verify
PG_FQDN=$(az postgres flexible-server list -g "$RG" --query "[0].fullyQualifiedDomainName" -o tsv)
PG_ADMIN_LOGIN=idpadmin
DB_NAME=idp

read -rsp "PG_ADMIN_PASSWORD: " PG_ADMIN_PASSWORD; echo
read -rsp "APP_USER_PASSWORD: " APP_USER_PASSWORD; echo
export PGPASSWORD="$PG_ADMIN_PASSWORD"

psql "host=$PG_FQDN port=5432 dbname=$DB_NAME user=$PG_ADMIN_LOGIN sslmode=require" \
  -v app_user_password="$APP_USER_PASSWORD" \
  -v pg_admin_login="$PG_ADMIN_LOGIN" \
  -f init-roles.sql
```

最後に出るロール属性の一覧では、**`app_user` の行だけを確認する**。`rolbypassrls` / `rolsuper` がいずれも `f`(false)であること。`t` になっていると RLS が素通りし、テナント分離の検証にならない。

```
 rolname  | rolbypassrls | rolsuper
----------+--------------+----------
 idpadmin | t            | f          ← これでよい(後述)
 app_user | f            | f          ← ここが f / f であることが重要
```

**管理者ロール(`idpadmin`)の `rolbypassrls` が `t` なのは正常**で、変更してはいけない。Azure PostgreSQL フレキシブル サーバーの管理者ロールは既定で `BYPASSRLS` を持つうえ、`seed.py` は**テナントコンテキストを設定せずに** `tenants` へ INSERT する(テナント作成はテナント外の運用操作という設計)ため、この属性が無いと 7.2 のシードが失敗する。ローカル開発の `POSTGRES_USER: app` がスーパーユーザである状態と等価。

> マイグレーション 0001 のコメントにある「FORCE により所有者の素通りを防止」は、`BYPASSRLS` 属性が `FORCE` より優先されるため Azure の管理者ロールには効かない。テナント分離の実質的な担保は「**アプリが `app_user` でしか接続しないこと**」であり、所有者ロールの接続文字列を持つのは DB初期化ジョブだけという構成でそれを維持している。

Cloud Shell の送信元は Azure なので、テンプレートが作る `AllowAllAzureServices` 規則でそのまま通る(`AllowClientIp` は不要)。

> **ローカルの WSL から直接実行できる環境なら**、リポジトリのルートで `-f infra/verify/scripts/init-roles.sql` を指定して同じコマンドを流してもよい。その場合は §3 の `CLIENT_IP` をファイアウォールに登録しておく必要がある。
>
> **順序**: `ALTER DEFAULT PRIVILEGES` は「これから作られるテーブル」に効くため、7.2 のマイグレーションより**先**に実行する。本スクリプトは冪等で、後から流しても `GRANT ... ON ALL TABLES` が既存テーブルを拾う。

### 7.2 マイグレーションとシード(ジョブ実行)

DB初期化ジョブは API・ワーカーと同一イメージで、`alembic upgrade head && python scripts/seed.py` を実行する。

```bash
az containerapp job start --name "$DB_INIT_JOB_NAME" --resource-group "$RG"
```

実行状況を確認する(完了まで1〜2分):

```bash
az containerapp job execution list --name "$DB_INIT_JOB_NAME" --resource-group "$RG" \
  --query "[0].{name:name, status:properties.status, start:properties.startTime}" -o json
```

`status` が `Succeeded` になれば完了。`Failed` ならログを見る:

```bash
az containerapp job logs show --name "$DB_INIT_JOB_NAME" --resource-group "$RG" \
  --container db-init --tail 100
```

`az containerapp job logs show` が使えない場合は Log Analytics から拾う(取り込みまで数分のラグがある):

```bash
az monitor log-analytics query \
  --workspace "$(az monitor log-analytics workspace show -g "$RG" -n log-idp-verify --query customerId -o tsv)" \
  --analytics-query "ContainerAppConsoleLogs_CL | where ContainerGroupName_s startswith '$DB_INIT_JOB_NAME' | order by TimeGenerated asc | project TimeGenerated, Log_s" \
  -o table
```

> **このジョブは何度実行してもよい。** `alembic upgrade head` も `seed.py` も冪等なため、マイグレーションを追加したら再度 `az containerapp job start` を叩くだけでよい(§11)。
>
> ジョブが投入する `LOCAL_TENANT_ID` / `LOCAL_USER_ID` は Bicep から API・ワーカーと同じ値が渡るため、ローカル実行時のような不一致は起きない。

### 7.3 アプリの疎通確認(SWAリンク前に必ず実施)

**§9 で SWA とリンクすると、Container App に「Static Web Apps 経由のみ許可」の認証設定が入り、この URL への直接アクセスができなくなる。** ヘルスチェックはリンク前に済ませておく。

```bash
curl -i "https://$API_FQDN/healthz"
# => HTTP/2 200, {"status":"ok"}

curl -s "https://$API_FQDN/api/v1/document-types" | head -c 400
# => シードした「見積書」が返る(= API から DB まで到達できている)
```

ワーカーの起動確認:

```bash
az containerapp logs show --name "$WORKER_APP_NAME" --resource-group "$RG" --tail 50
# => "worker started" / "maintenance loop started" が出ていればOK
```

---

## 8. フロントエンドのビルドとデプロイ

### 8.1 ビルド

API のベースURLは `/api` のまま(SWA のAPIリンクが同じパスでプロキシするため、ローカルの Vite proxy と同じ扱いになる)。

```bash
cd ~/dev/azure-idp-tool/frontend

# .env は作らなくてよい(既定値 VITE_API_BASE_URL=/api が使われる)
npm ci
npm run build
```

`frontend/public/staticwebapp.config.json` がビルド成果物(`dist/`)に含まれる。これは Vue Router の history モードのための設定で、**これが無いと `/documents/xxx` や `/share/xxx` の直リンク・リロードが 404 になる**。

### 8.2 デプロイトークンの取得

```bash
cd ~/dev/azure-idp-tool

export SWA_TOKEN="$(az staticwebapp secrets list \
  --name "$SWA_NAME" --resource-group "$RG" \
  --query "properties.apiKey" -o tsv)"
```

### 8.3 SWA へアップロード

```bash
cd ~/dev/azure-idp-tool/frontend

npx --yes @azure/static-web-apps-cli deploy ./dist \
  --deployment-token "$SWA_TOKEN" \
  --env production
```

完了すると `https://<SWA_HOST>` で画面が開ける(この時点では API 未リンクのためデータ取得は失敗する)。

```bash
cd ~/dev/azure-idp-tool
echo "https://$SWA_HOST"
```

---

## 9. Static Web Apps と API のリンク

SWA の **API リンク(バックエンド連携)** で、`/api` で始まるリクエストを Container Apps(API)へ**同じパスのまま**プロキシする。

### 9.1 CLI でリンクする

```bash
# 事前検証(リンク可能かをチェックするだけで、変更は加えない)
az staticwebapp backends validate \
  --name "$SWA_NAME" \
  --resource-group "$RG" \
  --backend-resource-id "$API_APP_ID" \
  --backend-region "$LOCATION"
```

```bash
az staticwebapp backends link \
  --name "$SWA_NAME" \
  --resource-group "$RG" \
  --backend-resource-id "$API_APP_ID" \
  --backend-region "$LOCATION"
```

1つの Static Web App にリンクできるバックエンドは**1つだけ**。SWA を作り直した場合など、同じ Container App を別の SWA にリンクし直すときは、先に古い認証設定を解除する必要がある(§9.3)。

### 9.2 ポータルでリンクする場合

1. Azure ポータルで Static Web App(`stapp-idp-verify`)を開く
2. 左メニューの **API** を選択
3. `Production` 環境の行で **リンク** を選択
4. **バックエンドリソースの種類**: `Container App`
5. サブスクリプションとリソース名(`ca-idp-verify-api`)を選び **リンク**

### 9.3 リンクの副作用(重要)

リンクすると Container App 側に `Azure Static Web Apps (Linked)` という ID プロバイダが自動構成され、**SWA 経由のトラフィックしか受け付けなくなる**。

- `https://<API_FQDN>/healthz` への直接アクセスは 401/リダイレクトになる(これは正常な挙動)
- リンク解除時に ID プロバイダも消したい場合は `--remove-backend-auth` を付ける。付けないと認証設定だけが残り、**別の SWA にリンクし直せなくなる**

```bash
# リンク解除(Container App 側の認証設定も併せて削除する)
az staticwebapp backends unlink \
  --name "$SWA_NAME" --resource-group "$RG" --remove-backend-auth
```

ポータルから消す場合は Container App の **認証** 画面で `Azure Static Web Apps (Linked)` の ID プロバイダを削除する。

### 9.4 確認

```bash
az staticwebapp backends show --name "$SWA_NAME" --resource-group "$RG" -o table

curl -s "https://$SWA_HOST/api/v1/document-types" | head -c 400
# => 「見積書」が返れば、SWA → Container Apps のプロキシが成立している
```

---

## 10. 動作確認(スモークテスト)

[setup-guide.md §10](../02_development/setup-guide.md#10-動作確認スモークテスト) と同じ内容を Azure 上で行う。

ブラウザで `https://<SWA_HOST>` を開く(`AUTH_MODE=local` のためログイン画面はスキップされる)。

| # | 手順 | 期待結果 | 確認できること |
|---|---|---|---|
| 1 | メイン操作画面が表示される | 書類一覧・アップロードのモーダルが出る | SWA 配信 + `/api` プロキシ + PostgreSQL 読み取り |
| 2 | `backend/tests/fixtures/mitsumori-sample.pdf` をアップロード(書類種別: 見積書) | 状態が「解析中」になる | Blob 書き込み(MI認証)+ Service Bus 投入(MI認証) |
| 3 | しばらく待つ | 状態が「解析済」に変わる | ワーカーのキュー消化 + Document Intelligence 解析(MI認証)+ ページPNG生成 |
| 4 | ドキュメントを開く | ページ画像とオーバレイが表示される | Blob 読み取り + 座標変換 |
| 5 | 転記項目(取引日付・取引先名・合計金額)に候補値が入っている | 値が表示される | Query Fields の解析結果取り込み |
| 6 | 値を編集して確定する | 確定状態になる | PostgreSQL 書き込み(RLS 下) |
| 7 | 共有URLを発行し、シークレットウィンドウで開く | 共有ビューが表示される | `SHARE_BASE_URL` が SWA を指していること + 認証なし経路 |
| 8 | 管理画面 → 利用状況 | グラフが表示される | 管理系API(`tenant_admin` ロール) |

**ここまで通れば検証環境の構築完了。**

3 で「解析中」から進まない場合はワーカーのログを見る:

```bash
az containerapp logs show --name "$WORKER_APP_NAME" --resource-group "$RG" --tail 100
```

> **アップロードするPDFのサイズ**: アプリの上限は 500MB(`MAX_UPLOAD_SIZE_MB`)だが、SWA のプロキシ経由にはリクエストサイズの制限がある。検証は数MB程度のサンプルPDFで行うこと。

---

## 11. 運用コマンド集

### ログ

```bash
# ライブストリーム
az containerapp logs show --name "$API_APP_NAME"    --resource-group "$RG" --follow
az containerapp logs show --name "$WORKER_APP_NAME" --resource-group "$RG" --follow

# Log Analytics に溜まったログを検索(取り込みまで数分のラグがある)
az monitor log-analytics query \
  --workspace "$(az monitor log-analytics workspace show -g "$RG" -n log-idp-verify --query customerId -o tsv)" \
  --analytics-query "ContainerAppConsoleLogs_CL | where ContainerAppName_s == '$WORKER_APP_NAME' | order by TimeGenerated desc | take 50" \
  -o table
```

### アプリを更新する(コード変更後)

```bash
export IMAGE_TAG=v2

cd backend && az acr build --registry "$ACR_NAME" --image "idp-backend:${IMAGE_TAG}" . && cd ..

export DEPLOY_APPS=true
az deployment group create --resource-group "$RG" --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

タグを変えずに同じタグへ push した場合はテンプレート差分が出ないため、リビジョンを手動で作り直す:

```bash
az containerapp revision restart --name "$API_APP_NAME" --resource-group "$RG" \
  --revision "$(az containerapp revision list -n "$API_APP_NAME" -g "$RG" --query '[0].name' -o tsv)"
```

> 検証では**タグを都度上げる**(v1 → v2 …)運用を推奨。どのイメージが動いているか追えなくなるため `latest` は使わない。

### フロントエンドだけ更新する

```bash
cd frontend && npm run build && \
npx --yes @azure/static-web-apps-cli deploy ./dist --deployment-token "$SWA_TOKEN" --env production && cd ..
```

### キューの滞留・DLQ を見る

```bash
az servicebus queue show --resource-group "$RG" \
  --namespace-name "$(outputs serviceBusNamespace | cut -d. -f1)" \
  --name interactive \
  --query "countDetails" -o json
```

`deadLetterMessageCount` が増えている場合は解析が失敗し続けている(ワーカーのログを確認)。

### マイグレーションを追加した場合

新しいイメージをビルド・push(§11「アプリを更新する」)したうえで、**DB初期化ジョブを再実行するだけ**でよい。

```bash
az containerapp job start --name "$DB_INIT_JOB_NAME" --resource-group "$RG"
```

ロール権限は `ALTER DEFAULT PRIVILEGES` により新規テーブルにも自動で付くため、`init-roles.sql` の再実行は不要。マイグレーションはイメージに同梱されているので、**ジョブが古いイメージを指していると古いマイグレーションが流れる**点に注意(`IMAGE_TAG` を上げたら §6 の再デプロイでジョブの参照イメージも更新される)。

---

## 12. 後片付け

```bash
az group delete --name "$RG" --yes --no-wait
```

Document Intelligence(Cognitive Services)は削除後も48時間は論理削除状態で残り、**同名では再作成できない**。すぐに作り直す場合は完全削除(purge)する:

```bash
az cognitiveservices account purge \
  --name "<di-idp-verify-xxxx>" \
  --resource-group "$RG" \
  --location "$LOCATION"
```

> リソース名にはリソースグループIDから導いたサフィックスが入るため、**リソースグループを作り直すとリソース名も変わる**(purge が不要になる代わりに、旧リソースの残骸が課金対象として残っていないか確認すること)。

---

## 付録A: 環境変数対応表(ローカル ↔ Azure)

Container Apps に設定される環境変数([infra/verify/modules/compute.bicep](../../infra/verify/modules/compute.bicep))と、ローカル `.env` の対応。

| 環境変数 | ローカル | Azure(検証環境) |
|---|---|---|
| `DATABASE_URL` | `app_user@localhost:5432` | `app_user@<psql>.postgres.database.azure.com:5432/idp?ssl=require`(シークレット) |
| `MIGRATION_DATABASE_URL` | 所有者ロール `app` | **設定しない**(マイグレーションはローカルから実行するため。未設定時は `DATABASE_URL` にフォールバック) |
| `BLOB_ACCOUNT_URL` | Azurite | `https://<st>.blob.core.windows.net/` |
| `BLOB_CONNECTION_STRING` | Azurite の開発用キー | **空**(空にすることで Managed Identity 経路になる) |
| `SERVICE_BUS_NAMESPACE` | 空 | `<sb>.servicebus.windows.net` |
| `SERVICE_BUS_CONNECTION_STRING` | エミュレータの接続文字列 | **空**(同上) |
| `DI_ENDPOINT` | 共有開発リソース | 検証環境専用リソース |
| `DI_KEY` | 受領したキー | **空**(同上。リソース側も `disableLocalAuth: true`) |
| `AZURE_CLIENT_ID` | — | ユーザ割り当てマネージドIDのクライアントID。**これが無いと `DefaultAzureCredential` がどのIDを使うか決められない** |
| `AUTH_MODE` | `local` | `local`(**既定では Keycloak を立てないため**。付録Eで立てたうえで `keycloak` に切り替えれば下の `OIDC_*` が効く) |
| `LOCAL_TENANT_ID` / `LOCAL_USER_ID` | seed 既定値 | 同じ値(`main.bicepparam`) |
| `OIDC_ISSUER` | `http://localhost:8080/realms/idp`(docker compose の Keycloak) | `https://<keycloak>.<region>.azurecontainerapps.io/realms/idp`。**Keycloak 未デプロイでも値は入る**(`AUTH_MODE=local` の間は参照されない) |
| `OIDC_AUDIENCE` | `idp-api` | 同じ値(`oidcAudience`。レルム定義の audience マッパーが出す値と一致させる。SPAのクライアントID `idp-frontend` とは別物) |
| `SHARE_BASE_URL` | `http://localhost:5173/share` | `https://<swa>.azurestaticapps.net/share` |

---

## 付録B: 検証環境で割り切っている点

[azure-architecture_v2.md §4.1](../01_design/azure-architecture_v2.md#41-初期-社内でのアプリ開発顧客データなし) の「初期(社内開発)」フェーズに対応する構成。**顧客データを1件でも入れる前に §4.4 のゲート条件を満たすこと。**

| 項目 | 検証環境 | 本番想定 |
|---|---|---|
| ネットワーク | パブリックエンドポイントのみ。VNet / Private Endpoint / NSG なし | VNet 内 + PE + NSG |
| 公開接点 | SWA が全公開。IP制限なし | Application Gateway + WAF(API Management は不採用) |
| 認証 | `AUTH_MODE=local`(JWT検証なし・全員が `tenant_admin`) | Keycloak(Container Apps・単一レルム)。**JWT検証はAPI側が唯一の強制点**(エッジの検証層なし) |
| Keycloak | 既定では立てない(付録E で任意にデプロイ)。external ingress で `/admin` も公開される | Application Gateway 経由で認証エンドポイントのみ公開。管理パス(`/admin/master`・`/admin/realms`・`/realms/master`)は遮断(NFR-SEC-19) |
| PostgreSQL | パスワード認証 + 「Azure サービスを許可」ファイアウォール | Entra ID 認証 + Private Endpoint |
| Blob | ソフト削除・バージョニングなし | ソフト削除 + バージョニング + ZRS |
| ACR | Basic(パブリック) | Premium + PE + 脆弱性スキャン |
| ワーカー | 1レプリカ固定(KEDA スケールなし) | KEDA によるキュー長スケール |
| 監視 | Log Analytics のみ | + Defender for Cloud + アラート |

**URL を知っていれば誰でもアクセスできる状態**である点に注意。社外に共有しないこと。露出を絞りたい場合は、SWA Standard の IP 制限を `frontend/public/staticwebapp.config.json` に追加してから再デプロイする:

```json
{
  "networking": {
    "allowedIpRanges": ["203.0.113.0/24"]
  }
}
```

Managed Identity・RLS・ロール分離といった**認証方式は本番同等**にしてある(後付けの改修コストが最も高い部分のため)。

---

## 付録C: コスト目安

2026-07時点・東日本・月額USD概算。停止せず1か月動かした場合。

| リソース | 目安 | 備考 |
|---|---|---|
| Container Apps(API 最小1 + ワーカー1レプリカ常駐) | $30〜60 | 常時起動のため検証環境の主コスト |
| PostgreSQL Flexible Server B1ms + 32GB | $15〜25 | |
| Service Bus Standard | ~$10 | |
| Static Web Apps Standard | $9 | API リンクに必須 |
| Container Registry Basic | ~$5 | |
| Storage / Log Analytics | 数ドル | |
| Document Intelligence S0 | 従量 | 解析ページ数次第 |
| **合計** | **~$70〜115 + DI従量** | |
| (任意)Keycloak 1レプリカ常駐 | +$15〜30 | 付録E でデプロイした場合のみ。`DEPLOY_KEYCLOAK=false` で止められる |

コストを抑えるには、検証しない期間に**ワーカーとAPIの最小レプリカを0にする**か、リソースグループごと削除する。

```bash
# 一時的にスケールを0に落とす(API はコールドスタートするようになる)
az containerapp update --name "$WORKER_APP_NAME" --resource-group "$RG" --min-replicas 0
az containerapp update --name "$API_APP_NAME"    --resource-group "$RG" --min-replicas 0
```

PostgreSQL は停止できる(7日で自動再開):

```bash
az postgres flexible-server stop --resource-group "$RG" --name "$(outputs postgresFqdn | cut -d. -f1)"
```

---

## 付録D: トラブルシューティング

| 症状 | 原因と対処 |
|---|---|
| デプロイが `AuthorizationFailed` (roleAssignments) で失敗 | 実行者に **ユーザー アクセス管理者** 権限がない(§2.3)。Owner 権限で実行するか、権限を付与してもらう |
| Container Apps の作成で `UNAUTHORIZED` / イメージ pull 失敗 | ロール割り当ての伝播待ち。数分待ってから `az deployment group create` を再実行する(冪等) |
| `az acr build` が遅い / タイムアウト | `backend/.dockerignore` が効かず `.venv` を送っている。`backend/` 直下で実行しているか確認 |
| `psql` が接続できない(タイムアウト) | 後述の「ローカルPCから PostgreSQL に接続できない」を参照。**DB初期化は §7 のジョブで行うため、これが直らなくても手順は完走できる** |
| `psql` が `password authentication failed` | `PG_ADMIN_PASSWORD` が §3 で生成した値と違う。控えた値を使う(不明なら `az postgres flexible-server update --admin-password` でリセット) |
| `alembic upgrade head` が `SSL connection required` | 接続URLに `?ssl=require` が付いていない |
| アプリが `permission denied for table ...` | `init-roles.sql` を流していない、またはマイグレーション後に流していない。§7.1 を再実行する(冪等) |
| DB初期化ジョブが `Failed` | ログを確認(§7.2)。多いのは ①`init-roles.sql` 未実行で `app_user` が存在しない ②PostgreSQL のファイアウォールから `AllowAllAzureServices` を消してしまった ③`IMAGE_TAG` を上げたのに §6 を再デプロイしておらず、ジョブが古いイメージを見ている |
| ジョブのログに `permission denied for schema public` (`asyncpg.exceptions.InsufficientPrivilegeError`) | 後述の「ローカルとAzureのロール権限の差異」を参照。マイグレーション 0002 以降で修正済みなので、古いイメージを使っていないか確認する |
| 画面は出るが API が 404 | SWA と Container Apps のリンクができていない(§9)。`az staticwebapp backends show` で確認 |
| `/documents/xxx` を直接開くと 404 | `staticwebapp.config.json` が `dist/` に含まれていない。`frontend/public/` にあるか確認して再ビルド・再デプロイ |
| 状態が「解析中」から進まない | ワーカーのログを確認(§11)。多いのは ①DI のリージョンで `2024-11-30` API が使えない ②`Cognitive Services User` ロールの伝播待ち ③`AZURE_CLIENT_ID` 未設定でMI認証が失敗 |
| ワーカーログに `DefaultAzureCredential failed to retrieve a token` | `AZURE_CLIENT_ID` がユーザ割り当てマネージドIDのクライアントIDと一致しているか確認する |
| ポータルのストレージブラウザで `AuthorizationFailure` | `allowSharedKeyAccess: false` のため。認証方法を「Entra ID ユーザーアカウント」に切り替え、自分に `Storage Blob Data Reader` 以上を付与する |
| DI の解析で 401 | `disableLocalAuth: true` のためキー認証は使えない。MI 経由(`DI_KEY` 空)であることを確認する |
| 共有URLがローカルホストを指す | `SHARE_BASE_URL` は Container Apps の環境変数に焼かれている。SWA を作り直した場合は §7 の再デプロイが必要 |
| 途中まで動いていた `az` が突然 `SSLV3_ALERT_HANDSHAKE_FAILURE` | apt 版 Azure CLI を使っている。venv 版に切り替える(§2.2 / 後述の「認証エンドポイントのTLSインスペクション」) |
| Keycloak のレプリカが起動と停止を繰り返す | `init-keycloak-db.sql` を流していない(`keycloak_user` が存在しない)、または `KEYCLOAK_DB_PASSWORD` が E.1 で使った値とずれている。ログは `az containerapp logs show -n <keycloakアプリ名> -g $RG --tail 100` |
| Keycloak のデプロイで イメージ pull 失敗 | E.2 の `az acr build` をしていない、または `KEYCLOAK_IMAGE_TAG` がビルドしたタグと違う。`az acr repository show-tags -n "$ACR_NAME" --repository idp-keycloak` で確認する |
| `$KEYCLOAK_ISSUER/.well-known/openid-configuration` が 404 | レルムが取り込まれていない。ログに import の行があるか確認する。既にレルムがある状態では `--import-realm` は何もしないため、定義を変えた場合は E.6 のDB作り直しが要る |
| ログインは通るが API が 401(バックエンド実装後) | アクセストークンの `aud` が API 側の `OIDC_AUDIENCE`(既定 `idp-api`)と一致していない。レルム定義の audience マッパーが効いているか、`jwt.io` 等でトークンを見て確認する。`aud` が `idp-frontend` のままなら古いレルムが残っている(付録 E.6 の手順でレルムを取り込み直す) |
| Keycloak のログに `permission denied for schema public` | E.1 の `GRANT ALL ON SCHEMA public` が `keycloak` データベースに対して実行されていない(誤って `idp` に接続して流した可能性)。接続先を確認して再実行する |
| Keycloak が `Healthy` にならない(タイムアウト) | 初回起動は構成ビルド+スキーマ作成で1〜2分かかる。Startup プローブは最大5分待つ設定。それでも駄目ならログを見る |
| Keycloak のログイン後に `Invalid parameter: redirect_uri` | クライアントの **Valid redirect URIs** に SWA のホスト名が入っていない(E.3) |
| 管理コンソールで `HTTPS required` | `KC_PROXY_HEADERS` / `KC_HTTP_ENABLED` の設定漏れ。Bicep 側で設定済みなので、リビジョンが最新か確認する |

### ローカルとAzureのロール権限の差異

**ローカルの所有者ロールはスーパーユーザだが、Azure の管理者ロールは非スーパーユーザ。** この差でローカルだけ通ってしまう処理がある。

| | ローカル(docker compose) | Azure Flexible Server |
|---|---|---|
| 所有者ロール | `app`(`POSTGRES_USER`)= **スーパーユーザ** | `idpadmin` = `rolsuper: f` / `rolbypassrls: t` |
| 権限検査 | スーパーユーザは**多くの検査をスキップする** | 通常どおり検査される |

実際に踏んだ例: マイグレーション 0002 の `ALTER FUNCTION ... OWNER TO share_link_reader` が `permission denied for schema public` で失敗した。PostgreSQL は**オブジェクトの所有者変更時に「新しい所有者が対象スキーマに `CREATE` 権限を持つこと」を要求する**が、`share_link_reader` は NOLOGIN ロールとして作られただけで CREATE を持たない。ローカルではスーパーユーザがこの検査をスキップするため通っていた。

修正済み(所有者変更の前後で CREATE を付与・剥奪する)だが、**同じ SECURITY DEFINER パターンを追加するときは同じ罠がある**。この種の差異はローカルでは検出できないため、マイグレーションを追加したら検証環境でジョブを流して確認すること。

```sql
-- ロール属性の確認(Cloud Shell から)
SELECT rolname, rolsuper, rolbypassrls, rolcreaterole FROM pg_roles
WHERE rolname IN ('idpadmin', 'app_user', 'share_link_reader', 'maintenance_reader');

-- スキーマ権限の確認
SELECT has_schema_privilege('idpadmin','public','CREATE') AS admin_create,
       has_schema_privilege('app_user','public','USAGE')  AS app_user_usage;
```

### ローカルPCから PostgreSQL に接続できない

**社内ネットワークからは PostgreSQL への直接接続が成立しない(2026-07-31 確認済み)。** 経路上の機器が 5432 の TCP を終端してしまい、PostgreSQL のプロトコルを通さないため。

**この制約があるので DB初期化は Container Apps Job(§7.2)で行う。** ローカルから `psql` が使えなくても手順は完走できるので、以下は「なぜ通らないか」を確認したいとき、または他のネットワークで作業するときのための記録。

#### 切り分けの結果と読み方

| 観測 | 読み方 |
|---|---|
| `psql` が **`timeout expired`** | TCP は繋がっており、その後の**サーバ応答待ちでハング**している。TCP接続自体の失敗(`Connection timed out`)とは別物。**libpq のこの2つの文言は必ず読み分ける** |
| `sslmode=disable` でも同じ | TLS の問題ではない。PostgreSQL のワイヤプロトコル全体が通っていない |
| `openssl s_client -starttls postgres` が無応答 | 同上 |
| `/dev/tcp` や `Test-NetConnection` は成功する | **疎通の証明にならない**。TCPを終端する機器があると、ハンドシェイクは常に成功する |

```bash
# 応答が返らなければ、5432 のアプリケーション層が通っていない
openssl s_client -starttls postgres -connect "$PG_FQDN:5432" -servername "$PG_FQDN" </dev/null 2>&1 | head -20

# 透過プロキシが 5432 を終端している直接的な証拠(HTTPの応答が返れば確定)
printf 'GET / HTTP/1.0\r\n\r\n' | timeout 10 nc "$PG_FQDN" 5432 | head -20
```

#### 送信元IPの食い違い(併発しうる別問題)

上記とは独立に、**HTTP の送信元IPと生の TCP の送信元IPは一致しない**。`curl` は `HTTPS_PROXY` を見てプロキシ経由で出ていくため `ifconfig.me` はプロキシの出口IPを返すが、`psql` は直接出ていくため Azure から見える送信元は別のIPになる。ファイアウォールに**使われない方のIP**を登録すると、許可対象外としてドロップされる。

```bash
# 2つの値が違えば該当する。ファイアウォールには --noproxy 側の値を登録する
echo "プロキシ経由: $(curl -s https://ifconfig.me)"
echo "直接        : $(curl --noproxy '*' -s --max-time 10 https://ifconfig.me)"
```

§3 の `CLIENT_IP` は `--noproxy` 付きで取得している。ポータルからも「PostgreSQL フレキシブル サーバー → 設定 → ネットワーク → ファイアウォール規則」で直接編集できる。

#### 一時的に接続してデバッグしたい場合

Cloud Shell を使う。送信元が Azure なので `AllowAllAzureServices` 規則でそのまま通り、社内網の機器を一切経由しない。`psql` は Cloud Shell に標準で入っている。

### 認証エンドポイントのTLSインスペクション(`az` の `SSLV3_ALERT_HANDSHAKE_FAILURE`)

**症状**: デプロイの途中まで `az` が正常に動いていたのに、ある時点から以下で失敗し続ける。

```
HTTPSConnectionPool(host='login.microsoftonline.com', port=443): Max retries exceeded with url: /<tenantId>/oauth2/v2.0/token
(Caused by SSLError(SSLError(1, '[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] sslv3 alert handshake failure')))
```

**原因**: apt 版 Azure CLI と社内インスペクション装置が、暗号スイートで合意できていない。詳細は §2.2。**venv 版 Azure CLI を使えば解消する。**

途中まで動くのは、`az login` で取得したアクセストークンが有効な間は `management.azure.com`(復号対象外)としか通信しないため。トークン更新が必要になった時点で初めて認証エンドポイントに接続し、そこで失敗する。**特定のコマンドが悪いのではなく、時間経過のタイミングである点に注意。**

同種の問題を切り分ける手順:

```bash
# 1. 提示されている証明書の発行者を見る(社内CA名が出れば、そのホストは復号されている)
curl -v --max-time 15 -o /dev/null https://login.microsoftonline.com/common/discovery/instance 2>&1 \
  | grep -E 'subject:|issuer:|SSL connection'
curl -v --max-time 15 -o /dev/null https://management.azure.com/ 2>&1 \
  | grep -E 'subject:|issuer:|SSL connection'
```

```bash
# 2. az が使う Python が、装置の出す暗号スイートを許容しているか
AZ_PY=$(az --version | sed -n "s/.*Python location '\(.*\)'.*/\1/p")
for py in "$AZ_PY" python3; do
  echo -n "$py : "
  "$py" -c "import ssl; c=ssl.create_default_context(); print('AES256-GCM-SHA384' in [x['name'] for x in c.get_ciphers()])"
done
```

az 側だけ `False` なら本項に該当する。`OPENSSL_CONF` で暗号スイート制限を緩める方法は、制限が Python のビルドに埋め込まれているため**効かない**(検証済み)。

`curl` が通って `az` だけ失敗するのは、`curl` がシステムの OpenSSL とシステムの信頼ストアを使うのに対し、`az` は同梱の Python と certifi バンドルを使うため。

**恒久対処**: ネットワーク管理者へ `login.microsoftonline.com` の復号除外を依頼する(Microsoft も認証エンドポイントの復号除外を推奨)。装置が前方秘匿性のない暗号スイートしか提示していない点は、az に限らず今後同種のツールが動かなくなる根拠として提示できる。

---

## 付録E: Keycloak(認証基盤)のデプロイ

要求変更により、認証は Entra External ID ではなく**自ホストの Keycloak** を使う([azure-architecture_v2.md](../01_design/azure-architecture_v2.md))。本手順は**オプション**で、実施しなくても §1〜§10 は完走できる。

- **いつ実施するか**: 認証フロー(ログイン・JWT検証)を Azure 上で検証したくなったとき
- **既定では立てない理由**: 1レプリカ常駐で月$15〜30ほど増えるため。使わない期間は `DEPLOY_KEYCLOAK=false` で再デプロイすれば止められる(DBの中身は残る)
- **前提**: §4〜§9 が完了していること。`keycloak` データベースと ACR は §4 で、SWA のホスト名は §9 までに確定している(レルムのリダイレクトURIに使う)

> **アプリ側の実装(JWT検証・ログイン導線)は完了している。** それでも Container Apps は `AUTH_MODE=local` のままにしてある。認証を実際に有効化するには、本付録で Keycloak を立てたうえで **`users` テーブルへの利用者の事前登録**(未登録は403)と、API側 `AUTH_MODE=keycloak` / SWA側 `VITE_AUTH_MODE=keycloak` への切り替えが必要。

### E.1 DBロールの作成(初回のみ)

Keycloak は自分のテーブルを作るため、`public` スキーマへの `CREATE` 権限を持つ専用ロールが要る(PostgreSQL 15 以降、`public` は既定で `CREATE` を持たない)。§7.1 と同様に **Azure Cloud Shell** から実行する。

1. Cloud Shell(bash)を開く
2. `infra/verify/scripts/init-keycloak-db.sql` をアップロードする
3. 以下を実行する。**接続先データベースが `keycloak` であること**(スクリプト側でも検査して弾く)

```bash
RG=rg-idp-verify
PG_FQDN=$(az postgres flexible-server list -g "$RG" --query "[0].fullyQualifiedDomainName" -o tsv)
PG_ADMIN_LOGIN=idpadmin
read -rsp 'Keycloak DB password: ' KEYCLOAK_DB_PASSWORD; echo
```

```bash
psql "host=$PG_FQDN port=5432 dbname=keycloak user=$PG_ADMIN_LOGIN sslmode=require" \
  -v keycloak_db_password="$KEYCLOAK_DB_PASSWORD" \
  -f init-keycloak-db.sql
```

最後の2つの確認クエリを見る。`keycloak_user` の `rolsuper` / `rolcreatedb` / `rolcreaterole` / `rolbypassrls` がすべて `f`、`can_create_in_public` が `t` であること。

### E.2 Keycloak イメージのビルド

Keycloak は公式イメージをそのまま使わず、`infra/verify/keycloak/` で最適化イメージを作る。目的は2つ:

- `kc.sh build` を済ませて `start --optimized` を使えるようにする(起動時の構成ビルドを省く)
- レルム定義(`realm-idp.json`)を同梱し、初回起動時に `--import-realm` で取り込む

レルムのリダイレクトURIは SPA のオリジンに依存するため、**SWA のホスト名をビルド引数で渡す**(§4.4 の `outputs` を使う)。あわせてバッチAPI用クライアント(`idp-batch-dev`)のシークレットと、そのクライアントに紐づくテナントIDも渡す。**既定値はローカル開発用の固定値なので、検証環境では必ず上書きする**。

```bash
export SWA_HOSTNAME="$(outputs staticWebAppHostname)"
export KEYCLOAK_IMAGE_TAG=v1
export BATCH_CLIENT_SECRET="$(openssl rand -base64 32)"
# バッチ連携に使う検証用テナントのUUID(seed.py で作ったテナント)
export BATCH_TENANT_ID="00000000-0000-0000-0000-000000000001"

az acr build   --registry "$ACR_NAME"   --image "idp-keycloak:$KEYCLOAK_IMAGE_TAG"   --build-arg APP_ORIGIN="https://$SWA_HOSTNAME"   --build-arg BATCH_CLIENT_SECRET="$BATCH_CLIENT_SECRET"   --build-arg BATCH_TENANT_ID="$BATCH_TENANT_ID"   infra/verify/keycloak
```

`BATCH_CLIENT_SECRET` はバッチ連携元へ渡す資格情報。生成した値を手元に控えておく(イメージからは取り出しにくいが、Keycloak 管理コンソールの **Clients → idp-batch-dev → Credentials** でいつでも再生成できる)。

> ビルドは Azure 上で走るため、ベースイメージ(quay.io の Keycloak)の取得は社内プロキシの影響を受けない。
>
> **SWA を作り直してホスト名が変わったら、このイメージを再ビルドして Keycloak を再デプロイする。** リダイレクトURIがイメージに焼き込まれているため。

### E.3 Keycloak のデプロイ

WSL に戻り、パスワードを環境変数に入れて再デプロイする。`KEYCLOAK_DB_PASSWORD` は E.1 で使った値と**同じもの**を指定すること。

```bash
export KEYCLOAK_DB_PASSWORD='...'      # E.1 と同じ値
export KEYCLOAK_ADMIN_PASSWORD='...'   # Keycloak 初期管理者のパスワード
export DEPLOY_KEYCLOAK=true
```

```bash
az deployment group create \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

> **§6 で使ったシェルをそのまま使うこと。** `DEPLOY_APPS` / `IMAGE_TAG` も引き続き必要で、未設定のまま再デプロイすると Container Apps が消える。ターミナルを開き直した場合は §3 と §4.4 のブロックを再実行する。

イメージは ACR ではなく `quay.io/keycloak/keycloak` を直接引く。pull は Azure 側で走るため社内プロキシの影響を受けない。

**初回起動は1〜2分かかる**(構成のビルドと、Keycloak 自身によるDBスキーマ作成が走るため)。出力を取り込んで起動を待つ:

```bash
export KEYCLOAK_APP_NAME="$(outputs keycloakAppName)"
export KEYCLOAK_URL="$(outputs keycloakBaseUrl)"
export KEYCLOAK_ISSUER="$(outputs keycloakIssuerUrl)"

az containerapp revision list -n "$KEYCLOAK_APP_NAME" -g "$RG" \
  --query "[0].{active:properties.active, health:properties.healthState, replicas:properties.replicas}" -o json
```

`healthState` が `Healthy` になれば起動完了。起動に失敗している場合はログを見る:

```bash
az containerapp logs show -n "$KEYCLOAK_APP_NAME" -g "$RG" --tail 100
```

### E.4 レルム構成の確認と検証用ユーザの作成

レルム `idp` とクライアント(`idp-frontend` / `idp-batch-dev`)は、イメージに同梱した [realm-idp.json](../../infra/verify/keycloak/realm-idp.json) が初回起動時に取り込むため**手動作成は不要**。まず取り込まれたことを確認する:

```bash
curl -s "$KEYCLOAK_ISSUER/.well-known/openid-configuration" | head -c 200; echo
```

JSON が返れば成功。`404` ならレルムが取り込まれていないので、ログで `import` の行を確認する。

両クライアントには**audience マッパー**を入れてあり、アクセストークンの `aud` に `idp-api` を載せる。これが無いと `aud` が `account` になり、バックエンドの `OIDC_AUDIENCE=idp-api` での検証が通らない。

> **`idp-api` はクライアントIDではなく、API 自身を指す audience 名。** SPA のクライアントID(`idp-frontend`)とは役割が違うので混同しない。レルム定義では実在クライアントを指す `included.client.audience` ではなく、任意の文字列を載せる `included.custom.audience` を使っている。

バッチ用の `idp-batch-dev` には audience マッパーに加えて、テナントIDを載せる **`tenant_id` クレームのマッパー**が入っている。バックエンドのバッチAPIはこのクレームだけでテナントを決めるため、マッパーの値を間違えると**別テナントのデータを操作できてしまう**。トークンを取って中身を確認しておく:

```bash
curl -s -X POST "$KEYCLOAK_ISSUER/protocol/openid-connect/token" -d grant_type=client_credentials -d client_id=idp-batch-dev -d client_secret="$BATCH_CLIENT_SECRET" | cut -d'"' -f4 | cut -d. -f2 | base64 -d 2>/dev/null; echo
```

`aud` が `idp-api`、`tenant_id` が意図したテナントのUUIDになっていることを確認する。

次に、検証用ユーザを1人作る(ユーザは環境ごとに違うのでレルム定義には含めていない):

1. `$KEYCLOAK_URL/admin` を開き、`kcadmin` / `KEYCLOAK_ADMIN_PASSWORD` でログインする
2. 左上のレルム選択を **idp** に切り替える(既定は `master`)
3. **Users** → **Add user** → ユーザ名とメールアドレスを入れて作成
4. **Credentials** タブでパスワードを設定する(**Temporary を Off**)

このユーザの `sub`(Users → 該当ユーザ → ID)が、アプリ側 `users.entra_object_id`(改名予定: `idp_subject`)に対応する。バックエンド実装時に seed か手動 INSERT で紐づける。

> **ロールはレルム定義に含めていない。** `tenant_admin` / `member` の判定は JWT クレームではなく `users` テーブルで行う設計のため([data-model.md](../01_design/data-model.md))。

issuer URL は §4.4 の `outputs` から取れる。この値は既に Container Apps の `OIDC_ISSUER` に渡してあるので、バックエンドの JWT 検証を実装したら `AUTH_MODE` を `keycloak` にするだけで効く:

```bash
echo "$KEYCLOAK_ISSUER"
# => https://ca-idp-verify-keycloak.<region>.azurecontainerapps.io/realms/idp
```

### E.5 セキュリティ上の注意

検証環境の Keycloak は **`/admin` を含めてインターネットに公開される**(SWA と同様に URL を知っていれば誰でも到達できる)。本番想定では Application Gateway の WAF カスタムルールで `/admin/master`・`/admin/realms`・`/realms/master` を遮断する(NFR-SEC-19)。

- 社外に URL を共有しない
- `KEYCLOAK_ADMIN_PASSWORD` は十分な長さのランダム文字列にする
- 恒久運用する場合は、管理者アカウントを別途作って `kcadmin`(ブートストラップ管理者)を無効化する
- ベースイメージのタグは固定してある(`infra/verify/keycloak/Dockerfile` の `KEYCLOAK_VERSION`)。CVE 追随は自社責任のため、放置せず定期的に上げて E.2 から再ビルドする(NFR-SEC-20)

### E.6 停止・削除

Keycloak だけ止める(DBの中身は残るので、再度 `true` にすれば同じレルム構成で戻る):

```bash
export DEPLOY_KEYCLOAK=false
az deployment group create \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

**レルム定義(`realm-idp.json`)を変更した場合は、再ビルド・再デプロイだけでは反映されない。** `--import-realm` はレルムが既に存在すると何もしないため。反映するには `keycloak` データベースを作り直す(**そのレルムのユーザもすべて消える**):

```bash
# Cloud Shell から。Keycloak を止めてから実行する(接続が残っていると DROP できない)
psql "host=$PG_FQDN port=5432 dbname=postgres user=$PG_ADMIN_LOGIN sslmode=require" \
  -c 'DROP DATABASE keycloak;' -c 'CREATE DATABASE keycloak;'
```

その後 E.1(ロール権限の再付与)からやり直す。**SWA を作り直してホスト名が変わった場合も同じ**(リダイレクトURIがイメージに焼き込まれているため、E.2 の再ビルドとDBの作り直しが要る)。

### E.7 audience(`aud`)を切り替えるときの順序

APIが検証する audience は SPA のクライアントID(`idp-frontend`)から分離してあり、既定は `idp-api`(`main.bicep` の `oidcAudience` パラメータ)。この値を変える場合、**Keycloak 側を先に、API 側を後に切り替える**。

**既存環境を `idp-frontend` から `idp-api` へ移行する場合もこの手順に従う。**

1. **Keycloak のレルムを新しい audience で取り込み直す** — E.6 の DB 作り直し → E.1(ロール権限の再付与)→ E.2(イメージ再ビルド)→ E.3(再デプロイ)
2. **API の `OIDC_AUDIENCE` を切り替える** — `oidcAudience` は既定で `idp-api` のため、§6 と同じ手順で Container Apps を再デプロイすれば反映される
3. E.4 の手順でトークンの `aud` が新しい値になっていることを確認し、検証用ユーザを作り直して(DB作り直しで消えている)`users.idp_subject` を更新する

> **順序を逆にすると全トークンが弾かれる。** API を先に `idp-api` へ切り替えると、Keycloak がまだ `idp-frontend` を出している間ずっと `401 invalid_token` になる。この窓は Keycloak の再ビルド・再デプロイが終わるまで(数分〜十数分)続く。Keycloak を先にすれば、噛み合わない窓は API 再デプロイの間だけに縮む。

#### 無停止で切り替えたい場合(検証環境では採らない)

audience マッパーを2つ載せれば `aud` は配列になるため、原理的には無停止で移せる:

1. 両クライアントに `idp-frontend` と `idp-api` の audience マッパーを**両方**載せる
2. API の `OIDC_AUDIENCE` を `idp-api` に切り替える
3. `idp-frontend` のマッパーを削除する

**検証環境ではこの方法は採らず、E.7 の一括切り替え(瞬断あり)とする。** レルム定義の変更は DB の作り直しでしか反映されず、その時点でレルムのユーザが全部消えるため、そもそも無停止にならないため。上の3段が意味を持つのは、レルム定義ではなく**管理コンソールでマッパーを直接編集する**場合(= 本番でユーザを消せないとき)に限られる。その場合はコンソールでの手修正とレルム定義の変更が二重管理になる点に注意する。
