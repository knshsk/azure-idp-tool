# 社内検証環境 デプロイ手順書(Azure)

README のクイックスタート([WSL上でのローカル実行](../../README.md#クイックスタートwsl内))と**同等の動作確認を Azure 上で行う**ための手順。
IaC は [infra/verify/](../../infra/verify/)、構成の説明は [infra/verify/README.md](../../infra/verify/README.md) を参照。

- **所要時間目安**: 1〜1.5時間(PostgreSQL の作成に10分前後、Container Apps 環境に5分前後かかる)
- **前提**: 顧客データは投入しない。ネットワーク防御(VNet / Private Endpoint / WAF)は設けない構成
- **作業場所**: すべて WSL(Ubuntu)内。コマンドは上から順に実行する

> CI/CD は使わない。Azure CLI とポータル操作による手動デプロイのみで完結する手順にしている。

## 目次

1. [全体像](#1-全体像)
2. [事前準備](#2-事前準備)
3. [環境変数の準備](#3-環境変数の準備)
4. [基盤リソースのデプロイ(1回目)](#4-基盤リソースのデプロイ1回目)
5. [コンテナイメージのビルド(ACR)](#5-コンテナイメージのビルドacr)
6. [データベースの初期化](#6-データベースの初期化)
7. [Container Apps のデプロイ(2回目)](#7-container-apps-のデプロイ2回目)
8. [フロントエンドのビルドとデプロイ](#8-フロントエンドのビルドとデプロイ)
9. [Static Web Apps と API のリンク](#9-static-web-apps-と-api-のリンク)
10. [動作確認(スモークテスト)](#10-動作確認スモークテスト)
11. [運用コマンド集](#11-運用コマンド集)
12. [後片付け](#12-後片付け)
- [付録A: 環境変数対応表(ローカル ↔ Azure)](#付録a-環境変数対応表ローカル--azure)
- [付録B: 検証環境で割り切っている点](#付録b-検証環境で割り切っている点)
- [付録C: コスト目安](#付録c-コスト目安)
- [付録D: トラブルシューティング](#付録d-トラブルシューティング)

---

## 1. 全体像

### 構成

```
[ブラウザ]
    |
    v
Static Web Apps (Standard)  ── 静的コンテンツ配信
    |  /api/* を APIリンクでプロキシ
    v
Container Apps (API / FastAPI)  ──> PostgreSQL Flexible Server (B1ms)
    |                            └─> Blob Storage
    | ジョブ投入                  
    v
Service Bus (interactive / batch)
    |
    v
Container Apps (ワーカー) ──> Document Intelligence (S0)
    |                     └─> Blob Storage / PostgreSQL
    v
Log Analytics(API・ワーカーのログ)

Container Registry ── API・ワーカー共通のイメージを保管(ビルドもここで実施)
ユーザ割り当てマネージドID ── ACR / Blob / Service Bus / DI へのアクセス
```

ローカル開発との対応:

| ローカル(docker compose) | Azure(本手順) |
|---|---|
| PostgreSQL コンテナ | PostgreSQL Flexible Server (B1ms) |
| Azurite | Storage Account(Blob) |
| Service Bus エミュレータ + SQL Server | Service Bus (Standard) |
| 共有の開発用 Document Intelligence | 検証環境専用の Document Intelligence (S0) |
| `uvicorn app.main:app` | Container Apps(API) |
| `python -m app.worker.main` | Container Apps(ワーカー) |
| Vite dev サーバ(`/api` を proxy) | Static Web Apps(`/api` を APIリンクでプロキシ) |

### 作業の流れ

デプロイは**2段階**に分かれる。コンテナイメージが ACR に存在しないと Container Apps を作成できないため。

```
§4 基盤リソース(DEPLOY_APPS=false)
      ↓
§5 az acr build でイメージをビルド・push
      ↓
§6 DB初期化(ロール分離 → マイグレーション → シード)
      ↓
§7 Container Apps(DEPLOY_APPS=true)
      ↓
§8 フロントエンドを SWA へデプロイ
      ↓
§9 SWA と API をリンク
      ↓
§10 スモークテスト
```

---

## 2. 事前準備

### 2.1 必要なツール(WSL内)

| ツール | 確認コマンド | 補足 |
|---|---|---|
| Azure CLI | `az version` | 2.53 以降(`.bicepparam` を `--parameters` 単独で渡すため) |
| Bicep CLI | `az bicep version` | 0.22 以降(`readEnvironmentVariable()` を使うため)。無ければ `az bicep install` / 古ければ `az bicep upgrade` |
| PostgreSQL クライアント | `psql --version` | 無ければ `sudo apt install -y postgresql-client` |
| Node.js / npm | `node -v` | フロントエンドのビルドと SWA CLI に使う |
| uv | `uv --version` | マイグレーション・シードの実行に使う |

Docker は不要(イメージのビルドは ACR 側で実行するため)。

> **社内プロキシ配下の注意**: `az` / `npm` / `uv` はいずれもプロキシ設定が必要。
> [setup-guide.md §4](../02_development/setup-guide.md#4-プロキシ設定最重要) の設定が済んでいることが前提。
> なお `az acr build` の**ビルド自体は Azure 上で走る**ため、ベースイメージ(`python:3.14-slim`、ghcr.io の `uv`)の取得はプロキシの影響を受けない。

### 2.2 必要な権限

デプロイ実行者には、対象サブスクリプション(またはリソースグループ)に対して以下が必要:

- **共同作成者(Contributor)** — リソースの作成
- **ユーザー アクセス管理者(User Access Administrator)** — マネージドIDへのロール割り当て(`infra/verify/modules/rbac.bicep`)

どちらも無い場合は **所有者(Owner)** で実行する。Contributor だけだとロール割り当てで `AuthorizationFailed` になる。

### 2.3 サインインとリソースプロバイダの登録

```bash
az login
az account set --subscription "<サブスクリプションID>"

# 未登録のプロバイダがあるとデプロイが失敗するため先に登録しておく(登録済みなら即完了)
for ns in Microsoft.App Microsoft.ContainerRegistry Microsoft.DBforPostgreSQL \
          Microsoft.ServiceBus Microsoft.CognitiveServices Microsoft.Storage \
          Microsoft.OperationalInsights Microsoft.Web Microsoft.ManagedIdentity; do
  az provider register --namespace "$ns"
done
```

登録状況の確認:

```bash
az provider show --namespace Microsoft.App --query registrationState -o tsv
```

---

## 3. 環境変数の準備

`infra/verify/main.bicepparam` は機微値をファイルに持たず、`readEnvironmentVariable()` で環境変数から読む。
以下を**このあとの作業で使うターミナル**にエクスポートする(ターミナルを開き直したら再実行する)。

```bash
cd ~/dev/azure-idp-tool

# --- リソースグループ ---
export RG=rg-idp-verify
export LOCATION=japaneast
export DEPLOYMENT_NAME=idp-verify

# --- パスワード ---
# 接続URLに埋め込むため、URL予約文字(@ : / ? # & %)を含まない英数字にすること
export PG_ADMIN_PASSWORD="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 24)"
export APP_USER_PASSWORD="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9' | head -c 24)"

# --- PostgreSQL に接続するローカルPCのグローバルIP ---
# マイグレーション・シードを WSL から流すためのファイアウォール穴
export CLIENT_IP="$(curl -s https://ifconfig.me)"

# --- デプロイ制御(1回目は false) ---
export DEPLOY_APPS=false
export IMAGE_TAG=v1
```

生成したパスワードは**必ず控えておく**(再デプロイ時に同じ値が必要。値が変わると `app_user` のパスワードと Container Apps の `DATABASE_URL` がずれる)。
Azure PostgreSQL のパスワード要件(英大文字・英小文字・数字・記号のうち3種以上)を満たすため、生成結果に**英大文字・英小文字・数字がすべて含まれていること**を確認する(含まれていなければ生成し直す)。

```bash
echo "PG_ADMIN_PASSWORD=$PG_ADMIN_PASSWORD"
echo "APP_USER_PASSWORD=$APP_USER_PASSWORD"
echo "CLIENT_IP=$CLIENT_IP"
```

> **リポジトリにコミットしないこと**。`.env` 相当の扱いとし、チームで共有する場合は別途安全な経路で渡す。

---

## 4. 基盤リソースのデプロイ(1回目)

### 4.1 リソースグループの作成

```bash
az group create --name "$RG" --location "$LOCATION"
```

### 4.2 what-if で差分を確認

```bash
az deployment group what-if \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

`main.bicepparam` の `using 'main.bicep'` からテンプレートが解決されるため、`--template-file` は指定しない。

### 4.3 デプロイ

```bash
az deployment group create \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

PostgreSQL Flexible Server と Container Apps 環境の作成に時間がかかるため、完了まで **10〜15分**程度かかる。

### 4.4 出力値の取り出し

以降の手順で使う値を変数に取り込む。ここで定義する `outputs` 関数は §7 以降でも使うため、ターミナルを開き直したらこのブロックを再実行する。

```bash
outputs() {
  az deployment group show --resource-group "$RG" --name "$DEPLOYMENT_NAME" \
    --query "properties.outputs.$1.value" -o tsv
}

export ACR_NAME="$(outputs registryName)"
export ACR_LOGIN_SERVER="$(outputs registryLoginServer)"
export PG_FQDN="$(outputs postgresFqdn)"
export PG_ADMIN_LOGIN="$(outputs postgresAdminUser)"
export DB_NAME="$(outputs databaseName)"
export SWA_NAME="$(outputs staticWebAppName)"
export SWA_HOST="$(outputs staticWebAppHostname)"
export DI_ENDPOINT="$(outputs documentIntelligenceEndpoint)"
export STORAGE_NAME="$(outputs storageAccountName)"

env | grep -E '^(ACR_|PG_FQDN|SWA_|DI_ENDPOINT|STORAGE_)' | sort
```

---

## 5. コンテナイメージのビルド(ACR)

API とワーカーは**同一イメージ**で、起動コマンドのみ切り替える([backend/Dockerfile](../../backend/Dockerfile))。

```bash
cd ~/dev/azure-idp-tool/backend

az acr build \
  --registry "$ACR_NAME" \
  --image "idp-backend:${IMAGE_TAG}" \
  .
```

- ビルドは Azure 上(ACR Tasks)で実行される。ローカルに Docker は不要
- `backend/.dockerignore` で `.venv` などをビルドコンテキストから除外している。除外が効いていないとアップロードに時間がかかる

push されたことを確認:

```bash
az acr repository show-tags --name "$ACR_NAME" --repository idp-backend -o table
```

```bash
cd ~/dev/azure-idp-tool
```

---

## 6. データベースの初期化

ローカルの `docker compose` では `docker/postgres-init/01-roles.sql` が初回起動時に自動実行されるが、Azure ではこれを手動で流す。

### 6.1 ロール分離(app_user の作成)

RLS は `FORCE ROW LEVEL SECURITY` で所有者にも効くため、**マイグレーション用の所有者ロール**と**アプリ接続ロール**を分ける必要がある。

```bash
export PGPASSWORD="$PG_ADMIN_PASSWORD"

psql "host=$PG_FQDN port=5432 dbname=$DB_NAME user=$PG_ADMIN_LOGIN sslmode=require" \
  -v app_user_password="$APP_USER_PASSWORD" \
  -v pg_admin_login="$PG_ADMIN_LOGIN" \
  -f infra/verify/scripts/init-roles.sql
```

最後に出る `rolbypassrls` / `rolsuper` がいずれも `f`(false)であることを確認する。`t` になっていると RLS が素通りする。

> 接続できない場合は `CLIENT_IP` が変わっている可能性がある。§付録D を参照。

### 6.2 マイグレーションとシード

ローカル開発と同じコマンドを、接続先だけ Azure に向けて実行する。
環境変数は `backend/.env` より優先されるため、`.env` はそのままでよい。

```bash
cd ~/dev/azure-idp-tool/backend

export MIGRATION_DATABASE_URL="postgresql+asyncpg://${PG_ADMIN_LOGIN}:${PG_ADMIN_PASSWORD}@${PG_FQDN}:5432/${DB_NAME}?ssl=require"
export DATABASE_URL="postgresql+asyncpg://app_user:${APP_USER_PASSWORD}@${PG_FQDN}:5432/${DB_NAME}?ssl=require"
export LOCAL_TENANT_ID=00000000-0000-0000-0000-000000000001
export LOCAL_USER_ID=00000000-0000-0000-0000-000000000002

uv run alembic upgrade head
uv run python scripts/seed.py
```

`LOCAL_TENANT_ID` / `LOCAL_USER_ID` は `infra/verify/main.bicepparam` の値と一致させること(不一致だと Container Apps 側のダミー認証が存在しないテナントを指す)。

確認:

```bash
psql "host=$PG_FQDN port=5432 dbname=$DB_NAME user=$PG_ADMIN_LOGIN sslmode=require" \
  -c "\dt" \
  -c "SELECT id, name FROM tenants;" \
  -c "SELECT code, name FROM document_types;"
```

作業後は接続用の環境変数を落としておく(以降の `az` コマンドには不要):

```bash
unset PGPASSWORD MIGRATION_DATABASE_URL DATABASE_URL
cd ~/dev/azure-idp-tool
```

---

## 7. Container Apps のデプロイ(2回目)

イメージが ACR に入ったので、`DEPLOY_APPS=true` にして同じテンプレートを再デプロイする。

```bash
export DEPLOY_APPS=true

az deployment group create \
  --resource-group "$RG" \
  --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

出力から API のFQDNとリソースIDを取り込む:

```bash
export API_FQDN="$(outputs apiAppFqdn)"
export API_APP_ID="$(outputs apiAppResourceId)"
export API_APP_NAME="$(outputs apiAppName)"
export WORKER_APP_NAME="$(outputs workerAppName)"

echo "API: https://$API_FQDN"
```

### 7.1 疎通確認(リンク前に必ず実施)

**§9 で SWA とリンクすると、Container App に「Static Web Apps 経由のみ許可」の認証設定が入り、この URL への直接アクセスができなくなる。** ヘルスチェックはリンク前に済ませておく。

```bash
curl -i "https://$API_FQDN/healthz"
# => HTTP/2 200, {"status":"ok"}

curl -s "https://$API_FQDN/api/v1/document-types" | head -c 400
# => シードした「見積書」が返る
```

ワーカーの起動確認:

```bash
az containerapp logs show --name "$WORKER_APP_NAME" --resource-group "$RG" --tail 50
# => "worker started" / "maintenance loop started" が出ていればOK
```

---

## 8. フロントエンドのビルドとデプロイ

### 8.1 ビルド

API のベースURLは `/api` のまま(SWA のAPIリンクが同じパスでプロキシするため、ローカルの Vite proxy と同じ扱いになる)。

```bash
cd ~/dev/azure-idp-tool/frontend

# .env は作らなくてよい(既定値 VITE_API_BASE_URL=/api が使われる)
npm ci
npm run build
```

`frontend/public/staticwebapp.config.json` がビルド成果物(`dist/`)に含まれる。これは Vue Router の history モードのための設定で、**これが無いと `/documents/xxx` や `/share/xxx` の直リンク・リロードが 404 になる**。

### 8.2 デプロイトークンの取得

```bash
cd ~/dev/azure-idp-tool

export SWA_TOKEN="$(az staticwebapp secrets list \
  --name "$SWA_NAME" --resource-group "$RG" \
  --query "properties.apiKey" -o tsv)"
```

### 8.3 SWA へアップロード

```bash
cd ~/dev/azure-idp-tool/frontend

npx --yes @azure/static-web-apps-cli deploy ./dist \
  --deployment-token "$SWA_TOKEN" \
  --env production
```

完了すると `https://<SWA_HOST>` で画面が開ける(この時点では API 未リンクのためデータ取得は失敗する)。

```bash
cd ~/dev/azure-idp-tool
echo "https://$SWA_HOST"
```

---

## 9. Static Web Apps と API のリンク

SWA の **API リンク(バックエンド連携)** で、`/api` で始まるリクエストを Container Apps(API)へ**同じパスのまま**プロキシする。

### 9.1 CLI でリンクする

```bash
# 事前検証(リンク可能かをチェックするだけで、変更は加えない)
az staticwebapp backends validate \
  --name "$SWA_NAME" \
  --resource-group "$RG" \
  --backend-resource-id "$API_APP_ID" \
  --backend-region "$LOCATION"
```

```bash
az staticwebapp backends link \
  --name "$SWA_NAME" \
  --resource-group "$RG" \
  --backend-resource-id "$API_APP_ID" \
  --backend-region "$LOCATION"
```

1つの Static Web App にリンクできるバックエンドは**1つだけ**。SWA を作り直した場合など、同じ Container App を別の SWA にリンクし直すときは、先に古い認証設定を解除する必要がある(§9.3)。

### 9.2 ポータルでリンクする場合

1. Azure ポータルで Static Web App(`stapp-idp-verify`)を開く
2. 左メニューの **API** を選択
3. `Production` 環境の行で **リンク** を選択
4. **バックエンドリソースの種類**: `Container App`
5. サブスクリプションとリソース名(`ca-idp-verify-api`)を選び **リンク**

### 9.3 リンクの副作用(重要)

リンクすると Container App 側に `Azure Static Web Apps (Linked)` という ID プロバイダが自動構成され、**SWA 経由のトラフィックしか受け付けなくなる**。

- `https://<API_FQDN>/healthz` への直接アクセスは 401/リダイレクトになる(これは正常な挙動)
- リンク解除時に ID プロバイダも消したい場合は `--remove-backend-auth` を付ける。付けないと認証設定だけが残り、**別の SWA にリンクし直せなくなる**

```bash
# リンク解除(Container App 側の認証設定も併せて削除する)
az staticwebapp backends unlink \
  --name "$SWA_NAME" --resource-group "$RG" --remove-backend-auth
```

ポータルから消す場合は Container App の **認証** 画面で `Azure Static Web Apps (Linked)` の ID プロバイダを削除する。

### 9.4 確認

```bash
az staticwebapp backends show --name "$SWA_NAME" --resource-group "$RG" -o table

curl -s "https://$SWA_HOST/api/v1/document-types" | head -c 400
# => 「見積書」が返れば、SWA → Container Apps のプロキシが成立している
```

---

## 10. 動作確認(スモークテスト)

[setup-guide.md §10](../02_development/setup-guide.md#10-動作確認スモークテスト) と同じ内容を Azure 上で行う。

ブラウザで `https://<SWA_HOST>` を開く(`AUTH_MODE=local` のためログイン画面はスキップされる)。

| # | 手順 | 期待結果 | 確認できること |
|---|---|---|---|
| 1 | メイン操作画面が表示される | 書類一覧・アップロードのモーダルが出る | SWA 配信 + `/api` プロキシ + PostgreSQL 読み取り |
| 2 | `backend/tests/fixtures/mitsumori-sample.pdf` をアップロード(書類種別: 見積書) | 状態が「解析中」になる | Blob 書き込み(MI認証)+ Service Bus 投入(MI認証) |
| 3 | しばらく待つ | 状態が「解析済」に変わる | ワーカーのキュー消化 + Document Intelligence 解析(MI認証)+ ページPNG生成 |
| 4 | ドキュメントを開く | ページ画像とオーバレイが表示される | Blob 読み取り + 座標変換 |
| 5 | 転記項目(取引日付・取引先名・合計金額)に候補値が入っている | 値が表示される | Query Fields の解析結果取り込み |
| 6 | 値を編集して確定する | 確定状態になる | PostgreSQL 書き込み(RLS 下) |
| 7 | 共有URLを発行し、シークレットウィンドウで開く | 共有ビューが表示される | `SHARE_BASE_URL` が SWA を指していること + 認証なし経路 |
| 8 | 管理画面 → 利用状況 | グラフが表示される | 管理系API(`tenant_admin` ロール) |

**ここまで通れば検証環境の構築完了。**

3 で「解析中」から進まない場合はワーカーのログを見る:

```bash
az containerapp logs show --name "$WORKER_APP_NAME" --resource-group "$RG" --tail 100
```

> **アップロードするPDFのサイズ**: アプリの上限は 500MB(`MAX_UPLOAD_SIZE_MB`)だが、SWA のプロキシ経由にはリクエストサイズの制限がある。検証は数MB程度のサンプルPDFで行うこと。

---

## 11. 運用コマンド集

### ログ

```bash
# ライブストリーム
az containerapp logs show --name "$API_APP_NAME"    --resource-group "$RG" --follow
az containerapp logs show --name "$WORKER_APP_NAME" --resource-group "$RG" --follow

# Log Analytics に溜まったログを検索(取り込みまで数分のラグがある)
az monitor log-analytics query \
  --workspace "$(az monitor log-analytics workspace show -g "$RG" -n log-idp-verify --query customerId -o tsv)" \
  --analytics-query "ContainerAppConsoleLogs_CL | where ContainerAppName_s == '$WORKER_APP_NAME' | order by TimeGenerated desc | take 50" \
  -o table
```

### アプリを更新する(コード変更後)

```bash
export IMAGE_TAG=v2

cd backend && az acr build --registry "$ACR_NAME" --image "idp-backend:${IMAGE_TAG}" . && cd ..

export DEPLOY_APPS=true
az deployment group create --resource-group "$RG" --name "$DEPLOYMENT_NAME" \
  --parameters infra/verify/main.bicepparam
```

タグを変えずに同じタグへ push した場合はテンプレート差分が出ないため、リビジョンを手動で作り直す:

```bash
az containerapp revision restart --name "$API_APP_NAME" --resource-group "$RG" \
  --revision "$(az containerapp revision list -n "$API_APP_NAME" -g "$RG" --query '[0].name' -o tsv)"
```

> 検証では**タグを都度上げる**(v1 → v2 …)運用を推奨。どのイメージが動いているか追えなくなるため `latest` は使わない。

### フロントエンドだけ更新する

```bash
cd frontend && npm run build && \
npx --yes @azure/static-web-apps-cli deploy ./dist --deployment-token "$SWA_TOKEN" --env production && cd ..
```

### キューの滞留・DLQ を見る

```bash
az servicebus queue show --resource-group "$RG" \
  --namespace-name "$(outputs serviceBusNamespace | cut -d. -f1)" \
  --name interactive \
  --query "countDetails" -o json
```

`deadLetterMessageCount` が増えている場合は解析が失敗し続けている(ワーカーのログを確認)。

### マイグレーションを追加した場合

§6.2 と同じ手順で `uv run alembic upgrade head` を流す。ロール権限は `ALTER DEFAULT PRIVILEGES` により新規テーブルにも自動で付く。

---

## 12. 後片付け

```bash
az group delete --name "$RG" --yes --no-wait
```

Document Intelligence(Cognitive Services)は削除後も48時間は論理削除状態で残り、**同名では再作成できない**。すぐに作り直す場合は完全削除(purge)する:

```bash
az cognitiveservices account purge \
  --name "<di-idp-verify-xxxx>" \
  --resource-group "$RG" \
  --location "$LOCATION"
```

> リソース名にはリソースグループIDから導いたサフィックスが入るため、**リソースグループを作り直すとリソース名も変わる**(purge が不要になる代わりに、旧リソースの残骸が課金対象として残っていないか確認すること)。

---

## 付録A: 環境変数対応表(ローカル ↔ Azure)

Container Apps に設定される環境変数([infra/verify/modules/compute.bicep](../../infra/verify/modules/compute.bicep))と、ローカル `.env` の対応。

| 環境変数 | ローカル | Azure(検証環境) |
|---|---|---|
| `DATABASE_URL` | `app_user@localhost:5432` | `app_user@<psql>.postgres.database.azure.com:5432/idp?ssl=require`(シークレット) |
| `MIGRATION_DATABASE_URL` | 所有者ロール `app` | **設定しない**(マイグレーションはローカルから実行するため。未設定時は `DATABASE_URL` にフォールバック) |
| `BLOB_ACCOUNT_URL` | Azurite | `https://<st>.blob.core.windows.net/` |
| `BLOB_CONNECTION_STRING` | Azurite の開発用キー | **空**(空にすることで Managed Identity 経路になる) |
| `SERVICE_BUS_NAMESPACE` | 空 | `<sb>.servicebus.windows.net` |
| `SERVICE_BUS_CONNECTION_STRING` | エミュレータの接続文字列 | **空**(同上) |
| `DI_ENDPOINT` | 共有開発リソース | 検証環境専用リソース |
| `DI_KEY` | 受領したキー | **空**(同上。リソース側も `disableLocalAuth: true`) |
| `AZURE_CLIENT_ID` | — | ユーザ割り当てマネージドIDのクライアントID。**これが無いと `DefaultAzureCredential` がどのIDを使うか決められない** |
| `AUTH_MODE` | `local` | `local`(Entra External ID 連携は未実装) |
| `LOCAL_TENANT_ID` / `LOCAL_USER_ID` | seed 既定値 | 同じ値(`main.bicepparam`) |
| `SHARE_BASE_URL` | `http://localhost:5173/share` | `https://<swa>.azurestaticapps.net/share` |

---

## 付録B: 検証環境で割り切っている点

[azure-architecture_v2.md §4.1](../01_design/azure-architecture_v2.md#41-初期-社内でのアプリ開発顧客データなし) の「初期(社内開発)」フェーズに対応する構成。**顧客データを1件でも入れる前に §4.4 のゲート条件を満たすこと。**

| 項目 | 検証環境 | 本番想定 |
|---|---|---|
| ネットワーク | パブリックエンドポイントのみ。VNet / Private Endpoint / NSG なし | VNet 内 + PE + NSG |
| 公開接点 | SWA が全公開。IP制限なし | Front Door + WAF + APIM |
| 認証 | `AUTH_MODE=local`(JWT検証なし・全員が `tenant_admin`) | Entra External ID + APIM `validate-jwt` |
| PostgreSQL | パスワード認証 + 「Azure サービスを許可」ファイアウォール | Entra ID 認証 + Private Endpoint |
| Blob | ソフト削除・バージョニングなし | ソフト削除 + バージョニング + ZRS |
| ACR | Basic(パブリック) | Premium + PE + 脆弱性スキャン |
| ワーカー | 1レプリカ固定(KEDA スケールなし) | KEDA によるキュー長スケール |
| 監視 | Log Analytics のみ | + Defender for Cloud + アラート |

**URL を知っていれば誰でもアクセスできる状態**である点に注意。社外に共有しないこと。露出を絞りたい場合は、SWA Standard の IP 制限を `frontend/public/staticwebapp.config.json` に追加してから再デプロイする:

```json
{
  "networking": {
    "allowedIpRanges": ["203.0.113.0/24"]
  }
}
```

Managed Identity・RLS・ロール分離といった**認証方式は本番同等**にしてある(後付けの改修コストが最も高い部分のため)。

---

## 付録C: コスト目安

2026-07時点・東日本・月額USD概算。停止せず1か月動かした場合。

| リソース | 目安 | 備考 |
|---|---|---|
| Container Apps(API 最小1 + ワーカー1レプリカ常駐) | $30〜60 | 常時起動のため検証環境の主コスト |
| PostgreSQL Flexible Server B1ms + 32GB | $15〜25 | |
| Service Bus Standard | ~$10 | |
| Static Web Apps Standard | $9 | API リンクに必須 |
| Container Registry Basic | ~$5 | |
| Storage / Log Analytics | 数ドル | |
| Document Intelligence S0 | 従量 | 解析ページ数次第 |
| **合計** | **~$70〜115 + DI従量** | |

コストを抑えるには、検証しない期間に**ワーカーとAPIの最小レプリカを0にする**か、リソースグループごと削除する。

```bash
# 一時的にスケールを0に落とす(API はコールドスタートするようになる)
az containerapp update --name "$WORKER_APP_NAME" --resource-group "$RG" --min-replicas 0
az containerapp update --name "$API_APP_NAME"    --resource-group "$RG" --min-replicas 0
```

PostgreSQL は停止できる(7日で自動再開):

```bash
az postgres flexible-server stop --resource-group "$RG" --name "$(outputs postgresFqdn | cut -d. -f1)"
```

---

## 付録D: トラブルシューティング

| 症状 | 原因と対処 |
|---|---|
| デプロイが `AuthorizationFailed` (roleAssignments) で失敗 | 実行者に **ユーザー アクセス管理者** 権限がない(§2.2)。Owner 権限で実行するか、権限を付与してもらう |
| Container Apps の作成で `UNAUTHORIZED` / イメージ pull 失敗 | ロール割り当ての伝播待ち。数分待ってから `az deployment group create` を再実行する(冪等) |
| `az acr build` が遅い / タイムアウト | `backend/.dockerignore` が効かず `.venv` を送っている。`backend/` 直下で実行しているか確認 |
| `psql` が接続できない(タイムアウト) | ローカルPCのグローバルIPが変わった。`export CLIENT_IP="$(curl -s https://ifconfig.me)"` の後、§4.3 のデプロイを再実行してファイアウォールを更新する |
| `psql` が `password authentication failed` | `PG_ADMIN_PASSWORD` が §3 で生成した値と違う。控えた値を使う(不明なら `az postgres flexible-server update --admin-password` でリセット) |
| `alembic upgrade head` が `SSL connection required` | 接続URLに `?ssl=require` が付いていない |
| アプリが `permission denied for table ...` | `init-roles.sql` を流していない、またはマイグレーション後に流していない。§6.1 を再実行する(冪等) |
| 画面は出るが API が 404 | SWA と Container Apps のリンクができていない(§9)。`az staticwebapp backends show` で確認 |
| `/documents/xxx` を直接開くと 404 | `staticwebapp.config.json` が `dist/` に含まれていない。`frontend/public/` にあるか確認して再ビルド・再デプロイ |
| 状態が「解析中」から進まない | ワーカーのログを確認(§11)。多いのは ①DI のリージョンで `2024-11-30` API が使えない ②`Cognitive Services User` ロールの伝播待ち ③`AZURE_CLIENT_ID` 未設定でMI認証が失敗 |
| ワーカーログに `DefaultAzureCredential failed to retrieve a token` | `AZURE_CLIENT_ID` がユーザ割り当てマネージドIDのクライアントIDと一致しているか確認する |
| ポータルのストレージブラウザで `AuthorizationFailure` | `allowSharedKeyAccess: false` のため。認証方法を「Entra ID ユーザーアカウント」に切り替え、自分に `Storage Blob Data Reader` 以上を付与する |
| DI の解析で 401 | `disableLocalAuth: true` のためキー認証は使えない。MI 経由(`DI_KEY` 空)であることを確認する |
| 共有URLがローカルホストを指す | `SHARE_BASE_URL` は Container Apps の環境変数に焼かれている。SWA を作り直した場合は §7 の再デプロイが必要 |
