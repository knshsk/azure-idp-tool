# テナントのオンボーディング / オフボーディング

テナントを受け入れるとき・解約するときの手順書(OI-10)。

現時点では**すべて手作業**。管理画面もCLIも用意していないため、SQL と Keycloak 管理コンソール(または Admin REST API)を直接操作する。プロトタイプ段階での割り切りであり、テナント数が増えたら自動化する。

> **前提**: 操作には PostgreSQL の所有者ロール(`MIGRATION_DATABASE_URL` の接続情報)と Keycloak の管理者権限が要る。どちらも SaaS 運用者のみが持つ。

## 登場する構成要素

| 要素 | 何を作るか | どこで |
|---|---|---|
| `tenants` レコード | テナントのID・名称・データ保持期間 | PostgreSQL |
| `users` レコード | tenant_admin のユーザ。Keycloakの`sub`と紐づける | PostgreSQL |
| Keycloak バッチ用クライアント | バッチAPIのOAuth2クライアントクレデンシャル | Keycloak |
| Keycloak ユーザ / Identity Brokering | エンドユーザの認証 | Keycloak |
| Blob コンテナ | テナントの全Blob | **自動**(初回アップロード時) |
| 書類種別・転記項目定義 | テナント固有の定義 | 管理画面(tenant_admin が自分で) |
| 送信元IP制限 | WAFカスタムルールへの追加 | Bicep パラメータ |

## 1. オンボーディング

### 1-1. テナントIDを決める

UUID を1つ払い出す。以降のすべての手順でこの値を使う。

```bash
python -c "import uuid; print(uuid.uuid4())"
```

### 1-2. テナントレコードを作成する

RLS の外で行う操作のため、**所有者ロール**で接続する(アプリロール `app_user` では `tenants` に書けない)。

```sql
INSERT INTO tenants (id, name, retention_days)
VALUES ('<テナントID>', '<テナント名>', 90);
```

`retention_days` は転記完了後の自動削除までの日数。既定90日で、あとからテナント設定画面で変更できる。

### 1-3. Keycloak にバッチ用クライアントを作成する

バッチAPIの認証はテナントごとの OAuth2 クライアントクレデンシャル([azure-architecture_v2.md §4.2.1](../01_design/azure-architecture_v2.md#421-送信元ipが特定できない連携元クラウド型業務システムへの対応))。

> **重要**: レルム定義ファイル(`infra/verify/keycloak/realm-idp.json`)を編集して増やす方法は**使えない**。`--import-realm` は既存レルムがあると何もしないため、反映するには Keycloak のDBを作り直すことになり、既存テナントのユーザとセッションが全部消える。**2テナント目以降は管理コンソールか Admin REST API で作成する。**

作成する内容:

| 項目 | 値 |
|---|---|
| クライアントID | `idp-batch-<テナント識別子>` |
| Client authentication | ON(コンフィデンシャルクライアント) |
| Service accounts roles | **ON**(クライアントクレデンシャルを使うため) |
| Standard flow / Direct access grants | **OFF**(このクライアントは人間のログインに使わない) |
| Access token lifespan | `300`(5分。漏洩時の影響窓を短くする) |

さらに **protocol mapper を2つ**追加する。どちらも欠けるとバッチAPIが 401 / 403 になる。

| マッパー名 | 種別 | 設定 |
|---|---|---|
| `audience-idp-api` | Audience | Included Custom Audience = `idp-api` / Add to access token = ON |
| `tenant-id` | Hardcoded claim | Token Claim Name = `tenant_id` / Claim value = **1-1 で払い出したUUID** / Claim JSON Type = String / Add to access token = ON |

`tenant_id` クレームが API のテナント解決の唯一の入力になる([auth.py の `_resolve_batch_tenant`](../../backend/app/core/auth.py))。値を間違えると**他テナントのデータを操作できてしまう**ため、登録後に必ず 1-6 の疎通確認で実際のトークンを確認する。

Admin REST API を使う場合の例:

```bash
# 管理者トークンを取得
TOKEN=$(curl -s -X POST "$KC_URL/realms/master/protocol/openid-connect/token" \
  -d "client_id=admin-cli" -d "username=$KC_ADMIN" -d "password=$KC_ADMIN_PASSWORD" \
  -d "grant_type=password" | python -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
```

```bash
# クライアントを作成(<...> は置き換える)
curl -X POST "$KC_URL/admin/realms/idp/clients" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{
    "clientId": "idp-batch-<テナント識別子>",
    "publicClient": false,
    "serviceAccountsEnabled": true,
    "standardFlowEnabled": false,
    "directAccessGrantsEnabled": false,
    "attributes": { "access.token.lifespan": "300" },
    "protocolMappers": [
      { "name": "audience-idp-api", "protocol": "openid-connect",
        "protocolMapper": "oidc-audience-mapper",
        "config": { "included.custom.audience": "idp-api", "access.token.claim": "true", "id.token.claim": "false" } },
      { "name": "tenant-id", "protocol": "openid-connect",
        "protocolMapper": "oidc-hardcoded-claim-mapper",
        "config": { "claim.name": "tenant_id", "claim.value": "<テナントID>",
                    "jsonType.label": "String", "access.token.claim": "true",
                    "id.token.claim": "false", "userinfo.token.claim": "false" } }
    ]
  }'
```

シークレットは Keycloak が生成する。管理コンソールの Credentials タブ、または Admin REST API の `GET /admin/realms/idp/clients/{id}/client-secret` で取得し、**テナントへは安全な経路で渡す**(メール本文に平文で書かない)。

### 1-4. エンドユーザを登録する

Keycloak と `users` テーブルの両方に登録が要る。API は JWT の `sub` から `users` を引いてテナントとロールを解決するため([auth.py の `_resolve_user`](../../backend/app/core/auth.py))、`users` に無いユーザは認証が通っても **403** になる。

**Keycloak ローカルアカウントの場合**は先に Keycloak でユーザを作れば `sub`(ユーザID)がその場で分かるので、続けて `users` に入れられる。

```sql
INSERT INTO users (tenant_id, idp_subject, email, display_name, role)
VALUES ('<テナントID>', '<Keycloakのユーザid>', '<メール>', '<表示名>', 'tenant_admin');
```

**顧客IdP連携(Identity Brokering)の場合は順序が逆になる。** ブローカ経由のユーザは初回ログイン時に Keycloak 側で作られるため、`sub` を事前に知る方法がない。運用は次のようになる:

1. 対象ユーザに一度ログインしてもらう → Keycloak にはユーザが作られるが、`users` に無いのでアプリは **403** を返す
2. 運用者が Keycloak 管理コンソールでそのユーザの ID を確認する
3. 上記 SQL で `users` に登録する
4. ユーザが再ログインすると通る

初回ログインが必ず1度失敗するのは体験として良くない。ユーザ管理のスコープ(OI-19)と初回ログイン時の自動作成(GAP-F5)を決めるときに併せて解消する。それまでは**事前にこの挙動をテナントへ説明しておく**。

一般ユーザを追加する場合は `role` を `member` にする。ロールごとの権限差は[画面設計](../01_design/screen-design.md)を参照。

### 1-5. 送信元IP制限を追加する(該当する場合)

連携元の送信元IPが特定できるテナントは、WAFカスタムルールの許可リストに追加する(§4.2.1)。

`infra/env/prod.bicepparam` の `allowedSourceIpRanges` にCIDRを追記して差分デプロイする。

```bash
az deployment group create --resource-group <rg名> \
  --template-file infra/main.bicep --parameters infra/env/prod.bicepparam
```

送信元IPを特定できない連携元(D365 / Power Platform 等)はこの手順を飛ばす。OAuth2 クライアントクレデンシャルのみで受ける判断は §4.2.1 に記載済み。

### 1-6. 疎通確認

テナントへ引き渡す前に、運用者側で必ず確認する。

```bash
# トークンを取得
curl -s -X POST "$KC_URL/realms/idp/protocol/openid-connect/token" \
  -d "grant_type=client_credentials" \
  -d "client_id=idp-batch-<テナント識別子>" \
  -d "client_secret=<シークレット>"
```

取得したアクセストークンを [jwt.io](https://jwt.io) 等でデコードし、**`tenant_id` が 1-1 のUUIDと一致していること**と `aud` が `idp-api` であることを確認する。

```bash
# バッチAPIを叩く(空の一覧が返れば疎通OK)
curl -s "https://<公開ホスト名>/api/v1/batch/documents" \
  -H "Authorization: Bearer <アクセストークン>"
```

### 1-7. テナントへ引き渡す情報

| 項目 | 値 |
|---|---|
| バッチAPIエンドポイント | `https://<公開ホスト名>/api/v1/batch` |
| トークンエンドポイント | `https://<公開ホスト名>/realms/idp/protocol/openid-connect/token` |
| クライアントID | `idp-batch-<テナント識別子>` |
| クライアントシークレット | (安全な経路で) |
| アクセストークンの有効期限 | 5分。連携システム側でトークンをキャッシュ・再取得する実装にしてもらう |

エンドポイントとクライアントIDはテナント設定画面でも確認できる。シークレットは画面には出さない([screen-design.md](../01_design/screen-design.md))。

## 2. オフボーディング

**順序が重要。** `tenants` を先に消すと FK の CASCADE で関連レコードが一斉に消え、課金記録も失われる。

### 2-1. 課金記録を退避する

`di_call_logs` は `tenants` への FK が CASCADE のため、テナント削除で消える。請求・監査で残す必要があるならこの時点でエクスポートする。

```sql
COPY (SELECT * FROM di_call_logs WHERE tenant_id = '<テナントID>')
TO STDOUT WITH CSV HEADER;
```

`usage_logs` と `api_request_counters` も同様。保持の要否は契約次第。

### 2-2. Keycloak の資格情報を無効化する

データを消す前に**まず入口を閉じる**。削除作業中に連携システムからの書き込みが走ると中途半端な状態になる。

1. バッチ用クライアントを削除(または `enabled: false`)
2. 当該テナントのユーザを削除、または Identity Brokering の連携を解除

### 2-3. Blob コンテナを削除する

```bash
az storage container delete --name tenant-<テナントID> \
  --account-name <ストレージアカウント名> --auth-mode login
```

コンテナのソフトデリートを有効にしているため、削除後7日間は復旧できる。**7日経過するまで完全消滅はしない**ため、「即時完全削除」を契約で約束しないこと。

### 2-4. DBレコードを削除する

```sql
DELETE FROM tenants WHERE id = '<テナントID>';
```

`documents` / `extracted_values` / `share_links` / `usage_logs` / `di_call_logs` / `api_request_counters` / `users` / `document_types` / `transcription_fields` は FK の CASCADE で一緒に消える。

### 2-5. 送信元IP制限から外す

1-5 で追加したCIDRを `allowedSourceIpRanges` から削除して差分デプロイする。

## 3. 未整備の点

この手順書の範囲で、現状わかっている弱いところ。

| 課題 | 影響 | 対応時期 |
|---|---|---|
| すべて手作業でスクリプトがない | 手順の抜け・テナントID打ち間違いのリスク。特に `tenant_id` クレームの誤設定は**テナント越境**に直結する | テナント数が増える前 |
| Identity Brokering の初回ログインが必ず1回失敗する | 顧客への説明が必要。体験が悪い | OI-19 / GAP-F5 と併せて |
| `users` への登録がSQL直打ち | 監査証跡が残らない | 同上 |
| 削除の完了確認手段がない | 「完全に消えたか」をテナントへ示せない | 契約・説明責任の観点で要検討 |
| Blob コンテナは初回アップロード時に自動作成される | オンボーディング時点では存在しない。[blob-storage.md](../01_design/blob-storage.md) の「オンボーディング時に作成する」という記述と実装([blob.py の `upload_bytes`](../../backend/app/clients/blob.py))がずれている | 記述の修正で足りる |
