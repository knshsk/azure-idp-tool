# 開発環境(ドラフト)

> **注**: 本ドキュメントの内容は構築手順と統合した [setup-guide.md](setup-guide.md) に反映済み。新規メンバのセットアップはそちらを参照。

前提: **Windows 11 + VS Code**。コンテナは**WSL2上のDocker Engine(docker-ce)**で動かし、Docker Desktopは使用しない(商用ライセンス対象のため)。社内認証プロキシ配下での開発を前提とする。

ローカルでエミュレートできるものはコンテナで動かし、できないもの(Document Intelligence)だけ開発用Azureリソースを共有する方針。

## 開発スタイルの基本方針

- **開発作業はWSL内に寄せる**: リポジトリはWSL側ファイルシステム(`~/dev/azure-idp-tool`)にcloneし、VS Codeは**Remote - WSL**で開く
  - Windows側(`/mnt/c/...`)にコードを置くとファイルI/Oが著しく遅く、改行コード・パス問題も起きやすいため避ける
- Node.js / Python / uv / Azure CLI / Docker はすべてWSL(Ubuntu)内にインストールする。Windows側に開発ランタイムは入れない
- WSL内で起動したサーバ(Vite :5173 / FastAPI :8000)には、Windows側のブラウザから`localhost`でそのままアクセスできる
- WSLのネットワークは`networkingMode=mirrored`(`.wslconfig`)を推奨【仮】。Windows⇔WSL間のlocalhost共有が双方向になり、ネットワーク周りのトラブルシューティングが単純になる

## 必要ツール

### Windows側

| ツール | 用途 |
|---|---|
| WSL2 + Ubuntu 24.04 LTS | 開発環境本体(`wsl --install -d Ubuntu-24.04`) |
| VS Code + Remote Development拡張 | エディタ。WSL内のリポジトリをRemote - WSLで開く |

### WSL(Ubuntu)側

| ツール | バージョン | 用途 |
|---|---|---|
| git | 最新 | |
| Node.js | 22 LTS | フロントエンド(npm使用。nvm等でインストール) |
| Python | 3.14 | バックエンド(uvでインストール。Ubuntu標準の3.12は使わない) |
| uv | 最新 | Pythonパッケージ管理 |
| Docker Engine(docker-ce)+ Compose plugin | 最新 | PostgreSQL / Azurite / Service Busエミュレータ。公式aptリポジトリから導入し、`sudo systemctl enable docker`で常駐させる |
| Azure CLI | 最新 | 開発用Azureリソース操作・Bicepデプロイ(`az bicep`含む) |

VS Code拡張(推奨): WSL / Vue - Official(Volar)/ ESLint / Prettier / Python / Ruff / Bicep / Mermaid Preview

## 社内認証プロキシへの対応

プロキシ設定は「WSL本体」「各ツール」「Dockerデーモン」の3層すべてに必要になる。設定値はチームの環境情報(プロキシホスト・ポート・除外ドメイン)を受領して使う。

### 認証方式(確定): Basic認証・URL埋め込み

社内プロキシはBasic認証(URL埋め込み)で通ることを確認済み。プロキシURLは資格情報込みの形式で指定する:

```
http://<ユーザ名>:<パスワード>@proxy.example.co.jp:8080
```

- パスワードに記号が含まれる場合はURLエンコードする(`@`→`%40`、`#`→`%23`など)
- 資格情報が平文で残るため、設定先は自分しか読めない場所に限定する(`/etc/environment`や`~/.bashrc`。**リポジトリ内のファイルには絶対に書かない**)
- パスワード変更(定期変更ポリシー等)のたびに設定箇所一覧の全箇所を更新する必要がある点に注意

### 設定箇所一覧

以下、プロキシURLを`$PROXY`(上記の資格情報込みURL)とする。

| 対象 | 設定方法 |
|---|---|
| WSL全体(環境変数) | `/etc/environment`または`~/.bashrc`に`HTTP_PROXY` / `HTTPS_PROXY` / `NO_PROXY`を設定。小文字版(`http_proxy`等)も両方定義する |
| apt | `/etc/apt/apt.conf.d/95proxy`に`Acquire::http::Proxy "$PROXY";`(https同様) |
| Dockerデーモン(イメージpull) | systemdドロップイン`/etc/systemd/system/docker.service.d/http-proxy.conf`の`[Service] Environment=`に設定し`systemctl daemon-reload && systemctl restart docker` |
| コンテナ内・docker build | `~/.docker/config.json`の`proxies`に設定(コンテナへ自動伝播) |
| npm / uv / pip / git / Azure CLI | 環境変数(`HTTP_PROXY`等)を参照するため個別設定は原則不要。効かない場合のみ個別設定を追加 |

`NO_PROXY`には最低限`localhost,127.0.0.1`と社内ドメインを入れる(ローカルのAPI・エミュレータ通信がプロキシに吸われるのを防ぐ)。

- WSLにはWindowsのプロキシ設定を自動反映する`autoProxy`機能もあるが、認証付きプロキシでは結局資格情報の扱いが必要になるため、本ドキュメントでは明示設定を基本とする

### SSLインスペクション(社内CA)がある場合【要確認】

プロキシがHTTPSを復号・再署名する環境では、社内ルートCA証明書を各層に登録しないと証明書エラーになる:

- WSL OS: `/usr/local/share/ca-certificates/`に配置して`sudo update-ca-certificates`
- Node.js: `NODE_EXTRA_CA_CERTS=<CAファイルパス>`
- Python(uv / pip / requests): `SSL_CERT_FILE` / `REQUESTS_CA_BUNDLE`
- Dockerデーモン: OSのCAストア反映後にdocker再起動

社内プロキシがSSLインスペクションを行うかどうかをチームに確認し、必要ならCA証明書の入手経路をonboardingに追記する。

## ローカル実行構成

すべてWSL内で動作する。Windows側からは`localhost`でアクセスする。

```
[Windows] ブラウザ / VS Code(Remote - WSL)
              | localhost
==============|=========================== WSL2 (Ubuntu) ===
+--------------------+     +---------------------+
| Vite devサーバ      | --> | FastAPI (uvicorn)   |
| localhost:5173     |     | localhost:8000      |
| (APIは/apiをproxy) |     +----------+----------+
+--------------------+                |
                          +-----------+------------+----------------+
                          v           v            v                v
                    PostgreSQL    Azurite     Service Bus      Document
                    (Docker)     (Docker)     エミュレータ      Intelligence
                    :5432        :10000-2     (Docker) :5672   ※開発用Azure
                                                                リソースを共有
+--------------------+                                          (プロキシ経由)
| ワーカー(別プロセス)| --> 同上(キュー消化・DI解析・候補取り込み)
+--------------------+
```

- ルートの`docker-compose.yml`【仮: 実装開始時に作成】で PostgreSQL / Azurite / Service Busエミュレータ を一括起動する
- Document Intelligenceはローカルエミュレータが存在しないため、開発用リソース(S0)をチームで共有する。エンドポイント・キーは`.env`に設定(**バックエンドからの外向き通信なのでプロキシ・CA設定の影響を受ける点に注意**)
- 認証(Entra External ID): ローカル開発では`AUTH_MODE=local`でJWT検証をスキップし、環境変数で指定したダミーユーザ・テナントとして動作する【仮】。External ID連携の動作確認は開発用テナントで行う

## 環境変数

`backend/.env.example`をコミットし、各自コピーして`.env`を作成する。主要なもの:

| 変数 | ローカルの値(例) | 説明 |
|---|---|---|
| `DATABASE_URL` | `postgresql+asyncpg://app_user:app@localhost:5432/idp` | ランタイム用。RLS適用対象のアプリロールで接続(`app_user`は`docker/postgres-init/01-roles.sql`で作成) |
| `MIGRATION_DATABASE_URL` | `postgresql+asyncpg://app:app@localhost:5432/idp` | Alembicマイグレーション・シード用。所有者ロールで接続 |
| `BLOB_ACCOUNT_URL` | Azuriteの接続情報 | 本番はManaged Identity |
| `SERVICE_BUS_NAMESPACE` | ローカルエミュレータの接続情報 | 本番はManaged Identity |
| `DI_ENDPOINT` / `DI_KEY` | 開発用リソースの値 | キーは各自受領。**コミット禁止** |
| `AUTH_MODE` | `local` | `local`=認証スキップ / `entra`=JWT検証 |
| `LOCAL_TENANT_ID` / `LOCAL_USER_ID` / `LOCAL_USER_ROLE` | シード投入したテナントID / ユーザID / `tenant_admin` | `AUTH_MODE=local`時のダミー認証情報 |

フロントエンドは`frontend/.env.example`(APIベースURL等)。プロキシ関連(`HTTP_PROXY`等)は`.env`ではなくシェル環境(`/etc/environment`等)で管理する。

## 開発用Azureリソース

| リソース | 扱い |
|---|---|
| Document Intelligence(S0) | 共有。SaaS運用者(リポジトリ管理者)が払い出し、キーを開発メンバに配布 |
| Entra External ID(開発テナント) | 認証フローの動作確認用。通常のローカル開発では不要(`AUTH_MODE=local`) |
| dev環境一式(Bicepデプロイ) | 結合確認用。個人ごとには作らず共有dev環境を1つ維持する【仮】 |

- ローカルで完結しない検証(APIM・VNet・Private Endpoint)はdev環境で行う
- dev環境はAPIM Standard v2を含み固定費が高いため、不要期間の削除・再デプロイをBicepで容易にしておく

## シードデータ

`backend/scripts/seed.py`【仮: 実装開始時に作成】で以下を投入する:

- 開発用テナント1件(`LOCAL_TENANT_ID`に設定して使う)
- 書類種別「見積書」+転記項目定義(取引日付・取引先名・合計金額)。転記項目はヘッダ項目のみ(品名・数量・単価などの明細列は項目定義を持たない)
- サンプルPDF(`backend/tests/fixtures/`に同梱)数点
