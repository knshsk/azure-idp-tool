# 開発規約(ドラフト)

プロトタイピング段階の規約。原則は「ツールに強制させられるものはツールに任せ、人間はレビューで設計を見る」。

## Git運用

- ブランチモデル: GitHub Flow(`main` + 作業ブランチ)
  - ブランチ名: `feature/<内容>` / `fix/<内容>` / `docs/<内容>`(例: `feature/upload-api`)
  - `main`へはPull Request経由でマージ。ただしプロトタイプ期の軽微な修正はmain直コミット許容【仮】
- コミットメッセージ: 日本語で簡潔に「何をしたか」を1行目に書く。プレフィックス(feat/fix等)は必須としない【仮】
- コミット禁止物: シークレット(APIキー・接続文字列)、`.env`、生成物(`dist/`, `__pycache__/`等)。`.env`は`.env.example`をコミットして実体は各自作成
- PRレビュー: 1名承認でマージ可。プロトタイプ期はセルフマージ許容【仮】

## モノレポ共通

- ルートに`.editorconfig`を置き、改行LF・UTF-8・末尾空白除去を統一
- 各パッケージ(`frontend/` `backend/` `infra/`)は独立してビルド・実行できること
- ドキュメントは日本語。コード内の識別子・コメントは以下の言語規約に従う

## フロントエンド(Vue 3 + TypeScript)

| 項目 | 規約 |
|---|---|
| TypeScriptバージョン | 6.x(JS実装系の最終メジャー。Go製ネイティブの7系はvue-tsc/Volarが対応するまで移行しない。2026-07時点で7.0はVueツーリング未対応) |
| ツール | ESLint + Prettier(設定はリポジトリにコミットし、CIとエディタ保存時に適用) |
| コンポーネント | Composition API + `<script setup lang="ts">`のみ。Options APIは使わない |
| 命名 | コンポーネント: PascalCase / composables: `useXxx` / Piniaストア: `useXxxStore` |
| ディレクトリ | `src/components`(汎用)/ `src/pages`(ルート単位)/ `src/stores` / `src/api`(APIクライアント層)/ `src/composables` |
| API呼び出し | コンポーネントから直接fetchしない。`src/api`のクライアント関数(型付き)を経由する |
| 型 | `any`禁止(やむを得ない場合は`// eslint-disable`+理由コメント)。APIレスポンス型は`src/api/types`に集約【仮: OpenAPIからの自動生成を検討】 |
| UI | Vuetify3のコンポーネントを素で使い、独自CSSは最小限にする |

## バックエンド(Python + FastAPI)

| 項目 | 規約 |
|---|---|
| Pythonバージョン | 3.14 |
| パッケージ管理 | uv(`pyproject.toml` + `uv.lock`をコミット) |
| Lint/Format | Ruff(lint + format両方)。設定は`pyproject.toml` |
| 型 | 型ヒント必須。Pydantic v2でAPIスキーマ定義。mypy等の型チェッカ導入は【仮: 実装初期に判断】 |
| ディレクトリ | `app/routers`(エンドポイント)/ `app/services`(業務ロジック)/ `app/models`(SQLAlchemy)/ `app/schemas`(Pydantic)/ `app/worker`(キュー消化処理) |
| DB | SQLAlchemy 2.0 + Alembic(マイグレーションは必ずAlembicで生成しコミット) |
| 命名 | モジュール・関数: snake_case / クラス: PascalCase。DBテーブル・列は設計書(data-model.md)の定義に従う |
| 例外 | ハンドラで共通エラー形式(api-design.md)に変換。素の500をクライアントに返さない |
| ログ | 標準loggingで構造化(JSON)出力。`tenant_id` / `document_id`を必ず含める |

- APIとワーカーは同一パッケージ・同一イメージで、起動コマンドで役割を切り替える(設計書の決定事項)

## IaC(Bicep)

- リソース命名はCloud Adoption Frameworkの略語規則に従う(例: `ca-`(Container Apps)、`psql-`、`st`、`agw-`(Application Gateway))+ `<app>-<env>`
- 環境差分は`.bicepparam`ファイル(`dev` / `prod`)で表現し、テンプレート本体に環境分岐を書かない
- モジュール分割はazure-architecture.mdの想定(ネットワーク/データ/AI/コンピュート/Application Gateway+WAF/監視)に従う

## テスト方針(プロトタイプ期)

- 網羅は目指さない。**壊れると発見が遅れるロジックに絞って**ユニットテストを書く:
  - バックエンド(pytest): 値の正規化(日付・数値)、座標変換、明細テーブルの構造化(DI検出テーブル→行×列への整形)
  - フロントエンド(Vitest): 座標変換・オーバレイ描画のユーティリティのみ【仮】
- E2Eテストはプロトタイプ期はスコープ外
- CI(GitHub Actions): PRでlint + ユニットテストを実行【仮: 実装開始時にワークフロー整備】
