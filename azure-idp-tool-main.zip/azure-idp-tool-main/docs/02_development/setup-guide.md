# 開発環境セットアップガイド(新規メンバ向け)

新規加入メンバが開発を始められる状態になるまでの手順を、環境の背景説明も含めて1本にまとめた統合ガイド。
[dev-environment.md](dev-environment.md)(環境構成のリファレンス)と [onboarding.md](onboarding.md)(手順の要約)の内容を統合・詳細化したもの。

- **所要時間目安**: 半日(プロキシ設定のはまり具合による)
- **前提**: Windows 11 + 社内認証プロキシ配下。手順は上から順に実施する(特にプロキシ設定を飛ばすと以降が全滅する)

## 目次

1. [全体像を理解する](#1-全体像を理解する)
2. [事前に受領するもの](#2-事前に受領するもの)
3. [Windows側のセットアップ](#3-windows側のセットアップ)
4. [プロキシ設定(最重要)](#4-プロキシ設定最重要)
5. [開発ツールのインストール(WSL内)](#5-開発ツールのインストールwsl内)
6. [リポジトリのクローンとVS Code](#6-リポジトリのクローンとvs-code)
7. [ローカルインフラの起動](#7-ローカルインフラの起動)
8. [バックエンドのセットアップ](#8-バックエンドのセットアップ)
9. [フロントエンドのセットアップ](#9-フロントエンドのセットアップ)
10. [動作確認(スモークテスト)](#10-動作確認スモークテスト)
11. [開発を始める前に](#11-開発を始める前に)
12. [日常の開発フロー(2日目以降)](#12-日常の開発フロー2日目以降)
13. [トラブルシューティング](#13-トラブルシューティング)
- [付録A: 環境変数リファレンス](#付録a-環境変数リファレンス)
- [付録B: 開発用Azureリソース](#付録b-開発用azureリソース)

---

## 1. 全体像を理解する

### 開発スタイルの基本方針

- **開発作業はすべてWSL内に寄せる**。リポジトリはWSL側ファイルシステム(`~/dev/azure-idp-tool`)にcloneし、VS Codeは **Remote - WSL** で開く
  - Windows側(`/mnt/c/...`)にコードを置くとファイルI/Oが著しく遅く、改行コード・パス問題も起きやすいため避ける
- Node.js / Python / uv / Azure CLI / Docker はすべてWSL(Ubuntu)内にインストールする。**Windows側に開発ランタイムは入れない**
- コンテナは **WSL2上のDocker Engine(docker-ce)** で動かす。**Docker Desktopは使用しない**(商用ライセンス対象のため)
- ローカルでエミュレートできるもの(PostgreSQL / Blob Storage / Service Bus)はコンテナで動かし、エミュレータが存在しないDocument Intelligenceだけ開発用Azureリソースをチームで共有する
- WSL内で起動したサーバ(Vite :5173 / FastAPI :8000)には、Windows側のブラウザから`localhost`でそのままアクセスできる

### ローカル実行構成

```
[Windows] ブラウザ / VS Code(Remote - WSL)
              | localhost
==============|=========================== WSL2 (Ubuntu) ===
+--------------------+     +---------------------+
| Vite devサーバ      | --> | FastAPI (uvicorn)   |
| localhost:5173     |     | localhost:8000      |
| (APIは/apiをproxy) |     +----------+----------+
+--------------------+                |
                          +-----------+------------+----------------+
                          v           v            v                v
                    PostgreSQL    Azurite     Service Bus      Document
                    (Docker)     (Docker)     エミュレータ      Intelligence
                    :5432        :10000-2     (Docker) :5672   ※開発用Azure
                                                                リソースを共有
+--------------------+                                          (プロキシ経由)
| ワーカー(別プロセス)| --> 同上(キュー消化・DI解析・候補取り込み)
+--------------------+
```

- ローカル依存サービスはリポジトリルートの [docker-compose.yml](../../docker-compose.yml) で一括起動する(Service BusエミュレータはSQL Serverコンテナに依存するため、mssqlコンテナも一緒に上がる)
- 認証(Keycloak)はローカル開発では `AUTH_MODE=local` でJWT検証をスキップし、`.env` で指定したダミーユーザ・テナントとして動作する。認証フローそのものを確認したい場合のみ Keycloak を起動して `AUTH_MODE=keycloak` に切り替える(クラウド上の開発用テナントは不要。手順は §7.5)

---

## 2. 事前に受領するもの

チーム(リポジトリ管理者)から以下を受け取ってから着手する:

- [ ] GitHubリポジトリへのアクセス権
- [ ] 開発用Document Intelligenceのエンドポイント・キー
- [ ] 社内プロキシの接続情報一式:
  - プロキシホスト・ポート
  - Basic認証のユーザ名 / パスワード
  - 除外ドメイン(`NO_PROXY`に設定する社内ドメイン)
  - SSLインスペクションの有無(ありの場合は社内CA証明書ファイル)
- [ ] (必要な場合のみ)共有dev環境のURL

---

## 3. Windows側のセットアップ

### 3.1 WSL2 + Ubuntuのインストール

PowerShellを**管理者権限**で開き:

```powershell
wsl --install -d Ubuntu-24.04
```

再起動後、Ubuntuの初回起動でユーザ名・パスワードを設定する。

### 3.2 WSLのネットワーク設定【仮】

`%UserProfile%\.wslconfig` を作成(または追記)する:

```ini
[wsl2]
networkingMode=mirrored
```

`networkingMode=mirrored` によりWindows⇔WSL間のlocalhost共有が双方向になり、ネットワーク周りのトラブルシューティングが単純になる。設定後は `wsl --shutdown`(PowerShell)でWSLを再起動して反映する。

### 3.3 VS Code

1. Windows側にVS Codeをインストールする
2. 拡張「**Remote Development**」(`ms-vscode-remote.vscode-remote-extensionpack`)をインストールする

Windows側に入れるのはここまで。以降の作業はすべてWSL(Ubuntu)内のターミナルで行う。

---

## 4. プロキシ設定(最重要)

**これをやらないと以降のapt / npm / uv / docker pullが全部失敗する。** プロキシ設定は「WSL本体」「各ツール」「Dockerデーモン」の3層すべてに必要になる。

### 4.1 プロキシURLの組み立て

社内プロキシはBasic認証(URL埋め込み)で通ることを確認済み。受領した資格情報からプロキシURLを組み立てる:

```
http://<ユーザ名>:<パスワード>@proxy.example.co.jp:8080
```

パスワードに記号が含まれる場合は**URLエンコード**する:

| 記号 | エンコード | 記号 | エンコード |
|---|---|---|---|
| `@` | `%40` | `#` | `%23` |
| `:` | `%3A` | `/` | `%2F` |
| `%` | `%25` | `&` | `%26` |

**取り扱い上の注意**:

- 資格情報が平文で残るため、設定先は自分しか読めない場所に限定する(`/etc/environment`や`~/.bashrc`)。**リポジトリ内のファイルには絶対に書かない**
- パスワード変更(定期変更ポリシー等)のたびに、本節の設定箇所**全部**を更新する必要がある。設定した場所を控えておくこと

以降、この資格情報込みURLを `$PROXY` と表記する。

### 4.2 WSL全体(環境変数)

`/etc/environment` に追記する(`sudo`で編集。大文字・小文字の両方を定義する — ツールによって参照する側が異なるため):

```
HTTP_PROXY=http://<ユーザ名>:<パスワード>@proxy.example.co.jp:8080
HTTPS_PROXY=http://<ユーザ名>:<パスワード>@proxy.example.co.jp:8080
NO_PROXY=localhost,127.0.0.1,<社内ドメイン>
http_proxy=http://<ユーザ名>:<パスワード>@proxy.example.co.jp:8080
https_proxy=http://<ユーザ名>:<パスワード>@proxy.example.co.jp:8080
no_proxy=localhost,127.0.0.1,<社内ドメイン>
```

- `NO_PROXY` には最低限 `localhost,127.0.0.1` と受領した社内ドメインを入れる。**これが漏れるとローカルのAPI・エミュレータ通信がプロキシに吸われて疎通しなくなる**
- 反映にはWSLの再ログイン(ターミナルを開き直す)が必要。`echo $HTTP_PROXY` で入っていることを確認する
- WSLにはWindowsのプロキシ設定を自動反映する`autoProxy`機能もあるが、認証付きプロキシでは結局資格情報の扱いが必要になるため、本プロジェクトでは明示設定を基本とする

### 4.3 apt

`/etc/apt/apt.conf.d/95proxy` を作成する:

```
Acquire::http::Proxy "$PROXY";
Acquire::https::Proxy "$PROXY";
```

(`$PROXY` は実際のURLに置き換える)

確認: `sudo apt update` が通ればOK。

### 4.4 Dockerデーモン(イメージpull用)

**Dockerデーモンは環境変数を見ない**ため、systemdドロップインで別途設定する。Docker Engine本体のインストール([5.4](#54-docker-enginedocker-ce))後に実施:

```bash
sudo mkdir -p /etc/systemd/system/docker.service.d
sudo tee /etc/systemd/system/docker.service.d/http-proxy.conf << 'EOF'
[Service]
Environment="HTTP_PROXY=$PROXY"
Environment="HTTPS_PROXY=$PROXY"
Environment="NO_PROXY=localhost,127.0.0.1,<社内ドメイン>"
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

(ヒアドキュメント内の `$PROXY` は実際のURLに置き換える)

### 4.5 コンテナ内・docker build用

`~/.docker/config.json` に設定するとコンテナへ自動伝播する:

```json
{
  "proxies": {
    "default": {
      "httpProxy": "$PROXY",
      "httpsProxy": "$PROXY",
      "noProxy": "localhost,127.0.0.1,<社内ドメイン>"
    }
  }
}
```

### 4.6 その他のツール

npm / uv / pip / git / Azure CLI は環境変数(`HTTP_PROXY`等)を参照するため**個別設定は原則不要**。効かない場合のみ個別設定を追加する(例: `npm config set proxy $PROXY`)。

### 4.7 SSLインスペクション(社内CA)がある場合【要確認】

プロキシがHTTPSを復号・再署名する環境では、社内ルートCA証明書を各層に登録しないと証明書エラー(`SELF_SIGNED_CERT_IN_CHAIN`等)になる:

```bash
# WSL OSのCAストアに登録
sudo cp <社内CA証明書>.crt /usr/local/share/ca-certificates/
sudo update-ca-certificates
```

さらにランタイムごとに環境変数を設定する(`~/.bashrc`等):

| 対象 | 設定 |
|---|---|
| Node.js | `NODE_EXTRA_CA_CERTS=<CAファイルパス>` |
| Python(uv / pip / requests) | `SSL_CERT_FILE=<CAファイルパス>` / `REQUESTS_CA_BUNDLE=<CAファイルパス>` |
| Dockerデーモン | OSのCAストア反映後に `sudo systemctl restart docker` |

SSLインスペクションの有無はチームに確認する(事前受領物に含まれる)。

### 4.8 疎通確認

```bash
curl -I https://github.com          # プロキシ経由の外向きHTTPS
sudo apt update                     # apt
```

両方通れば次へ進む。

---

## 5. 開発ツールのインストール(WSL内)

すべてWSL(Ubuntu)内のターミナルで実施する。バージョン方針:

| ツール | バージョン | 用途 |
|---|---|---|
| git | 最新 | |
| Node.js | 22 LTS | フロントエンド(npm使用) |
| Python | 3.14 | バックエンド(**Ubuntu標準の3.12は使わない**) |
| uv | 最新 | Pythonパッケージ管理・Python本体の導入 |
| Docker Engine(docker-ce)+ Compose plugin | 最新 | ローカル依存サービス |
| Azure CLI | 最新 | 開発用Azureリソース操作・Bicepデプロイ。**venv版を使う**(apt版は社内ネットワークで接続不可。§5.5) |

### 5.1 git

```bash
sudo apt install -y git
git config --global user.name "<名前>"
git config --global user.email "<メールアドレス>"
```

### 5.2 Node.js 22(nvm経由)

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
# ターミナルを開き直すか source ~/.bashrc
nvm install 22
node -v   # v22.x
```

### 5.3 uv + Python 3.14

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
# ターミナルを開き直すか source ~/.bashrc
uv python install 3.14
```

Pythonの仮想環境・依存関係はすべてuvが管理する(`uv sync`)。システムPythonは触らない。

### 5.4 Docker Engine(docker-ce)

公式aptリポジトリから導入する(Ubuntuの`docker.io`パッケージではなく公式の`docker-ce`を使う):

```bash
# 公式GPGキーとリポジトリの登録
sudo apt install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
  https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update

# 本体 + Composeプラグイン
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 常駐化と自ユーザのdockerグループ追加
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
```

グループ追加の反映にはターミナルの開き直し(または`newgrp docker`)が必要。

**この時点で [4.4 Dockerデーモンのプロキシ設定](#44-dockerデーモンイメージpull用) と [4.5](#45-コンテナ内docker-build用) を実施する**(忘れるとイメージpullが失敗する)。

確認:

```bash
docker run --rm hello-world
```

### 5.5 Azure CLI(venv版)

**本開発では Azure CLI を venv 版に統一する。** apt / 公式インストールスクリプト版(`curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash`)は**社内ネットワークでは使えない**。

社内のインスペクション装置が `login.microsoftonline.com`(Entra ID の認証エンドポイント)を復号しており、そこで提示される暗号スイートが TLS 1.2 / `AES256-GCM-SHA384`(前方秘匿性なし)のみのため、同梱 Python がこれを除外している apt 版は TLS ハンドシェイクが成立しない。システムの Python はこの暗号スイートを許容するので、venv に `pip` で入れれば接続できる。

```bash
sudo apt install -y python3-venv python3-dev build-essential libffi-dev libssl-dev

python3 -m venv ~/.venvs/azure-cli
# PyPIも復号対象のためpipにも社内CAを明示する(pipは独自のcertifiを使い、システムストアを見ない)
~/.venvs/azure-cli/bin/pip install --upgrade pip --cert /etc/ssl/certs/ca-certificates.crt
~/.venvs/azure-cli/bin/pip install azure-cli --cert /etc/ssl/certs/ca-certificates.crt
```

`~/.bashrc` に以下を追加する(`REQUESTS_CA_BUNDLE` はハンドシェイク成立後の証明書検証に必要):

```bash
export PATH="$HOME/.venvs/azure-cli/bin:$PATH"
export REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt
```

```bash
which az           # ~/.venvs/azure-cli/bin/az であること
az bicep install   # Bicepデプロイ用
```

> この症状は**アクセストークンが切れるまで表面化しない**(それまでは復号対象外の `management.azure.com` としか通信しない)。作業の途中で突然 `SSLV3_ALERT_HANDSHAKE_FAILURE` が出た場合はこれを疑う。切り分け手順は
> [verify-deployment-guide.md 付録D](../03_deployment/verify-deployment-guide.md#付録d-トラブルシューティング)。

---

## 6. リポジトリのクローンとVS Code

**WSL側ファイルシステム**にcloneする(`/mnt/c/`配下はNG):

```bash
mkdir -p ~/dev && cd ~/dev
git clone <リポジトリURL> azure-idp-tool
cd azure-idp-tool
code .   # Remote - WSLでVS Codeが開く
```

VS Codeが開いたら、右下に出る「推奨拡張機能をインストールしますか?」に従い [.vscode/extensions.json](../../.vscode/extensions.json) の推奨拡張を一括インストールする:

WSL / Vue - Official(Volar)/ ESLint / Prettier / Python / Ruff / Bicep / Markdown Mermaid

---

## 7. ローカルインフラの起動

リポジトリルートで:

```bash
docker compose up -d
```

起動するコンテナ:

| コンテナ | イメージ | ポート | 用途 |
|---|---|---|---|
| idp-postgres | postgres:16 | 5432 | アプリDB。初回起動時に`docker/postgres-init/01-roles.sql`でRLS用アプリロール(`app_user`)を作成 |
| idp-azurite | azurite | 10000-10002 | Blob Storageエミュレータ(Queue/Tableは未使用) |
| idp-mssql | mssql/server:2022 | (非公開) | Service Busエミュレータの内部DB |
| idp-servicebus | servicebus-emulator | 5672 | Service Busエミュレータ(interactive / batchキュー) |

確認:

```bash
docker compose ps   # 4コンテナがすべてUp(postgresはhealthy)になること
```

初回はイメージpullで数分かかる。pullが失敗する場合はDockerデーモンのプロキシ設定([4.4](#44-dockerデーモンイメージpull用))を確認する。

---

## 8. バックエンドのセットアップ

```bash
cd ~/dev/azure-idp-tool/backend

# 1. 依存関係のインストール(Python 3.14の仮想環境も自動作成される)
uv sync

# 2. 環境変数ファイルの作成
cp .env.example .env
```

`.env` を編集し、**受領したDocument Intelligenceの値**を設定する(それ以外はデフォルトのままでローカル開発可能):

```
DI_ENDPOINT=<受領したエンドポイント>
DI_KEY=<受領したキー>
```

`DI_KEY`はコミット禁止(`.env`は`.gitignore`済み)。続けて:

```bash
# 3. DBマイグレーション
uv run alembic upgrade head

# 4. シードデータ投入(冪等。何度実行しても安全)
uv run python scripts/seed.py
```

シードは `.env` の `LOCAL_TENANT_ID` のIDで開発テナントを作成し、書類種別「見積書」+転記項目定義(取引日付・取引先名・合計金額)、`AUTH_MODE=local` 用の開発ユーザを投入する。

### 起動確認

ターミナルを2つ開き:

```bash
# ターミナル1: APIサーバ
uv run uvicorn app.main:app --reload --port 8000

# ターミナル2: ワーカー(キュー消化・DI解析・候補取り込み)
uv run python -m app.worker.main
```

Windows側ブラウザで http://localhost:8000/docs を開き、Swagger UIが表示されればOK。

> **DB接続が2系統ある理由**: ランタイムはRLS(Row Level Security)適用対象のアプリロール`app_user`で接続し(`DATABASE_URL`)、マイグレーション・シードはRLSの外で動く所有者ロール`app`で接続する(`MIGRATION_DATABASE_URL`)。詳細は [backend/README.md](../../backend/README.md)。

---

## 9. フロントエンドのセットアップ

```bash
cd ~/dev/azure-idp-tool/frontend
npm install
cp .env.example .env   # デフォルト(VITE_API_BASE_URL=/api)のままでよい
npm run dev
```

Windows側ブラウザで http://localhost:5173 を開き、画面が表示されればOK(`AUTH_MODE=local`のためログイン画面はスキップされる)。APIへのリクエストはViteのproxy設定で`localhost:8000`へ転送される。

---

## 10. 動作確認(スモークテスト)

APIサーバ・ワーカー・フロントエンドがすべて起動した状態で:

1. メイン操作画面から `backend/tests/fixtures/` のサンプルPDFをアップロードする(書類種別: 見積書)
2. 状態が「解析中」→「解析済」に変わること(ワーカーとDocument Intelligenceの疎通確認。プロキシ経由の外向き通信なので、ここで初めてプロキシ/CA設定の問題が顕在化することがある)
3. 転記確定画面でオーバレイが表示されること

**ここまで通れば環境構築完了。**

---

## 10.5 (任意)Keycloak で認証フローを確認する

通常の開発では不要。`AUTH_MODE=local` がJWT検証をスキップするため、Keycloak を起動しなくてもアプリは動く。**認証フローそのものを触るときだけ**立てる。

Keycloak は `docker-compose.yml` で `auth` プロファイルに入れてあるので、`docker compose up -d` では起動もビルドもされない。

```bash
docker compose --profile auth up -d
```

初回はイメージのビルド(1〜2分)と Keycloak の起動(30秒前後)がかかる。ビルドしているのは [infra/verify/keycloak/](../../infra/verify/keycloak/) で、**検証環境の Azure と同じイメージ定義**。レルム定義も同梱されているため、起動しただけでレルムとクライアントが構成される。

| 項目 | 値 |
|---|---|
| 管理コンソール | http://localhost:8080/admin (`admin` / `admin`) |
| レルム | `idp` |
| クライアント | `idp-frontend`(パブリック・Authorization Code + PKCE(S256))<br>`idp-batch-dev`(機密・クライアントクレデンシャル。バッチAPI用) |
| issuer | `http://localhost:8080/realms/idp` |
| audience(`aud`) | `idp-api`(両クライアントの audience マッパーが載せる。API側の `OIDC_AUDIENCE` と揃える) |

起動を確認する:

```bash
curl -s http://localhost:8080/realms/idp/.well-known/openid-configuration | head -c 120
```

そのうえで `backend/.env` の `AUTH_MODE` を `keycloak` に変えて API を再起動する(`OIDC_ISSUER` / `OIDC_AUDIENCE` は `.env.example` の既定値のままでよい)。

> **以前に Keycloak を起動したことがある場合は、レルムを取り込み直す必要がある。** `--import-realm` は既存レルムがあると何もしないため、`aud` が古い値(`idp-frontend`)のまま出続けて `401 invalid_token` になる。`keycloak` データベースを作り直す(**そのレルムのユーザも消える。アプリDB `idp` は影響を受けない**):
>
> ```bash
> docker compose stop keycloak
> docker exec idp-postgres psql -U app -d idp -c 'DROP DATABASE keycloak;'
> docker exec -i idp-postgres psql -U app -d idp < docker/postgres-init/02-keycloak.sql
> docker compose --profile auth up -d keycloak
> ```
>
> `CREATE ROLE keycloak_user` は既存ロールがあるとエラーになるが、その行だけ失敗して後続は流れるので無視してよい。

そのうえで**バックエンドとフロントエンドの両方**を keycloak モードに切り替える。片方だけだと噛み合わない。

```bash
# backend/.env
AUTH_MODE=keycloak

# frontend/.env
VITE_AUTH_MODE=keycloak
```

フロントエンドは環境変数をビルド時に読むため、`.env` を変えたら `npm run dev` を再起動する。

#### バッチAPI(`/batch/*`)を keycloak モードで叩く

バッチAPIはブラウザを介さず、クライアントクレデンシャルで取得した短命トークンを使う。テナントはトークンの `tenant_id` クレームから解決されるため、ヘッダでテナントを渡す必要はない(渡しても読まれない)。

```bash
curl -s -X POST http://localhost:8080/realms/idp/protocol/openid-connect/token -d grant_type=client_credentials -d client_id=idp-batch-dev -d client_secret=local-dev-batch-secret
```

応答の `access_token` を `Authorization: Bearer` で送る。ローカルの `idp-batch-dev` には `LOCAL_TENANT_ID`(`00000000-0000-0000-0000-000000000001`)がマッパーで焼き込まれているため、シードで作った開発テナントとして動く。別のテナントで試すには [infra/verify/keycloak/Dockerfile](../../infra/verify/keycloak/Dockerfile) の `BATCH_TENANT_ID` を変えてイメージを作り直す(レルムは初回起動時にしか取り込まれないため、DBの作り直しも必要)。

なお `AUTH_MODE=local` のままなら、トークンなしでバッチAPIを叩いても `LOCAL_TENANT_ID` のダミーテナントとして通る。

> **ユーザは `users` テーブルへの事前登録が必要**(未登録は `/me` が403)。Keycloak の管理コンソールで作ったユーザの `sub`(Users → 該当ユーザ → ID)を `users.idp_subject` に入れる:
>
> ```bash
> docker exec idp-postgres psql -U app -d idp -c "UPDATE users SET idp_subject='<subの値>' WHERE email='dev@example.com'"
> ```
>
> 単一レルム構成のトークンだけでは所属テナントを決められないため、初回ログイン時の自動作成は実装していない(GAP-F5 / OI-19 が未決)。

検証用ユーザは管理コンソールの **Users** から作る(Credentials タブで Temporary を Off にする)。ユーザはレルム定義に含めていないため、DBを作り直すと消える。

止めるときは通常どおり:

```bash
docker compose --profile auth down
```

---

## 11. 開発を始める前に

- [ ] `docs/00_brainstorm/` と `docs/01_design/` に目を通す(特に [data-model.md](../01_design/data-model.md) と [api-design.md](../01_design/api-design.md))
- [ ] [coding-standards.md](coding-standards.md) を読む(Git運用・コーディング規約・テスト方針)
- [ ] エディタの保存時フォーマット(Prettier / Ruff)が効いていることを確認する
- [ ] ドキュメント内の【仮】マークは未確定事項。実装中に気づいたずれはドキュメント側を更新する

---

## 12. 日常の開発フロー(2日目以降)

### 起動手順まとめ

```bash
cd ~/dev/azure-idp-tool
docker compose up -d                                        # 依存サービス

cd backend
uv run uvicorn app.main:app --reload --port 8000            # ターミナル1: API
uv run python -m app.worker.main                            # ターミナル2: ワーカー

cd frontend
npm run dev                                                 # ターミナル3: フロントエンド
```

### よく使う開発コマンド

| 場所 | コマンド | 内容 |
|---|---|---|
| backend | `uv run pytest` | テスト |
| backend | `uv run ruff check .` / `uv run ruff format .` | Lint / Format |
| backend | `uv run alembic revision --autogenerate -m "説明"` | マイグレーション作成 |
| backend | `uv run alembic upgrade head` | マイグレーション適用 |
| frontend | `npm run test` | テスト(Vitest) |
| frontend | `npm run lint` / `npm run format` | Lint / Format |
| frontend | `npm run typecheck` | 型チェック |

---

## 13. トラブルシューティング

| 症状 | 対処 |
|---|---|
| apt / npm / uv が軒並みタイムアウト | プロキシ設定漏れ。[4章](#4-プロキシ設定最重要)をやり直す。`echo $HTTP_PROXY` で環境変数が入っているか確認 |
| `docker pull` だけ失敗する(他は通る) | Dockerデーモンは環境変数を見ない。systemdドロップイン([4.4](#44-dockerデーモンイメージpull用))+ `systemctl restart docker` を確認 |
| SSL証明書エラー(`SELF_SIGNED_CERT_IN_CHAIN`等) | SSLインスペクション環境。社内CA証明書の登録([4.7](#47-sslインスペクション社内caがある場合要確認))を確認 |
| ローカルAPI・エミュレータへの通信が失敗する | `NO_PROXY` / `no_proxy` に `localhost,127.0.0.1` が入っているか確認(プロキシに吸われている) |
| `docker compose up` でポート競合 | 5432 / 10000-10002 / 5672 を使用中のプロセスを停止するか、`docker-compose.yml` のポートを変更 |
| `docker` コマンドが permission denied | `docker`グループ追加後にターミナルを開き直していない。`newgrp docker` または再ログイン |
| 解析が「解析中」のまま進まない | ワーカープロセスの起動を確認。`DI_ENDPOINT` / `DI_KEY` の設定ミス、プロキシ・CA未設定による外向き通信失敗はワーカーのログに出る |
| DBスキーマ不整合のエラー | `uv run alembic upgrade head` を再実行。壊れた場合は `docker compose down -v` でDBを作り直し、マイグレーション+シードをやり直す(`-v`はボリューム削除=**ローカルDBの全データ消去**) |
| `app_user`ロールが存在しないエラー | `docker/postgres-init/01-roles.sql` は初回のボリューム作成時のみ実行される。既存ボリュームがある場合はスクリプト内コメントの手順で適用するか、`docker compose down -v` で作り直す |
| Keycloakが `FATAL: database "keycloak" does not exist` / `permission denied` で再起動を繰り返す | `docker/postgres-init/02-keycloak.sql` が未適用。上と同じ理由(既存ボリューム)なので、スクリプト内コメントの手順で手動適用する |
| Keycloak起動後に `permission denied for database` が出る | `REVOKE CONNECT ... FROM PUBLIC` を既存DBへ適用済みで、対象ロールへの `GRANT CONNECT` が漏れている。02-keycloak.sql を再適用する |
| WSL⇔Windowsでlocalhostがつながらない | `.wslconfig` の `networkingMode=mirrored` 設定と `wsl --shutdown` での再起動を確認 |

---

## 付録A: 環境変数リファレンス

`backend/.env.example` をコピーして `.env` を作成する。主要なもの:

| 変数 | ローカルの値(例) | 説明 |
|---|---|---|
| `DATABASE_URL` | `postgresql+asyncpg://app_user:app@localhost:5432/idp` | ランタイム用。RLS適用対象のアプリロールで接続 |
| `MIGRATION_DATABASE_URL` | `postgresql+asyncpg://app:app@localhost:5432/idp` | Alembicマイグレーション・シード用。所有者ロールで接続 |
| `BLOB_ACCOUNT_URL` / `BLOB_CONNECTION_STRING` | Azuriteの接続情報(`.env.example`の値のまま) | 本番はManaged Identity。Azuriteの既定キーは公開情報なのでコミット可 |
| `SERVICE_BUS_CONNECTION_STRING` | ローカルエミュレータの接続情報(同上) | 本番はManaged Identity |
| `SERVICE_BUS_QUEUE_INTERACTIVE` / `SERVICE_BUS_QUEUE_BATCH` | `interactive` / `batch` | ワーカーが購読する2キュー(interactive優先) |
| `DI_ENDPOINT` / `DI_KEY` | 開発用共有リソースの値 | 各自受領。**コミット禁止** |
| `SHARE_BASE_URL` | `http://localhost:5173/share` | 共有リンク発行時のURL組み立て用 |
| `AUTH_MODE` | `local` | `local`=認証スキップ / `keycloak`=JWT検証 |
| `LOCAL_TENANT_ID` / `LOCAL_USER_ID` / `LOCAL_USER_ROLE` | `.env.example`のデフォルト値のまま | `AUTH_MODE=local`時のダミー認証情報。シードがこのIDでテナント・ユーザを作成する |
| `OIDC_ISSUER` / `OIDC_AUDIENCE` | `http://localhost:8080/realms/idp` / `idp-api` | `AUTH_MODE=keycloak`時のみ使用。JWTのissuer・audience検証に使う。`OIDC_AUDIENCE` はAPI自身を指す識別子で、SPAのクライアントID(`idp-frontend`)とは別物 |

フロントエンドは `frontend/.env.example`(`VITE_API_BASE_URL`のみ)。

**プロキシ関連(`HTTP_PROXY`等)は`.env`ではなくシェル環境(`/etc/environment`等)で管理する**(資格情報をリポジトリ配下に置かないため)。

## 付録B: 開発用Azureリソース

| リソース | 扱い |
|---|---|
| Document Intelligence(S0) | 共有。SaaS運用者(リポジトリ管理者)が払い出し、キーを開発メンバに配布 |
| (Keycloak) | **Azureリソース不要**。ローカルは`docker compose --profile auth`のコンテナで動かす(§10.5)。通常のローカル開発では起動すら不要(`AUTH_MODE=local`) |
| dev環境一式(Bicepデプロイ) | 結合確認用。個人ごとには作らず共有dev環境を1つ維持する【仮】 |

- ローカルで完結しない検証(Application Gateway・WAF・VNet・Private Endpoint)はdev環境で行う
- dev環境はApplication Gateway WAF_v2(~$280〜380/月)を含み固定費が高いため、不要期間の削除・再デプロイをBicepで容易にしておく(`infra/` 参照)
