# 開発環境構築手順(ドラフト)

> **注**: 本ドキュメントの内容は環境説明と統合した [setup-guide.md](setup-guide.md) に反映済み。新規メンバのセットアップはそちらを参照。

開発メンバ追加時のセットアップガイド。所要時間目安: 半日(プロキシ設定のはまり具合による)。
※コマンドは実装開始後に実態と突き合わせて更新すること(現状はドラフト)。

## 0. 事前に受領するもの

チーム(リポジトリ管理者)から以下を受け取る:

- [ ] GitHubリポジトリへのアクセス権
- [ ] 開発用Document Intelligenceのエンドポイント・キー
- [ ] 社内プロキシの接続情報(ホスト・ポート・Basic認証のユーザ名/パスワード・除外ドメイン、SSLインスペクション有無と社内CA証明書)
- [ ] (必要な場合のみ)開発用Entra External IDテナントのアカウント、共有dev環境のURL

## 1. Windows側のセットアップ

1. WSL2 + Ubuntuをインストールする(PowerShell・管理者権限):

```powershell
wsl --install -d Ubuntu-24.04
```

2. `.wslconfig`(`%UserProfile%\.wslconfig`)で`networkingMode=mirrored`を設定する【仮】(詳細は[dev-environment.md](dev-environment.md))
3. VS CodeとRemote Development拡張をインストールする

## 2. WSL側のプロキシ設定

[dev-environment.md](dev-environment.md) の「社内認証プロキシへの対応」に従い、**先にプロキシを通す**(これをやらないと以降のapt/npm/uvが全部失敗する):

- `/etc/environment`に`HTTP_PROXY` / `HTTPS_PROXY` / `NO_PROXY`(小文字版も)。値は受領したBasic認証の資格情報込みURL(パスワードの記号はURLエンコード)
- `/etc/apt/apt.conf.d/95proxy`
- SSLインスペクションがある場合は社内CA証明書を`update-ca-certificates`で登録

## 3. WSL側のツールインストール

以降の作業はすべてWSL(Ubuntu)内のターミナルで行う。[dev-environment.md](dev-environment.md) の必要ツール表に従い、git / Node.js 22(nvm)/ uv(Python 3.14は`uv python install 3.14`で導入)/ Docker Engine(docker-ce+Composeプラグイン、公式aptリポジトリから)/ Azure CLI をインストールする。

- Dockerはインストール後に`sudo systemctl enable --now docker`、自ユーザを`docker`グループに追加
- Dockerデーモンのプロキシ設定(systemdドロップイン)も忘れずに行う(イメージpullが失敗する)

## 4. リポジトリのクローン

WSL側ファイルシステムにcloneし、VS CodeをRemote - WSLで開く:

```bash
mkdir -p ~/dev && cd ~/dev
git clone <リポジトリURL> azure-idp-tool
cd azure-idp-tool
code .   # Remote - WSLでVS Codeが開く。推奨拡張(.vscode/extensions.json【仮】)をインストール
```

## 5. ローカルインフラの起動

```bash
docker compose up -d   # PostgreSQL / Azurite / Service Busエミュレータ
```

## 6. バックエンドのセットアップ

```bash
cd backend
uv sync                          # 依存関係のインストール
cp .env.example .env             # 環境変数ファイルを作成
# .env を編集: DI_ENDPOINT / DI_KEY に受領した値を設定
uv run alembic upgrade head      # DBマイグレーション
uv run python scripts/seed.py    # シードデータ投入(出力されたテナントIDを.envのLOCAL_TENANT_IDに設定)
```

起動確認(ターミナル2つ):

```bash
uv run uvicorn app.main:app --reload --port 8000   # APIサーバ
uv run python -m app.worker                        # ワーカー
```

Windows側ブラウザで http://localhost:8000/docs を開き、Swagger UIが表示されればOK。

## 7. フロントエンドのセットアップ

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Windows側ブラウザで http://localhost:5173 を開き、画面が表示されればOK(`AUTH_MODE=local`のためログイン画面はスキップされる)。

## 8. 動作確認(スモークテスト)

1. ドキュメント一覧画面から`backend/tests/fixtures/`のサンプルPDFをアップロード(書類種別: 見積書)
2. 状態が「解析中」→「解析済」に変わること(ワーカーとDI疎通の確認)
3. 転記確定画面でオーバレイが表示されること

ここまで通れば環境構築完了。

## 9. 開発を始める前に

- [ ] `docs/00_brainstorm/` と `docs/01_design/` に目を通す(特にデータモデルとAPI設計)
- [ ] [coding-standards.md](coding-standards.md) を読む
- [ ] エディタの保存時フォーマット(Prettier / Ruff)が効いていることを確認する

## トラブルシューティング

| 症状 | 対処 |
|---|---|
| apt / npm / uv が軒並みタイムアウト | プロキシ設定漏れ。手順2をやり直す。`echo $HTTP_PROXY`で環境変数が入っているか確認 |
| `docker pull`だけ失敗する(他は通る) | Dockerデーモンは環境変数を見ない。systemdドロップインのプロキシ設定+`systemctl restart docker`を確認 |
| SSL証明書エラー(`SELF_SIGNED_CERT_IN_CHAIN`等) | SSLインスペクション環境。社内CA証明書の登録(OS / `NODE_EXTRA_CA_CERTS` / `SSL_CERT_FILE`)を確認 |
| ローカルAPIへの通信がプロキシに吸われる | `NO_PROXY`に`localhost,127.0.0.1`が入っているか確認 |
| `docker compose up`でポート競合 | 5432/10000-10002/5672を使用中のプロセスを停止するか、`docker-compose.yml`のポートを変更 |
| 解析が「解析中」のまま進まない | ワーカープロセスの起動を確認。DI_ENDPOINT/DI_KEYの設定ミス、プロキシ・CA未設定による外向き通信失敗はワーカーのログに出る |
| DBスキーマ不整合のエラー | `uv run alembic upgrade head`を再実行。壊れた場合は`docker compose down -v`でDBを作り直してマイグレーション+シードをやり直す |
