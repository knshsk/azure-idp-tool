# API設計

FastAPI。ベースパスは`/api/v1`。すべてAPIM経由で公開する。

## 認証と経路

| 経路 | 利用者 | 認証 | テナント解決 |
|---|---|---|---|
| フロントエンドAPI | ブラウザ(Vue) | Entra External IDのJWT(Bearer) | JWTクレーム → `users.entra_object_id` → `tenant_id` |
| バッチAPI(`/batch/*`) | テナント社内システム | APIMサブスクリプションキー | APIMがサブスクリプションに紐づく`X-Tenant-Id`ヘッダを付与して転送 |
| 共有URL(`/share/*`) | 共有URL受領者 | なし(URLトークンのみ) | トークン → `share_links` → `tenant_id` |

- Container AppsはVNet内(internal ingress)に配置し、APIMのアウトバウンドVNet統合経由でのみ到達可能とする(`X-Tenant-Id`の偽装防止をネットワーク層で担保)
- APIはトランザクション開始時に`SET LOCAL app.tenant_id`を発行(RLS適用)
- ロール制御: `tenant_admin`のみ書類種別・転記項目定義・保持期間設定・利用状況の操作が可能

## エラー形式(共通)

```json
{
  "error": {
    "code": "document_not_found",
    "message": "指定されたドキュメントが見つかりません"
  }
}
```

一覧系はクエリパラメータ`page` / `per_page`(デフォルト20)でページネーションし、`X-Total-Count`ヘッダを返す。

## エンドポイント一覧

### ドキュメント

| メソッド/パス | 説明 |
|---|---|
| `POST /documents` | PDFアップロード(multipart: `file`, `document_type_id`)。ハッシュ重複時は既存ドキュメントを`200`で返す【仮】。新規は`202`。受付後にinteractiveキュー投入まで行う |
| `GET /documents` | 一覧。フィルタ: `status`, `document_type_id`, `source`, `created_from/to` |
| `GET /documents/{id}` | 詳細(statusを含む) |
| `DELETE /documents/{id}` | 削除(原本・ページ画像・解析結果を含む) |
| `GET /documents/{id}/pages/{page_no}/image` | ページPNG配信 |
| `POST /documents/{id}/analyze` | 解析実行(interactiveキュー投入)。バッチ済み・解析済みなら`409` |
| `GET /documents/{id}/analysis` | オーバレイ用データ: Layoutの単語/行/テーブル(正規化座標)、Query Fields結果 |
| `GET /documents/{id}/values` | 転記値(候補/確定)一覧 |
| `PUT /documents/{id}/values` | 転記値の一括更新(手動修正含む。`manually_edited`を記録)。ヘッダは`transcription_field_id`、明細セルは`row_no + column_no`で指定 |
| `PUT /documents/{id}/line-item-table` | 明細領域の選択 `{page_no, table_index}`。選択時にDI検出テーブルから明細セルを`extracted_values`へ取り込む |
| `POST /documents/{id}/confirm` | 転記項目確定。`status=confirmed`へ |

### 出力JSON形式

```json
{
  "document_id": "...",
  "document_type": "quotation",
  "confirmed_at": "2026-07-14T12:34:56+09:00",
  "header": {
    "issue_date": {"value": "2026-07-01", "raw": "令和8年7月1日", "normalization_failed": false},
    "total_amount": {"value": 1234567, "raw": "¥1,234,567", "normalization_failed": false}
  },
  "line_items": {
    "columns": [
      {"column_no": 0, "header_text": "品名"},
      {"column_no": 1, "header_text": "数量"},
      {"column_no": 2, "header_text": "単価"}
    ],
    "rows": [
      {"page_no": 1, "cells": ["商品A", "10", "1,500"]},
      {"page_no": 1, "cells": ["商品B", "5", "3,200"]}
    ]
  }
}
```

- JSON出力はバッチAPI(`GET /batch/documents/{id}/json`)でのみ提供する。転記の実行主体は業務システム側のため、フロントエンドにJSON出力操作は設けない
- `header`のキー名はテナントの転記項目定義(`json_key`)に従う。`value`は型定義に従い正規化した値。正規化失敗時は`value`に生文字列を入れ`normalization_failed: true`
- `line_items`は列ヘッダテキスト+行×列のセル値(生文字列)のテーブル構造。どの列がどの項目に相当するかの判断は業務システム側の責務。`page_no`は複数ページ明細の由来確認用
- 出力JSONに座標は含めない(座標が必要な照合用途はフロントエンドのオーバレイ表示=`GET /documents/{id}/analysis`が担う)

### 書類種別・転記項目定義(tenant_adminのみ)

| メソッド/パス | 説明 |
|---|---|
| `GET /document-types` | 一覧 |
| `POST /document-types` | 作成 `{code, name}` |
| `PUT /document-types/{id}` / `DELETE ...` | 更新・削除 |
| `GET /document-types/{id}/fields` | 転記項目定義一覧 |
| `PUT /document-types/{id}/fields` | 転記項目定義の一括更新(json_key, label_ja, value_type, query_field_key, sort_order)。ヘッダ項目のみ |

### 共有URL(受領者向け・認証なし)

発行・一覧・失効はバッチAPI(下記)で行い、フロントエンドからは呼び出さない。

| メソッド/パス | 説明 |
|---|---|
| `GET /share/{token}` | 【認証なし】共有ビュー用メタデータ(ページ数など)。アクセスを利用ログに記録 |
| `GET /share/{token}/pages/{page_no}/image` | 【認証なし】ページPNG |
| `GET /share/{token}/download` | 【認証なし】原本PDFダウンロード |

### バッチAPI(APIMサブスクリプションキー)

| メソッド/パス | 説明 |
|---|---|
| `POST /batch/documents` | PDFアップロード(multipart: `file`, `document_type_code`)。batchキュー投入まで実行し`202`で`document_id`を返す。ハッシュ重複時は既存参照を`200`で返す【仮】 |
| `GET /batch/documents` | 一覧+処理状況(`status`でフィルタ)。ポーリング用 |
| `GET /batch/documents/{id}` | 個別の処理状況 |
| `GET /batch/documents/{id}/json` | 確定済みなら既定JSON(上記「出力JSON形式」)を返す(未確定は`409`)。取込元(フロントエンド/バッチ)を問わず取得可能 |
| `POST /batch/documents/{id}/share-links` | 共有URL発行 `{expires_in_hours}` → `{url, expires_at}`(トークン平文は応答にのみ含める)。取込元を問わず発行可能 |
| `GET /batch/documents/{id}/share-links` | 発行済み一覧(有効/失効/期限切れ) |
| `DELETE /batch/share-links/{id}` | 失効 |

### 管理・計測

| メソッド/パス | 説明 |
|---|---|
| `GET /usage/summary?month=YYYY-MM` | テナントの月次利用状況: APIリクエスト数(APIMメトリクス)+DIコール数・ページ数(`di_call_logs`集計) |
| `PUT /tenant/settings` | 保持期間(`retention_days`)等の設定(tenant_adminのみ) |
| `GET /me` | ログインユーザ情報(ロール・テナント) |

## 非同期処理の内部インターフェース

キューメッセージ(Service Bus)は最小情報のみ:

```json
{"document_id": "...", "tenant_id": "...", "requested_at": "..."}
```

- ワーカーは`document_id`からDBを引いて処理する(メッセージ肥大化と情報齟齬を防ぐ)
- 処理は冪等に実装する(同一メッセージの再配信・回収処理による再投入があるため、`status`検査で二重解析を防止)
- DI解析失敗時: リトライ可能なエラーは再試行(Service Busの再配信)、上限超過でDLQ+`status=failed`+`error_message`記録
