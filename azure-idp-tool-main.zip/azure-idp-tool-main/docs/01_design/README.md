# 設計ドキュメント

`docs/00_brainstorm/idp-tool-brainstorm.md` の決定事項を基にした設計フェーズのドキュメント群。

## ドキュメント一覧

| ドキュメント | 内容 |
|---|---|
| [azure-architecture.md](azure-architecture.md) | Azureアーキテクチャ図と構成要素の説明 |
| [data-model.md](data-model.md) | データモデル(ER図・テーブル定義・RLS方針) |
| [blob-storage.md](blob-storage.md) | Blob Storage構造(コンテナ設計・パス規約・アクセス経路・削除) |
| [api-design.md](api-design.md) | REST API設計(認証・エンドポイント・エラー形式) |
| [screen-design.md](screen-design.md) | 画面構成(画面一覧・主要画面のレイアウト・ユーザフロー) |

## モノレポ構成

このリポジトリ(`azure-idp-tool/`)をそのままモノレポとして構成する。

```
azure-idp-tool/
├── docs/
│   ├── 00_brainstorm/      # ブレインストーミング(要件の源泉)
│   ├── 01_design/          # 設計ドキュメント(本ディレクトリ)
│   ├── 02_development/     # 開発規約・開発環境
│   └── 03_deployment/      # デプロイ手順書
├── frontend/               # Vue.js + Vuetify3 + Pinia + Vite + TypeScript
├── backend/                # Python + FastAPI
│   └── (api / worker は同一イメージ・起動コマンド違い)
├── infra/                  # Bicep(IaC)
└── .github/
    └── workflows/          # CI/CD(詳細は未決)
```

- backendはAPIサーバとワーカーを同一パッケージ・同一コンテナイメージで実装し、起動コマンドで役割を切り替える(ブレスト決定事項)
- infraのBicepはモジュール分割(ネットワーク/データ/コンピュート/APIM)を想定

## ブレインストーミングから引き継ぐ未解決論点

設計ドキュメント内では以下を仮決め(【仮】マーク)として扱い、確定次第更新する:

- 値正規化の対応パターン範囲(和暦・全角数字・通貨記号)
- ファイルハッシュ重複検知時の挙動 → 設計上は「既存ドキュメントの参照を返す」を仮採用
- 応答時間目標・テナント別レート制限値などの性能系パラメータ(PDFサイズ・ページ数上限はDI S0制約準拠の500MB・2,000ページで確定済み)
