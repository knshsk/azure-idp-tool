# Azureアーキテクチャ v2(理想形・フェーズ別構成)

> 本書は単体で読めるように書かれている。コスト試算はすべて **2026-07時点・東日本リージョン・月額USD概算**。確定前に料金計算ツールでの再確認が必要。
>
> 全体を貫く方針:
> - **防御レベルはフェーズのデータ機微度に連動させる**(顧客データが入った時点でデータ層の防御を本番同等にする)
> - **認証・認可の方式(Managed Identity / Entra ID認証 / RLS)はフェーズ1から本番同等にする**。ネットワーク強化はBicepパラメータで後から締められるが、認証方式の後付け変更は改修コストが大きい

## 1. 理想形構成(コスト度外視)

### 1.1 構成図

```mermaid
flowchart LR
    subgraph clients["利用者"]
        browser["ブラウザ<br>(一般ユーザ / システム管理者)"]
        internal["テナント社内システム<br>(バッチ連携)"]
        guest["共有URL受領者"]
    end

    afd["Front Door Premium + WAF<br>OWASPマネージドルール / ボット対策<br>エッジレート制限 / DDoS緩和"]

    subgraph azure["Azure"]
        entra["Entra External ID<br>(認証・JWT発行)<br>複数issuerのクレーム信頼境界を定義"]
        swa["Static Web Apps<br>(Front Door経由のみ受信)"]
        apim["API Management (Standard v2)<br>受信: Front Doorのみ(X-Azure-FDID検証)<br>【ポリシー】validate-jwt(署名/issuer/aud) /<br>X-Tenant-Id 強制削除→JWT・サブスクキーから再設定 /<br>サブスクキーはヘッダのみ / ボディサイズ上限 / レート制限"]

        subgraph vnet["仮想ネットワーク (VNet) — 全サブネットにNSG"]
            subgraph aca["Container Apps 環境 (internal ingress)<br>受信NSG: APIM統合サブネットのみ許可"]
                api["API (FastAPI)<br>JWT再検証(多層防御)<br>アップロード検証(マジックバイト/サイズ)"]
                worker["ワーカー<br>最小1レプリカ / KEDA 1→N"]
            end
            natgw["NAT Gateway<br>(固定送信IP)"]
            di["Document Intelligence<br>【PE】パブリック無効"]
            blob["Blob Storage (ZRS)<br>テナント別コンテナ<br>ソフト削除+バージョニング(削除ジョブ誤爆対策)<br>【PE】パブリック無効"]
            pg["PostgreSQL Flexible Server<br>プールモデル + FORCE RLS<br>所有者ロール/アプリロール分離<br>pgaudit有効 / PITR<br>【PE】パブリック無効"]
            acr["Container Registry (Premium)<br>MI pull / イメージ脆弱性スキャン<br>【PE】パブリック無効"]
            kv["Key Vault<br>残余シークレット用<br>【PE】パブリック無効"]
        end

        sb["Service Bus (Standard)<br>interactive / batch キュー<br>MI認証(SAS無効) + IPファイアウォール<br>(NAT GWの固定IPのみ許可)<br>メッセージはID参照のみ・PII禁止"]
    end

    subgraph ops["監視・検知"]
        law["Log Analytics<br>APIM診断 / ACAログ / pgaudit /<br>Blobアクセスログ / サインインログ"]
        defender["Defender for Cloud<br>Storage(マルウェアスキャン) /<br>Containers / OSS DB"]
        alerts["アラート<br>認証失敗急増 / 共有トークン検証失敗連続 /<br>DLQ滞留 / SBファイアウォール拒否"]
    end

    browser -->|"静的コンテンツ"| afd
    browser -->|"認証 (PKCE)"| entra
    browser -->|"API (JWT)"| afd
    internal -->|"バッチAPI (サブスクキー)"| afd
    guest -->|"トークン付き共有URL<br>(検証失敗レート制限)"| afd
    afd --> swa
    afd --> apim
    apim -->|"アウトバウンドVNet統合"| api
    api -->|"ジョブ投入"| sb
    sb -->|"KEDAスケール / 消化"| worker
    worker -->|"解析実行"| di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
    aca -->|"固定送信IP"| natgw --> sb
    aca -.->|"イメージpull (PE)"| acr
    azure -.-> law
    law --> alerts
```

### 1.2 設計の要点

1. **Front Door Premium + WAF** が全公開トラフィックの前段。APIMは`X-Azure-FDID`ヘッダ検証でFront Door以外からの直接アクセスを拒否(SWAも同様)
2. **APIMポリシーでアイデンティティ伝搬を強制**: `validate-jwt`(署名/issuer/audience)→ 受信`X-Tenant-Id`を無条件削除 → 検証済みJWTクレームまたはサブスクキー紐づけテナントIDから再設定。API側でもJWTを再検証(多層防御)
3. **バックエンドは全てVNet内またはPrivate Endpoint**、全サブネットにNSG。Service BusのみPE不可(Premium専用)のため、**NAT Gatewayの固定送信IP**+IPファイアウォール+Managed Identity認証で防御
4. **Azureリソース間認証はManaged Identityに統一**(SASキー・アクセスキー・接続文字列を廃止。PostgreSQLはEntra ID認証)
5. **監視・検知**: Log Analytics集約+Defender for Cloud+アラートを本番の必須構成とする

図に表れない前提:

- 共有トークン: 128bit以上のエントロピー、DBにはハッシュで保存、定数時間比較、検証失敗のIP単位レート制限
- サブスクリプションキー: ヘッダのみ許可、プライマリ/セカンダリ2キーでのローテーション手順
- RLS: 所有者ロール/アプリ接続ロールの分離+`FORCE ROW LEVEL SECURITY`+コネクション取得時にテナントコンテキストを強制設定するミドルウェア層
- Service Busメッセージはdocument ID等の参照のみ(PII禁止)、DLQの監視・掃除運用
- Blobテナント越境の自動テスト(コンテナ名導出の単一コード経路化)
- Document Intelligenceは解析データを最大24時間サービス側に保持する仕様 → 顧客向けデータ取り扱い説明に記載

### 1.3 コスト試算

**基本構成**

| リソース | 月額目安 |
|---|---|
| APIM Standard v2 | ~$690 |
| Container Apps(消費・最小1レプリカ常駐) | $50〜150 |
| PostgreSQL Burstable (B2s) | $50〜70 |
| Blob Storage (ZRS) | $10〜30 |
| Service Bus Standard | ~$10 |
| Static Web Apps Standard | $9 |
| Private Endpoint ×3 (PG/Blob/DI) | ~$22 |
| Document Intelligence S0 | 従量(解析量次第) |
| **小計** | **~$850〜980 + DI従量** |

**セキュリティ強化分**

| リソース | 月額目安 | 目的 |
|---|---|---|
| Front Door Premium(基本料+WAFポリシー込) | ~$330〜380 | WAF・ボット対策・DDoS緩和 |
| ACR Premium + PE | ~$57 | イメージ供給網の保護 |
| NAT Gateway(基本料+処理量) | ~$35〜45 | 送信IP固定(SBファイアウォールの成立条件) |
| Key Vault + PE | ~$8 | 残余シークレット管理 |
| Log Analytics(~5〜15GB/月想定) | $15〜45 | 監視・監査ログ |
| Defender for Storage(+マルウェアスキャン従量) | $10〜30 | アップロード検疫 |
| Defender for Containers | ~$15 | イメージ/ランタイム脅威検知 |
| Defender for OSS DB | ~$15〜30 | DB脅威検知 |
| NSG / Blobソフト削除 / pgaudit / APIMポリシー | ほぼ$0 | 多数(§3参照) |
| **小計** | **~$490〜610** | |

**理想形合計: 月額 ~$1,350〜1,600 + 従量(DI・転送量)**

## 2. 理想形からのダウングレード選択肢

コスト強化分の6割超がFront Door Premium。判断の主分岐はここ。

| 対象 | 理想形 | ダウングレード案 | 月額削減 | 失うもの(トレードオフ) |
|---|---|---|---|---|
| WAF/エッジ | Front Door Premium | **Front Door Standard** | 約$300 | OWASPマネージドルールとボット対策(Premium専用)。カスタムWAFルール・レート制限・ジオフィルタは残るため「WAFなし」よりは大幅に良い |
| WAF/エッジ | Front Door Premium | **Front Door自体を見送り** | 約$330〜380 | WAF層が消滅。APIMのレート制限+サイズ上限のみで公開APIを防御。DDoSはAzure基盤レベルの緩和のみ。アップロード受付SaaSとしてはリスク受容の明文化が必須 |
| レジストリ | ACR Premium(PE) | **ACR Standard(パブリック+MI認証)** | 約$37 | イメージpullがパブリック経路になる(認証はMIで維持)。PE・ゾーン冗長を失う。脆弱性スキャンはCI側(Trivy等)で代替可能 |
| 検疫 | Defender for Storage | **アプリ側検証のみ**(マジックバイト/サイズ) | $10〜30 | マルウェア検知がなくなる。共有URLで第三者がファイルをダウンロードする本サービスの性質上、配布元責任のリスクが残る |
| 脅威検知 | Defender for Containers / OSS DB | **段階導入(ローンチ後に追加)** | $30〜45 | ランタイム脅威検知の空白期間。後付けが容易なため「時期の問題」に整理できる |
| ログ | Log Analytics フル収集 | **収集対象の絞り込み**(APIM診断+サインインログ優先) | $10〜30 | pgaudit/Blobログの遡及調査ができない。インシデント時の原因究明力が低下 |
| シークレット | Key Vault(PE) | **見送り**(MI統一で残余シークレットが実質ない場合) | 約$8 | 将来シークレットが発生した際の置き場がなく、環境変数直書きへ逃げる誘惑が生まれる |

### 削るべきでないもの

以下は合計~$60程度と安価なのに§3の観点の大半をカバーするため、ダウングレード対象にしない。

- APIMポリシー群(validate-jwt / X-Tenant-Id再設定 / サイズ上限)
- NSG(ほぼ$0)
- NAT Gateway(これを削るとService BusのIPファイアウォール自体が成立しない)
- Blobソフト削除+バージョニング
- RLSロール分離+FORCE RLS
- Log Analyticsの最小構成(検知ゼロの状態を避ける)

## 3. 各層のセキュリティ観点

### 3.1 公開層(SWA / Entra External ID / APIM / Front Door)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 1 | `X-Tenant-Id`の偽装防止をネットワーク層だけに頼らない | APIMがクライアント送信のヘッダを素通しすると、正規経路経由でテナント偽装が可能 | APIMポリシーで受信`X-Tenant-Id`を**無条件削除**し、検証済みJWTクレームまたはサブスクキー紐づけテナントIDから**APIMが再設定**する一方向の流れを強制 |
| 2 | JWT検証の場所を明確化 | API側のみだとAPIMが未認証トラフィックをバックエンドへ素通し | APIMで`validate-jwt`+API側でも再検証の多層防御。顧客Entra IDフェデレーションでissuerが複数になるため、どのissuerのどのクレームを信じるかの信頼境界を定義 |
| 3 | サブスクリプションキーは長期共有シークレット | テナント側での保管不備・漏洩 | ヘッダのみ許可(クエリ文字列送信を無効化)/ 2キーローテーション手順 / 漏洩時の失効フロー。将来はOAuth2クライアントクレデンシャルへの移行余地 |
| 4 | WAFの有無を意思決定として明示 | APIM Standard v2はWAFではない。公開SaaS+ファイルアップロード受付でOWASP系攻撃・ボットへの防御層 | Front Door(WAF付き)を前段に配置。見送る場合は「リスク受容+APIMレート制限・サイズ上限で代替」を文書化。ボディサイズ上限は採否に関わらず必須 |
| 5 | 共有URLエンドポイントは実質未認証 | トークン総当たり / URL残留(履歴・プロキシログ・Referer) | 128bit以上のエントロピー / DBにハッシュ保存・定数時間比較 / 検証失敗のIP単位レート制限+失敗ログ / URL残留リスクの許容判断を明記 |

### 3.2 アプリ層(Container Apps)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 6 | NSGによる東西トラフィック制御 | internal ingressでもVNet内に入れば環境へ到達可能。将来のサブネット追加時に穴になる | snet-acaの受信をAPIM統合サブネットからのみに絞るNSGを全サブネットに最初から敷く |
| 7 | イメージ供給網(サプライチェーン) | レジストリ認証・脆弱性スキャン・ベースイメージ更新が無防備 | ACRのManaged Identity pull / 脆弱性スキャン(Defender for ContainersまたはCI側Trivy等)/ ベースイメージ更新運用をCI/IaCに組み込む |
| 8 | アップロードファイルの検証場所 | 不正ファイルがDIまで素通り | マジックバイト検証・サイズ上限をAPI側で実施。Defender for Storageのマルウェアスキャン採否を決定 |

### 3.3 非同期層(Service Bus)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 9 | IPファイアウォールは送信IPの安定が前提 | Container Apps環境の送信IP変動でファイアウォールが形骸化 or 障害化 | NAT Gatewayで固定送信IP化 |
| 10 | メッセージ本文の内容規定 | DLQが「失敗データの保管庫」化し、テナントデータが滞留 | メッセージはdocument ID等の**参照のみ**・PII禁止を方針化。DLQの監視・掃除運用を定義 |

### 3.4 データ層(Blob / PostgreSQL / Document Intelligence)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 11 | **RLSはテーブル所有者にデフォルトで効かない** | マイグレーションロール=アプリ接続ロールだとRLSが素通し(プールモデルの定番の落とし穴) | 所有者ロールとアプリ接続ロールを分離+`FORCE ROW LEVEL SECURITY`。テナントコンテキスト(`set_config`)をコネクション取得時に強制設定するミドルウェア層 |
| 12 | Blobのテナント分離はアプリロジック頼み | API/ワーカーのMIは全テナントのコンテナにアクセス可能。アプリのバグ一つで越境 | 強制層がない事実を明示し、コンテナ名導出を単一コード経路に集約+テナント越境の自動テストを補償策とする |
| 13 | 日次削除ジョブの誤爆対策 | バグ時の大量削除 | Blob**ソフト削除+バージョニング**を有効化(安価な安全網) |
| 14 | DIのデータ保持仕様 | DIは解析データを最大24時間サービス側に保持 | 顧客向けデータ取り扱い説明に記載 |

### 3.5 横断(監視・検知)

- **Log Analytics集約**: APIM診断ログ(認証失敗・429)/ Container Appsログ / PostgreSQL(pgaudit)/ Blobアクセスログ / Entra External IDサインインログ
- **アラート**: 認証失敗の急増 / 共有トークン検証失敗の連続 / DLQ滞留 / Service Busファイアウォール拒否
- **Defender for Cloud**(Storage / Containers / OSS DB)の採否をコスト込みで判断
- 監査ログはテナントへの説明責任(誰がいつ何にアクセスしたか)の観点でも本番必須

## 4. フェーズ別構成(草案)

フェーズはデータの機微度で区切り、防御レベルを連動させる。

| 項目 | 初期(社内開発) | PoC(顧客テストデータ) | リリース(顧客本番データ) |
|---|---|---|---|
| 扱うデータ | ダミーデータのみ | 顧客提供テストデータ(機密として扱う) | 顧客本番データ |
| 公開接点 | Container Apps直公開+**社内IP制限** | APIM(**IP特定可能な送信元はIP限定**。特定不可の経路はOAuth2 CCで代替: §4.2.1) | Front Door + APIM(全公開) |
| WAF | なし | 原則なし(IP制限で代替。IP制限が効かない連携が主流ならFD Standard前倒し: §4.2.1) | **あり(ティアは§2の判断)** |
| VNet / Private Endpoint | なし(パブリック+IPファイアウォール) | **あり(本番同等)** | あり |
| 認証方式(MI / Entra ID認証 / RLS) | **本番同等**(最初から) | 本番同等 | 本番同等 |
| Blobソフト削除 / NSG / NAT GW | — / — / — | あり / あり / あり | あり / あり / あり |
| 監視・検知 | Log Analytics最小 | +Defender for Storage | +Defender一式・アラート整備 |
| 月額目安 | **~$50〜100** | **~$950〜1,100** | **~$1,050〜1,600**(FDティアによる) |

### 4.1 初期: 社内でのアプリ開発(顧客データなし)

方針: 顧客データが一切入らないため、**ネットワーク防御は最小化してコストと開発速度を優先**する。ただし認証方式(Managed Identity・Entra ID認証・RLS・キー無効化)は本番同等で実装する — ここを後回しにすると移行時の改修が最も高くつく。

```mermaid
flowchart LR
    dev["開発者・社内利用者"]

    subgraph azure["Azure(VNet・Private Endpointなし)"]
        entra["Entra External ID(無料枠)<br>認証フロー・JWTクレーム設計は本番同等"]
        swa["Static Web Apps Free"]
        subgraph aca["Container Apps 環境(external ingress)<br>受信は社内IPのみ許可 / 0→Nスケール"]
            api["API (FastAPI)<br>JWT検証・RLSコンテキスト設定は<br>この段階で実装"]
            worker["ワーカー(最小0レプリカ)"]
        end
        sb["Service Bus Standard<br>MI認証(SAS無効)"]
        di["Document Intelligence S0<br>パブリック+Entra認証のみ(キー無効)"]
        blob["Blob (LRS)<br>パブリック+IPファイアウォール<br>MI認証(キー無効)"]
        pg["PostgreSQL Burstable (B1ms)<br>パブリック+IPファイアウォール<br>Entra ID認証 / RLS・ロール分離は初期から実装"]
        law["Log Analytics(最小)"]
    end

    dev -->|"静的コンテンツ"| swa
    dev -->|"認証"| entra
    dev -->|"API(社内IP制限)"| aca
    api --> sb --> worker
    worker --> di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
```

- **APIMはこのフェーズでは置かない**。APIMポリシー(validate-jwt / X-Tenant-Id再設定)の実装検証が必要になった時点でBasic v2(~$147)を追加し、PoC移行時にStandard v2へ引き上げる
- SWAはFree、ワーカーは0レプリカ許容(コールドスタート要件は本番のみ)、PostgreSQLは最小SKU
- Bicepは本番と同一モジュールを使い、ネットワーク強化(VNet/PE/NSG/internal ingress)をパラメータで無効化する形にする — フェーズ移行が「パラメータ変更+差分デプロイ」になる

**月額目安: ~$50〜100 + DI従量**(ACA $10〜40 / PG $15〜25 / SB $10 / Blob・LA 数ドル)

### 4.2 PoC: 顧客提供テストデータの投入

方針: テストデータでも**顧客の実文書は機密**。データ層・ネットワーク層の防御を本番同等に引き上げる。一方で公開範囲はまだ限定できるため、**APIM受信を参加顧客の送信元IPに限定**することでWAF不在のリスクを大幅に緩和し、Front Doorの導入をリリース判断まで先送りする。

```mermaid
flowchart LR
    subgraph clients["参加顧客"]
        browser["ブラウザ"]
        internal["顧客業務システム<br>(オンプレ / SAP / D365等クラウド)"]
    end

    subgraph azure["Azure"]
        entra["Entra External ID"]
        swa["Static Web Apps Standard"]
        apim["APIM Standard v2<br>受信: IP特定可能な送信元はip-filterで限定<br>IP特定不可の連携経路はOAuth2 CC認証(§4.2.1)<br>validate-jwt / X-Tenant-Id再設定 /<br>サイズ上限 / レート制限 — 本番同等ポリシー"]

        subgraph vnet["VNet — 全サブネットにNSG"]
            subgraph aca["Container Apps 環境(internal ingress)"]
                api["API (FastAPI)"]
                worker["ワーカー(最小1レプリカ)"]
            end
            natgw["NAT Gateway(固定送信IP)"]
            di["Document Intelligence【PE】"]
            blob["Blob (ZRS)<br>ソフト削除+バージョニング【PE】"]
            pg["PostgreSQL (B2s)<br>FORCE RLS / pgaudit【PE】"]
        end

        sb["Service Bus Standard<br>MI認証+IPファイアウォール(NAT GW固定IP)"]
        acr["ACR Standard<br>パブリック+MI pull / CI側スキャン"]
    end

    subgraph ops["監視"]
        law["Log Analytics<br>APIM診断+サインインログ優先"]
        dfs["Defender for Storage<br>(マルウェアスキャン)"]
    end

    browser --> entra
    browser --> swa
    browser -->|"JWT"| apim
    internal -->|"サブスクキー"| apim
    apim -->|"VNet統合"| api
    api --> sb --> worker
    worker --> di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
    aca --> natgw --> sb
    aca -.->|"イメージpull"| acr
    azure -.-> law
```

初期からの追加: APIM Standard v2 / VNet・PE×3・NSG / internal ingress / NAT Gateway / Blobソフト削除・ZRS化 / Defender for Storage / ACR Standard。共有URL機能をPoCで提供する場合はIP制限と共存できないため、共有URL用ルートのみIP制限を外し、トークン検証失敗のレート制限を先行実装する。

**月額目安: ~$950〜1,100 + DI従量**

#### 4.2.1 送信元IPが特定できない連携元(クラウド型業務システム)への対応

IP制限は「**識別可能な送信元にのみ適用する追加防御**」と位置づけ、成立しない経路では認証強化で置き換える。SAPやD365のようなクラウド型業務システムは、送信元IPがプラットフォームの共有レンジとなりテナント固有に絞れない場合があるため、連携元ごとにIP特定可否を判定して扱いを分ける。

| 連携元 | 送信元IPの特定 | 適用する防御 |
|---|---|---|
| オンプレ業務システム | 可 | IP制限+サブスクキー(基本形) |
| SAP BTP / Integration Suite (CPI) | 可(サブアカウント・リージョンごとに送信IPが公開されており実質固定。S/4HANA Cloud直連携でもCPIを挟めば送信元はCPIのIPになる) | IP制限+サブスクキー |
| D365 / Power Platform | 不可(Azure共有レンジ。サービスタグ単位の許可は「Azure上の任意の第三者を許可する」のと大差なく防御にならないため不採用) | **IP制限なし+OAuth2クライアントクレデンシャル** |

**OAuth2クライアントクレデンシャル経路**(IP特定不可の連携元向け)

- §2で「将来の移行余地」としたものを、該当テナントのバッチ経路のみ前倒しする
- テナントごとにEntraへアプリ登録し、連携システムはclient ID+シークレット(またはクライアント証明書)で短命トークンを取得、APIMは`validate-jwt`で検証。静的なサブスクリプションキー単体より強い(トークンが短命で漏洩時の影響窓が小さい)
- SAP CPI / D365 / Power Platformカスタムコネクタはいずれも送信側OAuth2クライアントクレデンシャルに対応しており実現性が高い。APIMにはJWT検証経路が既にあるため追加実装は小さい
- 対応可能な顧客には**mTLS(APIMクライアント証明書検証)** の上乗せをオプション提供(送信元IPに依存しない最も強い送信元認証。SAP CPIは対応、Power Platform系は制約が多い)
- 補償統制(どの案でも併用): サブスクリプション単位のレート制限・クォータ / 認証失敗・リクエスト急増アラートの前倒し稼働 / バッチAPIの許可操作を最小化(アップロード・照会のみ、管理系操作は載せない)

**顧客側リレー**: 顧客が固定IPの中継点(オンプレ、または顧客Azure VNet+NAT Gateway)を用意できる場合はIP制限がそのまま成立する。顧客側の構築・運用負担が大きいためこちらから求めるものではなく、顧客側から提案された場合の受け皿とする。

**WAF前倒しの判断**: PoCでFront Doorを先送りした根拠は「IP制限で露出を限定できる」こと。IP制限でカバーできない連携が主流になる場合はこの根拠が部分的に崩れるため、**Front Door Standard(~$35/月)をPoCへ前倒し導入**する。Premium(OWASPマネージドルール・ボット対策)の判断はリリース時のままでよい。

### 4.3 リリース: 本稼働(顧客本番データ)

方針: 全公開になるため、**IP制限で代替していた入口防御をWAFに置き換える**のがこのフェーズの本質的な変更。構成は§1の理想形(またはそこから§2で採択したダウングレード適用形)。

PoCからの追加・変更:

| 項目 | 内容 | 月額増分 |
|---|---|---|
| Front Door + WAF | APIMのIP制限を解除し、代わりにFront Doorを前段配置(`X-Azure-FDID`検証)。ティアは§2の判断(Premium ~$330〜380 / Standard ~$35) | +$35〜380 |
| ACR Premium + PE | イメージ供給網をプライベート化(Standard維持も可: §2) | +$37 |
| Key Vault + PE | 残余シークレットの置き場(不要なら見送り可: §2) | +$8 |
| Defender for Containers / OSS DB | ランタイム・DB脅威検知 | +$30〜45 |
| Log Analyticsフル収集+アラート整備 | pgaudit / Blobログ追加、認証失敗急増・DLQ滞留等のアラート | +$10〜30 |
| 運用整備(コスト外) | サブスクキーのローテーション手順 / DLQ運用 / インシデント対応フロー / 顧客向けデータ取り扱い説明(DI 24時間保持を含む) | — |

**月額目安: ~$1,050〜1,250(FD Standard採用時)〜 $1,350〜1,600(理想形)+ 従量**

### 4.4 フェーズ移行のゲート条件

- **初期 → PoC**: 顧客データを1件でも入れる前に、VNet/PE/internal ingress/NSG/NAT GW/ソフト削除/Defender for Storageの適用と、RLS越境・Blob越境の自動テスト合格を必須とする
- **PoC期間中(テナント受け入れごと)**: 連携元の送信元IP特定可否を判定する(§4.2.1)。特定不可の場合、当該テナントの**OAuth2クライアントクレデンシャル経路の実装**と**認証失敗・急増アラートの稼働**を受け入れ条件とする。IP制限でカバーされない連携が主流になった時点でFront Door Standardの前倒し導入を判断する
- **PoC → リリース**: IP制限の全面解除の前に、WAF(または見送りのリスク受容文書)/ アラート整備 / 共有トークンのレート制限・失効フロー / サブスクキーおよびOAuthクライアントシークレットのローテーション手順を必須とする
