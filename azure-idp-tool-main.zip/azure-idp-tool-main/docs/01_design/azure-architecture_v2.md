# Azureアーキテクチャ v2(理想形・フェーズ別構成)

> 本書は単体で読めるように書かれている。コスト試算はすべて **2026-07時点・東日本リージョン・月額USD概算**。確定前に料金計算ツールでの再確認が必要。
>
> 全体を貫く方針:
> - **防御レベルはフェーズのデータ機微度に連動させる**(顧客データが入った時点でデータ層の防御を本番同等にする)
> - **認証・認可の方式(Managed Identity / Entra ID認証 / RLS)はフェーズ1から本番同等にする**。ネットワーク強化はBicepパラメータで後から締められるが、認証方式の後付け変更は改修コストが大きい
>
> **API Managementは採用しない**(2026-08の社内レビューで決定)。Standard v2の固定費 ~$690/月が本サービスの収益規模に見合わないため。APIMが担う予定だった責務は Application Gateway + WAF(入口防御・レート制限・ヘッダ書き換え)と API 本体(JWT検証・テナント解決)へ再配置した。判断の詳細と失うものは [§2.1](#21-api-management-を採用しない判断) を参照。

## 1. 理想形構成(コスト度外視)

### 1.1 構成図

```mermaid
flowchart LR
    subgraph clients["利用者"]
        browser["ブラウザ<br>(一般ユーザ / システム管理者)"]
        internal["テナント社内システム<br>(バッチ連携)"]
        guest["共有URL受領者"]
    end

    subgraph azure["Azure"]
        swa["Static Web Apps<br>(SPA配信。AppGWのバックエンド)"]

        subgraph vnet["仮想ネットワーク (VNet) — 全サブネットにNSG"]
            agw["Application Gateway v2 + WAF_v2<br>【唯一の公開接点】snet-appgw に配置<br>OWASP CRSマネージドルール(Preventionモード)<br>レート制限カスタムルール / ファイルサイズ上限<br>受信 X-Tenant-Id をヘッダ書き換えで無条件削除<br>Keycloak管理パスを遮断<br>【振り分け】/api→API /realms・/resources→Keycloak 既定→SWA"]

            subgraph aca["Container Apps 環境 (internal ingress)<br>受信NSG: snet-appgw のみ許可"]
                api["API (FastAPI)<br>【JWT検証の唯一の強制点】<br>署名/issuer/aud検証 → クレームからテナント解決<br>アップロード検証(マジックバイト/サイズ)"]
                worker["ワーカー<br>最小1レプリカ / KEDA 1→N"]
                keycloak["Keycloak<br>(認証・JWT発行)<br>顧客IdPをIdentity Brokeringで連携<br>バッチ連携はサービスアカウント(OAuth2 CC)<br>最小1レプリカ(スケールゼロ不可)"]
            end
            natgw["NAT Gateway<br>(固定送信IP)"]
            di["Document Intelligence<br>【PE】パブリック無効"]
            blob["Blob Storage (ZRS)<br>テナント別コンテナ<br>ソフト削除+バージョニング(削除ジョブ誤爆対策)<br>【PE】パブリック無効"]
            pg["PostgreSQL Flexible Server<br>プールモデル + FORCE RLS<br>所有者ロール/アプリロール分離<br>アプリDBとKeycloakDBは別データベース・別ロール<br>pgaudit有効 / PITR<br>【PE】パブリック無効"]
            acr["Container Registry (Premium)<br>MI pull / イメージ脆弱性スキャン<br>【PE】パブリック無効"]
            kv["Key Vault<br>残余シークレット用<br>【PE】パブリック無効"]
        end

        sb["Service Bus (Standard)<br>interactive / batch キュー<br>MI認証(SAS無効) + IPファイアウォール<br>(NAT GWの固定IPのみ許可)<br>メッセージはID参照のみ・PII禁止"]
    end

    subgraph ops["監視・検知"]
        law["Log Analytics<br>AppGWアクセス・WAFログ / ACAログ / pgaudit /<br>Blobアクセスログ / Keycloakイベントログ"]
        defender["Defender for Cloud<br>Storage(マルウェアスキャン) /<br>Containers / OSS DB"]
        alerts["アラート<br>認証失敗急増 / 共有トークン検証失敗連続 /<br>DLQ滞留 / SBファイアウォール拒否"]
    end

    browser -->|"静的コンテンツ"| agw
    browser -->|"認証 (PKCE)"| agw
    browser -->|"API (JWT)"| agw
    internal -->|"バッチAPI<br>(OAuth2 CCで取得した短命JWT)"| agw
    guest -->|"トークン付き共有URL<br>(検証失敗レート制限)"| agw
    agw -->|"既定ルート"| swa
    agw -->|"VNet内プライベート転送"| api
    agw -->|"VNet内プライベート転送<br>(認証エンドポイントのみ)"| keycloak
    keycloak -->|"レルム・ユーザ・セッション"| pg
    api -->|"ジョブ投入"| sb
    sb -->|"KEDAスケール / 消化"| worker
    worker -->|"解析実行"| di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
    aca -->|"固定送信IP"| natgw --> sb
    aca -.->|"イメージpull (PE)"| acr
    azure -.-> law
    law --> alerts
```

### 1.2 設計の要点

1. **Application Gateway v2 + WAF_v2 が唯一の公開接点**。VNet内の専用サブネット(`snet-appgw`)に配置し、Container Apps(internal ingress)へVNet内でプライベートに転送する。OWASP CRSマネージドルールはWAF_v2の標準機能で、Front Door Premium相当のルールセットを1/3以下のコストで得られる
2. **アイデンティティは「JWTクレームのみ」に一本化**: テナントIDをヘッダで伝搬する仕組みを廃止した。Application Gatewayはヘッダ書き換えルールで受信`X-Tenant-Id`を無条件削除し、API側が検証済みJWTのクレームからテナントを解決する。フロントエンド経路(ユーザトークン)もバッチ経路(サービスアカウントトークン)も同じKeycloakがissuerのため、検証経路は1本で済む
3. **JWT検証はAPI側の単一強制点**。APIMを置かないためエッジでのJWT検証層はなくなる。到達性(internal ingress + NSGでAppGWサブネットのみ許可)とWAFのレート制限で補い、**多層防御が1層に減ったことをリスク受容として明示する**(§3.1 #2)
4. **バックエンドは全てVNet内またはPrivate Endpoint**、全サブネットにNSG。Service BusのみPE不可(Premium専用)のため、**NAT Gatewayの固定送信IP**+IPファイアウォール+Managed Identity認証で防御
5. **Azureリソース間認証はManaged Identityに統一**(SASキー・アクセスキー・接続文字列を廃止。PostgreSQLはEntra ID認証)
6. **監視・検知**: Log Analytics集約+Defender for Cloud+アラートを本番の必須構成とする
7. **Keycloakは自ホスト運用**(Container Apps + PostgreSQL)。マネージドIdPと異なり、バージョン追随・バックアップ・可用性が自社責任になる。ブラウザから直接到達する必要があるため、VNet内に置いたうえで Application Gateway 経由で認証エンドポイントのみを公開し、管理パス(`/admin/master`・`/admin/realms`・`/realms/master`)はWAFカスタムルールで遮断する
8. **静的コンテンツ(SWA)もApplication Gateway配下に置く**。SPAとAPIが同一オリジンになるためCORSが不要になり、公開接点をAppGW1つに保てる(NFR-SEC-6)。SWAを直接配信してSPAから別オリジンのAPIを呼ぶ案も検討したが、(a) バックエンドにCORSミドルウェアがなく設定ミスの事故リスクを持ち込む、(b) WAF配下にない公開面が2つになる、(c) 後からAppGW配下へ寄せるほうが高くつく、の3点で見送った。AppGWのCU消費が静的アセット分増えるのは受容する。
   - 振り分けは `/api/*`→API、`/realms/*`・`/resources/*`→Keycloak、既定→SWA
   - **SPAの管理画面ルートは`/admin/*`のため、Keycloak管理パスの遮断は`/admin`の前方一致にできない**。`/admin/master`・`/admin/realms`・`/realms/master`だけを対象にする(§3.1 #6)
   - SWA自身の既定ホスト名はこの構成でも公開のまま残る。厳密に公開接点を1つにするならSWAのPrivate Endpoint化が要るが、そこに載るのはテナントデータを含まない静的アセットのみのため段階導入とする(§4.4)

図に表れない前提:

- 共有トークン: 128bit以上のエントロピー、DBにはハッシュで保存、定数時間比較、検証失敗のIP単位レート制限
- バッチ連携の資格情報: テナントごとのKeycloakクライアント(client ID+シークレット)。シークレットのローテーション手順・漏洩時の失効フローが必要。トークン自体は短命のため、漏洩時の影響窓は静的キーより小さい
- RLS: 所有者ロール/アプリ接続ロールの分離+`FORCE ROW LEVEL SECURITY`+コネクション取得時にテナントコンテキストを強制設定するミドルウェア層
- Service Busメッセージはdocument ID等の参照のみ(PII禁止)、DLQの監視・掃除運用
- Blobテナント越境の自動テスト(コンテナ名導出の単一コード経路化)
- Document Intelligenceは解析データを最大24時間サービス側に保持する仕様 → 顧客向けデータ取り扱い説明に記載
- Keycloak: レルム構成は**検証環境では全テナント共通の単一レルム**とし、顧客企業のIdPはIdentity Brokeringで追加する(issuerが1つで済み、テナント解決は`users`テーブル経由の現行方式を維持できる)。本番でテナントごとにレルムを分離するかは未決(OI-20)。KeycloakのDBはアプリDBと同一サーバ上の**別データベース・別ロール**とし、アプリのRLSと権限境界を混ぜない

### 1.3 コスト試算

**基本構成**

| リソース | 月額目安 |
|---|---|
| Container Apps(消費・API/ワーカー/Keycloakが各最小1レプリカ常駐) | $75〜220 |
| PostgreSQL Burstable (B2s) | $50〜70 |
| Blob Storage (ZRS) | $10〜30 |
| Service Bus Standard | ~$10 |
| Static Web Apps Standard | $9 |
| Private Endpoint ×3 (PG/Blob/DI) | ~$22 |
| Document Intelligence S0 | 従量(解析量次第) |
| **小計** | **~$180〜360 + DI従量** |

**セキュリティ強化分**

| リソース | 月額目安 | 目的 |
|---|---|---|
| Application Gateway WAF_v2(基本料+CU+Public IP) | ~$280〜380 | 公開接点・WAF(OWASP CRS)・レート制限 |
| ACR Premium + PE | ~$57 | イメージ供給網の保護 |
| NAT Gateway(基本料+処理量) | ~$35〜45 | 送信IP固定(SBファイアウォールの成立条件) |
| Key Vault + PE | ~$8 | 残余シークレット管理 |
| Log Analytics(~5〜15GB/月想定) | $15〜45 | 監視・監査ログ |
| Defender for Storage(+マルウェアスキャン従量) | $10〜30 | アップロード検疫 |
| Defender for Containers | ~$15 | イメージ/ランタイム脅威検知 |
| Defender for OSS DB | ~$15〜30 | DB脅威検知 |
| NSG / Blobソフト削除 / pgaudit / WAFカスタムルール | ほぼ$0 | 多数(§3参照) |
| **小計** | **~$435〜610** | |

**理想形合計: 月額 ~$620〜970 + 従量(DI・転送量)**

APIM(~$690)とFront Door Premium(~$330〜380)を Application Gateway WAF_v2(~$280〜380)1本に置き換えたことで、旧試算の **~$1,350〜1,600 から ~$620〜970 へ、月額 ~$630〜730 の削減**になる。

## 2. 構成の判断とダウングレード選択肢

### 2.1 API Management を採用しない判断

**決定**(2026-08の社内レビュー): API Management は構成に含めない。

**理由**: Standard v2 の固定費 ~$690/月は、環境数(開発・検証・本番)を掛けると回収構造が成立しない。VNet統合を諦めて Basic v2(~$147)にするとバックエンドをパブリックに晒すことになり、コストを下げる代わりに設計の前提が崩れる。

**APIMが担う予定だった責務の再配置**:

| APIMの責務 | 再配置先 | 備考 |
|---|---|---|
| 唯一の公開接点 / バックエンドへのプライベート転送 | **Application Gateway v2**(VNet内配置) | APIMのアウトバウンドVNet統合と同等の到達性を、専用サブネット+NSGで実現 |
| WAF(APIM単体では不可。Front Door前提だった) | **WAF_v2 のOWASP CRSマネージドルール** | Front Door Premium専用だったOWASPルールが標準で使える。**この点は理想形より改善** |
| レート制限 | WAF カスタムルール(送信元IP単位)+ **アプリ側実装**(テナント単位) | AppGWのレート制限キーにテナントを使えないため、テナント別クォータはAPI側の責務になる(GAP-N2) |
| ボディサイズ上限 | WAF `fileUploadLimitInMb`(最大750MB)+ API側検証 | WAFのボディ検査上限は128KB(`maxRequestBodySizeInKb`)のため、500MBのPDF本体は検査対象外で通過する。**マジックバイト・サイズ検証はAPI側が実質的な唯一の砦**(§3.2 #8) |
| `validate-jwt` | **API側の検証のみ**(実装済み: `backend/app/core/auth.py`) | 多層防御が1層に減る。リスク受容として明示(§3.1 #2) |
| `X-Tenant-Id` の削除→再設定 | **仕組みごと廃止**。AppGWのヘッダ書き換えで削除のみ行い、テナントはJWTクレームから解決 | 「ヘッダを信頼する」経路が消えるため、偽装リスク自体がなくなる(§3.1 #1) |
| バッチAPIのサブスクリプションキー認証・キー管理API | **Keycloak の OAuth2 クライアントクレデンシャル** | §4.2.1 で「IP特定不可の連携元向け」としていた経路を全面採用。テナント設定画面のキー表示・再生成UIは廃止(§3.1 #3) |
| テナント別APIリクエスト数メトリクス | **アプリ側の計測** | AppGWのアクセスログにはテナント識別子が出ないため、ログ集計では代替できない。API側ミドルウェアでの計上が必要(FR-LOG-2) |

**失うもの(受容するリスク)**:

- **エッジでのJWT検証層**。未認証リクエストがAPIコンテナまで到達する。API側検証は実装済みだが、検証をすり抜けるバグが即座に露出につながる
- **APIMの開発者ポータル・製品/サブスクリプション管理**。テナントへのAPI資格情報の払い出しはKeycloakの管理機能と自前の運用手順で賄う
- **ポリシーによる宣言的なAPI流量制御**。テナント別レート制限・クォータがアプリ実装に移り、テストの責任範囲が増える

### 2.2 理想形からのダウングレード選択肢

コスト強化分の6割超がApplication Gateway WAF_v2。判断の主分岐はここ。

| 対象 | 理想形 | ダウングレード案 | 月額削減 | 失うもの(トレードオフ) |
|---|---|---|---|---|
| WAF/エッジ | Application Gateway WAF_v2 | **Application Gateway Standard_v2**(WAFなし) | 約$100〜130 | OWASPマネージドルール・レート制限カスタムルールが消滅。L7転送とTLS終端は残るが、公開SaaS+ファイルアップロード受付としてはリスク受容の明文化が必須 |
| WAF/エッジ | Application Gateway WAF_v2 | **Front Door Standard + ACA external ingress** | 約$245〜345 | AppGW($280〜380)をFD Standard(~$35)に置換。グローバルエッジ・DDoS緩和は得られるが、OWASPマネージドルールがPremium専用のため失う。またACAがinternal ingressを維持できずパブリック公開になる(FD Private Linkオリジンは要検証) |
| レジストリ | ACR Premium(PE) | **ACR Standard(パブリック+MI認証)** | 約$37 | イメージpullがパブリック経路になる(認証はMIで維持)。PE・ゾーン冗長を失う。脆弱性スキャンはCI側(Trivy等)で代替可能 |
| 検疫 | Defender for Storage | **アプリ側検証のみ**(マジックバイト/サイズ) | $10〜30 | マルウェア検知がなくなる。共有URLで第三者がファイルをダウンロードする本サービスの性質上、配布元責任のリスクが残る |
| 脅威検知 | Defender for Containers / OSS DB | **段階導入(ローンチ後に追加)** | $30〜45 | ランタイム脅威検知の空白期間。後付けが容易なため「時期の問題」に整理できる |
| ログ | Log Analytics フル収集 | **収集対象の絞り込み**(AppGWアクセス・WAFログ+Keycloakイベントログ優先) | $10〜30 | pgaudit/Blobログの遡及調査ができない。インシデント時の原因究明力が低下 |
| シークレット | Key Vault(PE) | **見送り**(MI統一で残余シークレットが実質ない場合) | 約$8 | 将来シークレットが発生した際の置き場がなく、環境変数直書きへ逃げる誘惑が生まれる |

### 削るべきでないもの

以下は合計~$60程度と安価なのに§3の観点の大半をカバーするため、ダウングレード対象にしない。

- WAFカスタムルール群(レート制限 / `X-Tenant-Id`のヘッダ削除 / Keycloak管理パスの遮断)
- API側のJWT検証とアップロード検証(APIM除外により**唯一の強制点**になったため、むしろ重要度が上がった)
- NSG(ほぼ$0)
- NAT Gateway(これを削るとService BusのIPファイアウォール自体が成立しない)
- Blobソフト削除+バージョニング
- RLSロール分離+FORCE RLS
- Log Analyticsの最小構成(検知ゼロの状態を避ける)

## 3. 各層のセキュリティ観点

### 3.1 公開層(SWA / Keycloak / Application Gateway)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 1 | テナントIDをヘッダで伝搬しない | ヘッダ伝搬方式では、前段がクライアント送信のヘッダを素通しした瞬間にテナント偽装が成立する | **ヘッダ伝搬の仕組みごと廃止**。Application Gatewayのリクエストヘッダ書き換えルールで受信`X-Tenant-Id`を無条件削除し、APIは検証済みJWTのクレームからのみテナントを解決する。削除ルールが漏れてもAPIがヘッダを読まないため二重に成立しない |
| 2 | **JWT検証がAPI側の単一強制点になった** | APIMを置かないためエッジでの`validate-jwt`層がない。未認証リクエストがAPIコンテナまで到達する | **リスク受容**(§2.1)。補償として、(a) Container Appsをinternal ingressにしNSGで`snet-appgw`からの受信のみ許可、(b) WAFカスタムルールで認証エンドポイントへのレート制限、(c) API側検証は必須クレーム(`exp`/`iss`/`aud`/`sub`)と署名アルゴリズムをRS256に固定、(d) 認証失敗急増のアラートを本番必須とする。単一レルム構成のため信頼するissuerは1つに固定できる(テナント別レルムにする場合はOI-20) |
| 3 | バッチ連携の資格情報 | テナント側での保管不備・漏洩 | **Keycloak の OAuth2 クライアントクレデンシャル**(テナントごとのサービスアカウント有効クライアント)。連携システムはclient ID+シークレットで短命トークンを取得し、APIが検証する。静的な長期キーを配らないため漏洩時の影響窓が小さい。シークレットのローテーション・失効はKeycloak管理機能で行う |
| 4 | WAFはOWASP CRSマネージドルールをPreventionモードで運用する | 公開SaaS+ファイルアップロード受付でOWASP系攻撃への防御層 | Application Gateway **WAF_v2** のマネージドルールセット(OWASP CRS 3.2)を有効化。Front Door Premium専用だったOWASPルールが標準で得られる。ただし**ボット対策マネージドルールはFront Door Premium専用**で、AppGWでは同等物が得られない点は差分として残る |
| 5 | 共有URLエンドポイントは実質未認証 | トークン総当たり / URL残留(履歴・プロキシログ・Referer) | 128bit以上のエントロピー / DBにハッシュ保存・定数時間比較 / 検証失敗のIP単位レート制限+失敗ログ / URL残留リスクの許容判断を明記。WAFのレート制限カスタムルールを共有URLパスに個別適用する |
| 6 | Keycloak管理コンソールがインターネットに露出する | `/admin/master/console`(管理UI)・`/admin/realms`(Admin REST API)・`/realms/master`(masterレルム認証)が公開されると、認証基盤そのものが総当たり・既知脆弱性の標的になる | WAFカスタムルールでこの3つのプレフィックスをBlockする。**`/admin`の前方一致にはできない** — SPAの管理画面が`/admin/document-types`等で同一オリジンに同居するため(§1.2 #8)。運用者はプライベート経路(踏み台またはVNet内)からのみ到達する。管理者アカウントはMFA必須。ブートストラップ管理者は初期構築後に無効化する |
| 7 | 認証基盤の脆弱性追随が自社責任になる | マネージドIdPと違い、Keycloakの重大CVEに自分でパッチを当てる必要がある | イメージタグを固定(`latest`禁止)したうえで、リリース追跡とアップデート手順を運用手順に組み込む。ACRの脆弱性スキャン対象に含める |
| 8 | テナント別のレート制限・クォータが宣言的に書けなくなった | AppGWのレート制限キーは送信元IP・セッション等に限られ、テナント単位では設定できない | 送信元IP単位の粗いレート制限をWAFで、テナント単位のクォータを**API側実装**で行う二段構え。具体値はGAP-N2として未決 |

### 3.2 アプリ層(Container Apps)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 6 | NSGによる東西トラフィック制御 | internal ingressでもVNet内に入れば環境へ到達可能。将来のサブネット追加時に穴になる | snet-acaの受信を`snet-appgw`からのみに絞るNSGを全サブネットに最初から敷く。`snet-appgw`側はAppGW v2が必須とするGatewayManagerからの受信(65200-65535)を許可する |
| 7 | イメージ供給網(サプライチェーン) | レジストリ認証・脆弱性スキャン・ベースイメージ更新が無防備 | ACRのManaged Identity pull / 脆弱性スキャン(Defender for ContainersまたはCI側Trivy等)/ ベースイメージ更新運用をCI/IaCに組み込む |
| 8 | アップロードファイルの検証場所 | 不正ファイルがDIまで素通り | マジックバイト検証・サイズ上限をAPI側で実施。**WAFのリクエストボディ検査上限は128KBのため500MBのPDF本体は検査されない**(WAFが見るのは`fileUploadLimitInMb`によるサイズ拒否まで)。したがってAPI側検証が唯一の内容検証点であり、省略できない。Defender for Storageのマルウェアスキャン採否を決定 |

### 3.3 非同期層(Service Bus)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 9 | IPファイアウォールは送信IPの安定が前提 | Container Apps環境の送信IP変動でファイアウォールが形骸化 or 障害化 | NAT Gatewayで固定送信IP化 |
| 10 | メッセージ本文の内容規定 | DLQが「失敗データの保管庫」化し、テナントデータが滞留 | メッセージはdocument ID等の**参照のみ**・PII禁止を方針化。DLQの監視・掃除運用を定義 |

### 3.4 データ層(Blob / PostgreSQL / Document Intelligence)

| # | 観点 | リスク | 設計上の対応 |
|---|---|---|---|
| 11 | **RLSはテーブル所有者にデフォルトで効かない** | マイグレーションロール=アプリ接続ロールだとRLSが素通し(プールモデルの定番の落とし穴) | 所有者ロールとアプリ接続ロールを分離+`FORCE ROW LEVEL SECURITY`。テナントコンテキスト(`set_config`)をコネクション取得時に強制設定するミドルウェア層 |
| 12 | Blobのテナント分離はアプリロジック頼み | API/ワーカーのMIは全テナントのコンテナにアクセス可能。アプリのバグ一つで越境 | 強制層がない事実を明示し、コンテナ名導出を単一コード経路に集約+テナント越境の自動テストを補償策とする |
| 13 | 日次削除ジョブの誤爆対策 | バグ時の大量削除 | Blob**ソフト削除+バージョニング**を有効化(安価な安全網) |
| 14 | DIのデータ保持仕様 | DIは解析データを最大24時間サービス側に保持 | 顧客向けデータ取り扱い説明に記載 |

### 3.5 横断(監視・検知)

- **Log Analytics集約**: Application Gatewayのアクセスログ・WAFログ(ブロック検知・429)/ Container Appsログ(APIの認証失敗を含む)/ PostgreSQL(pgaudit)/ Blobアクセスログ / Keycloakのイベントログ(サインイン・管理操作。Keycloak側でイベント保存を有効化し、コンテナログ経由でLog Analyticsへ流す)
- **アラート**: 認証失敗の急増 / 共有トークン検証失敗の連続 / DLQ滞留 / Service Busファイアウォール拒否。**APIMの診断ログがなくなり認証失敗の観測点がAPIのアプリログに一本化されたため、APIが構造化ログで認証失敗を出力することがアラートの前提条件になる**
- **テナント別APIリクエスト数**(FR-LOG-2)はAppGWのアクセスログからは取得できない(ログにテナント識別子が出ない)。API側ミドルウェアでの計上が必要
- **Defender for Cloud**(Storage / Containers / OSS DB)の採否をコスト込みで判断
- 監査ログはテナントへの説明責任(誰がいつ何にアクセスしたか)の観点でも本番必須

## 4. フェーズ別構成(草案)

フェーズはデータの機微度で区切り、防御レベルを連動させる。

| 項目 | 初期(社内開発) | PoC(顧客テストデータ) | リリース(顧客本番データ) |
|---|---|---|---|
| 扱うデータ | ダミーデータのみ | 顧客提供テストデータ(機密として扱う) | 顧客本番データ |
| 公開接点 | Container Apps直公開+**社内IP制限** | **Application Gateway + WAF**(IP特定可能な送信元はWAFカスタムルールでIP限定: §4.2.1) | Application Gateway + WAF(IP制限を解除して全公開) |
| WAF | なし | **あり**(OWASP CRS・Preventionモード) | あり |
| VNet / Private Endpoint | なし(パブリック+IPファイアウォール) | **あり(本番同等)** | あり |
| 認証方式(MI / Entra ID認証 / RLS) | **本番同等**(最初から) | 本番同等 | 本番同等 |
| Blobソフト削除 / NSG / NAT GW | — / — / — | あり / あり / あり | あり / あり / あり |
| 監視・検知 | Log Analytics最小 | +Defender for Storage | +Defender一式・アラート整備 |
| 月額目安 | **~$50〜100** | **~$540〜870** | **~$620〜970** |

APIM除外の副次的な効果として、**WAFがPoCフェーズから使えるようになった**。旧構成ではWAF(Front Door)がAPIMとは別建ての追加コストだったためリリースまで先送りし、PoCは送信元IP制限で代替する設計だった。Application Gatewayは公開接点そのものであり、WAF_v2とStandard_v2の差額は~$100〜130しかないため、PoC時点でWAFを入れない理由がない。IP制限は「WAFの代替」から「WAFに上乗せする追加防御」へ位置づけが変わる。

### 4.1 初期: 社内でのアプリ開発(顧客データなし)

方針: 顧客データが一切入らないため、**ネットワーク防御は最小化してコストと開発速度を優先**する。ただし認証方式(Managed Identity・Entra ID認証・RLS・キー無効化)は本番同等で実装する — ここを後回しにすると移行時の改修が最も高くつく。

```mermaid
flowchart LR
    dev["開発者・社内利用者"]

    subgraph azure["Azure(VNet・Private Endpointなし)"]
        swa["Static Web Apps Free"]
        subgraph aca["Container Apps 環境(external ingress)<br>受信は社内IPのみ許可 / 0→Nスケール"]
            api["API (FastAPI)<br>JWT検証・RLSコンテキスト設定は<br>この段階で実装"]
            worker["ワーカー(最小0レプリカ)"]
            keycloak["Keycloak(単一レルム)<br>認証フロー・JWTクレーム設計は本番同等<br>最小1レプリカ(スケールゼロ不可)"]
        end
        sb["Service Bus Standard<br>MI認証(SAS無効)"]
        di["Document Intelligence S0<br>パブリック+Entra認証のみ(キー無効)"]
        blob["Blob (LRS)<br>パブリック+IPファイアウォール<br>MI認証(キー無効)"]
        pg["PostgreSQL Burstable (B1ms)<br>パブリック+IPファイアウォール<br>Entra ID認証 / RLS・ロール分離は初期から実装<br>アプリDBとKeycloakDBは別データベース"]
        law["Log Analytics(最小)"]
    end

    dev -->|"静的コンテンツ"| swa
    dev -->|"認証"| keycloak
    dev -->|"API(社内IP制限)"| aca
    keycloak --> pg
    api --> sb --> worker
    worker --> di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
```

- **Application Gatewayはこのフェーズでは置かない**。VNetがないためAppGWを配置できず、社内IP制限で露出を絞れば足りる。Container Apps の ingress IP制限で代替する
- 認証(JWT検証)はこの段階からAPI側に実装する。APIM除外により**API側検証が唯一の強制点**になったため、フェーズ移行で増える検証層はない — 初期フェーズで作った認証コードがそのまま本番の防御になる
- SWAはFree、ワーカーは0レプリカ許容(コールドスタート要件は本番のみ)、PostgreSQLは最小SKU
- Bicepは本番と同一モジュールを使い、ネットワーク強化(VNet/PE/NSG/internal ingress)と Application Gateway をパラメータ(`networkEnabled` / `appGatewayEnabled`)で無効化する形にする — フェーズ移行が「パラメータ変更+差分デプロイ」になる

**月額目安: ~$50〜100 + DI従量**(ACA $10〜40 / PG $15〜25 / SB $10 / Blob・LA 数ドル)

### 4.2 PoC: 顧客提供テストデータの投入

方針: テストデータでも**顧客の実文書は機密**。データ層・ネットワーク層の防御を本番同等に引き上げる。公開接点は Application Gateway + WAF とし、**WAFはこのフェーズから本番同等**にする。加えて公開範囲をまだ限定できるうちは、WAFカスタムルールで**参加顧客の送信元IPに限定**する上乗せ防御をかける。

```mermaid
flowchart LR
    subgraph clients["参加顧客"]
        browser["ブラウザ"]
        internal["顧客業務システム<br>(オンプレ / SAP / D365等クラウド)"]
    end

    subgraph azure["Azure"]
        swa["Static Web Apps Standard<br>(AppGWのバックエンド)"]

        subgraph vnet["VNet — 全サブネットにNSG"]
            agw["Application Gateway WAF_v2<br>OWASP CRS(Preventionモード) — 本番同等<br>IP特定可能な送信元はカスタムルールで限定<br>IP特定不可の連携経路はOAuth2 CC認証(§4.2.1)<br>レート制限 / ファイルサイズ上限 /<br>X-Tenant-Id 削除 / Keycloak管理パス遮断"]

            subgraph aca["Container Apps 環境(internal ingress)"]
                api["API (FastAPI)<br>JWT検証・テナント解決"]
                worker["ワーカー(最小1レプリカ)"]
                keycloak["Keycloak(最小1レプリカ)<br>AppGW経由で認証エンドポイントのみ公開"]
            end
            natgw["NAT Gateway(固定送信IP)"]
            di["Document Intelligence【PE】"]
            blob["Blob (ZRS)<br>ソフト削除+バージョニング【PE】"]
            pg["PostgreSQL (B2s)<br>FORCE RLS / pgaudit【PE】"]
        end

        sb["Service Bus Standard<br>MI認証+IPファイアウォール(NAT GW固定IP)"]
        acr["ACR Standard<br>パブリック+MI pull / CI側スキャン"]
    end

    subgraph ops["監視"]
        law["Log Analytics<br>AppGWアクセス・WAFログ+Keycloakイベント優先"]
        dfs["Defender for Storage<br>(マルウェアスキャン)"]
    end

    browser -->|"静的コンテンツ"| agw
    browser -->|"認証 (PKCE)"| agw
    browser -->|"JWT"| agw
    internal -->|"OAuth2 CCで取得した短命JWT"| agw
    agw -->|"既定ルート"| swa
    agw --> api
    agw -->|"認証エンドポイント"| keycloak
    keycloak --> pg
    api --> sb --> worker
    worker --> di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
    aca --> natgw --> sb
    aca -.->|"イメージpull"| acr
    azure -.-> law
```

初期からの追加: Application Gateway WAF_v2 / VNet・PE×3・NSG / internal ingress / NAT Gateway / Blobソフト削除・ZRS化 / Defender for Storage / ACR Standard。共有URL機能をPoCで提供する場合はIP制限と共存できないため、共有URL用パスのみIP制限ルールの対象外とし、トークン検証失敗のレート制限を先行実装する(WAFのレート制限カスタムルールとAPI側実装の二段構え)。

**月額目安: ~$540〜870 + DI従量**

#### 4.2.1 送信元IPが特定できない連携元(クラウド型業務システム)への対応

**バッチAPIの認証は全連携元でOAuth2クライアントクレデンシャルに統一する**(APIM除外によりサブスクリプションキー方式が使えなくなったため)。そのうえでIP制限を「**識別可能な送信元にのみ適用する追加防御**」として上乗せする。SAPやD365のようなクラウド型業務システムは、送信元IPがプラットフォームの共有レンジとなりテナント固有に絞れない場合があるため、連携元ごとにIP特定可否を判定して扱いを分ける。

| 連携元 | 送信元IPの特定 | 適用する防御 |
|---|---|---|
| オンプレ業務システム | 可 | OAuth2 CC + **WAFカスタムルールによるIP制限** |
| SAP BTP / Integration Suite (CPI) | 可(サブアカウント・リージョンごとに送信IPが公開されており実質固定。S/4HANA Cloud直連携でもCPIを挟めば送信元はCPIのIPになる) | OAuth2 CC + IP制限 |
| D365 / Power Platform | 不可(Azure共有レンジ。サービスタグ単位の許可は「Azure上の任意の第三者を許可する」のと大差なく防御にならないため不採用) | **OAuth2 CCのみ**(IP制限なし) |

**OAuth2クライアントクレデンシャル経路**

- テナントごとにKeycloakへサービスアカウント有効のクライアントを登録し、連携システムはclient ID+シークレット(またはクライアント証明書)で短命トークンを取得する。APIは`Authorization: Bearer`のJWTを検証し、クレームからテナントを解決する
- **フロントエンドAPIと同じKeycloakがissuer**になるため、検証経路・信頼するissuerを増やさずに済む。API側の検証実装(`backend/app/core/auth.py`)はユーザトークンとサービスアカウントトークンで共通化でき、差分は「`user_id`を持たない・ロールが`batch`になる」点のみ
- SAP CPI / D365 / Power Platformカスタムコネクタはいずれも送信側OAuth2クライアントクレデンシャルに対応しており実現性が高い
- 対応可能な顧客には**mTLS(Application Gatewayのクライアント証明書検証)** の上乗せをオプション提供(送信元IPに依存しない最も強い送信元認証。SAP CPIは対応、Power Platform系は制約が多い)
- 補償統制(どの案でも併用): テナント単位のレート制限・クォータ(**API側実装**: §3.1 #8)/ 認証失敗・リクエスト急増アラートの前倒し稼働 / バッチAPIの許可操作を最小化(アップロード・照会のみ、管理系操作は載せない)

**顧客側リレー**: 顧客が固定IPの中継点(オンプレ、または顧客Azure VNet+NAT Gateway)を用意できる場合はIP制限がそのまま成立する。顧客側の構築・運用負担が大きいためこちらから求めるものではなく、顧客側から提案された場合の受け皿とする。

**ボット対策の差分**: WAF_v2のOWASP CRSはPoCから有効だが、**ボット対策マネージドルールセットはFront Door Premium専用**でAppGWには同等物がない。ボット由来の不正アクセスが実測で問題化した場合に、Front Door Premiumの前置(+~$330〜380)を再検討する。現時点では「IP制限+レート制限で足りる」と判断して見送る。

### 4.3 リリース: 本稼働(顧客本番データ)

方針: 全公開になるため、**WAFカスタムルールのIP制限を解除する**のがこのフェーズの入口側の変更。WAF本体はPoCから稼働済みのため、旧構成のような「WAF層の新規導入」は発生せず、**フェーズ移行のリスクが大きく下がる**。構成は§1の理想形(またはそこから§2.2で採択したダウングレード適用形)。

PoCからの追加・変更:

| 項目 | 内容 | 月額増分 |
|---|---|---|
| WAFのIP制限解除 | 送信元IP限定のカスタムルールを外し、OWASP CRS+レート制限のみで受ける。**リソース追加なし** | ±$0 |
| ACR Premium + PE | イメージ供給網をプライベート化(Standard維持も可: §2.2) | +$37 |
| Key Vault + PE | 残余シークレットの置き場(不要なら見送り可: §2.2) | +$8 |
| Defender for Containers / OSS DB | ランタイム・DB脅威検知 | +$30〜45 |
| Log Analyticsフル収集+アラート整備 | pgaudit / Blobログ追加、認証失敗急増・DLQ滞留等のアラート | +$10〜30 |
| 運用整備(コスト外) | Keycloakクライアントシークレットのローテーション手順 / DLQ運用 / インシデント対応フロー / 顧客向けデータ取り扱い説明(DI 24時間保持を含む) | — |
| ボット対策(任意) | 必要と判断した場合のみ Front Door Premium を前置(§4.2.1) | +$330〜380 |

**月額目安: ~$620〜970 + 従量**(Front Door Premiumを追加する場合は +$330〜380)

### 4.4 フェーズ移行のゲート条件

- **初期 → PoC**: 顧客データを1件でも入れる前に、Application Gateway + WAF / VNet/PE/internal ingress/NSG/NAT GW/ソフト削除/Defender for Storageの適用と、RLS越境・Blob越境の自動テスト合格を必須とする。加えて、APIMを置かないことで**API側のJWT検証が唯一の強制点**になるため、認証バイパスの自動テスト(トークンなし・署名不正・issuer違い・aud違い・期限切れがすべて401になること)の合格をゲート条件に追加する
- **PoC期間中(テナント受け入れごと)**: 連携元の送信元IP特定可否を判定する(§4.2.1)。特定可否にかかわらず**OAuth2クライアントクレデンシャル経路**が前提であり、特定可能な場合のみWAFカスタムルールでIP制限を上乗せする。**認証失敗・急増アラートの稼働**は全テナント共通の受け入れ条件とする
- **PoC → リリース**: IP制限の全面解除の前に、アラート整備 / 共有トークンのレート制限・失効フロー / Keycloakクライアントシークレットのローテーション手順 / テナント別レート制限・クォータのAPI側実装(§3.1 #8)を必須とする
- **段階導入で構わないもの**: Static Web Apps のPrivate Endpoint化(§1.2 #8)。SWAの既定ホスト名がWAF配下でないまま残るが、そこに載るのはテナントデータを含まない静的アセットのみのため、ゲート条件には含めない
