# データモデル

PostgreSQL Flexible Server。プールモデル(全テナント同居)+ Row-Level Security。全9テーブル。

## 設計方針

- 主キーはすべてUUID(`gen_random_uuid()`)
- テナントに属するテーブルはすべて`tenant_id`列を持つ。**子テーブルにも非正規化して持たせ、RLSを全テーブルに一律適用する**(JOIN経由の適用漏れを防ぐ)
- RLSはセッション変数`app.tenant_id`と比較するポリシーで実装。APIは検証済みJWTのクレーム(フロントエンド経路=ユーザトークン、バッチ経路=サービスアカウントトークン)からテナントを解決し、トランザクション開始時に`SET LOCAL app.tenant_id = ...`を発行する
- SaaS運用者はテナント外の存在のため`users`テーブルには持たない(Keycloakのレルムロールで管理し、RLSをバイパスする専用接続ロールを使う)
- **常に親と丸ごと読み書きされ、横断検索されない「集約」はjsonb列で持つ**(ドキュメントのページ情報)。行単位の更新や横断検索があるものだけを独立テーブルにする(過剰なテーブル分割を避ける)
- 座標はすべてページサイズで正規化した座標系(0〜1)のjsonb `{x0, y0, x1, y1}`で保存
- DI解析結果の生JSONは大きいためDBに入れずBlobに保存し、パスのみ持つ
- Blob内パスは命名規約で統一する: `documents/{document_id}/original.pdf` / `documents/{document_id}/pages/{page_no}.png` / `documents/{document_id}/analysis/layout.json`(コンテナはテナントごと)。ページPNGのパスは規約から導出し、DBには保存しない。Blob側の詳細は [blob-storage.md](blob-storage.md) を参照

## ER図

```mermaid
erDiagram
    tenants ||--o{ users : ""
    tenants ||--o{ document_types : ""
    tenants ||--o{ documents : ""
    tenants ||--o{ usage_logs : ""
    tenants ||--o{ di_call_logs : ""
    tenants ||--o{ api_request_counters : ""
    document_types ||--o{ transcription_fields : ""
    document_types ||--o{ documents : ""
    transcription_fields ||--o{ extracted_values : ""
    documents ||--o{ extracted_values : ""
    documents ||--o{ share_links : ""
    documents ||--o{ di_call_logs : ""
```

## テーブル定義

### tenants(テナント)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| name | text | テナント名 |
| retention_days | int | データ保持期間(日)。デフォルト90。転記完了後この日数で自動削除 |
| created_at | timestamptz | |

### users(ユーザ)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| idp_subject | text UNIQUE | Keycloakが発行するJWTの`sub`(IdP側のユーザ識別子)。IdPの乗り換えに耐えるようIdP名を含めない列名にしている |
| email | text | |
| display_name | text | |
| role | text | `tenant_admin`(システム管理者)/ `member`(一般ユーザ) |
| created_at | timestamptz | |

### document_types(書類種別)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | テナント個別リソース |
| code | text | バッチAPIでの指定用コード。テナント内UNIQUE |
| name | text | 表示名(見積書、注文書など) |
| created_at | timestamptz | |

### transcription_fields(転記項目定義)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| document_type_id | uuid FK | |
| json_key | text | 出力JSONのキー名。書類種別内UNIQUE |
| label_ja | text | 日本語ラベル |
| value_type | text | `string` / `number` / `date` |
| query_field_key | text NULL | DI Query Fieldsで指定するキー名 |
| sort_order | int | 表示・出力順 |

- 転記項目はヘッダ項目のみ。明細列の意味づけは業務システム側の責務のため、明細列に対応する項目定義は持たない

### documents(ドキュメント)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| document_type_id | uuid FK | アップロード時に指定 |
| status | text | `uploaded` → `analyzing` → `analyzed` → `confirmed`(+ `failed`) |
| file_name | text | 元ファイル名 |
| file_hash | text | SHA-256。テナント内UNIQUE(重複検知。重複時は既存ドキュメントの参照を返す【仮】) |
| page_count | int NULL | 解析完了時に設定(アップロード時点では不明) |
| pages | jsonb NULL | ページ情報: `[{page_no, width_px, height_px}]`(座標変換用)。解析完了時に設定。PNGパスは命名規約から導出 |
| source | text | `frontend` / `batch` |
| uploaded_by | uuid FK NULL | バッチ時はNULL |
| layout_blob_path | text NULL | DI Layout生JSONのBlobパス(解析完了時に設定) |
| query_fields_result | jsonb NULL | Query Fields結果(値+座標)。解析完了時に設定 |
| line_item_table | jsonb NULL | ユーザが選択した明細領域: `{page_no, table_index, columns: [{column_no, header_text}]}`。明細領域選択時に設定 |
| error_message | text NULL | `failed`時の理由 |
| created_at / analyzed_at / confirmed_at | timestamptz | |

- `status`と`uploaded`滞留時間で回収処理(キュー再投入)の対象を判定する
- 原本PDFのBlobパスも命名規約(`documents/{id}/original.pdf`)から導出する

### extracted_values(転記値: 候補〜確定)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| document_id | uuid FK | |
| transcription_field_id | uuid FK NULL | ヘッダ項目のみ設定(明細セルはNULL) |
| row_no | int NULL | NULL=ヘッダ項目、0始まり=明細行 |
| column_no | int NULL | 明細セルの列番号(0始まり)。ヘッダ項目はNULL |
| page_no | int NULL | |
| bbox | jsonb NULL | 抽出元矩形(手入力時はNULL)。オーバレイ連動用でJSON出力には含めない |
| value_raw | text | 読み取り生文字列 |
| value_normalized | text NULL | 型に従い正規化した値(ヘッダ項目のみ。明細セルは正規化しない) |
| normalization_failed | boolean | 正規化失敗フラグ(ヘッダ項目のみ) |
| manually_edited | boolean | 手動修正の履歴 |
| updated_at | timestamptz | |

- ヘッダ項目は`transcription_field_id`、明細セルは`row_no + column_no`(`documents.line_item_table`の列定義に対応)で識別する
- 解析完了時にQuery Fields結果をヘッダ項目の初期候補としてINSERTし、明細セルはユーザが明細領域を選択した時点でDI検出テーブルからINSERTする。ユーザ修正でUPDATE、`documents.status = confirmed`で確定とみなす(バージョン管理はしない)
- 明細行×列で行数が多く、値単位の属性(手動修正)を持つため独立テーブルで持つ

### share_links(共有URL)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| document_id | uuid FK | |
| token_hash | text UNIQUE | ランダムトークン(128bit以上)のSHA-256。平文は保存しない |
| expires_at | timestamptz | |
| revoked_at | timestamptz NULL | 失効操作 |
| created_at | timestamptz | |

- 発行・失効はバッチAPI経由(業務システム)のみ。認証がテナント単位のサービスアカウント(OAuth2 CC)のため発行者ユーザは持たない(監査は`usage_logs`の`share_create`/`share_revoke`で行う)

### usage_logs(利用ログ)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| user_id | uuid FK NULL | 共有URLアクセス・バッチはNULL |
| action | text | `upload` / `analyze` / `confirm` / `share_create` / `share_revoke` / `share_access` / `export` など |
| resource_type / resource_id | text / uuid | 対象リソース |
| detail | jsonb | 付帯情報 |
| created_at | timestamptz | |

### di_call_logs(DIコール記録)

| 列 | 型 | 説明 |
|---|---|---|
| id | uuid PK | |
| tenant_id | uuid FK | |
| document_id | uuid FK NULL | ON DELETE SET NULL。課金根拠のため保持期間によるドキュメント削除後もレコードを残す |
| pages | int | 課金ページ数(全コールがLayout + Query Fieldsのためフラグは持たない) |
| created_at | timestamptz | テナント別DIコール数・コスト集計の源泉 |

- `usage_logs`への統合も可能だが、テナント課金の根拠となる数字のため型付き列での集計しやすさ・堅牢さを優先して分離を維持する

### api_request_counters(APIリクエスト数の日次カウンタ)

| 列 | 型 | 説明 |
|---|---|---|
| tenant_id | uuid PK/FK | `day`との複合主キー |
| day | date PK | JSTの日付 |
| count | int | その日のAPIリクエスト数 |

- APIリクエスト数(FR-LOG-2)はAPI Managementのメトリクスを源泉とする想定だったが、APIMを構成から外し([azure-architecture_v2.md §2.1](azure-architecture_v2.md#21-api-management-を採用しない判断))、Application Gatewayのアクセスログにはテナント識別子が出ないためログ集計では代替できない。アプリ側(ミドルウェア)で計上する
- リクエストごとに1行入れるとテーブルがリクエスト数に比例して膨れるため、`(tenant_id, day)`の1行をUPSERTでインクリメントする。行数は「テナント数×日数」に収まり、画面が必要とする月次合計・日次推移もこの粒度で足りる
- 同一行への更新が集中するため、リクエスト頻度が上がるとホットロウになりうる。プロトタイプ段階では許容し、問題化したらシャーディング(テナント×日×バケット)や非同期バッファリングを検討する
- 課金根拠は`di_call_logs`であり、こちらは利用状況の目安。計上の失敗はリクエストを失敗させない

## Row-Level Security

```sql
-- 全テナントスコープテーブルに同型のポリシーを適用
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON documents
    USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

- アプリ用DBロールは`BYPASSRLS`を持たない
- マイグレーションや全テナント横断の運用(SaaS運用者向け集計)は専用ロールで実行する
