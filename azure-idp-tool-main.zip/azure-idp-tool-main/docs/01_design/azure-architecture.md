# Azureアーキテクチャ

## 構成図

```mermaid
flowchart LR
    subgraph clients["利用者"]
        browser["ブラウザ<br>(一般ユーザ / システム管理者)"]
        internal["テナント社内システム<br>(バッチ連携)"]
        guest["共有URL受領者"]
    end

    subgraph azure["Azure"]
        entra["Microsoft Entra External ID<br>(認証・JWT発行)"]
        swa["Static Web Apps<br>(Vue.js フロントエンド配信)"]
        apim["API Management (Standard v2)<br>唯一の公開接点<br>サブスクリプションキー認証 / レート制限 /<br>テナント別リクエスト数計測"]

        subgraph vnet["仮想ネットワーク (VNet)"]
            subgraph aca["Container Apps 環境 (internal ingress)"]
                api["API<br>(FastAPI)"]
                worker["ワーカー<br>(同一イメージ・起動コマンド違い)<br>最小1レプリカ / KEDAで1→N"]
            end
            di["Document Intelligence<br>prebuilt-layout + Query Fields<br>【Private Endpoint】"]
            blob["Blob Storage (ZRS)<br>テナントごとにコンテナ分離<br>【Private Endpoint】"]
            pg["PostgreSQL Flexible Server<br>プールモデル + RLS / PITR<br>【Private Endpoint】"]
        end

        sb["Service Bus (Standard)<br>interactive キュー(優先)/ batch キュー<br>Managed Identity + IPファイアウォール<br>(PEはPremium専用のため対象外)"]
    end

    browser -->|"静的コンテンツ"| swa
    browser -->|"認証"| entra
    browser -->|"API (JWT)"| apim
    internal -->|"バッチAPI (サブスクリプションキー)"| apim
    guest -->|"トークン付き共有URL"| apim
    apim -->|"アウトバウンドVNet統合"| api
    api -->|"ジョブ投入"| sb
    sb -->|"KEDAスケール / 消化"| worker
    worker -->|"解析実行 (LROポーリング)"| di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
```

## 構成要素と役割

| リソース | ティア/構成 | 役割・設計上のポイント |
|---|---|---|
| Static Web Apps | Free〜Standard | Vueフロントエンドの配信(公開) |
| Entra External ID | 5万MAUまで無料 | ローカルアカウント+顧客Entra IDフェデレーション。テナント判別はJWTクレーム |
| API Management | **Standard v2** | **唯一の公開接点**。アウトバウンドVNet統合でVNet内のContainer Appsへ到達。バッチAPIのサブスクリプションキー認証(テナントごとに発行)、レート制限、テナント別リクエスト数計測。Basic v2はVNet機能なし、Consumptionはポリシー制約により不採用 |
| Container Apps (API) | 消費プラン・**internal ingress** | FastAPI。VNet内に配置しAPIM経由でのみ到達可能(`X-Tenant-Id`偽装防止をネットワーク層で担保)。アップロード受付・オーバレイ用データ提供・確定処理・共有URL検証 |
| Container Apps (ワーカー) | 最小1レプリカ | APIと同一イメージ。interactiveキュー優先消化。DIのTPS上限は同時実行数で一元制御。Jobsはコールドスタートのため不採用 |
| Service Bus | **Standard** | `interactive` / `batch` の優先度別2キュー。DLQ標準。Managed Identity認証(SASキー無効化)+IPファイアウォール。Private EndpointはPremium専用(月$680〜)で過剰なため不採用 |
| Document Intelligence | S0(従量)・**Private Endpoint** | prebuilt-layout + Query Fields(全書類に同梱)。パブリックアクセス無効 |
| Blob Storage | ZRS・**Private Endpoint** | テナントごとにコンテナ分離。原本PDF・ページPNG・DI解析結果の生JSONを保存。保持期間超過分はワーカーの日次ジョブで自動削除(ライフサイクル管理は「転記完了からN日」というテナント可変条件を表現できないため主手段にしない)。パブリックアクセス無効 |
| PostgreSQL Flexible Server | Burstable〜・**Private Endpoint** | プールモデル + Row-Level Security。PITRによるバックアップ。パブリックアクセス無効 |

## ネットワーク設計

- **公開されるのはStatic Web Apps(静的コンテンツ)とAPI Managementの受信側のみ**。SaaSの性質上、利用者はインターネット越しに来るためAPIMの受信は公開が正であり、TLS+認証(JWT/サブスクリプションキー/共有トークン)+レート制限で防御する
- バックエンドはすべてVNet内またはプライベートアクセス限定
  - Container Apps環境: VNet内・internal ingress。到達経路はAPIMのアウトバウンドVNet統合のみ
  - PostgreSQL / Blob / Document Intelligence: Private Endpoint(各 月$7〜8)+パブリックアクセス無効。名前解決はPrivate DNSゾーン
  - Service Bus: Private Endpoint不可(Premium専用)のため例外的にパブリックエンドポイントを維持し、Managed Identity認証+IPファイアウォール(Container Apps環境の送信IPのみ許可)で防御
- Azureリソース間の認証はManaged Identityに統一し、接続文字列・アクセスキーの保持を廃止する(PostgreSQLはEntra ID認証)

### VNet・サブネット / Private Endpoint 構成図

```mermaid
flowchart TB
    apim["API Management (Standard v2)<br>受信: パブリック(唯一の公開接点)"]

    subgraph vnet["VNet 10.0.0.0/16(アドレスは例)"]
        subgraph snet_apim["snet-apim-integration 10.0.0.0/27<br>委任: Microsoft.Web/serverFarms"]
            apim_int["APIM アウトバウンド<br>VNet統合ポイント"]
        end
        subgraph snet_aca["snet-aca 10.0.1.0/27<br>委任: Microsoft.App/environments"]
            aca_env["Container Apps環境<br>(internal ingress)<br>API / ワーカー"]
        end
        subgraph snet_pe["snet-pe 10.0.2.0/27(委任なし)"]
            pe_pg["Private Endpoint<br>(PostgreSQL)"]
            pe_blob["Private Endpoint<br>(Blob)"]
            pe_di["Private Endpoint<br>(Document Intelligence)"]
        end
    end

    pg["PostgreSQL Flexible Server<br>パブリックアクセス無効"]
    blob["Blob Storage<br>パブリックアクセス無効"]
    di["Document Intelligence<br>パブリックアクセス無効"]
    sb["Service Bus (Standard)<br>パブリックエンドポイント維持<br>IPファイアウォール + Managed Identity"]

    apim --> apim_int
    apim_int -->|"Private DNSで名前解決"| aca_env
    aca_env --> pe_pg --> pg
    aca_env --> pe_blob --> blob
    aca_env --> pe_di --> di
    aca_env -.->|"環境の送信IPのみ許可"| sb
```

### サブネット設計

| サブネット | CIDR(例) | 委任 | 用途 |
|---|---|---|---|
| snet-apim-integration | 10.0.0.0/27 | `Microsoft.Web/serverFarms` | APIM Standard v2のアウトバウンドVNet統合用 |
| snet-aca | 10.0.1.0/27 | `Microsoft.App/environments` | Container Apps環境(ワークロードプロファイル型・internal ingress)。消費専用(レガシー)環境にする場合は/23以上が必要 |
| snet-pe | 10.0.2.0/27 | なし | Private Endpoint集約用(PostgreSQL / Blob / DI) |

### Private DNSゾーン

Private Endpointおよびinternal環境の名前解決のため、以下のPrivate DNSゾーンを作成しVNetにリンクする。

| ゾーン | 対象 |
|---|---|
| `privatelink.postgres.database.azure.com` | PostgreSQL Flexible ServerのPE |
| `privatelink.blob.core.windows.net` | Blob StorageのPE |
| `privatelink.cognitiveservices.azure.com` | Document IntelligenceのPE |
| Container Apps環境の既定ドメインゾーン(`<環境固有>.<リージョン>.azurecontainerapps.io`) | APIMからinternal環境のFQDNを解決するために必要(環境作成後に払い出されるドメインでゾーンを作成) |

## リクエストの流れ

### 1. フロントエンドからの解析(interactive・優先)

1. ブラウザ → APIM → API: PDFアップロード(書類種別を指定)
2. API: Blobへ原本保存、`documents`レコード作成(`uploaded`)、ファイルハッシュ重複検知
3. API → Service Bus `interactive`キューへジョブ投入
4. ワーカー: Layout + Query FieldsでDI解析 → 結果保存(`analyzed`)、Query Fields結果をヘッダ項目の初期候補として取り込み
5. ブラウザ: 処理状態をポーリングし、完了後オーバレイ表示

### 2. バッチ連携

1. 社内システム → APIM(サブスクリプションキー)→ API: PDF一括アップロード(書類種別コードをパラメータ指定)
2. `batch`キュー経由で同一パイプラインを実行(interactiveが常に優先)
3. 社内システムは一覧・処理状況APIをポーリング

### 3. 共有URL

1. 業務システムがバッチAPI(サブスクリプションキー)で共有URL発行 → アプリ発行のランダムトークン(有効期限付き・失効可能)
2. 受領者はトークン付きURLでアクセス → APIがトークン検証 → ページ画像閲覧・原本ダウンロードを配信
3. アクセスは利用ログに記録(Blob SAS直接配布はログ・失効の観点で不採用)

## 可用性・データ保護

- 単一リージョン構成(マルチリージョンDRは明示的に見送り)
- PostgreSQL: PITR / Blob: ZRS
- 稼働率目標は本番から99.5%(SLA直列合成の理論値 約99.7%)

## IaC

- Bicepで全リソースを定義(`infra/`)
- モジュール分割の想定: ネットワーク(VNet・サブネット・Private DNS)/ データ(PostgreSQL・Blob・Private Endpoint)/ コンピュート(Container Apps環境)/ APIM / 監視

---

## セキュリティレビュー(層別の観点)

> 現行構成(本書上部)に対するレビュー結果。ネットワーク分離は良くできている一方、**アプリケーション層のアイデンティティ伝搬(X-Tenant-Id / JWT / RLSコンテキスト)と検知・監査が設計上の空白**、というのが総括。

### 公開層(SWA / Entra External ID / APIM)

| # | 指摘 | リスク | 推奨対策 |
|---|---|---|---|
| 1 | `X-Tenant-Id`の偽装防止が「ネットワーク層」のみ | APIMがクライアント送信のヘッダを素通しすると、APIM経由でテナント偽装が可能。防げているのは「APIM以外からの到達」だけ | APIMポリシーで受信`X-Tenant-Id`を**無条件削除**し、検証済みJWTのクレームまたはサブスクキーに紐づくテナントIDから**APIMが再設定**する一方向の流れを強制 |
| 2 | JWT検証の場所が未定義 | FastAPI側のみだとAPIMが未認証トラフィックをバックエンドへ素通し | APIMで`validate-jwt`(署名/issuer/audience/有効期限)+API側でも再検証の多層防御。顧客Entra IDフェデレーションでissuerが複数になるため、どのissuerのどのクレームを信じるかの信頼境界を定義 |
| 3 | サブスクリプションキーは長期共有シークレット | テナント側での保管不備・漏洩 | (a) ヘッダのみ許可(クエリ文字列でのキー送信を無効化) (b) プライマリ/セカンダリ2キーでのローテーション手順 (c) 漏洩時の失効フロー。将来はOAuth2クライアントクレデンシャルへの移行余地 |
| 4 | WAFがない(APIM Standard v2はWAFではない) | 公開SaaS+ファイルアップロード受付に対しOWASP系攻撃・ボットへの防御層がない | Front Door(WAF付き)を前段に配置。置かない場合は「コスト判断で見送り、APIMのレート制限+サイズ上限で代替」と意思決定を明記。APIMポリシーでの**リクエストボディサイズ上限**は必須 |
| 5 | 共有URLエンドポイントは実質未認証 | トークン総当たり | 128bit以上のエントロピー、検証失敗のIP単位レート制限、失敗ログ記録。トークンは**DBにハッシュで保存**・定数時間比較。トークン付きURLはブラウザ履歴・プロキシログに残る性質の許容判断も明記 |

### アプリ層(Container Apps)

| # | 指摘 | リスク | 推奨対策 |
|---|---|---|---|
| 6 | NSGが未定義 | internal ingressでもVNet内に入れば環境へ到達可能。将来のサブネット追加時に穴になる | snet-acaの受信をsnet-apim-integrationからのみに絞るNSGを全サブネットに最初から敷く |
| 7 | コンテナレジストリ・イメージの扱いが未定義 | イメージ供給網(サプライチェーン)が無防備 | ACRのManaged Identity pull、脆弱性スキャン(Defender for Containers等)、ベースイメージ更新運用をCI/IaCに組み込む |
| 8 | アップロードファイルの検証場所が未定義 | 不正ファイルがDIまで素通り | マジックバイト検証・サイズ上限をAPI側で実施。要件次第でDefender for Storageのマルウェアスキャン採否を決定 |

### 非同期層(Service Bus)

| # | 指摘 | リスク | 推奨対策 |
|---|---|---|---|
| 9 | 「環境の送信IPのみ許可」は送信IPの安定が前提 | IP変動でファイアウォールが形骸化 or 障害化 | NAT Gatewayを付けて固定送信IP化 |
| 10 | メッセージ本文の内容規定がない | DLQが「失敗データの保管庫」化し、テナントデータが滞留 | メッセージはdocument ID等の**参照のみ**・PII禁止を方針化。DLQの監視・掃除の運用を定義 |

### データ層(Blob / PostgreSQL / Document Intelligence)

| # | 指摘 | リスク | 推奨対策 |
|---|---|---|---|
| 11 | **RLSはテーブル所有者にデフォルトで効かない** | マイグレーションロール=アプリ接続ロールだとRLSが素通しになる、プールモデルの定番の落とし穴 | 所有者ロールとアプリ接続ロールを分離+`FORCE ROW LEVEL SECURITY`。テナントコンテキスト(`set_config`)をコネクション取得時に強制設定するミドルウェア層 |
| 12 | Blobのテナント分離はアプリロジック頼み | API/ワーカーのMIは全テナントのコンテナにアクセス可能。アプリのバグ一つで越境 | 強制層がない事実を明示し、コンテナ名導出を単一コード経路に集約+テナント越境の自動テストを補償策とする |
| 13 | 日次削除ジョブの誤爆対策がない | バグ時の大量削除 | Blob**ソフト削除+バージョニング**を有効化(安価な安全網) |
| 14 | DIのデータ保持仕様 | DIは解析データを最大24時間サービス側に保持 | 顧客向けデータ取り扱い説明に記載 |

### 横断(監視・検知)— 最大のギャップ

監査ログへの言及が「共有URLのアクセスログ」のみ。SaaSとしてテナントへの説明責任の面でも不足。

- **Log Analytics集約**: APIM診断ログ(認証失敗・429)/ Container Appsログ / PostgreSQL(pgaudit)/ Blobアクセスログ / Entra External IDサインインログ
- **アラート**: 認証失敗の急増 / 共有トークン検証失敗の連続 / DLQ滞留 / Service Busファイアウォール拒否
- **Defender for Cloud**(Storage / Containers / OSS DB)の採否をコスト込みで判断

## 理想形構成(コスト度外視・全指摘反映)

### 構成図

```mermaid
flowchart LR
    subgraph clients["利用者"]
        browser["ブラウザ<br>(一般ユーザ / システム管理者)"]
        internal["テナント社内システム<br>(バッチ連携)"]
        guest["共有URL受領者"]
    end

    afd["Front Door Premium + WAF<br>OWASPマネージドルール / ボット対策<br>エッジレート制限 / DDoS緩和"]

    subgraph azure["Azure"]
        entra["Entra External ID<br>(認証・JWT発行)<br>複数issuerのクレーム信頼境界を定義"]
        swa["Static Web Apps<br>(Front Door経由のみ受信)"]
        apim["API Management (Standard v2)<br>受信: Front Doorのみ(X-Azure-FDID検証)<br>【ポリシー】validate-jwt(署名/issuer/aud) /<br>X-Tenant-Id 強制削除→JWT・サブスクキーから再設定 /<br>サブスクキーはヘッダのみ / ボディサイズ上限 / レート制限"]

        subgraph vnet["仮想ネットワーク (VNet) — 全サブネットにNSG"]
            subgraph aca["Container Apps 環境 (internal ingress)<br>受信NSG: APIM統合サブネットのみ許可"]
                api["API (FastAPI)<br>JWT再検証(多層防御)<br>アップロード検証(マジックバイト/サイズ)"]
                worker["ワーカー<br>最小1レプリカ / KEDA 1→N"]
            end
            natgw["NAT Gateway<br>(固定送信IP)"]
            di["Document Intelligence<br>【PE】パブリック無効"]
            blob["Blob Storage (ZRS)<br>テナント別コンテナ<br>ソフト削除+バージョニング(削除ジョブ誤爆対策)<br>【PE】パブリック無効"]
            pg["PostgreSQL Flexible Server<br>プールモデル + FORCE RLS<br>所有者ロール/アプリロール分離<br>pgaudit有効 / PITR<br>【PE】パブリック無効"]
            acr["Container Registry (Premium)<br>MI pull / イメージ脆弱性スキャン<br>【PE】パブリック無効"]
            kv["Key Vault<br>残余シークレット用<br>【PE】パブリック無効"]
        end

        sb["Service Bus (Standard)<br>interactive / batch キュー<br>MI認証(SAS無効) + IPファイアウォール<br>(NAT GWの固定IPのみ許可)<br>メッセージはID参照のみ・PII禁止"]
    end

    subgraph ops["監視・検知"]
        law["Log Analytics<br>APIM診断 / ACAログ / pgaudit /<br>Blobアクセスログ / サインインログ"]
        defender["Defender for Cloud<br>Storage(マルウェアスキャン) /<br>Containers / OSS DB"]
        alerts["アラート<br>認証失敗急増 / 共有トークン検証失敗連続 /<br>DLQ滞留 / SBファイアウォール拒否"]
    end

    browser -->|"静的コンテンツ"| afd
    browser -->|"認証 (PKCE)"| entra
    browser -->|"API (JWT)"| afd
    internal -->|"バッチAPI (サブスクキー)"| afd
    guest -->|"トークン付き共有URL<br>(検証失敗レート制限)"| afd
    afd --> swa
    afd --> apim
    apim -->|"アウトバウンドVNet統合"| api
    api -->|"ジョブ投入"| sb
    sb -->|"KEDAスケール / 消化"| worker
    worker -->|"解析実行"| di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
    aca -->|"固定送信IP"| natgw --> sb
    aca -.->|"イメージpull (PE)"| acr
    azure -.-> law
    law --> alerts
```

### 現行案からの構造的変更点

1. **Front Door Premium + WAF** を全公開トラフィックの前段に配置。APIMは`X-Azure-FDID`ヘッダ検証でFront Door以外からの直接アクセスを拒否(SWAも同様にFront Door経由に限定)
2. **APIMポリシーの明文化**: `validate-jwt`、`X-Tenant-Id`の削除→サーバ側再設定、キーのヘッダ限定、ボディサイズ上限
3. **NAT Gateway** で送信IPを固定し、Service BusのIPファイアウォールを形骸化させない
4. **ACR Premium(PE)+ Key Vault(PE)** をVNet内に追加、全サブネットにNSG
5. **監視・検知スタック**(Log Analytics + Defender for Cloud + アラート)を明示

サブネットは既存3つのまま。snet-peにACR/KVのPEを追加し、NAT GWはsnet-acaに関連付ける。

### コスト試算(月額・USD概算、2026-07時点)

> 東日本リージョン・小規模本番想定の概算。確定前に料金計算ツールでの再確認が必要。

**ベースライン(現行案から不変)**

| リソース | 月額目安 |
|---|---|
| APIM Standard v2 | ~$690 |
| Container Apps(消費・最小1レプリカ常駐) | $50〜150 |
| PostgreSQL Burstable (B2s) | $50〜70 |
| Blob Storage (ZRS) | $10〜30 |
| Service Bus Standard | ~$10 |
| Static Web Apps Standard | $9 |
| Private Endpoint ×3 (PG/Blob/DI) | ~$22 |
| Document Intelligence S0 | 従量(解析量次第) |
| **小計** | **~$850〜980 + DI従量** |

**理想形での追加分**

| 追加リソース | 月額目安 | 対応する指摘 |
|---|---|---|
| Front Door Premium(基本料+WAFポリシー込) | ~$330〜380 | #4 WAF不在・DDoS |
| ACR Premium + PE | ~$57 | #7 イメージ供給網 |
| NAT Gateway(基本料+処理量) | ~$35〜45 | #9 送信IP固定 |
| Key Vault + PE | ~$8 | 残余シークレット管理 |
| Log Analytics(~5〜15GB/月想定) | $15〜45 | 横断: 監視・監査 |
| Defender for Storage(+マルウェアスキャン従量) | $10〜30 | #8 アップロード検疫 |
| Defender for Containers | ~$15 | #7 イメージ/ランタイム検知 |
| Defender for OSS DB | ~$15〜30 | 横断: DB脅威検知 |
| NSG / Blobソフト削除 / pgaudit / APIMポリシー | ほぼ$0 | #1,2,3,5,6,10,11,13 |
| **差分小計** | **~$490〜610** | |

**理想形合計: 月額 ~$1,350〜1,600 + 従量(DI・転送量)** — 現行案比 約1.5倍

### 図に表れない設計事項(理想形に含まれる前提)

- 共有トークン: 128bit以上のエントロピー、DBにはハッシュで保存、定数時間比較
- サブスクリプションキー: 2キーローテーション手順の文書化
- RLS: コネクション取得時にテナントコンテキストを強制設定するミドルウェア層
- Blobテナント越境の自動テスト(コンテナ名導出の単一コード経路化)
- DIの24時間データ保持仕様を顧客向け説明に記載

## 理想形からのダウングレード選択肢

コスト差分の6割超がFront Door Premium。判断の分岐点は主にここ。

| 対象 | 理想形 | ダウングレード案 | 月額削減 | 失うもの(トレードオフ) |
|---|---|---|---|---|
| WAF/エッジ | Front Door Premium | **Front Door Standard** | 約$300 | OWASPマネージドルールとボット対策(Premium専用)。カスタムWAFルール・レート制限・ジオフィルタは残るため「WAFなし」よりは大幅に良い |
| WAF/エッジ | Front Door Premium | **Front Door自体を見送り** | 約$330〜380 | WAF層が消滅。APIMのレート制限+サイズ上限のみで公開APIを防御。DDoSはAzure基盤レベルの緩和のみ。アップロード受付SaaSとしてはリスク受容の明文化が必須 |
| レジストリ | ACR Premium(PE) | **ACR Standard(パブリック+MI認証)** | 約$37 | イメージpullがパブリック経路になる(認証はMIで維持)。PE・ゾーン冗長を失う。スキャンはCI側(Trivy等)で代替可能 |
| 検疫 | Defender for Storage | **アプリ側検証のみ**(マジックバイト/サイズ) | $10〜30 | マルウェア検知がなくなる。共有URL経由で第三者がファイルをダウンロードする本サービスの性質上、配布元責任のリスクは残る |
| 脅威検知 | Defender for Containers / OSS DB | **段階導入(ローンチ後に追加)** | $30〜45 | ランタイム脅威検知の空白期間。後付けが容易なため時期の問題に整理できる |
| ログ | Log Analytics フル収集 | **収集対象の絞り込み**(APIM診断+サインインログ優先) | $10〜30 | pgaudit/Blobログの遡及調査ができない。インシデント時の原因究明力が低下 |
| シークレット | Key Vault(PE) | **見送り**(MI統一で残余シークレットが実質ない場合) | 約$8 | 将来シークレットが発生した際の置き場がなく、環境変数直書きへ逃げる誘惑が生まれる |

### 削るべきでないもの

以下は合計~$60程度と安価なのに指摘の大半をカバーするため、ダウングレード対象にしない:

- APIMポリシー群(validate-jwt / X-Tenant-Id再設定 / サイズ上限)— #1, #2, #4の一部
- NSG — #6
- NAT Gateway — #9(これを削るならService BusのIPファイアウォール自体が成立しない)
- Blobソフト削除 — #13
- RLSロール分離+FORCE RLS — #11
- Log Analyticsの最小構成 — 検知ゼロの状態を避ける
