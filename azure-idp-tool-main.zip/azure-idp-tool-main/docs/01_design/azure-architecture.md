# Azureアーキテクチャ

> **API Managementは採用しない**(2026-08の社内レビューで決定)。公開接点は Application Gateway v2 + WAF_v2 とし、JWT検証とテナント解決はAPI本体が担う。判断の根拠・責務の再配置・失うものは [azure-architecture_v2.md §2.1](azure-architecture_v2.md#21-api-management-を採用しない判断) を参照。
>
> 本書は**現行構成の各論**(構成要素・サブネット・Private DNS・リクエストの流れ)を扱う。セキュリティ観点の網羅・理想形・フェーズ別構成・コスト試算は [azure-architecture_v2.md](azure-architecture_v2.md) が一次情報。

## 構成図

```mermaid
flowchart LR
    subgraph clients["利用者"]
        browser["ブラウザ<br>(一般ユーザ / システム管理者)"]
        internal["テナント社内システム<br>(バッチ連携)"]
        guest["共有URL受領者"]
    end

    subgraph azure["Azure"]
        swa["Static Web Apps<br>(Vue.js フロントエンド配信)<br>AppGWのバックエンド"]

        subgraph vnet["仮想ネットワーク (VNet)"]
            agw["Application Gateway v2 + WAF_v2<br>唯一の公開接点<br>OWASP CRS / レート制限 /<br>X-Tenant-Id 削除 / Keycloak管理パス遮断<br>/api→API /realms・/resources→Keycloak 既定→SWA"]

            subgraph aca["Container Apps 環境 (internal ingress)"]
                api["API<br>(FastAPI)"]
                worker["ワーカー<br>(同一イメージ・起動コマンド違い)<br>最小1レプリカ / KEDAで1→N"]
                keycloak["Keycloak<br>(認証・JWT発行)<br>最小1レプリカ"]
            end
            di["Document Intelligence<br>prebuilt-layout + Query Fields<br>【Private Endpoint】"]
            blob["Blob Storage (ZRS)<br>テナントごとにコンテナ分離<br>【Private Endpoint】"]
            pg["PostgreSQL Flexible Server<br>プールモデル + RLS / PITR<br>【Private Endpoint】"]
        end

        sb["Service Bus (Standard)<br>interactive キュー(優先)/ batch キュー<br>Managed Identity + IPファイアウォール<br>(PEはPremium専用のため対象外)"]
    end

    browser -->|"静的コンテンツ"| agw
    agw -->|"既定ルート"| swa
    browser -->|"認証 (AppGW経由)"| agw
    browser -->|"API (JWT)"| agw
    internal -->|"バッチAPI (OAuth2 CCの短命JWT)"| agw
    guest -->|"トークン付き共有URL"| agw
    agw -->|"VNet内プライベート転送"| api
    agw -->|"VNet内プライベート転送<br>(認証エンドポイント)"| keycloak
    keycloak --> pg
    api -->|"ジョブ投入"| sb
    sb -->|"KEDAスケール / 消化"| worker
    worker -->|"解析実行 (LROポーリング)"| di
    api --> blob
    api --> pg
    worker --> blob
    worker --> pg
```

## 構成要素と役割

| リソース | ティア/構成 | 役割・設計上のポイント |
|---|---|---|
| Static Web Apps | Free〜Standard | Vueフロントエンドの配信。Application Gatewayのバックエンドプールに載せ、SPAとAPIを同一オリジンにする(CORS不要。azure-architecture_v2.md §1.2 #8) |
| Keycloak (Container Apps) | 最小1レプリカ・OSS(ライセンス費用なし) | 認証・JWT発行。Keycloakローカルアカウント+顧客IdP(Entra ID等)とのフェデレーション(Identity Brokering)。テナント判別はJWTクレーム。ストアはPostgreSQL Flexible Server上の専用データベース。マネージドIdPと違いバージョン追随・バックアップ・可用性は自社責任 |
| Application Gateway | **WAF_v2**(専用サブネット `snet-appgw`) | **唯一の公開接点**。VNet内に配置しContainer Apps(internal ingress)へプライベート転送。OWASP CRSマネージドルール(Preventionモード)、送信元IP単位のレート制限、`fileUploadLimitInMb`によるサイズ上限、受信`X-Tenant-Id`のヘッダ削除、Keycloak管理パス(`/admin/master`・`/admin/realms`・`/realms/master`)の遮断。**API Managementは固定費(~$690/月)が見合わないため不採用**([v2 §2.1](azure-architecture_v2.md#21-api-management-を採用しない判断)) |
| Container Apps (API) | 消費プラン・**internal ingress** | FastAPI。VNet内に配置しApplication Gateway経由でのみ到達可能。**JWT検証とテナント解決の唯一の強制点**(エッジ側にJWT検証層はない)。アップロード受付・オーバレイ用データ提供・確定処理・共有URL検証 |
| Container Apps (ワーカー) | 最小1レプリカ | APIと同一イメージ。interactiveキュー優先消化。DIのTPS上限は同時実行数で一元制御。Jobsはコールドスタートのため不採用 |
| Service Bus | **Standard** | `interactive` / `batch` の優先度別2キュー。DLQ標準。Managed Identity認証(SASキー無効化)+IPファイアウォール。Private EndpointはPremium専用(月$680〜)で過剰なため不採用 |
| Document Intelligence | S0(従量)・**Private Endpoint** | prebuilt-layout + Query Fields(全書類に同梱)。パブリックアクセス無効 |
| Blob Storage | ZRS・**Private Endpoint** | テナントごとにコンテナ分離。原本PDF・ページPNG・DI解析結果の生JSONを保存。保持期間超過分はワーカーの日次ジョブで自動削除(ライフサイクル管理は「転記完了からN日」というテナント可変条件を表現できないため主手段にしない)。パブリックアクセス無効 |
| PostgreSQL Flexible Server | Burstable〜・**Private Endpoint** | プールモデル + Row-Level Security。PITRによるバックアップ。パブリックアクセス無効 |

## ネットワーク設計

- **公開されるのはApplication Gatewayのフロントエンドのみ**(静的コンテンツもAppGW経由で配信する)。SaaSの性質上、利用者はインターネット越しに来るためAppGWの受信は公開が正であり、TLS+WAF+認証(JWT/共有トークン)+レート制限で防御する
  - SWA自身の既定ホスト名はPrivate Endpoint化するまで公開のまま残る。載るのはテナントデータを含まない静的アセットのみのため段階導入とする
- バックエンドはすべてVNet内またはプライベートアクセス限定
  - Container Apps環境: VNet内・internal ingress。到達経路はApplication Gateway(`snet-appgw`)からのVNet内転送のみ
  - PostgreSQL / Blob / Document Intelligence: Private Endpoint(各 月$7〜8)+パブリックアクセス無効。名前解決はPrivate DNSゾーン
  - Service Bus: Private Endpoint不可(Premium専用)のため例外的にパブリックエンドポイントを維持し、Managed Identity認証+IPファイアウォール(Container Apps環境の送信IPのみ許可)で防御
- Azureリソース間の認証はManaged Identityに統一し、接続文字列・アクセスキーの保持を廃止する(PostgreSQLはEntra ID認証)

### VNet・サブネット / Private Endpoint 構成図

```mermaid
flowchart TB
    internet["インターネット"]

    subgraph vnet["VNet 10.0.0.0/16(アドレスは例)"]
        subgraph snet_agw["snet-appgw 10.0.0.0/24(委任なし)<br>Application Gateway専用サブネット"]
            agw["Application Gateway WAF_v2<br>受信: パブリック(唯一の公開接点)<br>Public IP (Standard/Static)"]
        end
        subgraph snet_aca["snet-aca 10.0.1.0/27<br>委任: Microsoft.App/environments"]
            aca_env["Container Apps環境<br>(internal ingress)<br>API / ワーカー"]
        end
        subgraph snet_pe["snet-pe 10.0.2.0/27(委任なし)"]
            pe_pg["Private Endpoint<br>(PostgreSQL)"]
            pe_blob["Private Endpoint<br>(Blob)"]
            pe_di["Private Endpoint<br>(Document Intelligence)"]
        end
    end

    pg["PostgreSQL Flexible Server<br>パブリックアクセス無効"]
    blob["Blob Storage<br>パブリックアクセス無効"]
    di["Document Intelligence<br>パブリックアクセス無効"]
    sb["Service Bus (Standard)<br>パブリックエンドポイント維持<br>IPファイアウォール + Managed Identity"]

    internet --> agw
    agw -->|"Private DNSで名前解決"| aca_env
    aca_env --> pe_pg --> pg
    aca_env --> pe_blob --> blob
    aca_env --> pe_di --> di
    aca_env -.->|"環境の送信IPのみ許可"| sb
```

### サブネット設計

| サブネット | CIDR(例) | 委任 | 用途 |
|---|---|---|---|
| snet-appgw | 10.0.0.0/24 | なし | **Application Gateway専用**(他リソースと共有不可)。v2は最小/24が推奨。NSGはGatewayManagerからの受信(65200-65535)とAzure Load Balancerを許可する必要がある |
| snet-aca | 10.0.1.0/27 | `Microsoft.App/environments` | Container Apps環境(ワークロードプロファイル型・internal ingress)。消費専用(レガシー)環境にする場合は/23以上が必要 |
| snet-pe | 10.0.2.0/27 | なし | Private Endpoint集約用(PostgreSQL / Blob / DI) |

### Private DNSゾーン

Private Endpointおよびinternal環境の名前解決のため、以下のPrivate DNSゾーンを作成しVNetにリンクする。

| ゾーン | 対象 |
|---|---|
| `privatelink.postgres.database.azure.com` | PostgreSQL Flexible ServerのPE |
| `privatelink.blob.core.windows.net` | Blob StorageのPE |
| `privatelink.cognitiveservices.azure.com` | Document IntelligenceのPE |
| Container Apps環境の既定ドメインゾーン(`<環境固有>.<リージョン>.azurecontainerapps.io`) | Application Gatewayのバックエンドプールからinternal環境のFQDNを解決するために必要(環境作成後に払い出されるドメインでゾーンを作成) |

## リクエストの流れ

### 1. フロントエンドからの解析(interactive・優先)

1. ブラウザ → Application Gateway → API: PDFアップロード(書類種別を指定)
2. API: Blobへ原本保存、`documents`レコード作成(`uploaded`)、ファイルハッシュ重複検知
3. API → Service Bus `interactive`キューへジョブ投入
4. ワーカー: Layout + Query FieldsでDI解析 → 結果保存(`analyzed`)、Query Fields結果をヘッダ項目の初期候補として取り込み
5. ブラウザ: 処理状態をポーリングし、完了後オーバレイ表示

### 2. バッチ連携

1. 社内システム → Keycloak: OAuth2クライアントクレデンシャルで短命トークンを取得
2. 社内システム → Application Gateway(`Authorization: Bearer`)→ API: PDF一括アップロード(書類種別コードをパラメータ指定)。APIがJWTを検証し、クレームからテナントを解決する
3. `batch`キュー経由で同一パイプラインを実行(interactiveが常に優先)
4. 社内システムは一覧・処理状況APIをポーリング

### 3. 共有URL

1. 業務システムがバッチAPI(OAuth2 CCのトークン)で共有URL発行 → アプリ発行のランダムトークン(有効期限付き・失効可能)
2. 受領者はトークン付きURLでアクセス → APIがトークン検証 → ページ画像閲覧・原本ダウンロードを配信
3. アクセスは利用ログに記録(Blob SAS直接配布はログ・失効の観点で不採用)

## 可用性・データ保護

- 単一リージョン構成(マルチリージョンDRは明示的に見送り)
- PostgreSQL: PITR / Blob: ZRS
- 稼働率目標は本番から99.5%(SLA直列合成の理論値 約99.7%)

## IaC

- Bicepで全リソースを定義(`infra/`)
- モジュール分割: ネットワーク(VNet・サブネット・NSG・NAT GW・Private DNS)/ データ(PostgreSQL・Blob・Service Bus・Private Endpoint)/ AI(Document Intelligence)/ コンピュート(Managed Identity・ACR・Container Apps・Static Web Apps・ロール割り当て)/ Application Gateway + WAF / 監視(Log Analytics)

---

## セキュリティ観点・理想形・フェーズ別構成

以前は本書の後半にセキュリティレビュー(層別の観点)・理想形構成・ダウングレード選択肢を併記していたが、
[azure-architecture_v2.md](azure-architecture_v2.md) と内容が重複し、APIM除外の反映で両者が食い違う状態になった。
**これらの一次情報は v2 に集約する**:

| 内容 | 参照先 |
|---|---|
| 理想形構成(構成図・設計の要点) | [v2 §1](azure-architecture_v2.md#1-理想形構成コスト度外視) |
| コスト試算 | [v2 §1.3](azure-architecture_v2.md#13-コスト試算) |
| API Managementを採用しない判断と責務の再配置 | [v2 §2.1](azure-architecture_v2.md#21-api-management-を採用しない判断) |
| ダウングレード選択肢 / 削るべきでないもの | [v2 §2.2](azure-architecture_v2.md#22-理想形からのダウングレード選択肢) |
| 各層のセキュリティ観点(公開層・アプリ層・非同期層・データ層・監視) | [v2 §3](azure-architecture_v2.md#3-各層のセキュリティ観点) |
| フェーズ別構成(初期 / PoC / リリース)と移行のゲート条件 | [v2 §4](azure-architecture_v2.md#4-フェーズ別構成草案) |

削除前の記述は Git履歴(`git log -- docs/01_design/azure-architecture.md`)から辿れる。
