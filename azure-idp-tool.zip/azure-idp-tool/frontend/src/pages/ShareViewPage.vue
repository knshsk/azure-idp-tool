<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'

import { getShareMeta, shareDownloadUrl, sharePageImageUrl, type ShareMeta } from '@/api/share'

const route = useRoute()
const token = route.params.token as string

const meta = ref<ShareMeta | null>(null)
const invalid = ref(false)
const loading = ref(true)
const currentPage = ref(1)

onMounted(async () => {
  try {
    meta.value = await getShareMeta(token)
  } catch {
    // 不存在・失効・期限切れを区別しない(存在有無を推測させない)
    invalid.value = true
  } finally {
    loading.value = false
  }
})

const pageCount = computed(() => meta.value?.page_count ?? 0)

function formatExpiry(iso: string): string {
  return new Date(iso).toLocaleString('ja-JP', { dateStyle: 'medium', timeStyle: 'short' })
}
</script>

<template>
  <div class="share-view">
    <v-app-bar color="primary" density="comfortable">
      <v-app-bar-title class="flex-0-0 mr-6">取引書類読み取りツール</v-app-bar-title>
      <template v-if="meta">
        <span class="text-body-1">{{ meta.file_name }}</span>
        <v-spacer />
        <v-btn
          :href="shareDownloadUrl(token)"
          prepend-icon="mdi-download"
          variant="tonal"
          color="white"
        >
          原本ダウンロード
        </v-btn>
      </template>
    </v-app-bar>

    <v-main>
      <v-container class="d-flex flex-column align-center">
        <v-progress-circular v-if="loading" indeterminate size="48" class="mt-12" />

        <!-- 無効なURL: 専用エラー表示のみ -->
        <v-card v-else-if="invalid" class="pa-12 mt-12 text-center" max-width="480">
          <v-icon icon="mdi-link-off" size="48" class="mb-4 text-medium-emphasis" />
          <div class="text-h6">このURLは無効です</div>
        </v-card>

        <template v-else-if="meta">
          <v-card v-if="pageCount > 0" class="page-card" elevation="2">
            <img
              :src="sharePageImageUrl(token, currentPage)"
              :alt="`ページ ${currentPage}`"
              class="page-image"
            />
          </v-card>
          <div v-else class="text-medium-emphasis mt-12">表示できるページがありません</div>

          <div v-if="pageCount >= 1" class="d-flex align-center ga-2 my-3">
            <v-btn
              icon="mdi-chevron-left"
              size="small"
              variant="text"
              :disabled="currentPage <= 1"
              @click="currentPage -= 1"
            />
            <span>ページ {{ currentPage }} / {{ pageCount }}</span>
            <v-btn
              icon="mdi-chevron-right"
              size="small"
              variant="text"
              :disabled="currentPage >= pageCount"
              @click="currentPage += 1"
            />
          </div>

          <div class="text-caption text-medium-emphasis mb-6">
            この共有URLの有効期限: {{ formatExpiry(meta.expires_at) }}
          </div>
        </template>
      </v-container>
    </v-main>
  </div>
</template>

<style scoped>
.page-card {
  max-width: 900px;
  width: 100%;
}

.page-image {
  width: 100%;
  display: block;
}
</style>
