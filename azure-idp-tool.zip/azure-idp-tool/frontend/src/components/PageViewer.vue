<script setup lang="ts">
import { computed } from 'vue'

import type { Bbox } from '@/api/types'
import { bboxToRect } from '@/utils/overlay'

export interface ViewerRect {
  id: string
  bbox: Bbox
  kind: 'field' | 'word' | 'table' | 'cell'
  selected?: boolean
  clickable?: boolean
}

const props = defineProps<{
  imageUrl: string
  widthPx: number
  heightPx: number
  rects: ViewerRect[]
}>()

const emit = defineEmits<{ rectClick: [id: string] }>()

const shapes = computed(() =>
  props.rects.map((r) => ({ ...r, rect: bboxToRect(r.bbox, props.widthPx, props.heightPx) })),
)
</script>

<template>
  <svg
    class="page-viewer"
    :viewBox="`0 0 ${props.widthPx} ${props.heightPx}`"
    preserveAspectRatio="xMidYMid meet"
  >
    <image :href="props.imageUrl" x="0" y="0" :width="props.widthPx" :height="props.heightPx" />
    <rect
      v-for="shape in shapes"
      :key="shape.id"
      :x="shape.rect.x"
      :y="shape.rect.y"
      :width="shape.rect.width"
      :height="shape.rect.height"
      :class="[
        'overlay-rect',
        `kind-${shape.kind}`,
        { selected: shape.selected, clickable: shape.clickable },
      ]"
      @click="shape.clickable && emit('rectClick', shape.id)"
    />
  </svg>
</template>

<style scoped>
.page-viewer {
  width: 100%;
  height: auto;
  display: block;
  border: 1px solid rgba(0, 0, 0, 0.12);
  background: #fff;
}

.overlay-rect {
  fill: transparent;
}

.kind-field {
  stroke: #1976d2;
  stroke-width: 3;
}

.kind-word {
  stroke: rgba(0, 0, 0, 0.3);
  stroke-width: 1;
}

.kind-table {
  stroke: #7b1fa2;
  stroke-width: 3;
  stroke-dasharray: 8 4;
}

.kind-cell {
  stroke: rgba(123, 31, 162, 0.4);
  stroke-width: 1;
}

.selected {
  fill: rgba(25, 118, 210, 0.15);
  stroke-width: 4;
}

.kind-table.selected {
  fill: rgba(123, 31, 162, 0.08);
  stroke-dasharray: none;
}

.clickable {
  cursor: pointer;
}
</style>
